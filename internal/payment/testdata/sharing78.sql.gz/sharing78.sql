--
-- PostgreSQL database dump
--

\restrict shSK4XrrvRXGSjF4a1VPno5Cui4VjXOEI5sKTHccS4By3eQFLf8TnBghQ92BvGG

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: member72_1c1acaaf36d7e39a; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA member72_1c1acaaf36d7e39a;


--
-- Name: alipay_bank_binding_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.alipay_bank_binding_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN IF (NEW.transfer_id,NEW.product_code,NEW.request_digest) IS DISTINCT FROM (OLD.transfer_id,OLD.product_code,OLD.request_digest) OR (OLD.submit_order_id<>'' AND NEW.submit_order_id<>OLD.submit_order_id) OR (OLD.submit_bound AND NOT NEW.submit_bound) THEN RAISE EXCEPTION 'immutable alipay bank recipient binding'; END IF; RETURN NEW; END $$;


--
-- Name: alipay_bank_binding_insert_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.alipay_bank_binding_insert_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN IF NOT EXISTS(SELECT 1 FROM bank_transfer_lifecycle b JOIN provider_transfer_policies p ON p.transfer_id=b.transfer_id WHERE b.transfer_id=NEW.transfer_id AND b.provider_kind='alipay_bankcard' AND p.request_hash=NEW.request_digest) THEN RAISE EXCEPTION 'alipay bank binding does not match original intent'; END IF; RETURN NEW; END $$;


--
-- Name: audit_operation_transition(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.audit_operation_transition() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE previous text; kind text;
BEGIN
 IF TG_OP='UPDATE' THEN
  previous:=OLD.status;
  IF NEW.status=OLD.status THEN RETURN NEW; END IF;
  IF OLD.status IN ('succeeded','failed') OR NEW.status='pending' THEN RAISE EXCEPTION 'terminal operation cannot transition'; END IF;
 END IF;
 kind:=CASE WHEN TG_TABLE_NAME='refunds' THEN 'refund' ELSE 'transfer' END;
 INSERT INTO operation_audit(operation_kind,operation_id,merchant_id,from_status,to_status) VALUES(kind,NEW.id,NEW.merchant_id,previous,NEW.status);
 RETURN NEW;
END $$;


--
-- Name: authorization_remaining_complete(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.authorization_remaining_complete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE oid bigint;
BEGIN
 oid:=NEW.order_id;
 IF NOT EXISTS(SELECT 1 FROM payment_authorization_releases r JOIN payment_authorizations a ON a.order_id=r.order_id WHERE r.order_id=oid
  AND (r.channel_id,r.auth_no,r.amount)=(a.channel_id,a.auth_no,a.amount) AND r.request_no='UA'||r.order_id::text
  AND ((r.remaining_source_revision=0 AND NOT EXISTS(SELECT 1 FROM authorization_remaining_sources s WHERE s.order_id=r.order_id) AND NOT EXISTS(SELECT 1 FROM authorization_remaining_claims c WHERE c.order_id=r.order_id))
   OR (r.remaining_source_revision>0 AND (SELECT count(*) FROM authorization_remaining_sources s WHERE s.order_id=r.order_id)=r.remaining_source_revision
    AND EXISTS(SELECT 1 FROM authorization_remaining_sources s WHERE (s.id,s.order_id,s.revision,s.proof_hash)=(r.remaining_source_id,r.order_id,r.remaining_source_revision,r.remaining_source_hash))
    AND ((NOT r.sent AND NOT EXISTS(SELECT 1 FROM authorization_remaining_claims c WHERE c.order_id=r.order_id)) OR
     (r.sent AND EXISTS(SELECT 1 FROM authorization_remaining_claims c WHERE (c.order_id,c.source_id,c.source_revision)=(r.order_id,r.remaining_source_id,r.remaining_source_revision)))))))
 THEN RAISE EXCEPTION 'incomplete original authorization remaining source';END IF;
 RETURN NULL;
END $$;


--
-- Name: bank_provider_kind_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.bank_provider_kind_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN IF NEW.provider_kind<>OLD.provider_kind THEN RAISE EXCEPTION 'immutable bank transfer provider'; END IF; RETURN NEW; END $$;


--
-- Name: bank_transfer_lifecycle_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.bank_transfer_lifecycle_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NEW.transfer_id<>OLD.transfer_id OR (OLD.bank_fee_amount IS NOT NULL AND NEW.bank_fee_amount IS DISTINCT FROM OLD.bank_fee_amount) OR (OLD.settled AND NOT NEW.settled) OR (OLD.return_observed AND NOT NEW.return_observed) THEN RAISE EXCEPTION 'immutable bank transfer fee and identity'; END IF;
 IF OLD.state IN ('reversed','failed') AND (NEW.state,NEW.settled,NEW.service_fee_held,NEW.returned_principal,NEW.returned_service_fee,NEW.returned_bank_fee) IS DISTINCT FROM (OLD.state,OLD.settled,OLD.service_fee_held,OLD.returned_principal,OLD.returned_service_fee,OLD.returned_bank_fee) THEN RAISE EXCEPTION 'immutable final bank return'; END IF;
 RETURN NEW;
END $$;


--
-- Name: bank_unsent_cancel_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.bank_unsent_cancel_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF OLD.state='cancelled' AND NEW IS DISTINCT FROM OLD THEN RAISE EXCEPTION 'immutable platform unsent cancellation'; END IF;
 IF NEW.state='cancelled'
 AND NOT EXISTS(SELECT 1 FROM transfer_unsent_cancellations c JOIN transfer_batch_items i ON i.transfer_id=c.transfer_id WHERE c.transfer_id=NEW.transfer_id AND i.state='cancelled')
 AND NOT EXISTS(SELECT 1 FROM settlement_payout_cancellations c JOIN settlement_payouts p ON p.request_id=c.request_id AND p.transfer_id=c.transfer_id JOIN settlement_bank_payouts bp ON bp.request_id=p.request_id AND bp.transfer_id=p.transfer_id WHERE c.transfer_id=NEW.transfer_id AND p.send_state='cancelled' AND p.claimed_at IS NULL)
 THEN RAISE EXCEPTION 'bank cancellation requires durable unsent proof'; END IF;
 RETURN NEW;
END $$;


--
-- Name: batch_execution_binding_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.batch_execution_binding_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM transfer_batches b WHERE b.id=NEW.batch_id AND b.merchant_id=NEW.merchant_id)
 OR (SELECT count(DISTINCT v) FROM unnest(NEW.transfer_ids) v)<>cardinality(NEW.transfer_ids)
 OR (SELECT count(*) FROM transfer_batch_items i WHERE i.batch_id=NEW.batch_id AND i.transfer_id=ANY(NEW.transfer_ids) AND i.state='unsent')<>cardinality(NEW.transfer_ids)
 THEN RAISE EXCEPTION 'invalid authorized batch subset'; END IF;
 RETURN NEW;
END $$;


--
-- Name: batch_execution_claim_committed_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.batch_execution_claim_committed_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM transfer_batch_items WHERE transfer_id=NEW.transfer_id AND state='claimed')
 THEN RAISE EXCEPTION 'authorization claim without committed send barrier'; END IF;
 RETURN NULL;
END $$;


--
-- Name: batch_execution_claim_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.batch_execution_claim_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM transfer_batch_executions e JOIN transfer_batch_items i ON i.batch_id=e.batch_id
  WHERE e.execution_no=NEW.execution_no AND i.transfer_id=NEW.transfer_id AND i.transfer_id=ANY(e.transfer_ids) AND i.state='unsent')
 THEN RAISE EXCEPTION 'claim outside authorized batch subset'; END IF;
 RETURN NEW;
END $$;


--
-- Name: block_refund_while_income_held(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.block_refund_while_income_held() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
 PERFORM id FROM orders WHERE id=NEW.order_id FOR UPDATE;
 IF EXISTS(SELECT 1 FROM order_income_holds h WHERE h.order_id=NEW.order_id AND h.state='held' AND NOT EXISTS(SELECT 1 FROM order_income_hold_fundings f WHERE f.hold_id=h.id)) THEN RAISE EXCEPTION 'income_hold_source_unprepared';END IF;RETURN NEW;END $$;


--
-- Name: bump_admin_funds_epoch(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.bump_admin_funds_epoch() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NEW.password_hash IS DISTINCT FROM OLD.password_hash OR NEW.enabled IS DISTINCT FROM OLD.enabled OR NEW.credential_epoch>OLD.credential_epoch THEN
  NEW.credential_epoch:=OLD.credential_epoch+1;
 ELSE NEW.credential_epoch:=OLD.credential_epoch; END IF;
 NEW.updated_at:=clock_timestamp(); RETURN NEW;
END $$;


--
-- Name: bump_console_auth_version(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.bump_console_auth_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NEW.password_hash IS DISTINCT FROM OLD.password_hash OR NEW.subject_id IS DISTINCT FROM OLD.subject_id OR NEW.enabled IS DISTINCT FROM OLD.enabled OR NEW.admin_class IS DISTINCT FROM OLD.admin_class OR NEW.auth_version>OLD.auth_version THEN
  NEW.auth_version:=OLD.auth_version+1;
 ELSE NEW.auth_version:=OLD.auth_version; END IF;
 RETURN NEW;
END $$;


--
-- Name: channel_sharing_account_identity_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_account_identity_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF OLD.kind='channel_sharing_reserve' AND (TG_OP='DELETE' OR (NEW.owner_id,NEW.kind,NEW.scope_id) IS DISTINCT FROM (OLD.owner_id,OLD.kind,OLD.scope_id)) THEN RAISE EXCEPTION 'immutable sharing account identity'; END IF;
 RETURN CASE WHEN TG_OP='DELETE' THEN OLD ELSE NEW END;
END $$;


--
-- Name: channel_sharing_active_rule_receiver_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_active_rule_receiver_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF OLD.state='bound' AND NEW.state='unbinding' AND EXISTS(SELECT 1 FROM channel_sharing_rule_items i JOIN channel_sharing_rules r ON r.id=i.rule_id JOIN channel_sharing_rule_current c ON c.rule_id=r.id WHERE i.receiver_id=OLD.id AND r.enabled)
 THEN RAISE EXCEPTION 'receiver is used by an enabled sharing rule'; END IF;
 RETURN NEW;
END $$;


--
-- Name: channel_sharing_completion_finish_exclusion_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_completion_finish_exclusion_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 PERFORM id FROM orders WHERE id=NEW.order_id FOR UPDATE;
 IF EXISTS(SELECT 1 FROM channel_sharing_finishes WHERE order_id=NEW.order_id) THEN RAISE EXCEPTION 'independent finish excludes auto finish completion'; END IF;RETURN NEW;
END $$;


--
-- Name: channel_sharing_execution_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_execution_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE sid bigint; s channel_sharing_orders%ROWTYPE; d provider_attempt_sharing%ROWTYPE; cnt integer; total bigint; success integer; failed integer;
BEGIN
 IF TG_TABLE_NAME='channel_sharing_orders' THEN sid:=NEW.id; ELSE sid:=NEW.sharing_id; END IF;
 SELECT * INTO STRICT s FROM channel_sharing_orders WHERE id=sid;
 SELECT * INTO STRICT d FROM provider_attempt_sharing WHERE order_id=s.order_id;
 IF s.state='unsent' OR s.claimed_at IS NULL OR NOT EXISTS(SELECT 1 FROM backoffice_audit a WHERE a.resource='channel-sharing-orders' AND a.resource_id=s.id AND a.operation='submit' AND a.changes->>'state'='claimed' AND (a.actor_role,a.actor_id,a.actor_name)=(s.actor_role,s.actor_id,s.actor_name)) THEN RAISE EXCEPTION 'sharing intent lacks its original actor claim audit'; END IF;
 IF s.last_observation_id IS NULL AND s.state IN ('unknown','failed') AND NOT EXISTS(SELECT 1 FROM backoffice_audit a WHERE a.resource='channel-sharing-orders' AND a.resource_id=s.id AND a.operation='submit-result' AND a.changes->>'state'=s.state AND (a.actor_role,a.actor_id,a.actor_name)=(s.actor_role,s.actor_id,s.actor_name)) THEN RAISE EXCEPTION 'sharing outcome lacks its original actor result audit'; END IF;
 IF EXISTS(SELECT 1 FROM channel_sharing_observations v WHERE v.sharing_id=s.id AND NOT EXISTS(SELECT 1 FROM backoffice_audit a WHERE a.resource='channel-sharing-orders' AND a.resource_id=s.id AND a.operation=v.source||'-result' AND a.changes->>'state'=v.state AND (a.actor_role,a.actor_id,a.actor_name)=(v.actor_role,v.actor_id,v.actor_name))) THEN RAISE EXCEPTION 'sharing observation lacks its actual observer audit'; END IF;
 IF EXISTS(SELECT 1 FROM channel_sharing_completions WHERE sharing_id=s.id) AND NOT EXISTS(SELECT 1 FROM backoffice_audit a WHERE a.resource='channel-sharing-orders' AND a.resource_id=s.id AND a.operation='release-remainder' AND a.changes->>'state'='completed') THEN RAISE EXCEPTION 'sharing release lacks its actor audit'; END IF;
 IF d.provider='wxpay' AND s.last_observation_id IS NOT NULL AND length(s.provider_order_no)=0 THEN RAISE EXCEPTION 'wechat sharing observation requires its provider order number'; END IF;
 IF NOT d.declared OR s.merchant_id<>d.merchant_id OR NOT s.auto_finish OR NOT EXISTS(SELECT 1 FROM verified_payment_receipts p WHERE p.order_id=s.order_id AND p.channel_id=d.channel_id AND p.provider_trade_no=s.provider_trade_no) THEN RAISE EXCEPTION 'sharing operation lacks original paid declaration'; END IF;
 SELECT count(*),COALESCE(sum(amount),0),count(*) FILTER(WHERE state='succeeded'),count(*) FILTER(WHERE state='failed') INTO cnt,total,success,failed FROM channel_sharing_order_items WHERE sharing_id=s.id;
 IF cnt<>s.receiver_count OR cnt<>d.receiver_count OR total>d.merchant_net OR EXISTS(SELECT 1 FROM channel_sharing_order_items i LEFT JOIN provider_attempt_sharing_items p ON p.attempt_id=d.attempt_id AND p.receiver_id=i.receiver_id WHERE i.sharing_id=s.id AND (p.attempt_id IS NULL OR p.amount<>i.amount)) THEN RAISE EXCEPTION 'sharing operation changed original recipient terms'; END IF;
 IF s.completed AND (success+failed<>cnt OR s.state<>CASE WHEN failed=0 THEN 'succeeded' WHEN success=0 THEN 'failed' ELSE 'partial' END) THEN RAISE EXCEPTION 'sharing completion requires all recipient outcomes'; END IF;
 IF NOT EXISTS(SELECT 1 FROM channel_sharing_funding_invariants WHERE order_id=s.order_id AND valid IS TRUE) THEN RAISE EXCEPTION 'invalid original sharing funding'; END IF;
 RETURN NULL;
END $$;


--
-- Name: channel_sharing_finish_complete_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_finish_complete_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE fid bigint; oid bigint;
BEGIN
 IF TG_TABLE_NAME='channel_sharing_finishes' THEN fid:=NEW.id; ELSE fid:=NEW.finish_id; END IF;
 SELECT order_id INTO oid FROM channel_sharing_finishes WHERE id=fid;
 IF NOT EXISTS(SELECT 1 FROM channel_sharing_finish_invariants WHERE finish_id=fid AND valid IS TRUE) OR NOT EXISTS(SELECT 1 FROM channel_sharing_funding_invariants WHERE order_id=oid AND valid IS TRUE) THEN RAISE EXCEPTION 'finish lacks its original payment, result, funding or actor proof'; END IF;RETURN NULL;
END $$;


--
-- Name: channel_sharing_finish_identity_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_finish_identity_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE d provider_attempt_sharing%ROWTYPE; p channel_sharing_orders%ROWTYPE;
BEGIN
 PERFORM id FROM orders WHERE id=NEW.order_id FOR UPDATE;
 IF TG_OP='INSERT' THEN
  SELECT * INTO STRICT d FROM provider_attempt_sharing WHERE order_id=NEW.order_id;
  SELECT * INTO p FROM channel_sharing_orders WHERE order_id=NEW.order_id;
  IF EXISTS(SELECT 1 FROM channel_sharing_finishes x WHERE x.order_id=NEW.order_id AND x.state<>'failed') OR NEW.previous_finish_id IS DISTINCT FROM (SELECT max(x.id) FROM channel_sharing_finishes x WHERE x.order_id=NEW.order_id) OR NEW.state<>'unsent' OR NOT d.declared OR d.purpose<>'payment' OR d.product<>'wxpay_v3_direct' OR
   (NEW.merchant_id,NEW.gross_amount,NEW.merchant_net) IS DISTINCT FROM (d.merchant_id,d.gross_amount,d.merchant_net) OR
   NOT EXISTS(SELECT 1 FROM verified_payment_receipts r WHERE r.order_id=NEW.order_id AND r.channel_id=d.channel_id AND r.provider_trade_no=NEW.provider_trade_no) OR
   EXISTS(SELECT 1 FROM recharge_intents WHERE order_id=NEW.order_id) OR
   p.id IS NOT NULL AND (p.id IS DISTINCT FROM NEW.original_sharing_id OR p.state<>'failed' OR p.completed OR p.last_observation_id IS NOT NULL OR p.failure_proof IS NULL) OR
   p.id IS NULL AND NEW.original_sharing_id IS NOT NULL OR
   EXISTS(SELECT 1 FROM channel_sharing_completions WHERE order_id=NEW.order_id)
  THEN RAISE EXCEPTION 'finish requires an unspent declared original payment or proved unaccepted PS'; END IF;
 ELSE
  IF (NEW.id,NEW.order_id,NEW.merchant_id,NEW.external_no,NEW.out_no,NEW.provider_trade_no,NEW.gross_amount,NEW.merchant_net,NEW.shared_amount,NEW.expected_unsplit,NEW.release_amount,NEW.original_sharing_id,NEW.previous_finish_id,NEW.request_hash,NEW.actor_role,NEW.actor_id,NEW.actor_name,NEW.actor_class,NEW.created_at)
    IS DISTINCT FROM (OLD.id,OLD.order_id,OLD.merchant_id,OLD.external_no,OLD.out_no,OLD.provider_trade_no,OLD.gross_amount,OLD.merchant_net,OLD.shared_amount,OLD.expected_unsplit,OLD.release_amount,OLD.original_sharing_id,OLD.previous_finish_id,OLD.request_hash,OLD.actor_role,OLD.actor_id,OLD.actor_name,OLD.actor_class,OLD.created_at)
   OR OLD.state IN ('succeeded','failed') AND NEW IS DISTINCT FROM OLD OR OLD.claimed_at IS NOT NULL AND NEW.claimed_at IS DISTINCT FROM OLD.claimed_at OR OLD.provider_order_no<>'' AND NEW.provider_order_no<>OLD.provider_order_no
  THEN RAISE EXCEPTION 'immutable original finish request or terminal result'; END IF;
  IF OLD.state='unsent' AND NEW.state<>'claimed' OR OLD.state<>'unsent' AND NEW.state IN ('unsent','claimed') AND NEW IS DISTINCT FROM OLD THEN RAISE EXCEPTION 'finish cannot be rearmed'; END IF;
 END IF;
 RETURN NEW;
END $$;


--
-- Name: channel_sharing_funding_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_funding_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE oid bigint;
BEGIN
 IF TG_TABLE_NAME='accounts' THEN IF NEW.kind<>'channel_sharing_reserve' THEN RETURN NULL; END IF;oid:=NEW.scope_id;
 ELSIF TG_TABLE_NAME='ledger_entries' THEN SELECT scope_id INTO oid FROM accounts WHERE id=NEW.account_id AND kind='channel_sharing_reserve';IF oid IS NULL THEN RETURN NULL;END IF;
 ELSIF TG_TABLE_NAME='orders' THEN
  oid:=NEW.id;
  IF NEW.status<>'paid' OR NOT EXISTS(SELECT 1 FROM provider_attempt_sharing WHERE order_id=oid AND declared) THEN RETURN NULL; END IF;
 ELSE oid:=NEW.order_id;END IF;
 IF NOT EXISTS(SELECT 1 FROM channel_sharing_funding_invariants WHERE order_id=oid AND valid IS TRUE) THEN RAISE EXCEPTION 'invalid channel sharing funding evidence'; END IF;
 RETURN NULL;
END $$;


--
-- Name: channel_sharing_lease_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_lease_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'immutable sharing lease history'; END IF;
 IF TG_OP='INSERT' THEN IF NEW.released_by_operation_id IS NOT NULL OR NEW.released_at IS NOT NULL THEN RAISE EXCEPTION 'new sharing lease must be active'; END IF;RETURN NEW;END IF;
 IF (NEW.id,NEW.relation_id,NEW.receiver_id,NEW.bind_operation_id,NEW.created_at) IS DISTINCT FROM (OLD.id,OLD.relation_id,OLD.receiver_id,OLD.bind_operation_id,OLD.created_at) OR OLD.released_by_operation_id IS NOT NULL AND NEW IS DISTINCT FROM OLD THEN RAISE EXCEPTION 'immutable sharing lease proof'; END IF;
 RETURN NEW;
END $$;


--
-- Name: channel_sharing_open_payment_receiver_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_open_payment_receiver_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF OLD.state='bound' AND NEW.state='unbinding' AND EXISTS(SELECT 1 FROM provider_attempt_sharing_items i JOIN provider_attempt_sharing d ON d.attempt_id=i.attempt_id WHERE i.receiver_id=OLD.id AND d.declared AND channel_sharing_payment_reference_active(d.order_id))
 THEN RAISE EXCEPTION 'receiver is required by an original sharing payment'; END IF;
 RETURN NEW;
END $$;


--
-- Name: channel_sharing_order_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_order_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE obs channel_sharing_observations%ROWTYPE;
BEGIN
 IF TG_OP='INSERT' THEN IF NEW.state<>'unsent' OR NEW.completed OR NEW.last_observation_id IS NOT NULL OR NEW.provider_order_no<>'' THEN RAISE EXCEPTION 'new sharing operation must be unsent'; END IF; RETURN NEW; END IF;
 IF (NEW.id,NEW.order_id,NEW.merchant_id,NEW.external_no,NEW.out_no,NEW.provider_trade_no,NEW.request_hash,NEW.auto_finish,NEW.receiver_count,NEW.actor_role,NEW.actor_id,NEW.actor_name,NEW.actor_class,NEW.created_at)
 IS DISTINCT FROM (OLD.id,OLD.order_id,OLD.merchant_id,OLD.external_no,OLD.out_no,OLD.provider_trade_no,OLD.request_hash,OLD.auto_finish,OLD.receiver_count,OLD.actor_role,OLD.actor_id,OLD.actor_name,OLD.actor_class,OLD.created_at)
 OR OLD.claimed_at IS NOT NULL AND NEW.claimed_at IS DISTINCT FROM OLD.claimed_at OR OLD.provider_order_no<>'' AND NEW.provider_order_no<>OLD.provider_order_no OR OLD.completed AND NEW IS DISTINCT FROM OLD
 THEN RAISE EXCEPTION 'immutable original sharing operation'; END IF;
 IF OLD.state='unsent' THEN IF NEW.state<>'claimed' THEN RAISE EXCEPTION 'sharing operation must claim before I/O'; END IF; RETURN NEW; END IF;
 IF NEW.state='unsent' OR NEW.state='claimed' AND OLD.state<>'claimed' THEN RAISE EXCEPTION 'sharing operation cannot resend'; END IF;
 IF NEW.last_observation_id IS NOT NULL THEN
  SELECT * INTO STRICT obs FROM channel_sharing_observations WHERE id=NEW.last_observation_id;
  IF obs.sharing_id<>NEW.id OR obs.provider_order_no<>NEW.provider_order_no OR obs.state<>NEW.state OR NEW.completed<>(obs.state<>'pending') THEN RAISE EXCEPTION 'sharing result must match original observation'; END IF;
 ELSIF NEW.completed OR NEW.provider_order_no<>'' THEN RAISE EXCEPTION 'missing sharing result evidence';
 END IF;
 RETURN NEW;
END $$;


--
-- Name: channel_sharing_order_item_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_order_item_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE obs channel_sharing_observations%ROWTYPE;
BEGIN
 IF TG_OP='INSERT' THEN IF NEW.state<>'pending' OR NEW.last_observation_id IS NOT NULL OR NEW.paid_journal_id IS NOT NULL THEN RAISE EXCEPTION 'new sharing recipient must be pending'; END IF; RETURN NEW; END IF;
 IF (NEW.sharing_id,NEW.position,NEW.receiver_id,NEW.amount) IS DISTINCT FROM (OLD.sharing_id,OLD.position,OLD.receiver_id,OLD.amount) OR OLD.state IN ('succeeded','failed') AND NEW IS DISTINCT FROM OLD THEN RAISE EXCEPTION 'immutable original sharing recipient result'; END IF;
 SELECT * INTO STRICT obs FROM channel_sharing_observations WHERE id=NEW.last_observation_id;
 IF obs.sharing_id<>NEW.sharing_id OR NOT EXISTS(SELECT 1 FROM jsonb_array_elements(obs.items) x WHERE x->>'receiver_id'=NEW.receiver_id::text AND x->>'amount'=NEW.amount::text AND x->>'state'=NEW.state AND COALESCE(x->>'provider_detail_no','')=NEW.provider_detail_no AND COALESCE(x->>'failure_code','')=NEW.failure_code)
 THEN RAISE EXCEPTION 'sharing recipient result lacks its exact original observation'; END IF;
 RETURN NEW;
END $$;


--
-- Name: channel_sharing_payment_reference_active(bigint); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_payment_reference_active(oid bigint) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT NOT EXISTS(SELECT 1 FROM channel_sharing_fund_releases WHERE order_id=oid)
$$;


--
-- Name: channel_sharing_ps_finish_exclusion_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_ps_finish_exclusion_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 PERFORM id FROM orders WHERE id=NEW.order_id FOR UPDATE;
 IF EXISTS(SELECT 1 FROM channel_sharing_finishes WHERE order_id=NEW.order_id) AND (TG_OP='INSERT' OR NEW IS DISTINCT FROM OLD) THEN RAISE EXCEPTION 'original payment already claimed by independent finish'; END IF;
 RETURN NEW;
END $$;


--
-- Name: channel_sharing_receiver_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_receiver_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE op channel_sharing_receiver_operations%ROWTYPE;
BEGIN
 IF TG_OP='INSERT' THEN IF NEW.state<>'draft' OR NEW.last_operation_id IS NOT NULL THEN RAISE EXCEPTION 'new sharing receiver must be draft'; END IF; RETURN NEW; END IF;
 IF (NEW.id,NEW.merchant_id,NEW.channel_id,NEW.external_no,NEW.provider,NEW.app_id,NEW.product,NEW.account_hash,NEW.input_hash,NEW.relation_account_hash,NEW.relation_hash,NEW.relation_auth_hash,NEW.receiver_cipher,NEW.created_at)
 IS DISTINCT FROM (OLD.id,OLD.merchant_id,OLD.channel_id,OLD.external_no,OLD.provider,OLD.app_id,OLD.product,OLD.account_hash,OLD.input_hash,OLD.relation_account_hash,OLD.relation_hash,OLD.relation_auth_hash,OLD.receiver_cipher,OLD.created_at)
 THEN RAISE EXCEPTION 'immutable sharing receiver identity'; END IF;
 IF NEW.state=OLD.state THEN IF NEW.last_operation_id IS DISTINCT FROM OLD.last_operation_id THEN RAISE EXCEPTION 'sharing operation cannot be rebound'; END IF; RETURN NEW; END IF;
 SELECT * INTO op FROM channel_sharing_receiver_operations WHERE id=NEW.last_operation_id;
 IF op.id IS NULL OR op.receiver_id<>OLD.id THEN RAISE EXCEPTION 'missing original receiver operation'; END IF;
 IF OLD.state IN ('draft','unbound') AND NEW.state='binding' AND op.action='bind' AND op.state='claimed' THEN RETURN NEW; END IF;
 IF OLD.state='bound' AND NEW.state='unbinding' AND op.action='unbind' AND op.state='claimed' THEN RETURN NEW; END IF;
 IF NEW.last_operation_id IS DISTINCT FROM OLD.last_operation_id THEN RAISE EXCEPTION 'sharing result changed original operation'; END IF;
 IF OLD.state='binding' AND op.action='bind' AND ((NEW.state='bound' AND op.state='succeeded') OR (NEW.state='draft' AND op.state='failed') OR (NEW.state='unknown' AND op.state='unknown')) THEN RETURN NEW; END IF;
 IF OLD.state='unbinding' AND op.action='unbind' AND ((NEW.state='unbound' AND op.state='succeeded') OR (NEW.state='bound' AND op.state='failed') OR (NEW.state='unknown' AND op.state='unknown')) THEN RETURN NEW; END IF;
 IF OLD.state='unknown' AND ((op.action='bind' AND NEW.state='bound') OR (op.action='unbind' AND NEW.state='unbound')) AND op.state='succeeded' THEN RETURN NEW; END IF;
 RAISE EXCEPTION 'invalid sharing receiver transition';
END $$;


--
-- Name: channel_sharing_receiver_has_references(bigint); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_receiver_has_references(rid bigint) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT EXISTS(SELECT 1 FROM channel_sharing_rule_items i JOIN channel_sharing_rules r ON r.id=i.rule_id JOIN channel_sharing_rule_current c ON c.rule_id=r.id WHERE i.receiver_id=rid AND r.enabled)
 OR EXISTS(SELECT 1 FROM provider_attempt_sharing_items i JOIN provider_attempt_sharing d ON d.attempt_id=i.attempt_id WHERE i.receiver_id=rid AND d.declared AND channel_sharing_payment_reference_active(d.order_id))
$$;


--
-- Name: channel_sharing_receiver_operation_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_receiver_operation_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_OP='INSERT' THEN IF NEW.state<>'unsent' THEN RAISE EXCEPTION 'new receiver operation must be unsent'; END IF; RETURN NEW; END IF;
 IF (NEW.id,NEW.receiver_id,NEW.action,NEW.out_no,NEW.external_no,NEW.request_hash,NEW.actor_role,NEW.actor_id,NEW.actor_name,NEW.actor_class,NEW.created_at)
 IS DISTINCT FROM (OLD.id,OLD.receiver_id,OLD.action,OLD.out_no,OLD.external_no,OLD.request_hash,OLD.actor_role,OLD.actor_id,OLD.actor_name,OLD.actor_class,OLD.created_at)
 OR OLD.claimed_at IS NOT NULL AND NEW.claimed_at IS DISTINCT FROM OLD.claimed_at
 THEN RAISE EXCEPTION 'immutable receiver operation'; END IF;
 IF NEW.state=OLD.state THEN RETURN NEW; END IF;
 IF OLD.state='unsent' AND NEW.state='claimed' OR OLD.state='claimed' AND NEW.state IN ('succeeded','failed','unknown') OR OLD.state='unknown' AND NEW.state IN ('succeeded','failed') THEN RETURN NEW; END IF;
 RAISE EXCEPTION 'receiver operation cannot resend';
END $$;


--
-- Name: channel_sharing_reference_operation_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_reference_operation_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE g channel_sharing_relations%ROWTYPE; r channel_sharing_receivers%ROWTYPE; src channel_sharing_receivers%ROWTYPE; proof channel_sharing_receiver_operations%ROWTYPE;
BEGIN
 IF TG_OP='UPDATE' THEN
  IF (NEW.relation_id,NEW.source,NEW.reference_operation_id) IS DISTINCT FROM (OLD.relation_id,OLD.source,OLD.reference_operation_id) THEN RAISE EXCEPTION 'immutable sharing reference proof'; END IF;RETURN NEW;
 END IF;
 SELECT * INTO STRICT g FROM channel_sharing_relations WHERE id=NEW.relation_id;
 SELECT * INTO STRICT r FROM channel_sharing_receivers WHERE id=NEW.receiver_id;
 SELECT * INTO STRICT src FROM channel_sharing_receivers WHERE id=g.source_receiver_id;
 IF r.relation_hash<>g.relation_hash OR r.relation_auth_hash<>g.relation_auth_hash THEN RAISE EXCEPTION 'receiver changed global relation'; END IF;
 IF NEW.source='remote' THEN
  IF NEW.action='bind' AND g.state<>'unbound' OR NEW.action='unbind' AND g.state<>'bound' THEN RAISE EXCEPTION 'global relation already has a send barrier'; END IF;
  IF NEW.action='unbind' AND ((SELECT count(*) FROM channel_sharing_relation_leases WHERE relation_id=g.id AND released_by_operation_id IS NULL)<>1 OR NOT EXISTS(SELECT 1 FROM channel_sharing_relation_leases WHERE relation_id=g.id AND receiver_id=r.id AND released_by_operation_id IS NULL)) THEN RAISE EXCEPTION 'remote unbind requires the last original lease'; END IF;
 ELSE
  SELECT * INTO proof FROM channel_sharing_receiver_operations WHERE id=NEW.reference_operation_id;
  IF g.state<>'bound' OR proof.id IS NULL OR proof.id IS DISTINCT FROM g.bound_operation_id OR proof.source<>'remote' OR proof.action<>'bind' OR proof.state<>'succeeded' OR proof.relation_id<>g.id
   OR (r.provider,r.app_id,r.product,r.account_hash) IS DISTINCT FROM (src.provider,src.app_id,src.product,src.account_hash)
  THEN RAISE EXCEPTION 'reference has no matching successful remote binding'; END IF;
  IF NEW.action='unbind' AND (SELECT count(*) FROM channel_sharing_relation_leases WHERE relation_id=g.id AND released_by_operation_id IS NULL)<=1 THEN RAISE EXCEPTION 'last sharing lease requires remote unbind'; END IF;
 END IF;
 RETURN NEW;
END $$;


--
-- Name: channel_sharing_refund_hold_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_refund_hold_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 PERFORM id FROM orders WHERE id=NEW.order_id FOR UPDATE;
 IF EXISTS(SELECT 1 FROM channel_sharing_fundings f WHERE f.order_id=NEW.order_id AND NOT EXISTS(SELECT 1 FROM channel_sharing_fund_releases c WHERE c.order_id=f.order_id)) THEN RAISE EXCEPTION USING ERRCODE='55000',MESSAGE='channel sharing funds are frozen',CONSTRAINT='channel_sharing_income_blocked'; END IF;RETURN NEW;
END $$;


--
-- Name: channel_sharing_relation_complete(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_relation_complete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE gid bigint; g channel_sharing_relations%ROWTYPE; proof channel_sharing_receiver_operations%ROWTYPE; last_op channel_sharing_receiver_operations%ROWTYPE; last_receiver channel_sharing_receivers%ROWTYPE; cnt bigint; expected_receiver_state text;
BEGIN
 IF TG_TABLE_NAME='channel_sharing_relations' THEN gid:=NEW.id;
 ELSIF TG_TABLE_NAME='channel_sharing_receivers' THEN SELECT id INTO gid FROM channel_sharing_relations WHERE relation_hash=NEW.relation_hash;
 ELSE gid:=NEW.relation_id;END IF;
 IF gid IS NULL THEN RETURN NULL;END IF;
 SELECT * INTO STRICT g FROM channel_sharing_relations WHERE id=gid;
 -- Validate both directions. Checking only claimed operations would miss an
 -- operation changed to failed while its global/receiver barrier stayed live.
 IF g.last_operation_id IS NULL THEN
  IF g.state<>'unbound' OR g.bound_operation_id IS NOT NULL THEN RAISE EXCEPTION 'global sharing state is missing its original operation'; END IF;
 ELSE
  SELECT * INTO STRICT last_op FROM channel_sharing_receiver_operations WHERE id=g.last_operation_id;
  SELECT * INTO STRICT last_receiver FROM channel_sharing_receivers WHERE id=last_op.receiver_id;
  IF last_op.source<>'remote' OR last_op.relation_id<>g.id OR last_receiver.relation_hash<>g.relation_hash THEN RAISE EXCEPTION 'global sharing state changed its original remote operation'; END IF;
  IF g.state='binding' THEN
   IF last_op.action<>'bind' OR last_op.state<>'claimed' OR g.source_receiver_id<>last_receiver.id OR g.bound_operation_id IS NOT NULL THEN RAISE EXCEPTION 'global binding lacks its claimed original bind'; END IF;
   expected_receiver_state:='binding';
  ELSIF g.state='unbinding' THEN
   IF last_op.action<>'unbind' OR last_op.state<>'claimed' THEN RAISE EXCEPTION 'global unbinding lacks its claimed original unbind'; END IF;
   expected_receiver_state:='unbinding';
  ELSIF g.state='unknown' THEN
   IF last_op.state<>'unknown' OR last_op.action='bind' AND (g.source_receiver_id<>last_receiver.id OR g.bound_operation_id IS NOT NULL) OR last_op.action='unbind' AND g.bound_operation_id IS NULL THEN RAISE EXCEPTION 'global uncertainty lacks its original uncertain operation'; END IF;
   expected_receiver_state:='unknown';
  ELSIF g.state='bound' THEN
   IF NOT(last_op.action='bind' AND last_op.state='succeeded' AND g.bound_operation_id=last_op.id OR last_op.action='unbind' AND last_op.state='failed') THEN RAISE EXCEPTION 'global bound state differs from its original result'; END IF;
   expected_receiver_state:='bound';
  ELSE
   IF NOT(last_op.action='bind' AND last_op.state='failed' AND g.bound_operation_id IS NULL OR last_op.action='unbind' AND last_op.state='succeeded') THEN RAISE EXCEPTION 'global unbound state differs from its original result'; END IF;
   expected_receiver_state:=CASE WHEN last_op.action='bind' THEN 'draft' ELSE 'unbound' END;
  END IF;
  IF g.state IN ('binding','unbinding','unknown') AND last_receiver.last_operation_id IS DISTINCT FROM last_op.id OR
   last_receiver.last_operation_id=last_op.id AND last_receiver.state<>expected_receiver_state THEN RAISE EXCEPTION 'original receiver differs from its global operation result'; END IF;
 END IF;
 SELECT count(*) INTO cnt FROM channel_sharing_relation_leases WHERE relation_id=gid AND released_by_operation_id IS NULL;
 IF g.state='bound' AND cnt<1 OR g.state IN ('unbound','binding') AND cnt<>0 OR g.state='unbinding' AND cnt<>1 THEN RAISE EXCEPTION 'global sharing relation has invalid live leases'; END IF;
 IF g.state IN ('bound','unbinding') OR g.state='unknown' AND g.bound_operation_id IS NOT NULL THEN
  SELECT * INTO proof FROM channel_sharing_receiver_operations WHERE id=g.bound_operation_id;
  IF proof.id IS NULL OR proof.relation_id<>gid OR proof.source<>'remote' OR proof.action<>'bind' OR proof.state<>'succeeded' THEN RAISE EXCEPTION 'global sharing relation has no remote binding proof'; END IF;
 END IF;
 IF EXISTS(SELECT 1 FROM channel_sharing_relation_leases l JOIN channel_sharing_receivers r ON r.id=l.receiver_id JOIN channel_sharing_receiver_operations b ON b.id=l.bind_operation_id
  LEFT JOIN channel_sharing_receiver_operations u ON u.id=l.released_by_operation_id
  WHERE l.relation_id=gid AND (b.receiver_id<>l.receiver_id OR b.relation_id<>gid OR b.action<>'bind' OR b.state<>'succeeded'
   OR l.released_by_operation_id IS NOT NULL AND (u.id IS NULL OR u.receiver_id<>l.receiver_id OR u.relation_id<>gid OR u.action<>'unbind' OR u.state<>'succeeded')
   OR l.released_by_operation_id IS NULL AND (r.state NOT IN ('bound','unbinding','unknown') OR g.state NOT IN ('bound','unbinding','unknown') OR b.source='remote' AND b.id IS DISTINCT FROM g.bound_operation_id OR b.source='reference' AND b.reference_operation_id IS DISTINCT FROM g.bound_operation_id)))
 THEN RAISE EXCEPTION 'invalid sharing lease operation proof'; END IF;
 IF EXISTS(SELECT 1 FROM channel_sharing_receivers r WHERE r.relation_hash=g.relation_hash AND
  ((r.state IN ('bound','unbinding') OR r.state='unknown' AND EXISTS(SELECT 1 FROM channel_sharing_receiver_operations op WHERE op.id=r.last_operation_id AND op.action='unbind'))
    IS DISTINCT FROM EXISTS(SELECT 1 FROM channel_sharing_relation_leases l WHERE l.receiver_id=r.id AND l.released_by_operation_id IS NULL)))
 THEN RAISE EXCEPTION 'receiver binding is missing its original sharing lease'; END IF;
 IF EXISTS(SELECT 1 FROM channel_sharing_receiver_operations op WHERE op.relation_id=gid AND op.source='reference' AND
  (op.state<>'succeeded' OR NOT EXISTS(SELECT 1 FROM channel_sharing_receiver_operations p WHERE p.id=op.reference_operation_id AND p.relation_id=gid AND p.source='remote' AND p.action='bind' AND p.state='succeeded') OR
   op.action='bind' AND NOT EXISTS(SELECT 1 FROM channel_sharing_relation_leases l WHERE l.bind_operation_id=op.id AND l.receiver_id=op.receiver_id) OR
   op.action='unbind' AND NOT EXISTS(SELECT 1 FROM channel_sharing_relation_leases l WHERE l.released_by_operation_id=op.id AND l.receiver_id=op.receiver_id)))
 THEN RAISE EXCEPTION 'uncommitted sharing reference result'; END IF;
 IF EXISTS(SELECT 1 FROM channel_sharing_receiver_operations op WHERE op.relation_id=gid AND op.source='remote' AND op.state IN ('claimed','unknown') AND
  (op.id IS DISTINCT FROM g.last_operation_id OR g.state NOT IN ('binding','unbinding','unknown') OR NOT EXISTS(SELECT 1 FROM channel_sharing_receivers r WHERE r.id=op.receiver_id AND r.last_operation_id=op.id AND r.state IN ('binding','unbinding','unknown'))))
 THEN RAISE EXCEPTION 'remote sharing operation lost its global send barrier'; END IF;
 IF EXISTS(SELECT 1 FROM channel_sharing_receiver_operations op WHERE op.relation_id=gid AND op.state<>'unsent' AND
  (NOT EXISTS(SELECT 1 FROM backoffice_audit a WHERE a.resource='channel-sharing-receiver-operations' AND a.resource_id=op.id AND a.operation=op.action AND a.actor_role=op.actor_role AND a.actor_id=op.actor_id AND a.actor_name=op.actor_name AND a.changes->>'state'='claimed')
   OR op.state<>'claimed' AND NOT EXISTS(SELECT 1 FROM backoffice_audit a WHERE a.resource='channel-sharing-receiver-operations' AND a.resource_id=op.id AND a.operation=op.action AND a.actor_role=op.actor_role AND a.actor_id=op.actor_id AND a.actor_name=op.actor_name AND a.changes->>'state'=op.state)))
 THEN RAISE EXCEPTION 'sharing operation is missing its original actor audit'; END IF;
 RETURN NULL;
END $$;


--
-- Name: channel_sharing_relation_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_relation_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE op channel_sharing_receiver_operations%ROWTYPE; r channel_sharing_receivers%ROWTYPE;
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'immutable sharing relation history'; END IF;
 SELECT * INTO STRICT r FROM channel_sharing_receivers WHERE id=NEW.source_receiver_id;
 IF (r.relation_hash,r.relation_auth_hash) IS DISTINCT FROM (NEW.relation_hash,NEW.relation_auth_hash) THEN RAISE EXCEPTION 'sharing relation source identity mismatch'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.state<>'unbound' OR NEW.last_operation_id IS NOT NULL OR NEW.bound_operation_id IS NOT NULL THEN RAISE EXCEPTION 'new sharing relation must be unbound'; END IF;RETURN NEW;
 END IF;
 IF (NEW.id,NEW.relation_hash,NEW.created_at) IS DISTINCT FROM (OLD.id,OLD.relation_hash,OLD.created_at) THEN RAISE EXCEPTION 'immutable sharing physical identity'; END IF;
 IF NEW IS NOT DISTINCT FROM OLD THEN RETURN NEW; END IF;
 IF OLD.state='unbound' AND NEW.state='unbound' AND NEW.last_operation_id IS NOT DISTINCT FROM OLD.last_operation_id AND NEW.bound_operation_id IS NOT DISTINCT FROM OLD.bound_operation_id
  AND NOT EXISTS(SELECT 1 FROM channel_sharing_relation_leases WHERE relation_id=OLD.id AND released_by_operation_id IS NULL) THEN RETURN NEW; END IF;
 SELECT * INTO op FROM channel_sharing_receiver_operations WHERE id=NEW.last_operation_id;
 IF op.id IS NULL OR op.relation_id<>OLD.id OR op.source<>'remote' THEN RAISE EXCEPTION 'missing original remote relation operation'; END IF;
 IF (NEW.source_receiver_id,NEW.relation_auth_hash) IS DISTINCT FROM (OLD.source_receiver_id,OLD.relation_auth_hash) AND NOT(OLD.state='unbound' AND NEW.state='binding') THEN RAISE EXCEPTION 'live sharing relation cannot change source'; END IF;
 IF OLD.state='unbound' AND NEW.state='binding' AND op.action='bind' AND op.state='claimed' AND op.receiver_id=NEW.source_receiver_id AND NEW.bound_operation_id IS NULL THEN RETURN NEW; END IF;
 IF OLD.state='bound' AND NEW.state='unbinding' AND op.action='unbind' AND op.state='claimed' AND NEW.bound_operation_id=OLD.bound_operation_id THEN RETURN NEW; END IF;
 IF NEW.last_operation_id IS DISTINCT FROM OLD.last_operation_id THEN RAISE EXCEPTION 'sharing result changed original remote operation'; END IF;
 IF OLD.state='binding' AND op.action='bind' AND
 ((NEW.state='bound' AND op.state='succeeded' AND NEW.bound_operation_id=op.id) OR (NEW.state='unbound' AND op.state='failed' AND NEW.bound_operation_id IS NULL) OR (NEW.state='unknown' AND op.state='unknown' AND NEW.bound_operation_id IS NULL)) THEN RETURN NEW; END IF;
 IF OLD.state='unbinding' AND op.action='unbind' AND NEW.bound_operation_id=OLD.bound_operation_id AND
 ((NEW.state='unbound' AND op.state='succeeded') OR (NEW.state='bound' AND op.state='failed') OR (NEW.state='unknown' AND op.state='unknown')) THEN RETURN NEW; END IF;
 RAISE EXCEPTION 'invalid global sharing relation transition';
END $$;


--
-- Name: channel_sharing_return_complete_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_return_complete_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE rid bigint;
BEGIN
 IF TG_TABLE_NAME='channel_sharing_returns' THEN rid:=NEW.id; ELSE rid:=NEW.return_id; END IF;
 IF NOT EXISTS(SELECT 1 FROM channel_sharing_return_invariants WHERE return_id=rid AND valid IS TRUE) THEN RAISE EXCEPTION 'invalid original sharing return funding'; END IF;
 RETURN NULL;
END $$;


--
-- Name: channel_sharing_return_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_return_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE obs channel_sharing_return_observations%ROWTYPE;
BEGIN
 PERFORM id FROM orders WHERE id=NEW.order_id FOR UPDATE;
 IF TG_OP='INSERT' THEN
  IF NEW.state<>'unsent' OR NEW.last_observation_id IS NOT NULL OR NEW.provider_return_no<>'' OR NEW.paid_journal_id IS NOT NULL THEN RAISE EXCEPTION 'new sharing return must be unsent'; END IF;
  RETURN NEW;
 END IF;
 IF (NEW.id,NEW.sharing_id,NEW.order_id,NEW.merchant_id,NEW.receiver_id,NEW.external_no,NEW.out_no,NEW.amount,NEW.request_hash,NEW.actor_role,NEW.actor_id,NEW.actor_name,NEW.actor_class,NEW.created_at)
 IS DISTINCT FROM (OLD.id,OLD.sharing_id,OLD.order_id,OLD.merchant_id,OLD.receiver_id,OLD.external_no,OLD.out_no,OLD.amount,OLD.request_hash,OLD.actor_role,OLD.actor_id,OLD.actor_name,OLD.actor_class,OLD.created_at)
 OR OLD.claimed_at IS NOT NULL AND NEW.claimed_at IS DISTINCT FROM OLD.claimed_at
 OR OLD.provider_return_no<>'' AND NEW.provider_return_no<>OLD.provider_return_no
 OR OLD.state IN ('succeeded','failed') AND NEW IS DISTINCT FROM OLD THEN RAISE EXCEPTION 'immutable original sharing return'; END IF;
 IF OLD.state='unsent' THEN
  IF NEW.state<>'claimed' OR NEW.last_observation_id IS NOT NULL OR NEW.provider_return_no<>'' OR NEW.paid_journal_id IS NOT NULL THEN RAISE EXCEPTION 'sharing return must claim before I/O'; END IF;
  RETURN NEW;
 END IF;
 IF NEW.state IN ('unsent','claimed') AND NEW.state<>OLD.state THEN RAISE EXCEPTION 'sharing return cannot resend'; END IF;
 IF NEW.last_observation_id IS NULL THEN
  IF OLD.last_observation_id IS NOT NULL OR NEW.state NOT IN ('claimed','unknown','failed') OR NEW.provider_return_no<>'' OR NEW.paid_journal_id IS NOT NULL THEN RAISE EXCEPTION 'sharing return lacks outcome evidence'; END IF;
 ELSE
  SELECT * INTO STRICT obs FROM channel_sharing_return_observations WHERE id=NEW.last_observation_id;
  IF (obs.return_id,obs.state,obs.provider_return_no,obs.amount) IS DISTINCT FROM (NEW.id,NEW.state,NEW.provider_return_no,NEW.amount) THEN RAISE EXCEPTION 'sharing return must match its exact observation'; END IF;
 END IF;
 RETURN NEW;
END $$;


--
-- Name: channel_sharing_rule_complete(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_rule_complete() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE rid bigint; r channel_sharing_rules%ROWTYPE; cnt integer; last_position integer; rates bigint; fixed bigint;
BEGIN
 IF TG_TABLE_NAME='channel_sharing_rules' THEN rid:=NEW.id; ELSE rid:=NEW.rule_id; END IF;
 SELECT * INTO STRICT r FROM channel_sharing_rules WHERE id=rid;
 SELECT count(*),max(position),COALESCE(sum(rate_bps),0),COALESCE(sum(fixed_amount),0) INTO cnt,last_position,rates,fixed FROM channel_sharing_rule_items WHERE rule_id=rid;
 IF cnt<>r.receiver_count OR last_position<>cnt OR rates>10000 OR fixed>999999999999 THEN RAISE EXCEPTION 'incomplete sharing rule'; END IF;
 IF EXISTS(SELECT 1 FROM channel_sharing_rule_items i JOIN channel_sharing_receivers a ON a.id=i.receiver_id WHERE i.rule_id=rid AND
  ((a.merchant_id,a.channel_id,a.provider,a.app_id,a.product,a.account_hash) IS DISTINCT FROM (r.merchant_id,r.channel_id,r.provider,r.app_id,r.product,r.account_hash) OR r.enabled AND a.state<>'bound'))
 THEN RAISE EXCEPTION 'sharing rule receiver scope or state mismatch'; END IF;
 IF EXISTS(SELECT 1 FROM jsonb_array_elements(r.methods) m WHERE jsonb_typeof(m)<>'string' OR trim(both '"' FROM m::text) !~ '^[a-z][a-z0-9_]{0,31}$') OR
 (SELECT count(DISTINCT m) FROM jsonb_array_elements(r.methods) m)<>jsonb_array_length(r.methods) THEN RAISE EXCEPTION 'invalid sharing rule methods'; END IF;
 RETURN NEW;
END $_$;


--
-- Name: channel_sharing_rule_current_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_rule_current_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE r channel_sharing_rules%ROWTYPE; previous_revision bigint;
BEGIN
 SELECT * INTO STRICT r FROM channel_sharing_rules WHERE id=NEW.rule_id;
 IF (r.merchant_id,r.channel_id) IS DISTINCT FROM (NEW.merchant_id,NEW.channel_id) THEN RAISE EXCEPTION 'sharing rule pointer scope mismatch'; END IF;
 IF TG_OP='INSERT' THEN IF r.revision<>1 THEN RAISE EXCEPTION 'first sharing rule revision must be one'; END IF;
 ELSE
  IF (NEW.merchant_id,NEW.channel_id) IS DISTINCT FROM (OLD.merchant_id,OLD.channel_id) THEN RAISE EXCEPTION 'immutable sharing rule pointer owner'; END IF;
  IF NEW.rule_id=OLD.rule_id THEN RETURN NEW; END IF;
  SELECT revision INTO STRICT previous_revision FROM channel_sharing_rules WHERE id=OLD.rule_id;
  IF r.revision<>previous_revision+1 THEN RAISE EXCEPTION 'sharing rule pointer must advance one revision'; END IF;
 END IF;
 RETURN NEW;
END $$;


--
-- Name: channel_stop_complete(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_stop_complete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
 IF NOT EXISTS(SELECT 1 FROM channel_stop_heads h JOIN channel_stop_events e ON e.id=h.event_id WHERE h.channel_id=NEW.channel_id AND (h.channel_id,h.revision,h.proof_hash)=(e.channel_id,e.revision,e.proof_hash) AND h.revision=(SELECT count(*) FROM channel_stop_events s WHERE s.channel_id=h.channel_id)) THEN RAISE EXCEPTION 'incomplete channel stop source history';END IF;RETURN NULL;
END $$;


--
-- Name: channel_stop_head_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_stop_head_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
 IF TG_OP='UPDATE' AND (NEW.channel_id<>OLD.channel_id OR NEW.revision<>OLD.revision+1 OR NOT EXISTS(SELECT 1 FROM channel_stop_events e WHERE e.id=NEW.event_id AND e.previous_id=OLD.event_id AND e.previous_hash=OLD.proof_hash AND e.transaction_id=pg_current_xact_id())) THEN RAISE EXCEPTION 'channel stop head requires next original source transaction';END IF;
 IF TG_OP='INSERT' AND (NEW.revision<>1 OR NOT EXISTS(SELECT 1 FROM channel_stop_events e WHERE e.id=NEW.event_id AND e.revision=1 AND e.transaction_id=pg_current_xact_id())) THEN RAISE EXCEPTION 'channel stop head requires first original source transaction';END IF;
 RETURN NEW;
END $$;


--
-- Name: channel_stop_notice_claim_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_stop_notice_claim_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
 IF NEW.transaction_id<>pg_current_xact_id() OR NOT EXISTS(SELECT 1 FROM channel_stop_events e JOIN jobs j ON j.id=NEW.job_id WHERE e.id=NEW.event_id AND e.action='pause' AND j.kind='admin.channel-stopped' AND j.event_key='channel-stop:'||e.id::text AND j.payload=jsonb_build_object('event_id',e.id::text) AND j.state='running' AND j.lease_until>clock_timestamp() AND sha256(convert_to(j.lease_token,'UTF8'))=NEW.lease_hash) THEN RAISE EXCEPTION 'channel notice requires original current job claim';END IF;RETURN NEW;
END $$;


--
-- Name: channel_stop_source_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.channel_stop_source_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
 IF NOT EXISTS(SELECT 1 FROM settlement_payouts p JOIN settlement_auto_claims c ON c.request_id=p.request_id WHERE (p.request_id,p.transfer_id,p.channel_id,p.send_state)=(NEW.request_id,NEW.transfer_id,NEW.channel_id,'claimed') AND c.claim_seq=NEW.claim_sequence AND c.transfer_id=NEW.transfer_id AND c.authorization_id=p.auto_authorization_id) THEN RAISE EXCEPTION 'channel stop requires original automatic send claim';END IF;
 IF NEW.revision>1 AND NOT EXISTS(SELECT 1 FROM channel_stop_heads h JOIN channel_stop_events e ON e.id=h.event_id WHERE h.channel_id=NEW.channel_id AND h.revision=NEW.revision-1 AND (h.event_id,h.proof_hash)=(NEW.previous_id,NEW.previous_hash) AND e.action<>NEW.action) THEN RAISE EXCEPTION 'channel stop requires original alternating current source';END IF;
 IF NEW.revision>1 AND NEW.action='pause' AND NOT EXISTS(SELECT 1 FROM channel_stop_events e JOIN settlement_auto_claims c ON c.claim_seq=NEW.claim_sequence WHERE e.id=NEW.previous_id AND e.action='resume' AND c.claimed_at>e.created_at) THEN RAISE EXCEPTION 'channel stop requires send claim after latest explicit restoration';END IF;
 IF NEW.revision=1 AND EXISTS(SELECT 1 FROM channel_stop_heads WHERE channel_id=NEW.channel_id) THEN RAISE EXCEPTION 'channel stop source already exists';END IF;
 RETURN NEW;
END $$;


--
-- Name: check_account_balance(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.check_account_balance() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN IF (SELECT balance FROM accounts WHERE id=NEW.id)<>(SELECT COALESCE(sum(amount),0) FROM ledger_entries WHERE account_id=NEW.id) THEN
 RAISE EXCEPTION 'account balance does not match journal'; END IF; RETURN NULL; END $$;


--
-- Name: check_journal_balance(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.check_journal_balance() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF (SELECT count(*)<2 OR COALESCE(sum(amount),0)<>0 FROM ledger_entries WHERE journal_id=NEW.id) THEN
 RAISE EXCEPTION 'unbalanced journal %',NEW.id; END IF; RETURN NULL;
END $$;


--
-- Name: check_ledger_append(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.check_ledger_append() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN IF NOT EXISTS(SELECT 1 FROM journals WHERE id=NEW.journal_id AND transaction_id=pg_current_xact_id()) THEN
 RAISE EXCEPTION 'cannot append to historical journal'; END IF; RETURN NEW; END $$;


--
-- Name: check_profile_identity_link_audit(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.check_profile_identity_link_audit() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE q profile_identity_links;
BEGIN
 SELECT * INTO STRICT q FROM profile_identity_links WHERE request_id=NEW.request_id;
 IF (SELECT count(*) FROM profile_identity_link_events WHERE request_id=q.request_id AND operation IN ('created','claimed'))<>2
 OR (q.status<>'creating' AND NOT EXISTS(SELECT 1 FROM profile_identity_link_events WHERE request_id=q.request_id AND operation=q.status))
 THEN RAISE EXCEPTION 'identity link requires audit'; END IF;
 RETURN NULL;
END $$;


--
-- Name: guard_application_authorization(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_application_authorization() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF (NEW.id,NEW.purpose,NEW.merchant_id,NEW.merchant_revision,NEW.profile_id,NEW.profile_revision,NEW.issuer_app_id,NEW.expected_auth_app_id,NEW.launch_kind,NEW.app_types,NEW.profile_hash,NEW.session_hash,NEW.actor_username,NEW.actor_role,NEW.actor_id,NEW.actor_auth_version,NEW.authorization_hash,NEW.source_proof,NEW.created_at,NEW.expires_at)
 IS DISTINCT FROM (OLD.id,OLD.purpose,OLD.merchant_id,OLD.merchant_revision,OLD.profile_id,OLD.profile_revision,OLD.issuer_app_id,OLD.expected_auth_app_id,OLD.launch_kind,OLD.app_types,OLD.profile_hash,OLD.session_hash,OLD.actor_username,OLD.actor_role,OLD.actor_id,OLD.actor_auth_version,OLD.authorization_hash,OLD.source_proof,OLD.created_at,OLD.expires_at)
 OR OLD.state_hash IS NOT NULL AND (NEW.state_hash,NEW.browser_hash,NEW.launch_proof) IS DISTINCT FROM (OLD.state_hash,OLD.browser_hash,OLD.launch_proof)
 OR OLD.state_hash IS NULL AND NEW.state_hash IS NOT NULL AND (OLD.status<>'pending' OR NEW.status<>'pending')
 OR NEW.status<>OLD.status AND NOT(OLD.status='pending' AND NEW.status IN ('processing','failed') OR OLD.status='processing' AND NEW.status IN ('verified','failed') OR OLD.status='verified' AND NEW.status IN ('revealed','failed'))
 OR NEW.result_cipher IS DISTINCT FROM OLD.result_cipher AND NOT(OLD.status='processing' AND NEW.status='verified' AND OLD.result_cipher IS NULL AND NEW.result_cipher IS NOT NULL)
 OR OLD.completed_at IS NOT NULL AND NEW.completed_at IS DISTINCT FROM OLD.completed_at
 OR OLD.revealed_at IS NOT NULL AND NEW.revealed_at IS DISTINCT FROM OLD.revealed_at
 THEN RAISE EXCEPTION 'immutable application authorization binding or result'; END IF;RETURN NEW;
END $$;


--
-- Name: guard_authorization_release(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_authorization_release() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
 IF (NEW.order_id,NEW.channel_id,NEW.request_no,NEW.auth_no,NEW.amount) IS DISTINCT FROM (OLD.order_id,OLD.channel_id,OLD.request_no,OLD.auth_no,OLD.amount) THEN RAISE EXCEPTION 'authorization release identity is immutable';END IF;
 IF OLD.sent AND NOT NEW.sent OR OLD.state='succeeded' AND NEW.state<>'succeeded' OR OLD.sent AND NEW.state='checking' THEN RAISE EXCEPTION 'authorization release cannot be resent or reversed';END IF;
 IF (NEW.remaining_source_id,NEW.remaining_source_revision,NEW.remaining_source_hash) IS DISTINCT FROM (OLD.remaining_source_id,OLD.remaining_source_revision,OLD.remaining_source_hash) THEN
  IF OLD.sent OR NEW.sent OR OLD.state NOT IN('checking','reversal_pending') OR NEW.state<>'checking'
   OR NEW.remaining_source_revision<>OLD.remaining_source_revision+1 OR NEW.remaining_source_id IS NULL OR NEW.remaining_source_hash IS NULL
   OR NOT EXISTS(SELECT 1 FROM authorization_remaining_sources s WHERE (s.id,s.order_id,s.revision)=(NEW.remaining_source_id,NEW.order_id,NEW.remaining_source_revision)
    AND s.previous_id IS NOT DISTINCT FROM OLD.remaining_source_id AND s.previous_hash IS NOT DISTINCT FROM OLD.remaining_source_hash AND s.proof_hash=NEW.remaining_source_hash AND s.transaction_id=pg_current_xact_id())
  THEN RAISE EXCEPTION 'remaining release requires a new exact unsent source transaction';END IF;
 END IF;
 IF NEW.sent AND NOT OLD.sent AND NEW.remaining_source_revision>0 AND NOT EXISTS(SELECT 1 FROM authorization_remaining_claims c WHERE (c.order_id,c.source_id,c.source_revision)=(NEW.order_id,NEW.remaining_source_id,NEW.remaining_source_revision) AND c.transaction_id=pg_current_xact_id()) THEN RAISE EXCEPTION 'remaining release requires its original atomic claim';END IF;
 RETURN NEW;
END $$;


--
-- Name: guard_capture_after_release(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_capture_after_release() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NEW.capture_state='processing' AND OLD.capture_state<>'processing' AND NEW.release_state<>'none' THEN RAISE EXCEPTION 'capture blocked by authorization release intent'; END IF;
 IF OLD.release_state<>'none' AND NEW.release_state='none' THEN RAISE EXCEPTION 'authorization release intent cannot be reset'; END IF;
 RETURN NEW;
END $$;


--
-- Name: guard_identity_lookup(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_identity_lookup() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF (NEW.id,NEW.authorization_hash,NEW.session_hash,NEW.actor_username,NEW.actor_role,NEW.actor_id,NEW.actor_auth_version,NEW.merchant_id,NEW.channel_id,NEW.provider,NEW.app_id,NEW.scope,NEW.account_scope_hash,NEW.purpose,NEW.created_at,NEW.expires_at)
 IS DISTINCT FROM (OLD.id,OLD.authorization_hash,OLD.session_hash,OLD.actor_username,OLD.actor_role,OLD.actor_id,OLD.actor_auth_version,OLD.merchant_id,OLD.channel_id,OLD.provider,OLD.app_id,OLD.scope,OLD.account_scope_hash,OLD.purpose,OLD.created_at,OLD.expires_at)
 OR OLD.browser_hash IS NOT NULL AND NEW.browser_hash IS DISTINCT FROM OLD.browser_hash
 OR NEW.status<>OLD.status AND NOT (OLD.status='pending' AND NEW.status IN ('processing','failed') OR OLD.status='processing' AND NEW.status IN ('verified','failed') OR OLD.status='verified' AND NEW.status='revealed')
 OR OLD.subject_cipher IS NOT NULL AND NEW.subject_cipher IS DISTINCT FROM OLD.subject_cipher
 OR OLD.completed_at IS NOT NULL AND NEW.completed_at IS DISTINCT FROM OLD.completed_at
 OR OLD.revealed_at IS NOT NULL AND NEW.revealed_at IS DISTINCT FROM OLD.revealed_at
 THEN RAISE EXCEPTION 'immutable identity lookup binding or terminal result'; END IF;
 RETURN NEW;
END $$;


--
-- Name: guard_identity_lookup_state(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_identity_lookup_state() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF (NEW.state_hash,NEW.request_id,NEW.purpose,NEW.browser_hash,NEW.created_at,NEW.expires_at) IS DISTINCT FROM (OLD.state_hash,OLD.request_id,OLD.purpose,OLD.browser_hash,OLD.created_at,OLD.expires_at)
 OR OLD.consumed_at IS NOT NULL AND NEW.consumed_at IS DISTINCT FROM OLD.consumed_at THEN RAISE EXCEPTION 'immutable identity lookup state'; END IF;
 RETURN NEW;
END $$;


--
-- Name: guard_last_super_admin(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_last_super_admin() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF OLD.role='admin' AND OLD.admin_class='super' AND OLD.enabled AND (TG_OP='DELETE' OR NEW.admin_class<>'super' OR NOT NEW.enabled) THEN
  PERFORM pg_advisory_xact_lock(74973234);
  IF NOT EXISTS(SELECT 1 FROM console_users WHERE role='admin' AND admin_class='super' AND enabled AND id<>OLD.id) THEN
   RAISE EXCEPTION 'last super administrator is required';
  END IF;
 END IF;
 IF TG_OP='DELETE' THEN RETURN OLD; END IF; RETURN NEW;
END $$;


--
-- Name: guard_membership_purchase_version(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_membership_purchase_version() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
 IF NEW.source_version IS DISTINCT FROM 1 THEN RAISE EXCEPTION 'new membership purchase requires source version one';END IF;RETURN NEW;END $$;


--
-- Name: guard_membership_referral_birth(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_membership_referral_birth() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
 IF NEW.transaction_id<>pg_current_xact_id() OR NOT EXISTS(SELECT 1 FROM membership_purchases p WHERE p.id=NEW.purchase_id AND p.source_version=1 AND p.created_at=transaction_timestamp() AND (p.merchant_id,p.price)=(NEW.merchant_id,NEW.price)) THEN RAISE EXCEPTION 'membership referral requires original purchase transaction';END IF;
 IF NEW.price>0 AND NOT EXISTS(SELECT 1 FROM accounts a WHERE a.id=NEW.income_account_id AND (a.owner_id,a.kind,a.scope_id,a.balance)=(0::bigint,'membership_income',NEW.purchase_id,NEW.price-NEW.reward_amount)) THEN RAISE EXCEPTION 'membership referral requires exact isolated purchase income';END IF;RETURN NEW;END $$;


--
-- Name: guard_mini_oauth_state(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_mini_oauth_state() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF (NEW.state_hash,NEW.order_id,NEW.merchant_id,NEW.channel_id,NEW.provider,NEW.app_id,NEW.method,NEW.purpose,NEW.path,NEW.created_at,NEW.expires_at) IS DISTINCT FROM (OLD.state_hash,OLD.order_id,OLD.merchant_id,OLD.channel_id,OLD.provider,OLD.app_id,OLD.method,OLD.purpose,OLD.path,OLD.created_at,OLD.expires_at) OR OLD.consumed_at IS NOT NULL AND NEW.consumed_at IS DISTINCT FROM OLD.consumed_at THEN RAISE EXCEPTION 'Mini OAuth state binding is immutable'; END IF;
 RETURN NEW;
END $$;


--
-- Name: guard_oauth_binding(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_oauth_binding() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NEW IS DISTINCT FROM OLD THEN RAISE EXCEPTION 'OAuth payment identity is immutable'; END IF;
 RETURN NEW;
END $$;


--
-- Name: guard_oauth_state(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_oauth_state() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF (NEW.state_hash,NEW.order_id,NEW.merchant_id,NEW.channel_id,NEW.provider,NEW.app_id,NEW.method,NEW.purpose,NEW.browser_hash,NEW.created_at,NEW.expires_at) IS DISTINCT FROM (OLD.state_hash,OLD.order_id,OLD.merchant_id,OLD.channel_id,OLD.provider,OLD.app_id,OLD.method,OLD.purpose,OLD.browser_hash,OLD.created_at,OLD.expires_at) OR OLD.consumed_at IS NOT NULL AND NEW.consumed_at IS DISTINCT FROM OLD.consumed_at THEN RAISE EXCEPTION 'OAuth state binding is immutable'; END IF;
 RETURN NEW;
END $$;


--
-- Name: guard_order_client_ip(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_order_client_ip() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF OLD.client_ip<>'' AND NEW.client_ip IS DISTINCT FROM OLD.client_ip THEN RAISE EXCEPTION 'immutable original payment client IP'; END IF;
 RETURN NEW;
END $$;


--
-- Name: guard_order_income_hold(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_order_income_hold() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF (NEW.id,NEW.order_id,NEW.merchant_id,NEW.request_no,NEW.merchant_net,NEW.refund_merchant_amount,NEW.amount,NEW.created_at) IS DISTINCT FROM (OLD.id,OLD.order_id,OLD.merchant_id,OLD.request_no,OLD.merchant_net,OLD.refund_merchant_amount,OLD.amount,OLD.created_at) OR OLD.state='released' AND NEW IS DISTINCT FROM OLD THEN
 RAISE EXCEPTION 'immutable income hold identity'; END IF;
 RETURN NEW;
END $$;


--
-- Name: guard_original_daily_reward(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_original_daily_reward() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
 IF EXISTS(SELECT 1 FROM referral_order_terms t JOIN referral_policies p ON p.id=COALESCE(NULLIF((t.policy_versions->>2)::bigint,0),NULLIF((t.policy_versions->>1)::bigint,0),NULLIF((t.policy_versions->>0)::bigint,0)) WHERE t.order_id=NEW.order_id AND t.enabled AND p.mode='daily')
 AND NOT EXISTS(SELECT 1 FROM referral_daily_award_invariants WHERE order_id=NEW.order_id AND valid IS TRUE) THEN RAISE EXCEPTION 'original daily policy cannot award without deferred source';END IF;RETURN NULL;END $$;


--
-- Name: guard_payment_authorization(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_payment_authorization() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF (NEW.order_id,NEW.channel_id,NEW.auth_no,NEW.buyer_id,NEW.amount) IS DISTINCT FROM (OLD.order_id,OLD.channel_id,OLD.auth_no,OLD.buyer_id,OLD.amount) THEN RAISE EXCEPTION 'authorization identity is immutable'; END IF;
 IF OLD.capture_state='succeeded' AND NEW.capture_state<>'succeeded' OR OLD.capture_state<>'none' AND NEW.capture_state='none' OR OLD.capture_state IN ('unknown','failed') AND NEW.capture_state='processing' THEN RAISE EXCEPTION 'authorization capture cannot be resent'; END IF;
 RETURN NEW;
END $$;


--
-- Name: guard_preauth_observation(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_preauth_observation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
 IF TG_OP='INSERT' THEN
  IF NEW.status<>'processing' OR NEW.rest_amount IS NOT NULL OR NEW.observed_at IS NOT NULL OR NEW.result_proof IS NOT NULL THEN RAISE EXCEPTION 'observation must begin as a query claim'; END IF;
  IF NOT EXISTS(SELECT 1 FROM orders o JOIN provider_attempts p ON p.order_id=o.id JOIN payment_authorizations a ON a.order_id=o.id JOIN provider_attempt_accounts ac ON ac.attempt_id=p.id WHERE o.id=NEW.order_id AND o.merchant_id=NEW.merchant_id AND o.trade_no=NEW.trade_no AND o.amount=NEW.amount AND o.type='alipay' AND p.id=NEW.attempt_id AND p.channel_id=NEW.channel_id AND p.method='preauth' AND a.channel_id=NEW.channel_id AND a.amount=NEW.amount AND a.auth_no=NEW.auth_no AND a.buyer_id=NEW.buyer_id AND ac.account_hash=NEW.account_hash) THEN RAISE EXCEPTION 'original authorization source mismatch';END IF;
 ELSE
  IF (NEW.id,NEW.client_request_no,NEW.merchant_id,NEW.order_id,NEW.attempt_id,NEW.channel_id,NEW.trade_no,NEW.app_id,NEW.auth_no,NEW.buyer_id,NEW.amount,NEW.account_hash,NEW.merchant_revision,NEW.session_hash,NEW.actor_username,NEW.actor_role,NEW.actor_id,NEW.actor_auth_version,NEW.source_proof,NEW.created_at,NEW.expires_at)
  IS DISTINCT FROM(OLD.id,OLD.client_request_no,OLD.merchant_id,OLD.order_id,OLD.attempt_id,OLD.channel_id,OLD.trade_no,OLD.app_id,OLD.auth_no,OLD.buyer_id,OLD.amount,OLD.account_hash,OLD.merchant_revision,OLD.session_hash,OLD.actor_username,OLD.actor_role,OLD.actor_id,OLD.actor_auth_version,OLD.source_proof,OLD.created_at,OLD.expires_at)
  OR OLD.status<>'processing' OR NEW.status NOT IN('verified','unknown') THEN RAISE EXCEPTION 'immutable observation source or result';END IF;
 END IF;RETURN NEW;END $$;


--
-- Name: guard_profile_identity_link(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_profile_identity_link() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'identity link immutable'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.birth_xid<>pg_current_xact_id() OR NEW.status<>'creating' THEN RAISE EXCEPTION 'identity link birth'; END IF;
  RETURN NEW;
 END IF;
 IF ROW(NEW.request_id,NEW.parent_proof,NEW.parent_created_at,NEW.actor_class,NEW.created_at,NEW.expires_at,NEW.requested_expires_at,NEW.birth_xid,NEW.source_proof)
 IS DISTINCT FROM ROW(OLD.request_id,OLD.parent_proof,OLD.parent_created_at,OLD.actor_class,OLD.created_at,OLD.expires_at,OLD.requested_expires_at,OLD.birth_xid,OLD.source_proof)
 OR OLD.status<>'creating' OR NEW.status NOT IN ('ready','failed','unknown')
 THEN RAISE EXCEPTION 'identity link transition'; END IF;
 RETURN NEW;
END $$;


--
-- Name: guard_profile_identity_link_event(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_profile_identity_link_event() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE q profile_identity_links;
BEGIN
 IF TG_OP<>'INSERT' THEN RAISE EXCEPTION 'identity link audit immutable'; END IF;
 SELECT * INTO STRICT q FROM profile_identity_links WHERE request_id=NEW.request_id;
 IF (NEW.operation IN ('created','claimed') AND (q.birth_xid<>pg_current_xact_id() OR q.status<>'creating'))
 OR (NEW.operation NOT IN ('created','claimed') AND NEW.operation<>q.status)
 THEN RAISE EXCEPTION 'identity link audit transition'; END IF;
 RETURN NEW;
END $$;


--
-- Name: guard_profile_identity_lookup(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_profile_identity_lookup() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF (NEW.id,NEW.merchant_id,NEW.merchant_revision,NEW.channel_id,NEW.profile_id,NEW.profile_revision,NEW.provider,NEW.app_id,NEW.kind,NEW.path,NEW.profile_hash,NEW.session_hash,NEW.actor_username,NEW.actor_role,NEW.actor_id,NEW.actor_auth_version,NEW.authorization_hash,NEW.source_proof,NEW.created_at,NEW.expires_at)
 IS DISTINCT FROM (OLD.id,OLD.merchant_id,OLD.merchant_revision,OLD.channel_id,OLD.profile_id,OLD.profile_revision,OLD.provider,OLD.app_id,OLD.kind,OLD.path,OLD.profile_hash,OLD.session_hash,OLD.actor_username,OLD.actor_role,OLD.actor_id,OLD.actor_auth_version,OLD.authorization_hash,OLD.source_proof,OLD.created_at,OLD.expires_at)
 OR OLD.state_hash IS NOT NULL AND (NEW.state_hash,NEW.browser_hash,NEW.launch_proof) IS DISTINCT FROM (OLD.state_hash,OLD.browser_hash,OLD.launch_proof)
 OR NEW.status<>OLD.status AND NOT(OLD.status='pending' AND NEW.status IN ('processing','failed') OR OLD.status='processing' AND NEW.status IN ('verified','failed') OR OLD.status='verified' AND NEW.status IN ('revealed','failed'))
 OR OLD.subject_cipher IS NOT NULL AND NEW.subject_cipher IS DISTINCT FROM OLD.subject_cipher
 OR OLD.completed_at IS NOT NULL AND NEW.completed_at IS DISTINCT FROM OLD.completed_at
 OR OLD.revealed_at IS NOT NULL AND NEW.revealed_at IS DISTINCT FROM OLD.revealed_at
 THEN RAISE EXCEPTION 'immutable standalone identity binding or result'; END IF;RETURN NEW;
END $$;


--
-- Name: guard_provider_attempt(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_provider_attempt() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NEW.order_id<>OLD.order_id OR NEW.channel_id<>OLD.channel_id OR NEW.method<>OLD.method THEN
  RAISE EXCEPTION 'provider attempt identity is immutable';
 END IF;
 IF OLD.state<>'processing' AND (NEW.state<>OLD.state OR NEW.material_type<>OLD.material_type OR NEW.material<>OLD.material OR NEW.provider_trade_no<>OLD.provider_trade_no) THEN
  RAISE EXCEPTION 'provider attempt outcome is immutable; use reconciliation';
 END IF;
 RETURN NEW;
END $$;


--
-- Name: guard_provider_operation(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_provider_operation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NEW.kind<>OLD.kind OR NEW.business_key<>OLD.business_key OR NEW.order_id<>OLD.order_id OR NEW.channel_id<>OLD.channel_id OR NEW.refund_id IS DISTINCT FROM OLD.refund_id THEN RAISE EXCEPTION 'immutable provider operation identity'; END IF;
 IF OLD.state IN ('succeeded','failed') AND NEW.state<>OLD.state THEN
  IF OLD.kind<>'refund' OR NEW.state NOT IN ('succeeded','failed') OR NOT EXISTS(
   SELECT 1 FROM provider_refund_result_evidence e JOIN refunds r ON r.id=e.refund_id
   WHERE e.operation_id=OLD.id AND e.refund_id=OLD.refund_id AND e.order_id=OLD.order_id AND e.channel_id=OLD.channel_id
   AND e.prior_operation_state=OLD.state AND e.state=NEW.state AND e.created_at=transaction_timestamp()
   AND r.status=e.state
  ) THEN RAISE EXCEPTION 'terminal provider operation'; END IF;
 END IF;
 RETURN NEW;
END $$;


--
-- Name: guard_provider_route_attempt(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_provider_route_attempt() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF EXISTS(SELECT 1 FROM orders o JOIN provider_route_assignments r ON r.merchant_id=o.merchant_id AND r.out_trade_no=o.out_trade_no
           WHERE o.id=NEW.order_id AND (r.channel_id<>NEW.channel_id OR
             CASE WHEN r.method='applet' THEN CASE WHEN r.pay_type='wxpay' THEN 'jsapi' ELSE 'mini' END ELSE r.method END<>NEW.method)) THEN
  RAISE EXCEPTION 'provider attempt conflicts with immutable route';
 END IF;
 RETURN NEW;
END $$;


--
-- Name: guard_provider_subject_channel(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_provider_subject_channel() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF EXISTS(SELECT 1 FROM provider_subject_snapshots WHERE order_id=NEW.order_id AND channel_id<>NEW.channel_id) THEN
  RAISE EXCEPTION 'provider subject conflicts with immutable channel';
 END IF;
 RETURN NEW;
END $$;


--
-- Name: guard_referral_daily_activation_source(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_referral_daily_activation_source() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
 IF NOT EXISTS(SELECT 1 FROM referral_daily_liability_sources WHERE order_id=NEW.order_id AND valid IS TRUE) THEN RAISE EXCEPTION 'daily activation source or audit invalid';END IF;RETURN NULL;END $$;


--
-- Name: guard_referral_daily_activation_tx(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_referral_daily_activation_tx() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
 IF NOT EXISTS(SELECT 1 FROM journals j WHERE j.id=NEW.funding_journal_id AND j.transaction_id=pg_current_xact_id()) THEN RAISE EXCEPTION 'daily activation requires original funding transaction';END IF;RETURN NEW;END $$;


--
-- Name: guard_referral_daily_award(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_referral_daily_award() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
 IF NOT EXISTS(SELECT 1 FROM referral_daily_award_invariants WHERE order_id=NEW.order_id AND valid IS TRUE) OR EXISTS(SELECT 1 FROM referral_daily_refund_reservations c WHERE c.order_id=NEW.order_id AND c.state<>'failed') THEN RAISE EXCEPTION 'daily award lacks funded source or has refund obligation';END IF;RETURN NULL;END $$;


--
-- Name: guard_referral_daily_refund_source(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_referral_daily_refund_source() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
 IF NOT EXISTS(SELECT 1 FROM referral_daily_refund_invariants WHERE refund_id=NEW.refund_id AND valid IS TRUE) THEN RAISE EXCEPTION 'daily refund original funding or audit invalid';END IF;RETURN NULL;END $$;


--
-- Name: guard_referral_daily_refund_transition(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_referral_daily_refund_transition() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
 IF TG_OP='INSERT' THEN
 IF NEW.state<>'pending' OR NEW.result_hash IS NOT NULL OR NEW.previous_result_hash IS NOT NULL OR NEW.result_at IS NOT NULL OR NOT EXISTS(SELECT 1 FROM journals j WHERE j.id=NEW.reserve_journal_id AND j.transaction_id=pg_current_xact_id()) THEN RAISE EXCEPTION 'daily refund requires original funded claim';END IF;
 ELSE
 IF (NEW.refund_id,NEW.order_id,NEW.amount,NEW.original_fee,NEW.refund_fee,NEW.fee_contribution,NEW.pending_account_id,NEW.escrow_account_id,NEW.fees_account_id,NEW.fee_reserved_account_id,NEW.reserve_journal_id,NEW.contribution_journal_id,NEW.request_hash,NEW.created_at)
 IS DISTINCT FROM (OLD.refund_id,OLD.order_id,OLD.amount,OLD.original_fee,OLD.refund_fee,OLD.fee_contribution,OLD.pending_account_id,OLD.escrow_account_id,OLD.fees_account_id,OLD.fee_reserved_account_id,OLD.reserve_journal_id,OLD.contribution_journal_id,OLD.request_hash,OLD.created_at)
 OR OLD.state NOT IN('pending','unknown') OR NEW.state NOT IN('unknown','failed','succeeded') OR NEW.state=OLD.state OR NEW.previous_result_hash IS DISTINCT FROM OLD.result_hash THEN RAISE EXCEPTION 'immutable daily refund source or terminal result';END IF;
 END IF;RETURN NEW;END $$;


--
-- Name: guard_referral_daily_terms_birth(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.guard_referral_daily_terms_birth() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
 IF NOT EXISTS(SELECT 1 FROM orders o JOIN referral_order_terms t ON t.order_id=o.id JOIN accounts a ON a.id=NEW.pending_account_id WHERE o.id=NEW.order_id AND o.status='created' AND o.created_at=transaction_timestamp()
 AND (o.merchant_id,o.amount,o.platform_fee)=(NEW.merchant_id,NEW.amount,NEW.platform_fee)
 AND t.enabled AND (t.promoter_id,t.reward_amount,t.policy_versions,t.proof_hash)=(NEW.promoter_id,NEW.reward_amount,NEW.policy_versions,NEW.terms_hash)
 AND (a.owner_id,a.kind,a.scope_id,a.balance)=(0::bigint,'referral_daily_pending',o.id,0::bigint)) THEN RAISE EXCEPTION 'daily terms require original created-order source';END IF;RETURN NEW;END $$;


--
-- Name: income_funding_account_identity(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.income_funding_account_identity() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN IF (OLD.kind IN('order_income_reserve','order_income_refund_reserve') OR NEW.kind IN('order_income_reserve','order_income_refund_reserve')) AND (TG_OP='DELETE' OR (NEW.owner_id,NEW.kind,NEW.scope_id) IS DISTINCT FROM (OLD.owner_id,OLD.kind,OLD.scope_id)) THEN RAISE EXCEPTION 'immutable income reserve identity';END IF;RETURN CASE WHEN TG_OP='DELETE' THEN OLD ELSE NEW END;END $$;


--
-- Name: income_funding_birth_version_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.income_funding_birth_version_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN IF NEW.funding_evidence_version<>2 THEN RAISE EXCEPTION 'new income funding requires version two';END IF;RETURN NEW;END $$;


--
-- Name: income_funding_complete_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.income_funding_complete_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ DECLARE hid bigint;rid bigint;BEGIN
 IF TG_TABLE_NAME='order_income_holds' THEN hid:=NEW.id;
 ELSIF TG_TABLE_NAME IN('order_income_hold_fundings','order_income_hold_releases') THEN hid:=NEW.hold_id;
 ELSIF TG_TABLE_NAME='refunds' THEN rid:=NEW.id;
 ELSIF TG_TABLE_NAME IN('refund_fundings','refund_funding_resolutions') THEN rid:=NEW.refund_id;
 ELSIF TG_TABLE_NAME='accounts' THEN IF NEW.kind='order_income_reserve' THEN hid:=NEW.scope_id;ELSIF NEW.kind='order_income_refund_reserve' THEN rid:=NEW.scope_id;ELSE RETURN NULL;END IF;
 ELSE SELECT CASE WHEN kind='order_income_reserve' THEN scope_id END,CASE WHEN kind='order_income_refund_reserve' THEN scope_id END INTO hid,rid FROM accounts WHERE id=NEW.account_id;END IF;
 IF rid IS NOT NULL THEN
 IF EXISTS(SELECT 1 FROM refunds WHERE id=rid AND funding_evidence_version=2) AND NOT EXISTS(SELECT 1 FROM refund_funding_invariants WHERE refund_id=rid AND valid IS TRUE) THEN RAISE EXCEPTION 'missing valid refund source funding';END IF;
 IF TG_TABLE_NAME IN('accounts','ledger_entries') AND NOT EXISTS(SELECT 1 FROM refund_fundings WHERE refund_id=rid) THEN RAISE EXCEPTION 'orphan income refund account';END IF;
 SELECT hold_id INTO hid FROM refund_fundings WHERE refund_id=rid;END IF;
 IF hid IS NOT NULL AND NOT EXISTS(SELECT 1 FROM order_income_hold_funding_evidence WHERE id=hid AND valid IS TRUE) THEN RAISE EXCEPTION 'invalid isolated income funding';END IF;RETURN NULL;END $$;


--
-- Name: income_funding_version_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.income_funding_version_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN IF NEW.funding_evidence_version<>OLD.funding_evidence_version THEN RAISE EXCEPTION 'immutable income funding version';END IF;RETURN NEW;END $$;


--
-- Name: legacy_import_history_birth(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.legacy_import_history_birth() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NEW.refund_history_birth_xid IS DISTINCT FROM pg_current_xact_id() THEN RAISE EXCEPTION 'invalid legacy import birth transaction'; END IF;
 IF NEW.refund_history_version<>2 THEN RAISE EXCEPTION 'new legacy import requires history manifest'; END IF;
 RETURN NEW;
END $$;


--
-- Name: legacy_refund_history_birth(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.legacy_refund_history_birth() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF EXISTS(SELECT 1 FROM legacy_import_runs WHERE export_id=NEW.export_id)
 OR EXISTS(SELECT 1 FROM legacy_refund_manifests WHERE export_id=NEW.export_id)
 THEN RAISE EXCEPTION 'legacy refund export already sealed'; END IF;
 RETURN NEW;
END $$;


--
-- Name: legacy_refund_history_complete(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.legacy_refund_history_complete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM orders o WHERE (o.id,o.merchant_id,o.trade_no)=(NEW.order_id,NEW.merchant_id,NEW.trade_no))
 -- Require the parent to have been born in this transaction too. This closes
 -- a concurrent late-child insert that saw no parent at its BEFORE trigger.
 -- The explicit top-level xid also supports parent insertion in a savepoint.
 OR NOT EXISTS(SELECT 1 FROM legacy_import_runs r WHERE r.export_id=NEW.export_id AND r.sha256=NEW.source_hash AND r.refund_history_birth_xid=pg_current_xact_id())
 THEN RAISE EXCEPTION 'incomplete legacy refund history source'; END IF;
 RETURN NULL;
END $$;


--
-- Name: legacy_refund_manifest_complete(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.legacy_refund_manifest_complete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE target text;
BEGIN
 target:=NEW.export_id;
 IF NOT EXISTS(SELECT 1 FROM legacy_import_runs r JOIN legacy_refund_manifests m ON m.export_id=r.export_id WHERE r.export_id=target
  AND r.refund_history_version=2 AND (r.source,r.sha256)=(m.source,m.source_hash)
  AND m.refund_count=(SELECT count(*) FROM legacy_refund_history h WHERE h.export_id=target)
  AND m.unknown_count=(SELECT count(*) FROM legacy_refund_history h WHERE h.export_id=target AND h.legacy_status='unknown'))
 THEN RAISE EXCEPTION 'incomplete legacy refund manifest'; END IF;
 RETURN NULL;
END $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: membership_purchases; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.membership_purchases (
    id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    group_id bigint NOT NULL,
    external_no text NOT NULL,
    price bigint NOT NULL,
    group_name text NOT NULL,
    duration_days integer NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    actor text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    source_version integer DEFAULT 1 NOT NULL,
    CONSTRAINT membership_purchases_duration_days_check CHECK (((duration_days >= 1) AND (duration_days <= 3660))),
    CONSTRAINT membership_purchases_price_check CHECK ((price >= 0)),
    CONSTRAINT membership_purchases_source_version_check CHECK ((source_version = ANY (ARRAY[0, 1])))
);


--
-- Name: membership_referral_legacy_snapshot(member72_1c1acaaf36d7e39a.membership_purchases); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.membership_referral_legacy_snapshot(p member72_1c1acaaf36d7e39a.membership_purchases) RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
 SELECT jsonb_build_object('id',p.id,'merchant_id',p.merchant_id,'group_id',p.group_id,'external_no',p.external_no,'price',p.price,'group_name',p.group_name,'duration_days',p.duration_days,'actor',p.actor,'source_version',p.source_version,
 'expires_at',to_char(p.expires_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"'),'created_at',to_char(p.created_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"')) $$;


--
-- Name: merchant_group_baseline_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.merchant_group_baseline_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE assigned text;
BEGIN
 IF TG_OP='INSERT' OR COALESCE(NEW.profile->>'group_id','') IS DISTINCT FROM COALESCE(OLD.profile->>'group_id','') THEN
  assigned:=COALESCE(NEW.profile->>'group_id','');
  IF assigned='' THEN NEW.base_group_id:=0;
  ELSIF assigned ~ '^[0-9]{1,19}$' AND assigned::numeric<=9223372036854775807 THEN NEW.base_group_id:=assigned::bigint;
  ELSE RAISE EXCEPTION 'invalid administrator baseline group'; END IF;
  NEW.group_baseline_unresolved:=false;
 END IF;
 RETURN NEW;
END $_$;


--
-- Name: order_fee_snapshot_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.order_fee_snapshot_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_OP='INSERT' THEN IF NEW.merchant_amount IS NULL THEN NEW.merchant_amount:=NEW.amount; END IF; RETURN NEW; END IF;
 IF (NEW.amount,NEW.merchant_amount,NEW.platform_fee,NEW.fee_policy,NEW.fee_rate_bps,NEW.fee_group_id,NEW.refund_fee_payer) IS DISTINCT FROM (OLD.amount,OLD.merchant_amount,OLD.platform_fee,OLD.fee_policy,OLD.fee_rate_bps,OLD.fee_group_id,OLD.refund_fee_payer) THEN
 RAISE EXCEPTION 'immutable order fee snapshot'; END IF; RETURN NEW;
END $$;


--
-- Name: order_income_channel_sharing_outflow(bigint); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.order_income_channel_sharing_outflow(oid bigint) RETURNS bigint
    LANGUAGE sql STABLE
    AS $$
 SELECT GREATEST(0::numeric,
  COALESCE((SELECT sum(i.amount) FROM channel_sharing_orders s JOIN channel_sharing_order_items i ON i.sharing_id=s.id WHERE s.order_id=oid AND i.state='succeeded' AND EXISTS(SELECT 1 FROM channel_sharing_funding_invariants v WHERE v.order_id=s.order_id AND v.valid IS TRUE)),0)
  -COALESCE((SELECT sum(r.amount) FROM channel_sharing_returns r WHERE r.order_id=oid AND r.state='succeeded' AND EXISTS(SELECT 1 FROM channel_sharing_return_invariants v WHERE v.return_id=r.id AND v.valid IS TRUE)),0)
 )::bigint
$$;


--
-- Name: order_income_holding_account_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.order_income_holding_account_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF OLD.kind='order_income_hold' AND (TG_OP='DELETE' OR (NEW.owner_id,NEW.kind,NEW.scope_id) IS DISTINCT FROM (OLD.owner_id,OLD.kind,OLD.scope_id)) THEN RAISE EXCEPTION 'immutable order income holding account'; END IF;
 RETURN CASE WHEN TG_OP='DELETE' THEN OLD ELSE NEW END;
END $$;


--
-- Name: order_income_holding_funding_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.order_income_holding_funding_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE owner bigint;BEGIN IF TG_TABLE_NAME='accounts' THEN owner:=NEW.owner_id;ELSE owner:=NEW.merchant_id;END IF;
 IF NOT EXISTS(SELECT 1 FROM accounts a WHERE(a.owner_id,a.kind,a.scope_id)=(owner,'order_income_hold',0) AND a.balance=(SELECT COALESCE(sum(h.amount),0) FROM order_income_holds h WHERE h.merchant_id=owner AND h.state='held' AND NOT EXISTS(SELECT 1 FROM order_income_hold_fundings f WHERE f.hold_id=h.id))) OR EXISTS(SELECT 1 FROM order_income_holds h WHERE h.merchant_id=owner AND NOT EXISTS(SELECT 1 FROM order_income_hold_funding_evidence v WHERE v.id=h.id AND v.valid IS TRUE)) THEN RAISE EXCEPTION 'income hold lacks isolated original funding';END IF;RETURN NULL;END $$;


--
-- Name: order_income_source_snapshot_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.order_income_source_snapshot_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE e order_income_source_evidence%ROWTYPE;
BEGIN
 IF TG_OP='UPDATE' THEN
  IF (NEW.channel_sharing_amount,NEW.internal_allocated_amount,NEW.evidence_version) IS DISTINCT FROM (OLD.channel_sharing_amount,OLD.internal_allocated_amount,OLD.evidence_version) THEN RAISE EXCEPTION 'immutable income source snapshot'; END IF;RETURN NEW;
 END IF;
 PERFORM id FROM orders WHERE id=NEW.order_id FOR UPDATE;
 SELECT * INTO e FROM order_income_source_evidence WHERE order_id=NEW.order_id;
 IF NEW.evidence_version<>2 OR e.order_id IS NULL OR e.valid IS NOT TRUE OR e.pending_refunds<>0 OR e.remaining<=0 OR
  (NEW.merchant_id,NEW.merchant_net,NEW.refund_merchant_amount,NEW.channel_sharing_amount,NEW.internal_allocated_amount,NEW.amount) IS DISTINCT FROM (e.merchant_id,e.merchant_net,e.refund_merchant_amount,e.channel_sharing_amount,e.internal_allocated_amount,e.remaining)
 THEN RAISE EXCEPTION 'income hold differs from retained original source evidence'; END IF;
 RETURN NEW;
END $$;


--
-- Name: order_profit_request_evidence_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.order_profit_request_evidence_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE rid bigint;
BEGIN
 IF TG_TABLE_NAME='ledger_requests' THEN rid:=NEW.id; ELSE rid:=NEW.request_id; END IF;
 IF EXISTS(SELECT 1 FROM order_profit_allocations a WHERE a.request_id=rid AND NOT EXISTS(SELECT 1 FROM order_income_internal_allocation_evidence v WHERE v.id=a.id AND v.valid IS TRUE)) THEN RAISE EXCEPTION 'internal order allocation lacks original request journals and audit'; END IF;
 RETURN NULL;
END $$;


--
-- Name: order_profit_source_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.order_profit_source_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE e order_income_source_evidence%ROWTYPE; o orders%ROWTYPE; request ledger_requests%ROWTYPE;
BEGIN
 PERFORM id FROM orders WHERE id=NEW.order_id FOR UPDATE;
 SELECT * INTO STRICT o FROM orders WHERE id=NEW.order_id;
 SELECT * INTO e FROM order_income_source_evidence WHERE order_id=NEW.order_id;
 SELECT * INTO STRICT request FROM ledger_requests WHERE id=NEW.request_id;
 IF e.valid IS NOT TRUE OR e.pending_refunds<>0 OR NEW.amount>e.remaining OR NEW.amount<>floor(o.amount::numeric*NEW.rate_bps/10000) OR
  request.kind<>'profitsharing' OR request.status<>'pending' OR request.merchant_id<>o.merchant_id OR request.amount<>NEW.amount OR request.external_no<>'order:'||o.trade_no||':rule:'||NEW.rule_id::text OR
  EXISTS(SELECT 1 FROM order_income_holds WHERE order_id=o.id AND state='held') OR
  EXISTS(SELECT 1 FROM channel_sharing_fundings f WHERE f.order_id=o.id AND NOT EXISTS(SELECT 1 FROM channel_sharing_fund_releases c WHERE c.order_id=f.order_id))
 THEN RAISE EXCEPTION 'profit allocation exceeds retained original income'; END IF;
 RETURN NEW;
END $$;


--
-- Name: printing_head_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.printing_head_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'immutable printing head'; END IF;
 IF TG_OP='INSERT' AND NEW.revision<>1 OR TG_OP='UPDATE' AND NEW.revision<>OLD.revision+1 THEN RAISE EXCEPTION 'invalid printing config revision'; END IF;
 IF TG_TABLE_NAME='printing_platform_head' THEN
  IF NOT EXISTS(SELECT 1 FROM printing_platform_configs c WHERE (c.id,c.revision)=(NEW.config_id,NEW.revision)) THEN RAISE EXCEPTION 'foreign printing head'; END IF;
 ELSE
  IF NOT EXISTS(SELECT 1 FROM printing_merchant_configs c WHERE (c.id,c.merchant_id,c.revision)=(NEW.config_id,NEW.merchant_id,NEW.revision)) THEN RAISE EXCEPTION 'foreign printing merchant head'; END IF;
 END IF;
 RETURN NEW;
END $$;


--
-- Name: printing_intent_complete(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.printing_intent_complete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN IF NOT EXISTS(SELECT 1 FROM printing_intent_invariants WHERE id=NEW.id AND valid IS TRUE) THEN RAISE EXCEPTION 'incomplete printing intent'; END IF; RETURN NULL; END $$;


--
-- Name: provider_attempt_original_identity_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.provider_attempt_original_identity_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF (NEW.id,NEW.order_id,NEW.channel_id,NEW.method,NEW.created_at) IS DISTINCT FROM (OLD.id,OLD.order_id,OLD.channel_id,OLD.method,OLD.created_at) THEN RAISE EXCEPTION 'immutable original provider attempt identity'; END IF;
 RETURN NEW;
END $$;


--
-- Name: provider_attempt_sharing_birth_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.provider_attempt_sharing_birth_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 PERFORM id FROM orders WHERE id=NEW.order_id FOR UPDATE;
 IF NOT EXISTS(SELECT 1 FROM provider_attempts a JOIN orders o ON o.id=a.order_id WHERE a.id=NEW.attempt_id AND a.order_id=NEW.order_id AND a.state='processing' AND o.status='created' AND a.created_at=transaction_timestamp()
  AND NOT EXISTS(SELECT 1 FROM verified_payment_receipts p WHERE p.order_id=o.id)
  AND NOT EXISTS(SELECT 1 FROM journals j WHERE j.event_key='payment:'||o.trade_no))
 THEN RAISE EXCEPTION 'sharing declaration must precede the original payment attempt'; END IF;
 RETURN NEW;
END $$;


--
-- Name: provider_attempt_sharing_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.provider_attempt_sharing_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE aid bigint; d provider_attempt_sharing%ROWTYPE; r channel_sharing_rules%ROWTYPE; expected_count integer; actual_count integer; expected_sum numeric; actual_sum numeric;
BEGIN
 IF TG_TABLE_NAME='provider_attempt_sharing' THEN aid:=NEW.attempt_id;
 ELSIF TG_TABLE_NAME='provider_attempt_sharing_items' THEN aid:=NEW.attempt_id;
 ELSE aid:=NEW.attempt_id; END IF;
 SELECT * INTO d FROM provider_attempt_sharing WHERE attempt_id=aid;
 IF d.attempt_id IS NULL THEN RAISE EXCEPTION 'missing original sharing declaration'; END IF;
 IF NOT EXISTS(SELECT 1 FROM provider_attempt_accounts WHERE attempt_id=aid) THEN RAISE EXCEPTION 'missing original payment account proof'; END IF;
 IF NOT EXISTS(SELECT 1 FROM provider_attempts a JOIN orders o ON o.id=a.order_id WHERE a.id=aid AND
  (a.order_id,a.channel_id,a.method,o.merchant_id,o.type,o.amount,o.merchant_amount)=(d.order_id,d.channel_id,d.method,d.merchant_id,d.provider,d.gross_amount,d.merchant_net))
 THEN RAISE EXCEPTION 'invalid original sharing payment binding'; END IF;
 IF d.rule_id IS NOT NULL THEN
  SELECT * INTO STRICT r FROM channel_sharing_rules WHERE id=d.rule_id;
  IF (r.merchant_id,r.channel_id) IS DISTINCT FROM (d.merchant_id,d.channel_id) THEN RAISE EXCEPTION 'sharing policy owner mismatch'; END IF;
 END IF;
 SELECT count(*),COALESCE(sum(amount),0) INTO actual_count,actual_sum FROM provider_attempt_sharing_items WHERE attempt_id=aid;
 IF actual_count<>d.receiver_count OR actual_sum>d.merchant_net THEN RAISE EXCEPTION 'invalid sharing payment allocations'; END IF;
 IF d.purpose='recharge' AND d.declared THEN RAISE EXCEPTION 'balance recharge cannot declare profit sharing'; END IF;
 IF NOT d.declared THEN
  IF d.purpose='payment' AND d.rule_id IS NOT NULL AND r.enabled AND r.methods ? d.method AND d.gross_amount>=r.minimum_amount AND EXISTS(SELECT 1 FROM channel_sharing_rule_items i WHERE i.rule_id=r.id AND CASE WHEN i.mode='fixed' THEN i.fixed_amount ELSE floor(d.gross_amount::numeric*i.rate_bps/10000) END>0)
  THEN RAISE EXCEPTION 'effective sharing policy requires an explicit declaration'; END IF;
  RETURN NULL;
 END IF;
 IF NOT r.enabled OR NOT(r.methods ? d.method) OR d.gross_amount<r.minimum_amount OR
  (r.provider,r.app_id,r.product,r.account_hash,r.refund_mode,r.auto_finish) IS DISTINCT FROM (d.provider,d.app_id,d.product,d.account_hash,d.refund_mode,d.auto_finish)
 THEN RAISE EXCEPTION 'original sharing declaration policy mismatch'; END IF;
 SELECT count(*),COALESCE(sum(amount),0) INTO expected_count,expected_sum FROM
  (SELECT CASE WHEN mode='fixed' THEN fixed_amount ELSE floor(d.gross_amount::numeric*rate_bps/10000) END AS amount FROM channel_sharing_rule_items WHERE rule_id=r.id) x WHERE amount>0;
 IF actual_count<>expected_count OR actual_sum<>expected_sum OR EXISTS(
  SELECT 1 FROM provider_attempt_sharing_items x LEFT JOIN channel_sharing_rule_items i ON i.rule_id=r.id AND i.receiver_id=x.receiver_id
  WHERE x.attempt_id=aid AND (i.rule_id IS NULL OR x.amount<>CASE WHEN i.mode='fixed' THEN i.fixed_amount ELSE floor(d.gross_amount::numeric*i.rate_bps/10000) END))
 THEN RAISE EXCEPTION 'sharing allocations differ from original policy'; END IF;
 RETURN NULL;
END $$;


--
-- Name: provider_attempt_sharing_purpose_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.provider_attempt_sharing_purpose_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF (NEW.purpose='recharge') IS DISTINCT FROM EXISTS(SELECT 1 FROM recharge_intents WHERE order_id=NEW.order_id) OR NEW.purpose='recharge' AND NEW.declared THEN RAISE EXCEPTION 'sharing declaration changed original business purpose'; END IF;
 RETURN NEW;
END $$;


--
-- Name: provider_refund_result_birth_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.provider_refund_result_birth_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NEW.created_at<>transaction_timestamp() OR NOT EXISTS(
  SELECT 1 FROM refunds r
  WHERE r.id=NEW.refund_id
  AND (r.order_id,r.amount,r.refund_no,r.status)=(NEW.order_id,NEW.amount,NEW.refund_no,NEW.state)
  AND (NEW.source='internal' OR EXISTS(SELECT 1 FROM provider_operations p WHERE p.refund_id=r.id AND p.id=NEW.operation_id AND p.kind='refund' AND (p.order_id,p.channel_id,p.state)=(NEW.order_id,NEW.channel_id,NEW.prior_operation_state)))
  AND EXISTS(SELECT 1 FROM operation_audit a WHERE a.operation_kind='refund' AND a.operation_id=r.id AND a.from_status=NEW.prior_refund_state AND a.to_status=NEW.state AND a.created_at=transaction_timestamp())
 ) THEN RAISE EXCEPTION 'refund result evidence lacks original nonterminal intent'; END IF;
 RETURN NEW;
END $$;


--
-- Name: provider_refund_result_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.provider_refund_result_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM provider_refund_result_invariants WHERE refund_id=NEW.refund_id AND valid IS TRUE) THEN RAISE EXCEPTION 'invalid terminal refund evidence'; END IF;
 RETURN NULL;
END $$;


--
-- Name: recharge_intent_birth_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.recharge_intent_birth_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 PERFORM id FROM orders WHERE id=NEW.order_id FOR UPDATE;
 IF NOT EXISTS(SELECT 1 FROM recharge_intents WHERE order_id=NEW.order_id) AND (EXISTS(SELECT 1 FROM provider_attempts WHERE order_id=NEW.order_id) OR EXISTS(SELECT 1 FROM verified_payment_receipts WHERE order_id=NEW.order_id) OR EXISTS(SELECT 1 FROM orders WHERE id=NEW.order_id AND status<>'created')) THEN RAISE EXCEPTION 'recharge intent must precede original payment'; END IF;
 RETURN NEW;
END $$;


--
-- Name: referral_clawback_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_clawback_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE rid bigint; oid bigint;
BEGIN
 IF TG_TABLE_NAME='accounts' THEN
  IF NEW.kind<>'referral_clawback_reserve' THEN RETURN NULL; END IF; rid:=NEW.scope_id;
 ELSIF TG_TABLE_NAME='ledger_entries' THEN
  SELECT scope_id INTO rid FROM accounts WHERE id=NEW.account_id AND kind='referral_clawback_reserve'; IF rid IS NULL THEN RETURN NULL; END IF;
 ELSIF TG_TABLE_NAME='refunds' THEN rid:=NEW.id;
 ELSE rid:=NEW.refund_id; END IF;
 SELECT order_id INTO oid FROM refunds WHERE id=rid;
 IF EXISTS(SELECT 1 FROM referral_refund_clawbacks WHERE refund_id=rid) THEN
  IF NOT EXISTS(SELECT 1 FROM referral_clawback_invariants WHERE refund_id=rid AND valid IS TRUE) THEN RAISE EXCEPTION 'invalid referral clawback evidence'; END IF;
 ELSE
  IF TG_TABLE_NAME IN ('accounts','ledger_entries') OR EXISTS(SELECT 1 FROM referral_rewards w WHERE w.order_id=oid AND NOT EXISTS(SELECT 1 FROM referral_refund_clawbacks c WHERE c.reward_id=w.id AND c.state='succeeded' AND c.refund_id<>rid)) THEN RAISE EXCEPTION 'missing original referral clawback'; END IF;
 END IF;
 RETURN NULL;
END $$;


--
-- Name: referral_clawback_journal_valid(bigint, text, bigint, bigint, bigint); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_clawback_journal_valid(jid bigint, event text, source bigint, target bigint, value bigint) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT CASE WHEN value=0 THEN jid IS NULL ELSE jid IS NOT NULL AND EXISTS(
  SELECT 1 FROM journals j WHERE j.id=jid AND j.event_key=event
   AND (SELECT count(*)=2 FROM ledger_entries e WHERE e.journal_id=j.id)
   AND (SELECT COALESCE(sum(e.amount),0)=-value FROM ledger_entries e WHERE e.journal_id=j.id AND e.account_id=source)
   AND (SELECT COALESCE(sum(e.amount),0)=value FROM ledger_entries e WHERE e.journal_id=j.id AND e.account_id=target)) END
$$;


--
-- Name: referral_clawback_update_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_clawback_update_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'immutable original referral clawback'; END IF;
 IF TG_OP='INSERT' THEN
  IF NEW.state<>'pending' OR NEW.result_hash IS NOT NULL THEN RAISE EXCEPTION 'clawback must begin pending'; END IF;
  RETURN NEW;
 END IF;
 IF (NEW.refund_id,NEW.reward_id,NEW.order_id,NEW.merchant_id,NEW.promoter_id,NEW.amount,NEW.original_fee,NEW.prior_fee_used,NEW.refund_fee,NEW.fee_contribution,NEW.escrow_account_id,NEW.promoter_account_id,NEW.fees_account_id,NEW.fee_reserved_account_id,NEW.reward_hash,NEW.request_hash,NEW.reserve_journal_id,NEW.contribution_journal_id,NEW.created_at)
 IS DISTINCT FROM (OLD.refund_id,OLD.reward_id,OLD.order_id,OLD.merchant_id,OLD.promoter_id,OLD.amount,OLD.original_fee,OLD.prior_fee_used,OLD.refund_fee,OLD.fee_contribution,OLD.escrow_account_id,OLD.promoter_account_id,OLD.fees_account_id,OLD.fee_reserved_account_id,OLD.reward_hash,OLD.request_hash,OLD.reserve_journal_id,OLD.contribution_journal_id,OLD.created_at)
 THEN RAISE EXCEPTION 'immutable original referral clawback'; END IF;
 IF OLD.state IN ('succeeded','failed') AND NEW IS DISTINCT FROM OLD THEN RAISE EXCEPTION 'terminal referral clawback'; END IF;
 IF OLD.state='unknown' AND NEW.state='pending' THEN RAISE EXCEPTION 'unknown referral clawback cannot be resent'; END IF;
 RETURN NEW;
END $$;


--
-- Name: referral_daily_award_valid(bigint); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_daily_award_valid(oid bigint) RETURNS boolean
    LANGUAGE sql STABLE
    SET jit TO 'off'
    AS $$ SELECT EXISTS(SELECT 1 FROM referral_daily_award_invariants WHERE order_id=oid AND valid IS TRUE) $$;


--
-- Name: referral_daily_journal_valid(bigint, bigint, bigint, bigint, text); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_daily_journal_valid(jid bigint, src bigint, dst bigint, cents bigint, original_key text) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$ SELECT CASE WHEN cents=0 THEN jid IS NULL ELSE jid IS NOT NULL AND EXISTS(SELECT 1 FROM journals j WHERE j.id=jid AND j.event_key=original_key
 AND (SELECT count(*)=2 FROM ledger_entries e WHERE e.journal_id=j.id)
 AND (SELECT COALESCE(sum(e.amount),0)=-cents FROM ledger_entries e WHERE e.journal_id=j.id AND e.account_id=src)
 AND (SELECT COALESCE(sum(e.amount),0)=cents FROM ledger_entries e WHERE e.journal_id=j.id AND e.account_id=dst)) END $$;


--
-- Name: referral_daily_liability_valid(bigint); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_daily_liability_valid(oid bigint) RETURNS boolean
    LANGUAGE sql STABLE
    SET jit TO 'off'
    AS $$ SELECT EXISTS(SELECT 1 FROM referral_daily_liability_invariants WHERE order_id=oid AND valid IS TRUE) $$;


--
-- Name: referral_daily_refund_valid(bigint); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_daily_refund_valid(rid bigint) RETURNS boolean
    LANGUAGE sql STABLE
    SET jit TO 'off'
    AS $$ SELECT EXISTS(SELECT 1 FROM referral_daily_refund_invariants WHERE refund_id=rid AND valid IS TRUE) $$;


--
-- Name: referral_escrow_identity_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_escrow_identity_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF (OLD.kind='referral_clawback_reserve' OR NEW.kind='referral_clawback_reserve') AND (NEW.owner_id,NEW.kind,NEW.scope_id) IS DISTINCT FROM (OLD.owner_id,OLD.kind,OLD.scope_id) THEN RAISE EXCEPTION 'immutable referral escrow identity'; END IF;
 RETURN NEW;
END $$;


--
-- Name: referral_merchant_birth_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_merchant_birth_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF (NEW.id,NEW.created_at) IS DISTINCT FROM (OLD.id,OLD.created_at) THEN RAISE EXCEPTION 'immutable merchant birth identity'; END IF;RETURN NEW;
END $$;


--
-- Name: referral_order_source_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_order_source_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF (NEW.referral_source_version,NEW.referral_source_hash) IS NOT DISTINCT FROM
 (OLD.referral_source_version,OLD.referral_source_hash) THEN RETURN NEW; END IF;
 IF OLD.referral_source_version<>0 OR OLD.referral_source_hash IS NOT NULL
 OR NEW.referral_source_version<>3 OR NEW.referral_source_hash IS NULL
 OR OLD.status<>'created' OR OLD.created_at<>transaction_timestamp()
 OR NOT EXISTS(SELECT 1 FROM referral_order_terms t WHERE t.order_id=OLD.id)
 THEN RAISE EXCEPTION 'original order referral source is immutable and birth-only'; END IF;
 RETURN NEW;
END $$;


--
-- Name: referral_policy_audit_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_policy_audit_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE p referral_policies;
BEGIN
 SELECT * INTO STRICT p FROM referral_policies WHERE id=NEW.id;
 IF NOT EXISTS(SELECT 1 FROM referral_policy_audits a WHERE a.policy_id=p.id AND (a.actor_role,a.actor_id,a.actor_name)=(p.actor_role,p.actor_id,p.actor_name)) THEN RAISE EXCEPTION 'missing referral policy audit'; END IF;
 RETURN NULL;
END $$;


--
-- Name: referral_policy_head_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_policy_head_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE p referral_policies; previous_revision bigint;
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'referral policy heads cannot be removed'; END IF;
 SELECT * INTO STRICT p FROM referral_policies WHERE id=NEW.policy_id;
 IF (p.scope_kind,p.scope_id) IS DISTINCT FROM (NEW.scope_kind,NEW.scope_id) THEN RAISE EXCEPTION 'referral policy scope mismatch'; END IF;
 IF TG_OP='UPDATE' THEN
  IF (OLD.scope_kind,OLD.scope_id) IS DISTINCT FROM (NEW.scope_kind,NEW.scope_id) THEN RAISE EXCEPTION 'immutable referral policy scope'; END IF;
  SELECT revision INTO STRICT previous_revision FROM referral_policies WHERE id=OLD.policy_id;
  IF p.revision<>previous_revision+1 THEN RAISE EXCEPTION 'referral policy revision conflict'; END IF;
 ELSE
  IF p.revision<>1 THEN RAISE EXCEPTION 'referral policy initial revision conflict'; END IF;
 END IF;
 RETURN NEW;
END $$;


--
-- Name: referral_profit_audit_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_profit_audit_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM referral_profit_cost_events e WHERE e.order_id=NEW.order_id
 AND e.event_key='referral-profit:'||NEW.order_id::text||':birth' AND e.subject_hash=NEW.proof_hash AND e.actor='payment-engine')
 THEN RAISE EXCEPTION 'missing original profit cost audit'; END IF;
 RETURN NULL;
END $$;


--
-- Name: referral_profit_birth_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_profit_birth_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE o orders; t referral_order_terms;
BEGIN
 SELECT * INTO STRICT o FROM orders WHERE id=NEW.order_id FOR UPDATE;
 SELECT * INTO STRICT t FROM referral_order_terms WHERE order_id=o.id;
 IF o.status<>'created' OR o.created_at<>transaction_timestamp() OR t.purpose<>'payment'
 OR (o.merchant_id,o.type,o.amount,o.platform_fee,t.reward_amount,t.proof_hash) IS DISTINCT FROM
 (NEW.merchant_id,NEW.provider,NEW.amount,NEW.platform_fee,NEW.reward_amount,NEW.terms_hash)
 THEN RAISE EXCEPTION 'profit cost must be born with exact original terms'; END IF;
 RETURN NEW;
END $$;


--
-- Name: referral_profit_event_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_profit_event_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM referral_profit_costs c WHERE c.order_id=NEW.order_id AND c.created_at=transaction_timestamp()
 AND c.proof_hash=NEW.subject_hash AND NEW.event_key='referral-profit:'||c.order_id::text||':birth')
 THEN RAISE EXCEPTION 'original profit event mismatch'; END IF;
 RETURN NEW;
END $$;


--
-- Name: referral_profit_required(bigint); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_profit_required(oid bigint) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT COALESCE((SELECT t.purpose='payment' AND t.relation_id IS NOT NULL
 AND t.reason NOT IN('disabled','promoter_disabled') AND
 (SELECT p.basis FROM jsonb_array_elements_text(t.policy_versions) WITH ORDINALITY r(v,n)
 JOIN referral_policies p ON p.id=r.v::bigint WHERE r.n<=3 ORDER BY r.n DESC LIMIT 1)='profit'
 FROM referral_order_terms t WHERE t.order_id=oid),false)
$$;


--
-- Name: referral_profit_terms_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_profit_terms_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE c referral_profit_costs; t referral_order_terms; required boolean;
BEGIN
 SELECT * INTO STRICT t FROM referral_order_terms WHERE order_id=NEW.order_id;
 required := referral_profit_required(NEW.order_id);
 IF required AND NOT EXISTS(SELECT 1 FROM orders o WHERE o.id=NEW.order_id AND o.referral_source_version=3 AND octet_length(o.referral_source_hash)=32)
 THEN RAISE EXCEPTION 'profit cost requires original order source anchor'; END IF;
 SELECT * INTO c FROM referral_profit_costs WHERE order_id=t.order_id;
 IF required IS DISTINCT FROM FOUND THEN RAISE EXCEPTION 'original profit cost family mismatch'; END IF;
 IF required AND (c.reward_amount IS DISTINCT FROM
 ((c.profit_amount/10000)*t.rate_bps + ((c.profit_amount%10000)*t.rate_bps+5000)/10000))
 THEN RAISE EXCEPTION 'original profit reward mismatch'; END IF;
 RETURN NULL;
END $$;


--
-- Name: referral_recharge_purpose_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_recharge_purpose_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF EXISTS(SELECT 1 FROM referral_order_terms t WHERE t.order_id=NEW.order_id AND t.purpose<>'recharge') THEN RAISE EXCEPTION 'original referral purpose is immutable'; END IF;
 RETURN NEW;
END $$;


--
-- Name: referral_relation_birth_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_relation_birth_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 PERFORM pg_advisory_xact_lock(74973256);
 IF NEW.created_at<>transaction_timestamp() OR NOT EXISTS(SELECT 1 FROM merchants WHERE id=NEW.invited_id AND created_at=transaction_timestamp() AND enabled) OR
  NOT EXISTS(SELECT 1 FROM referral_tokens t JOIN referral_token_current c ON c.token_id=t.id AND c.merchant_id=t.merchant_id JOIN merchants p ON p.id=t.merchant_id
   WHERE t.id=NEW.token_id AND (t.merchant_id,t.version)=(NEW.promoter_id,NEW.token_version) AND t.enabled AND p.enabled AND t.expires_at>clock_timestamp()) OR
  EXISTS(WITH RECURSIVE ancestors(id,path) AS (
   SELECT NEW.promoter_id,ARRAY[NEW.promoter_id] UNION ALL
   SELECT r.promoter_id,a.path||r.promoter_id FROM referral_relations r JOIN ancestors a ON r.invited_id=a.id WHERE NOT r.promoter_id=ANY(a.path)
  ) SELECT 1 FROM ancestors WHERE id=NEW.invited_id)
 THEN RAISE EXCEPTION 'referral relation must be born with a new verified registration and a current promoter'; END IF;
 RETURN NEW;
END $$;


--
-- Name: referral_relation_complete_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_relation_complete_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM referral_relation_evidence WHERE id=NEW.id AND valid IS TRUE) OR NOT EXISTS(SELECT 1 FROM referral_tokens t JOIN referral_token_current c ON c.token_id=t.id WHERE t.id=NEW.token_id AND t.enabled AND t.expires_at>clock_timestamp()) THEN RAISE EXCEPTION 'referral relation lacks its verified registration and original audit'; END IF;RETURN NULL;
END $$;


--
-- Name: referral_reward_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_reward_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM referral_reward_invariants v WHERE v.reward_id=NEW.id AND v.valid IS TRUE) THEN RAISE EXCEPTION 'invalid original fee reward'; END IF;
 RETURN NULL;
END $$;


--
-- Name: referral_terms_birth_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_terms_birth_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE o orders;
BEGIN
 SELECT * INTO STRICT o FROM orders WHERE id=NEW.order_id FOR UPDATE;
 IF o.status<>'created' OR o.created_at<>transaction_timestamp() OR o.merchant_id<>NEW.merchant_id OR o.platform_fee<>NEW.platform_fee THEN RAISE EXCEPTION 'referral terms must be born with the original order'; END IF;
 IF (NEW.purpose='recharge') IS DISTINCT FROM EXISTS(SELECT 1 FROM recharge_intents i WHERE i.order_id=o.id) THEN RAISE EXCEPTION 'referral payment purpose mismatch'; END IF;
 IF NEW.relation_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM referral_relations r WHERE r.id=NEW.relation_id AND r.invited_id=o.merchant_id AND r.promoter_id=NEW.promoter_id) THEN RAISE EXCEPTION 'referral relation mismatch'; END IF;
 RETURN NEW;
END $$;


--
-- Name: referral_token_complete_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_token_complete_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE mid bigint; current_version bigint;
BEGIN
 mid:=NEW.merchant_id;
 SELECT version INTO current_version FROM referral_token_current WHERE merchant_id=mid;
 IF current_version IS NULL OR (SELECT count(*) FROM referral_tokens WHERE merchant_id=mid)<>current_version OR (SELECT max(version) FROM referral_tokens WHERE merchant_id=mid)<>current_version OR
  EXISTS(SELECT 1 FROM referral_tokens t WHERE t.merchant_id=mid AND NOT EXISTS(
   SELECT 1 FROM backoffice_audit b WHERE b.resource='referral-tokens' AND b.resource_id=t.id AND b.actor_role='merchant' AND b.actor_id=t.merchant_id AND b.actor_name=t.actor_name
    AND b.operation=CASE WHEN NOT t.enabled THEN 'revoke' WHEN t.version=1 THEN 'issue' ELSE 'rotate' END
    AND b.changes->>'version'=t.version::text AND b.changes->>'merchant_id'=t.merchant_id::text AND b.changes->>'enabled'=t.enabled::text))
 THEN RAISE EXCEPTION 'referral token lacks its owner audit and complete version history'; END IF;
 RETURN NULL;
END $$;


--
-- Name: referral_token_current_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.referral_token_current_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE r referral_tokens%ROWTYPE;
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'referral token current pointer cannot be removed'; END IF;
 SELECT * INTO STRICT r FROM referral_tokens WHERE id=NEW.token_id;
 IF (r.merchant_id,r.version) IS DISTINCT FROM (NEW.merchant_id,NEW.version) OR
  TG_OP='INSERT' AND NEW.version<>1 OR TG_OP='UPDATE' AND (NEW.merchant_id<>OLD.merchant_id OR NEW.version<>OLD.version+1)
 THEN RAISE EXCEPTION 'referral token version must advance exactly once'; END IF;
 IF NOT EXISTS(SELECT 1 FROM merchants WHERE id=NEW.merchant_id AND enabled) THEN RAISE EXCEPTION 'referral owner is unavailable'; END IF;
 RETURN NEW;
END $$;


--
-- Name: refund_allocation_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.refund_allocation_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_OP='INSERT' THEN
  IF NEW.merchant_amount IS NULL THEN NEW.merchant_amount:=NEW.amount; END IF;
  IF NEW.result_evidence_version<>2 THEN RAISE EXCEPTION 'new refund requires current result evidence'; END IF;
  RETURN NEW;
 END IF;
 IF (NEW.amount,NEW.merchant_amount,NEW.fee_amount,NEW.order_id,NEW.merchant_id,NEW.refund_no,NEW.result_evidence_version) IS DISTINCT FROM (OLD.amount,OLD.merchant_amount,OLD.fee_amount,OLD.order_id,OLD.merchant_id,OLD.refund_no,OLD.result_evidence_version) THEN RAISE EXCEPTION 'immutable refund allocation'; END IF;
 RETURN NEW;
END $$;


--
-- Name: refund_funding_birth_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.refund_funding_birth_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ DECLARE active bigint;BEGIN
 PERFORM id FROM orders WHERE id=NEW.order_id FOR UPDATE;SELECT id INTO active FROM order_income_holds WHERE order_id=NEW.order_id AND state='held';
 IF NEW.hold_id IS DISTINCT FROM active THEN RAISE EXCEPTION 'refund funding differs from original active hold';END IF;
 IF NEW.hold_id IS NOT NULL AND NEW.hold_amount>(SELECT h.amount::numeric-COALESCE(sum(x.hold_amount) FILTER(WHERE r.status<>'failed'),0) FROM order_income_holds h LEFT JOIN refund_fundings x ON x.hold_id=h.id LEFT JOIN refunds r ON r.id=x.refund_id WHERE h.id=NEW.hold_id GROUP BY h.id) THEN RAISE EXCEPTION 'refund exceeds own held principal';END IF;RETURN NEW;END $$;


--
-- Name: refund_merchant_reserve_valid(bigint); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.refund_merchant_reserve_valid(rid bigint) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT CASE WHEN f.refund_id IS NULL THEN r.funding_evidence_version=1 AND referral_clawback_journal_valid((SELECT id FROM journals WHERE event_key='refund:'||r.id||':reserve'),'refund:'||r.id||':reserve',av.id,rv.id,r.merchant_amount)
 ELSE (f.order_id,f.merchant_id,f.merchant_amount,f.fee_amount)=(r.order_id,r.merchant_id,r.merchant_amount,r.fee_amount)
 AND referral_clawback_journal_valid(f.available_reserve_journal_id,'refund:'||r.id||':reserve',av.id,f.reserve_account_id,f.available_amount)
 AND referral_clawback_journal_valid(f.hold_reserve_journal_id,'refund-hold:'||r.id||':reserve',h.account_id,f.reserve_account_id,f.hold_amount)
 END FROM refunds r LEFT JOIN refund_fundings f ON f.refund_id=r.id LEFT JOIN order_income_hold_fundings h ON h.hold_id=f.hold_id JOIN accounts av ON(av.owner_id,av.kind,av.scope_id)=(r.merchant_id,'available',0) JOIN accounts rv ON(rv.owner_id,rv.kind,rv.scope_id)=(r.merchant_id,'reserved',0) WHERE r.id=rid
$$;


--
-- Name: refund_merchant_resolution_valid(bigint); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.refund_merchant_resolution_valid(rid bigint) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT CASE WHEN r.status IN('pending','unknown') THEN NOT EXISTS(SELECT 1 FROM refund_funding_resolutions WHERE refund_id=r.id)
 WHEN f.refund_id IS NULL THEN r.funding_evidence_version=1 AND referral_clawback_journal_valid((SELECT id FROM journals WHERE event_key='refund:'||r.id||':resolve'),'refund:'||r.id||':resolve',rv.id,CASE WHEN r.status='failed' THEN av.id ELSE cl.id END,r.merchant_amount)
 ELSE z.state=r.status AND z.request_hash=f.request_hash AND
 CASE WHEN z.state='succeeded' THEN z.held_return_journal_id IS NULL AND z.available_return_journal_id IS NULL AND referral_clawback_journal_valid(z.consume_journal_id,'refund:'||r.id||':resolve',f.reserve_account_id,cl.id,r.merchant_amount)
 ELSE z.consume_journal_id IS NULL AND referral_clawback_journal_valid(z.held_return_journal_id,'refund-hold:'||r.id||':resolve',f.reserve_account_id,h.account_id,f.hold_amount) AND referral_clawback_journal_valid(z.available_return_journal_id,'refund:'||r.id||':resolve',f.reserve_account_id,av.id,f.available_amount) END
 END FROM refunds r LEFT JOIN refund_fundings f ON f.refund_id=r.id LEFT JOIN refund_funding_resolutions z ON z.refund_id=r.id LEFT JOIN order_income_hold_fundings h ON h.hold_id=f.hold_id JOIN accounts av ON(av.owner_id,av.kind,av.scope_id)=(r.merchant_id,'available',0) JOIN accounts rv ON(rv.owner_id,rv.kind,rv.scope_id)=(r.merchant_id,'reserved',0) JOIN accounts cl ON(cl.owner_id,cl.kind,cl.scope_id)=(0,'clearing',0) WHERE r.id=rid
$$;


--
-- Name: refund_required_result_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.refund_required_result_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NEW.result_evidence_version=2 AND NEW.status IN ('succeeded','failed') AND NOT EXISTS(SELECT 1 FROM provider_refund_result_invariants v WHERE v.refund_id=NEW.id AND v.valid IS TRUE) THEN RAISE EXCEPTION 'missing new refund terminal evidence'; END IF;
 RETURN NULL;
END $$;


--
-- Name: reject_baseline_repair_mutation(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.reject_baseline_repair_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN RAISE EXCEPTION 'immutable membership baseline repair evidence'; END $$;


--
-- Name: reject_ledger_mutation(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN RAISE EXCEPTION 'immutable financial record'; END $$;


--
-- Name: scan_cancellation_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.scan_cancellation_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_TABLE_NAME='scan_cancellation_claims' THEN
  IF NOT EXISTS(SELECT 1 FROM scan_recovery_origins o JOIN scan_recovery_eligibility e ON e.attempt_id=o.attempt_id JOIN scan_recovery_query_heads h ON h.attempt_id=e.attempt_id
      WHERE o.attempt_id=NEW.attempt_id AND o.proof_hash=NEW.source_hash AND e.proof_hash=NEW.eligibility_hash AND h.proof_hash=NEW.query_head_hash AND h.revision=12
      AND NEW.created_at>=o.created_at+interval '15 seconds' AND NEW.created_at<o.expires_at)
  OR (SELECT count(*) FROM backoffice_audit WHERE resource='scan-cancellations' AND resource_id=NEW.attempt_id)<>1
  OR NOT EXISTS(SELECT 1 FROM backoffice_audit WHERE resource='scan-cancellations' AND resource_id=NEW.attempt_id AND actor_role='system' AND actor_id=0 AND actor_name='scan-recovery' AND operation='claim'
      AND changes=jsonb_build_object('attempt_id',NEW.attempt_id::text,'proof',encode(NEW.proof_hash,'hex'),'query_head',encode(NEW.query_head_hash,'hex')))
  THEN RAISE EXCEPTION 'original barcode cancellation claim mismatch';END IF;
 ELSE
  IF NOT EXISTS(SELECT 1 FROM scan_cancellation_claims c JOIN scan_recovery_origins s ON s.attempt_id=c.attempt_id JOIN orders o ON o.id=s.order_id
      WHERE c.attempt_id=NEW.attempt_id AND c.proof_hash=NEW.claim_hash AND NEW.created_at>=c.created_at AND o.status=CASE WHEN NEW.state='cancelled' THEN 'closed' ELSE 'unknown' END)
  OR (SELECT count(*) FROM backoffice_audit WHERE resource='scan-cancellation-results' AND resource_id=NEW.attempt_id)<>1
  OR NOT EXISTS(SELECT 1 FROM backoffice_audit WHERE resource='scan-cancellation-results' AND resource_id=NEW.attempt_id AND actor_role='system' AND actor_id=0 AND actor_name='scan-recovery' AND operation=NEW.state
      AND changes=jsonb_build_object('attempt_id',NEW.attempt_id::text,'proof',encode(NEW.proof_hash,'hex'),'claim',encode(NEW.claim_hash,'hex')))
  THEN RAISE EXCEPTION 'original barcode cancellation result mismatch';END IF;
 END IF;
 RETURN NULL;
END $$;


--
-- Name: scan_recovery_eligibility_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.scan_recovery_eligibility_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM scan_recovery_origins o WHERE o.attempt_id=NEW.attempt_id AND o.proof_hash=NEW.source_hash AND NEW.created_at>=o.created_at AND NEW.created_at<o.expires_at)
 THEN RAISE EXCEPTION 'original barcode eligibility source mismatch';END IF;
 IF (SELECT count(*) FROM backoffice_audit WHERE resource='scan-recovery-eligibility' AND resource_id=NEW.attempt_id)<>1
 OR NOT EXISTS(SELECT 1 FROM backoffice_audit WHERE resource='scan-recovery-eligibility' AND resource_id=NEW.attempt_id AND actor_role='system' AND actor_id=0 AND actor_name='scan-recovery' AND operation='eligible'
 AND changes=jsonb_build_object('proof',encode(NEW.proof_hash,'hex'),'source',encode(NEW.source_hash,'hex')))
 OR NOT EXISTS(SELECT 1 FROM jobs WHERE event_key='scan-recover:'||NEW.attempt_id::text AND kind='payment.scan-recover' AND payload=jsonb_build_object('attempt_id',NEW.attempt_id::text))
 THEN RAISE EXCEPTION 'original barcode eligibility audit or job missing';END IF;
 RETURN NULL;
END $$;


--
-- Name: scan_recovery_origin_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.scan_recovery_origin_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS (
  SELECT 1 FROM provider_attempts p JOIN orders o ON o.id=p.order_id
  JOIN provider_attempt_identities i ON i.attempt_id=p.id
  JOIN provider_attempt_accounts a ON a.attempt_id=p.id
  WHERE p.id=NEW.attempt_id AND p.method='scan' AND p.channel_id=NEW.channel_id
   AND (o.id,o.merchant_id,o.trade_no,o.type,o.amount)=(NEW.order_id,NEW.merchant_id,NEW.trade_no,NEW.provider,NEW.amount)
   AND i.request_hash=NEW.request_identity_hash AND a.recovery_version=1 AND a.recovery_source_hash=NEW.proof_hash
 ) THEN RAISE EXCEPTION 'original barcode recovery source mismatch';END IF;
 IF (SELECT count(*) FROM backoffice_audit WHERE resource='scan-recovery-origins' AND resource_id=NEW.attempt_id)<>1
 OR (SELECT count(*) FROM backoffice_audit WHERE resource='scan-recovery-origins' AND resource_id=NEW.attempt_id
      AND actor_role='system' AND actor_id=0 AND actor_name='scan-recovery' AND operation='create'
      AND changes=jsonb_build_object('proof',encode(NEW.proof_hash,'hex'),'order_id',NEW.order_id::text))<>1
 THEN RAISE EXCEPTION 'missing original barcode recovery audit';END IF;
 RETURN NULL;
END $$;


--
-- Name: scan_recovery_query_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.scan_recovery_query_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_TABLE_NAME='scan_recovery_query_heads' THEN
  IF NOT EXISTS(SELECT 1 FROM scan_recovery_eligibility e WHERE e.attempt_id=NEW.attempt_id AND e.proof_hash=NEW.eligibility_hash)
  OR (NEW.revision>0 AND NOT EXISTS(SELECT 1 FROM scan_recovery_query_events e WHERE (e.id,e.attempt_id,e.revision,e.proof_hash)=(NEW.event_id,NEW.attempt_id,NEW.revision,NEW.event_hash)))
  THEN RAISE EXCEPTION 'original barcode query head mismatch';END IF;
 ELSE
  IF NOT EXISTS(SELECT 1 FROM jobs j WHERE j.id=NEW.job_id AND j.event_key='scan-recover:'||NEW.attempt_id::text AND j.kind='payment.scan-recover' AND j.payload=jsonb_build_object('attempt_id',NEW.attempt_id::text))
  OR (SELECT count(*) FROM backoffice_audit WHERE resource='scan-recovery-queries' AND resource_id=NEW.id)<>1
  OR NOT EXISTS(SELECT 1 FROM backoffice_audit WHERE resource='scan-recovery-queries' AND resource_id=NEW.id AND actor_role='system' AND actor_id=0 AND actor_name='scan-recovery' AND operation=NEW.kind
     AND changes=jsonb_build_object('attempt_id',NEW.attempt_id::text,'query_number',NEW.query_number::text,'kind',NEW.kind,'proof',encode(NEW.proof_hash,'hex')))
  THEN RAISE EXCEPTION 'original barcode query audit mismatch';END IF;
 END IF;
 RETURN NULL;
END $$;


--
-- Name: settlement_account_identity_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.settlement_account_identity_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF OLD.kind='settlement_reserve' AND (TG_OP='DELETE' OR NEW.owner_id<>OLD.owner_id OR NEW.kind<>OLD.kind OR NEW.scope_id<>OLD.scope_id) THEN RAISE EXCEPTION 'immutable settlement account identity'; END IF;
 RETURN CASE WHEN TG_OP='DELETE' THEN OLD ELSE NEW END;
END $$;


--
-- Name: settlement_auto_claim_complete(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.settlement_auto_claim_complete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
 IF NOT EXISTS(SELECT 1 FROM settlement_auto_claims c JOIN settlement_payouts p ON p.request_id=c.request_id JOIN settlement_plan_items i ON i.id=c.item_id JOIN settlement_plan_runs r ON r.id=i.run_id JOIN settlement_auto_authorizations a ON a.id=c.authorization_id
 WHERE c.request_id=NEW.request_id AND c.transaction_id=pg_current_xact_id() AND p.auto_authorization_id=a.id AND p.send_state='claimed' AND p.transfer_id=c.transfer_id
 AND (i.request_id,i.merchant_id,i.run_id,i.gross,i.fee,i.net)=(c.request_id,c.merchant_id,c.run_id,c.gross,c.fee,c.net) AND i.state='created'
 AND c.plan_id=r.plan_id AND c.business_date=r.business_date AND r.authorization_id=a.generation_authorization_id AND (r.plan_id,r.plan_revision)=(a.plan_id,a.plan_revision)
 AND EXISTS(SELECT 1 FROM settlement_payout_events e WHERE e.request_id=p.request_id AND e.action='claim' AND (e.actor_role,e.actor_id,e.actor_name)=('system',0::bigint,'settlement-auto')))
 THEN RAISE EXCEPTION 'automatic claim requires original run, payout and system audit';END IF;RETURN NULL;END $$;


--
-- Name: settlement_auto_head_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.settlement_auto_head_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE a settlement_auto_authorizations;
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'auto authority head cannot be erased';END IF;
 SELECT * INTO STRICT a FROM settlement_auto_authorizations WHERE id=NEW.authorization_id;
 IF a.plan_id<>NEW.plan_id THEN RAISE EXCEPTION 'auto authority plan mismatch';END IF;
 IF TG_OP='INSERT' THEN
  IF a.expected_authorization_id IS NOT NULL THEN RAISE EXCEPTION 'auto authority must begin with original version';END IF;
 ELSIF (NEW.plan_id<>OLD.plan_id OR a.expected_authorization_id IS DISTINCT FROM OLD.authorization_id) THEN
  RAISE EXCEPTION 'auto authority requires a fresh chained version';
 END IF;
 RETURN NEW;
END $$;


--
-- Name: settlement_auto_payout_source_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.settlement_auto_payout_source_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
 IF NEW.auto_authorization_id IS NOT DISTINCT FROM OLD.auto_authorization_id THEN RETURN NEW;END IF;
 IF OLD.auto_authorization_id IS NOT NULL OR OLD.send_state<>'unsent' OR NEW.send_state<>'claimed'
 OR NOT EXISTS(SELECT 1 FROM settlement_auto_claims c WHERE c.request_id=OLD.request_id AND c.transfer_id=OLD.transfer_id AND c.authorization_id=NEW.auto_authorization_id AND c.transaction_id=pg_current_xact_id())
 THEN RAISE EXCEPTION 'auto payout source requires exact original claim transaction';END IF;RETURN NEW;END $$;


--
-- Name: settlement_funding_deferred_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.settlement_funding_deferred_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE rid bigint;
BEGIN
 IF TG_TABLE_NAME='accounts' THEN IF NEW.kind<>'settlement_reserve' THEN RETURN NULL; END IF; rid:=NEW.scope_id;
 ELSIF TG_TABLE_NAME='ledger_entries' THEN SELECT scope_id INTO rid FROM accounts WHERE id=NEW.account_id AND kind='settlement_reserve'; IF rid IS NULL THEN RETURN NULL; END IF;
 ELSIF TG_TABLE_NAME='ledger_requests' THEN rid:=NEW.id; IF NOT EXISTS(SELECT 1 FROM settlement_fundings WHERE request_id=rid) THEN RETURN NULL; END IF;
 ELSE rid:=NEW.request_id; END IF;
 IF NOT EXISTS(SELECT 1 FROM settlement_funding_invariants WHERE request_id=rid AND valid) THEN RAISE EXCEPTION 'invalid settlement funding evidence'; END IF;
 RETURN NULL;
END $$;


--
-- Name: settlement_journal_matches(text, bigint, bigint, bigint); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.settlement_journal_matches(event text, debit_account bigint, credit_account bigint, value bigint) RETURNS boolean
    LANGUAGE sql STABLE
    AS $$
 SELECT value>0 AND EXISTS(SELECT 1 FROM journals j WHERE j.event_key=event
  AND (SELECT count(*)=2 FROM ledger_entries e WHERE e.journal_id=j.id)
  AND (SELECT COALESCE(sum(e.amount),0) FROM ledger_entries e WHERE e.journal_id=j.id AND e.account_id=debit_account)=-value
  AND (SELECT COALESCE(sum(e.amount),0) FROM ledger_entries e WHERE e.journal_id=j.id AND e.account_id=credit_account)=value);
$$;


--
-- Name: settlement_payout_cancel_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.settlement_payout_cancel_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM settlement_payouts p JOIN transfers t ON t.id=p.transfer_id JOIN provider_transfer_attempts a ON a.transfer_id=t.id WHERE p.request_id=NEW.request_id AND p.transfer_id=NEW.transfer_id AND p.send_state='cancelled' AND p.claimed_at IS NULL AND t.status='pending' AND a.state='processing' AND a.provider_transfer_no='') THEN RAISE EXCEPTION 'settlement cancellation requires proof unsent'; END IF;
 RETURN NEW;
END $$;


--
-- Name: settlement_payout_identity_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.settlement_payout_identity_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'immutable settlement payout'; END IF;
 IF ROW(NEW.request_id,NEW.transfer_id,NEW.channel_id,NEW.provider_kind,NEW.app_id,NEW.recipient_hash,NEW.gross_amount,NEW.net_amount,NEW.fee_amount,NEW.created_at) IS DISTINCT FROM ROW(OLD.request_id,OLD.transfer_id,OLD.channel_id,OLD.provider_kind,OLD.app_id,OLD.recipient_hash,OLD.gross_amount,OLD.net_amount,OLD.fee_amount,OLD.created_at) OR OLD.send_state<>'unsent' THEN RAISE EXCEPTION 'immutable settlement payout intent'; END IF;
 RETURN NEW;
END $$;


--
-- Name: settlement_plan_config_complete(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.settlement_plan_config_complete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE pid bigint; eid bigint; role text; aid bigint; aname text; v_resource text; v_op text;
BEGIN
 IF TG_TABLE_NAME='settlement_plans' THEN pid:=NEW.id;
 ELSIF TG_TABLE_NAME='settlement_plan_versions' THEN
  pid:=NEW.plan_id;eid:=NEW.id;role:='admin';aid:=NEW.actor_id;aname:=NEW.actor_name;v_resource:='settlement-plan-versions';v_op:='define';
 ELSIF TG_TABLE_NAME='settlement_plan_authorizations' THEN
  pid:=NEW.plan_id;eid:=NEW.id;role:='admin';aid:=NEW.actor_id;aname:=NEW.actor_name;v_resource:='settlement-plan-authorizations';v_op:='authorize';
 ELSIF TG_TABLE_NAME='settlement_plan_revocations' THEN
  pid:=NEW.plan_id;eid:=NEW.authorization_id;role:='admin';aid:=NEW.actor_id;aname:=NEW.actor_name;v_resource:='settlement-plan-authorizations';v_op:='revoke';
 ELSE
  eid:=NEW.id;role:='merchant';aid:=NEW.merchant_id;aname:=NEW.actor_name;v_resource:='settlement-schedule-preferences';v_op:='configure';
  IF NEW.recipient_config_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM settlement_recipient_configs c WHERE c.id=NEW.recipient_config_id AND c.merchant_id=NEW.merchant_id) THEN RAISE EXCEPTION 'foreign scheduled recipient'; END IF;
  IF NOT EXISTS(SELECT 1 FROM settlement_schedule_preference_heads h WHERE h.merchant_id=NEW.merchant_id AND h.revision>0) THEN RAISE EXCEPTION 'orphan settlement preference'; END IF;
 END IF;
 IF pid IS NOT NULL AND NOT EXISTS(SELECT 1 FROM settlement_plans p JOIN settlement_plan_versions v ON (v.plan_id,v.revision)=(p.id,p.revision) WHERE p.id=pid
  AND p.revision=(SELECT count(*) FROM settlement_plan_versions x WHERE x.plan_id=p.id)
  AND p.last_authorization_id IS NOT DISTINCT FROM (SELECT max(x.id) FROM settlement_plan_authorizations x WHERE x.plan_id=p.id)
  AND (NOT p.enabled OR EXISTS(SELECT 1 FROM settlement_plan_authorizations a WHERE a.id=p.last_authorization_id AND (a.plan_id,a.plan_revision)=(p.id,p.revision) AND NOT EXISTS(SELECT 1 FROM settlement_plan_revocations r WHERE r.authorization_id=a.id)))) THEN RAISE EXCEPTION 'incomplete settlement plan authorization'; END IF;
 IF eid IS NOT NULL AND NOT EXISTS(SELECT 1 FROM backoffice_audit a WHERE a.resource=v_resource AND a.resource_id=eid AND a.operation=v_op AND (a.actor_role,a.actor_id,a.actor_name)=(role,aid,aname)) THEN RAISE EXCEPTION 'missing settlement scheduling actor audit'; END IF;
 RETURN NULL;
END $$;


--
-- Name: settlement_plan_head_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.settlement_plan_head_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'immutable settlement plan identity'; END IF;
 IF TG_OP='INSERT' AND (NEW.revision<>1 OR NEW.enabled OR NEW.last_authorization_id IS NOT NULL) OR TG_OP='UPDATE' AND (NEW.id<>OLD.id OR NEW.created_at<>OLD.created_at OR NEW.revision NOT IN (OLD.revision,OLD.revision+1) OR NEW.revision<>OLD.revision AND NEW.enabled) THEN RAISE EXCEPTION 'invalid settlement plan head transition'; END IF;
 IF TG_OP='UPDATE' THEN
  IF NEW.last_authorization_id IS DISTINCT FROM OLD.last_authorization_id AND NOT EXISTS(
   SELECT 1 FROM settlement_plan_authorizations a WHERE a.id=NEW.last_authorization_id AND a.plan_id=NEW.id AND a.plan_revision=NEW.revision
   AND a.expected_authorization_id IS NOT DISTINCT FROM OLD.last_authorization_id AND a.created_at=transaction_timestamp()
   AND a.id=(SELECT max(x.id) FROM settlement_plan_authorizations x WHERE x.plan_id=NEW.id)
   AND EXISTS(SELECT 1 FROM backoffice_audit b WHERE b.resource='settlement-plan-authorizations' AND b.resource_id=a.id AND b.operation='authorize'
    AND (b.actor_role,b.actor_id,b.actor_name)=('admin',a.actor_id,a.actor_name) AND b.created_at=transaction_timestamp())
  ) THEN RAISE EXCEPTION 'settlement plan requires a fresh chained authority'; END IF;
  IF NEW.enabled AND NOT OLD.enabled AND NEW.last_authorization_id IS NOT DISTINCT FROM OLD.last_authorization_id THEN RAISE EXCEPTION 'old settlement authority cannot be rearmed'; END IF;
 END IF;
 RETURN NEW;
END $$;


--
-- Name: settlement_plan_item_complete(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.settlement_plan_item_complete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE iid bigint;
BEGIN
 IF TG_TABLE_NAME='ledger_requests' THEN
  SELECT settlement_plan_item_id INTO iid FROM ledger_requests WHERE id=NEW.id;
  IF iid IS NULL THEN
   IF EXISTS(SELECT 1 FROM ledger_request_events e WHERE e.request_id=NEW.id AND e.actor='system:settlement-scheduler') THEN RAISE EXCEPTION 'missing scheduled request source'; END IF;
   RETURN NULL;
  END IF;
  IF NOT EXISTS(SELECT 1 FROM settlement_plan_items i WHERE i.id=iid AND i.state='created' AND i.request_id=NEW.id) THEN RAISE EXCEPTION 'foreign scheduled request source'; END IF;
 ELSIF TG_TABLE_NAME='ledger_request_events' THEN
  IF NEW.actor<>'system:settlement-scheduler' THEN RETURN NULL; END IF;
  SELECT settlement_plan_item_id INTO iid FROM ledger_requests WHERE id=NEW.request_id;
  IF iid IS NULL THEN RAISE EXCEPTION 'missing scheduled request source'; END IF;
  IF NOT EXISTS(SELECT 1 FROM settlement_plan_items i WHERE i.id=iid AND i.state='created' AND i.request_id=NEW.request_id) THEN RAISE EXCEPTION 'foreign scheduled request source'; END IF;
 ELSIF TG_TABLE_NAME='settlement_plan_items' THEN iid:=NEW.id; ELSE iid:=NEW.item_id; END IF;
 IF NOT EXISTS(SELECT 1 FROM settlement_plan_item_invariants WHERE id=iid AND valid IS TRUE) THEN RAISE EXCEPTION 'incomplete scheduled settlement original funding'; END IF;
 RETURN NULL;
END $$;


--
-- Name: settlement_plan_request_birth(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.settlement_plan_request_birth() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NEW.settlement_plan_item_id IS NOT DISTINCT FROM OLD.settlement_plan_item_id THEN RETURN NEW; END IF;
 IF OLD.settlement_plan_item_id IS NOT NULL OR NEW.settlement_plan_item_id IS NULL OR NEW.kind<>'settlements' OR NEW.status<>'pending' OR NEW.created_at<transaction_timestamp()
 OR NOT EXISTS(SELECT 1 FROM journals j WHERE j.event_key='request:'||NEW.id::text||':reserve' AND j.created_at=transaction_timestamp())
 OR NOT EXISTS(SELECT 1 FROM ledger_request_events e WHERE e.request_id=NEW.id AND e.actor='system:settlement-scheduler' AND e.status='pending')
 THEN RAISE EXCEPTION 'scheduled request must originate in its reserve transaction'; END IF;
 RETURN NEW;
END $$;


--
-- Name: settlement_plan_run_complete(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.settlement_plan_run_complete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM settlement_plan_run_invariants v WHERE v.id=NEW.id AND v.valid IS TRUE)
 OR NOT EXISTS(SELECT 1 FROM jobs j WHERE j.event_key='settlement-plan-run:'||NEW.id::text AND j.kind='settlement-plan.generate' AND j.payload=jsonb_build_object('run_id',NEW.id::text))
 THEN RAISE EXCEPTION 'incomplete original settlement generation run'; END IF;
 RETURN NULL;
END $$;


--
-- Name: settlement_preference_head_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.settlement_preference_head_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_OP='DELETE' OR NOT EXISTS(SELECT 1 FROM settlement_schedule_preferences p WHERE p.id=NEW.preference_id AND (p.merchant_id,p.revision)=(NEW.merchant_id,NEW.revision))
 OR TG_OP='INSERT' AND NEW.revision<>1 OR TG_OP='UPDATE' AND (NEW.merchant_id<>OLD.merchant_id OR NEW.revision<>OLD.revision+1) THEN RAISE EXCEPTION 'invalid settlement preference revision'; END IF;
 RETURN NEW;
END $$;


--
-- Name: settlement_recipient_binding_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.settlement_recipient_binding_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM ledger_requests r JOIN settlement_recipient_configs c ON c.id=NEW.config_id AND c.merchant_id=r.merchant_id WHERE r.id=NEW.request_id AND r.kind='settlements' AND c.identity_hash=NEW.identity_hash) THEN RAISE EXCEPTION 'invalid settlement recipient binding'; END IF;
 RETURN NEW;
END $$;


--
-- Name: settlement_request_terms_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.settlement_request_terms_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM ledger_requests WHERE id=NEW.request_id AND kind='settlements' AND amount=NEW.gross_amount) THEN RAISE EXCEPTION 'settlement terms require original gross reservation'; END IF;
 RETURN NEW;
END $$;


--
-- Name: settlement_threshold_mode_family_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.settlement_threshold_mode_family_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
 IF EXISTS(SELECT 1 FROM settlement_plan_authorizations WHERE plan_id=NEW.plan_id)
 AND EXISTS(SELECT 1 FROM settlement_plan_authorizations a JOIN settlement_plan_versions v ON (v.plan_id,v.revision)=(a.plan_id,a.plan_revision) WHERE a.plan_id=NEW.plan_id AND v.mode<>NEW.mode)
 THEN RAISE EXCEPTION 'authorized settlement plan business mode is immutable';END IF;
 RETURN NEW;
END $$;


--
-- Name: settlement_threshold_run_source_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.settlement_threshold_run_source_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$ BEGIN
 IF TG_OP='DELETE' THEN RAISE EXCEPTION 'immutable settlement run';END IF;
 IF (to_jsonb(NEW)-ARRAY['threshold_source_version','threshold_source_hash','threshold_source_sequence']) IS DISTINCT FROM (to_jsonb(OLD)-ARRAY['threshold_source_version','threshold_source_hash','threshold_source_sequence'])
 OR OLD.threshold_source_version<>0 OR NEW.threshold_source_version<>1 OR OLD.threshold_source_hash IS NOT NULL
 OR EXISTS(SELECT 1 FROM settlement_plan_items WHERE run_id=OLD.id)
 OR NOT EXISTS(SELECT 1 FROM settlement_threshold_selections s JOIN settlement_plan_versions v ON (v.plan_id,v.revision)=(OLD.plan_id,OLD.plan_revision)
  WHERE s.run_id=OLD.id AND v.mode='balance_threshold' AND s.transaction_id=pg_current_xact_id() AND s.proof_hash=NEW.threshold_source_hash AND s.source_sequence=NEW.threshold_source_sequence)
 THEN RAISE EXCEPTION 'threshold source must originate once in its exact selection transaction';END IF;
 RETURN NEW;
END $$;


--
-- Name: settlement_threshold_selection_complete(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.settlement_threshold_selection_complete() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE rid bigint;
BEGIN
 IF TG_TABLE_NAME='settlement_plan_runs' THEN rid:=NEW.id;ELSE rid:=NEW.run_id;END IF;
 IF NOT EXISTS(SELECT 1 FROM settlement_plan_runs r JOIN settlement_plan_versions v ON (v.plan_id,v.revision)=(r.plan_id,r.plan_revision)
  WHERE r.id=rid AND (
   (r.threshold_source_version=0 AND NOT EXISTS(SELECT 1 FROM settlement_threshold_selections WHERE run_id=r.id)
    AND (v.mode<>'balance_threshold' OR NOT EXISTS(SELECT 1 FROM settlement_plan_items WHERE run_id=r.id)))
   OR (r.threshold_source_version=1 AND v.mode='balance_threshold' AND EXISTS(
    SELECT 1 FROM settlement_threshold_selections s JOIN settlement_plan_authorizations a ON a.id=r.authorization_id
    WHERE s.run_id=r.id AND s.proof_hash=r.threshold_source_hash AND s.source_sequence=r.threshold_source_sequence
    AND jsonb_array_length(s.snapshot->'candidates')=jsonb_array_length(a.scope_snapshot->'merchants')
    AND (SELECT count(*) FROM settlement_plan_items WHERE run_id=r.id)=jsonb_array_length(s.snapshot->'selected')
    AND NOT EXISTS(SELECT 1 FROM jsonb_array_elements(s.snapshot->'candidates') c WHERE NOT EXISTS(SELECT 1 FROM jsonb_array_elements(a.scope_snapshot->'merchants') m WHERE m->>'merchant_id'=c->>'merchant_id'))
    AND NOT EXISTS(SELECT 1 FROM jsonb_array_elements(a.scope_snapshot->'merchants') m WHERE NOT EXISTS(SELECT 1 FROM jsonb_array_elements(s.snapshot->'candidates') c WHERE c->>'merchant_id'=m->>'merchant_id'))
    AND (SELECT count(DISTINCT value) FROM jsonb_array_elements_text(s.snapshot->'selected'))=jsonb_array_length(s.snapshot->'selected')
    AND NOT EXISTS(SELECT 1 FROM jsonb_array_elements_text(s.snapshot->'selected') x WHERE NOT EXISTS(SELECT 1 FROM jsonb_array_elements(s.snapshot->'candidates') c WHERE c->>'merchant_id'=x.value))
    AND NOT EXISTS(SELECT 1 FROM jsonb_array_elements_text(s.snapshot->'selected') x WHERE NOT EXISTS(SELECT 1 FROM settlement_plan_items i WHERE i.run_id=r.id AND i.merchant_id::text=x.value))
    AND EXISTS(SELECT 1 FROM backoffice_audit b WHERE b.resource='settlement-threshold-selections' AND b.resource_id=r.id AND b.operation='select' AND (b.actor_role,b.actor_id,b.actor_name)=('system',0::bigint,'settlement-scheduler'))
   ))
  )) THEN RAISE EXCEPTION 'incomplete original threshold selection and run items';END IF;
 RETURN NULL;
END $$;


--
-- Name: settlement_transfer_funding_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.settlement_transfer_funding_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE rid bigint;
BEGIN
 IF TG_TABLE_NAME='transfers' THEN SELECT request_id INTO rid FROM settlement_payouts WHERE transfer_id=NEW.id;
 ELSE SELECT request_id INTO rid FROM settlement_payouts WHERE transfer_id=NEW.transfer_id; END IF;
 IF rid IS NOT NULL AND NOT EXISTS(SELECT 1 FROM settlement_funding_invariants WHERE request_id=rid AND valid) THEN RAISE EXCEPTION 'invalid settlement payout funding'; END IF;
 RETURN NULL;
END $$;


--
-- Name: transfer_attempt_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.transfer_attempt_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF (NEW.transfer_id,NEW.channel_id,NEW.recipient_cipher) IS DISTINCT FROM (OLD.transfer_id,OLD.channel_id,OLD.recipient_cipher) THEN RAISE EXCEPTION 'immutable transfer recipient and channel'; END IF;
 IF OLD.state IN ('succeeded','failed') AND (NEW.state,NEW.provider_transfer_no,NEW.pay_date) IS DISTINCT FROM (OLD.state,OLD.provider_transfer_no,OLD.pay_date) THEN RAISE EXCEPTION 'immutable terminal transfer outcome'; END IF;
 RETURN NEW;
END $$;


--
-- Name: transfer_batch_item_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.transfer_batch_item_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF (NEW.batch_id,NEW.position,NEW.transfer_id,NEW.provider_kind,NEW.app_id,NEW.bank_product) IS DISTINCT FROM (OLD.batch_id,OLD.position,OLD.transfer_id,OLD.provider_kind,OLD.app_id,OLD.bank_product) OR OLD.state<>'unsent' AND NEW IS DISTINCT FROM OLD THEN RAISE EXCEPTION 'immutable batch transfer identity/send barrier'; END IF;
 RETURN NEW;
END $$;


--
-- Name: transfer_proof_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.transfer_proof_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NEW.transfer_id<>OLD.transfer_id OR (OLD.file_id<>'' AND NEW.file_id<>OLD.file_id) THEN RAISE EXCEPTION 'immutable transfer proof identity'; END IF;
 IF OLD.state IN ('succeeded','failed') AND (NEW.state,NEW.file_id,NEW.download_cipher) IS DISTINCT FROM (OLD.state,OLD.file_id,OLD.download_cipher) THEN RAISE EXCEPTION 'immutable terminal transfer proof'; END IF;
 RETURN NEW;
END $$;


--
-- Name: transfer_resolution_time_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.transfer_resolution_time_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_OP='UPDATE' AND OLD.resolved_at IS NOT NULL AND NEW.resolved_at IS DISTINCT FROM OLD.resolved_at THEN RAISE EXCEPTION 'immutable transfer resolution time'; END IF;
 IF NEW.status IN ('succeeded','failed') AND NEW.resolved_at IS NULL THEN NEW.resolved_at:=now(); END IF;
 RETURN NEW;
END $$;


--
-- Name: transfer_snapshot_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.transfer_snapshot_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF TG_OP='INSERT' THEN
  IF NEW.biz_no IS NULL THEN NEW.biz_no:=NEW.id::text; END IF;
  IF NEW.cost_amount IS NULL THEN NEW.cost_amount:=NEW.amount; END IF;
  RETURN NEW;
 END IF;
 IF (NEW.merchant_id,NEW.transfer_no,NEW.amount,NEW.cost_amount,NEW.fee_amount,NEW.fee_rate_bps,NEW.biz_no) IS DISTINCT FROM (OLD.merchant_id,OLD.transfer_no,OLD.amount,OLD.cost_amount,OLD.fee_amount,OLD.fee_rate_bps,OLD.biz_no) THEN
 RAISE EXCEPTION 'immutable transfer identity and cost'; END IF; RETURN NEW;
END $$;


--
-- Name: transfer_unsent_cancel_proof_guard(); Type: FUNCTION; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE FUNCTION member72_1c1acaaf36d7e39a.transfer_unsent_cancel_proof_guard() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM transfer_batch_items i JOIN transfers t ON t.id=i.transfer_id JOIN provider_transfer_attempts a ON a.transfer_id=t.id WHERE i.transfer_id=NEW.transfer_id AND i.state='cancelled' AND i.claimed_at IS NULL AND t.status='pending' AND t.cost_amount=NEW.cost_amount AND a.state='processing' AND a.provider_transfer_no='') THEN RAISE EXCEPTION 'unsent cancellation proof does not match original send barrier'; END IF;
 RETURN NEW;
END $$;


--
-- Name: accounts; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.accounts (
    id bigint NOT NULL,
    owner_id bigint NOT NULL,
    kind text NOT NULL,
    balance bigint DEFAULT 0 NOT NULL,
    scope_id bigint DEFAULT 0 NOT NULL,
    CONSTRAINT accounts_check CHECK (((owner_id = 0) OR (balance >= 0))),
    CONSTRAINT accounts_kind_check CHECK ((kind = ANY (ARRAY['available'::text, 'reserved'::text, 'clearing'::text, 'deposit'::text, 'deposit_reserved'::text, 'fees'::text, 'fee_reserved'::text, 'bank_service_fee_hold'::text, 'bank_fee_expense'::text, 'order_income_hold'::text, 'settlement_reserve'::text, 'channel_sharing_reserve'::text, 'referral_clawback_reserve'::text, 'order_income_reserve'::text, 'order_income_refund_reserve'::text, 'referral_daily_pending'::text, 'referral_daily_refund_reserve'::text, 'membership_income'::text]))),
    CONSTRAINT accounts_scope_domain CHECK ((((kind = ANY (ARRAY['settlement_reserve'::text, 'channel_sharing_reserve'::text, 'order_income_reserve'::text, 'order_income_refund_reserve'::text])) AND (owner_id > 0) AND (scope_id > 0)) OR ((kind = ANY (ARRAY['referral_clawback_reserve'::text, 'referral_daily_pending'::text, 'referral_daily_refund_reserve'::text, 'membership_income'::text])) AND (owner_id = 0) AND (scope_id > 0)) OR ((kind <> ALL (ARRAY['settlement_reserve'::text, 'channel_sharing_reserve'::text, 'referral_clawback_reserve'::text, 'order_income_reserve'::text, 'order_income_refund_reserve'::text, 'referral_daily_pending'::text, 'referral_daily_refund_reserve'::text, 'membership_income'::text])) AND (scope_id = 0)))),
    CONSTRAINT bank_fee_accounts_domain CHECK ((((kind <> 'bank_service_fee_hold'::text) OR ((owner_id = 0) AND (balance >= 0))) AND ((kind <> 'bank_fee_expense'::text) OR ((owner_id = 0) AND (balance <= 0))))),
    CONSTRAINT membership_income_nonnegative CHECK (((kind <> 'membership_income'::text) OR (balance >= 0))),
    CONSTRAINT order_income_account_domain CHECK (((kind <> 'order_income_hold'::text) OR (owner_id > 0))),
    CONSTRAINT platform_fee_nonnegative CHECK (((kind <> ALL (ARRAY['fees'::text, 'fee_reserved'::text])) OR (balance >= 0))),
    CONSTRAINT referral_daily_nonnegative CHECK (((kind <> ALL (ARRAY['referral_daily_pending'::text, 'referral_daily_refund_reserve'::text])) OR (balance >= 0)))
);


--
-- Name: accounts_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.accounts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.accounts_id_seq OWNED BY member72_1c1acaaf36d7e39a.accounts.id;


--
-- Name: admin_funds_audit; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.admin_funds_audit (
    id bigint NOT NULL,
    username text NOT NULL,
    subject_id bigint NOT NULL,
    session_hash bytea NOT NULL,
    operation text NOT NULL,
    action_kind text DEFAULT ''::text NOT NULL,
    resource_id text DEFAULT ''::text NOT NULL,
    action_digest bytea,
    operation_key text DEFAULT ''::text NOT NULL,
    credential_epoch bigint DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT admin_funds_audit_session_hash_check CHECK ((octet_length(session_hash) = 32))
);


--
-- Name: admin_funds_audit_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.admin_funds_audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: admin_funds_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.admin_funds_audit_id_seq OWNED BY member72_1c1acaaf36d7e39a.admin_funds_audit.id;


--
-- Name: admin_funds_challenges; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.admin_funds_challenges (
    challenge_hash bytea NOT NULL,
    session_hash bytea NOT NULL,
    username text NOT NULL,
    subject_id bigint NOT NULL,
    auth_version bigint NOT NULL,
    credential_epoch bigint NOT NULL,
    action_kind text NOT NULL,
    resource_id text NOT NULL,
    action_digest bytea NOT NULL,
    created_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    confirmed_at timestamp with time zone,
    CONSTRAINT admin_funds_challenges_action_digest_check CHECK ((octet_length(action_digest) = 32)),
    CONSTRAINT admin_funds_challenges_challenge_hash_check CHECK ((octet_length(challenge_hash) = 32)),
    CONSTRAINT admin_funds_challenges_check CHECK (((expires_at > created_at) AND (expires_at <= (created_at + '00:02:00'::interval)))),
    CONSTRAINT admin_funds_challenges_session_hash_check CHECK ((octet_length(session_hash) = 32))
);


--
-- Name: admin_funds_credentials; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.admin_funds_credentials (
    username text NOT NULL,
    role text DEFAULT 'admin'::text NOT NULL,
    password_hash text NOT NULL,
    credential_epoch bigint DEFAULT 1 NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    updated_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT admin_funds_credentials_credential_epoch_check CHECK ((credential_epoch > 0)),
    CONSTRAINT admin_funds_credentials_password_hash_check CHECK ((password_hash ~~ '$argon2id$%'::text)),
    CONSTRAINT admin_funds_credentials_role_check CHECK ((role = 'admin'::text))
);


--
-- Name: admin_funds_grants; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.admin_funds_grants (
    grant_hash bytea NOT NULL,
    challenge_hash bytea NOT NULL,
    session_hash bytea NOT NULL,
    username text NOT NULL,
    subject_id bigint NOT NULL,
    auth_version bigint NOT NULL,
    credential_epoch bigint NOT NULL,
    action_kind text NOT NULL,
    resource_id text NOT NULL,
    action_digest bytea NOT NULL,
    created_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone,
    operation_key text,
    CONSTRAINT admin_funds_grants_action_digest_check CHECK ((octet_length(action_digest) = 32)),
    CONSTRAINT admin_funds_grants_check CHECK (((expires_at > created_at) AND (expires_at <= (created_at + '00:05:00'::interval)))),
    CONSTRAINT admin_funds_grants_check1 CHECK (((consumed_at IS NULL) = (operation_key IS NULL))),
    CONSTRAINT admin_funds_grants_grant_hash_check CHECK ((octet_length(grant_hash) = 32)),
    CONSTRAINT admin_funds_grants_session_hash_check CHECK ((octet_length(session_hash) = 32))
);


--
-- Name: admin_funds_throttle; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.admin_funds_throttle (
    key_hash bytea NOT NULL,
    window_start timestamp with time zone NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    failures integer DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT admin_funds_throttle_attempts_check CHECK ((attempts >= 0)),
    CONSTRAINT admin_funds_throttle_failures_check CHECK ((failures >= 0)),
    CONSTRAINT admin_funds_throttle_key_hash_check CHECK ((octet_length(key_hash) = 32))
);


--
-- Name: alipay_bank_bindings; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.alipay_bank_bindings (
    transfer_id bigint NOT NULL,
    product_code text DEFAULT 'TRANS_BANKCARD_NO_PWD'::text NOT NULL,
    request_digest bytea NOT NULL,
    submit_order_id text DEFAULT ''::text NOT NULL,
    submit_bound boolean DEFAULT false NOT NULL,
    estimated_fee_amount bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT alipay_bank_bindings_check CHECK (((NOT submit_bound) OR (submit_order_id <> ''::text))),
    CONSTRAINT alipay_bank_bindings_estimated_fee_amount_check CHECK ((estimated_fee_amount >= 0)),
    CONSTRAINT alipay_bank_bindings_product_code_check CHECK ((product_code = 'TRANS_BANKCARD_NO_PWD'::text)),
    CONSTRAINT alipay_bank_bindings_request_digest_check CHECK ((octet_length(request_digest) = 32))
);


--
-- Name: alipay_bank_observations; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.alipay_bank_observations (
    id bigint NOT NULL,
    transfer_id bigint NOT NULL,
    provider_state text NOT NULL,
    provider_transfer_no text NOT NULL,
    amount bigint,
    estimated_fee_amount bigint,
    result_state text NOT NULL,
    reason text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT alipay_bank_observations_amount_check CHECK ((amount > 0)),
    CONSTRAINT alipay_bank_observations_estimated_fee_amount_check CHECK ((estimated_fee_amount >= 0))
);


--
-- Name: alipay_bank_observations_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.alipay_bank_observations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: alipay_bank_observations_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.alipay_bank_observations_id_seq OWNED BY member72_1c1acaaf36d7e39a.alipay_bank_observations.id;


--
-- Name: application_authorization_code_claims; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.application_authorization_code_claims (
    issuer_app_id text NOT NULL,
    code_hash bytea NOT NULL,
    request_id text NOT NULL,
    claim_proof bytea NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT application_authorization_code_claims_claim_proof_check CHECK ((octet_length(claim_proof) = 32)),
    CONSTRAINT application_authorization_code_claims_code_hash_check CHECK ((octet_length(code_hash) = 32)),
    CONSTRAINT application_authorization_code_claims_issuer_app_id_check CHECK ((issuer_app_id ~ '^[0-9]{16}$'::text))
);


--
-- Name: application_authorization_events; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.application_authorization_events (
    id bigint NOT NULL,
    request_id text NOT NULL,
    operation text NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT application_authorization_events_operation_check CHECK ((operation = ANY (ARRAY['created'::text, 'authorized'::text, 'processing'::text, 'verified'::text, 'failed'::text, 'revealed'::text])))
);


--
-- Name: application_authorization_events_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.application_authorization_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: application_authorization_events_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.application_authorization_events_id_seq OWNED BY member72_1c1acaaf36d7e39a.application_authorization_events.id;


--
-- Name: application_authorization_requests; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.application_authorization_requests (
    id text NOT NULL,
    purpose text DEFAULT 'alipay_app_authorization'::text NOT NULL,
    merchant_id bigint NOT NULL,
    merchant_revision bigint NOT NULL,
    profile_id bigint NOT NULL,
    profile_revision bigint NOT NULL,
    issuer_app_id text NOT NULL,
    expected_auth_app_id text CONSTRAINT application_authorization_request_expected_auth_app_id_not_null NOT NULL,
    launch_kind text NOT NULL,
    app_types jsonb NOT NULL,
    profile_hash bytea NOT NULL,
    session_hash bytea NOT NULL,
    actor_username text NOT NULL,
    actor_role text NOT NULL,
    actor_id bigint NOT NULL,
    actor_auth_version bigint NOT NULL,
    authorization_hash bytea NOT NULL,
    source_proof bytea NOT NULL,
    state_hash bytea,
    browser_hash bytea,
    launch_proof bytea,
    status text DEFAULT 'pending'::text NOT NULL,
    result_cipher bytea,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    revealed_at timestamp with time zone,
    CONSTRAINT application_authorization_requests_actor_auth_version_check CHECK ((actor_auth_version > 0)),
    CONSTRAINT application_authorization_requests_actor_id_check CHECK ((actor_id > 0)),
    CONSTRAINT application_authorization_requests_actor_role_check CHECK ((actor_role = 'admin'::text)),
    CONSTRAINT application_authorization_requests_app_types_check CHECK ((jsonb_typeof(app_types) = 'array'::text)),
    CONSTRAINT application_authorization_requests_authorization_hash_check CHECK ((octet_length(authorization_hash) = 32)),
    CONSTRAINT application_authorization_requests_browser_hash_check CHECK ((octet_length(browser_hash) = 32)),
    CONSTRAINT application_authorization_requests_check CHECK (((expires_at > created_at) AND (expires_at <= (created_at + '00:05:00'::interval)))),
    CONSTRAINT application_authorization_requests_check1 CHECK ((((state_hash IS NULL) = (browser_hash IS NULL)) AND ((state_hash IS NULL) = (launch_proof IS NULL)))),
    CONSTRAINT application_authorization_requests_check2 CHECK (((status <> ALL (ARRAY['processing'::text, 'verified'::text, 'revealed'::text])) OR (state_hash IS NOT NULL))),
    CONSTRAINT application_authorization_requests_check3 CHECK (((status <> ALL (ARRAY['verified'::text, 'revealed'::text])) OR (result_cipher IS NOT NULL))),
    CONSTRAINT application_authorization_requests_check4 CHECK (((status = 'revealed'::text) = (revealed_at IS NOT NULL))),
    CONSTRAINT application_authorization_requests_check5 CHECK ((((launch_kind = 'basic'::text) AND (app_types = '[]'::jsonb)) OR ((launch_kind = 'assigned'::text) AND ((jsonb_array_length(app_types) >= 1) AND (jsonb_array_length(app_types) <= 5))))),
    CONSTRAINT application_authorization_requests_expected_auth_app_id_check CHECK ((expected_auth_app_id ~ '^[0-9]{16}$'::text)),
    CONSTRAINT application_authorization_requests_id_check CHECK ((id ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT application_authorization_requests_issuer_app_id_check CHECK ((issuer_app_id ~ '^[0-9]{16}$'::text)),
    CONSTRAINT application_authorization_requests_launch_kind_check CHECK ((launch_kind = ANY (ARRAY['basic'::text, 'assigned'::text]))),
    CONSTRAINT application_authorization_requests_launch_proof_check CHECK ((octet_length(launch_proof) = 32)),
    CONSTRAINT application_authorization_requests_merchant_revision_check CHECK ((merchant_revision > 0)),
    CONSTRAINT application_authorization_requests_profile_hash_check CHECK ((octet_length(profile_hash) = 32)),
    CONSTRAINT application_authorization_requests_profile_id_check CHECK ((profile_id > 0)),
    CONSTRAINT application_authorization_requests_profile_revision_check CHECK ((profile_revision > 0)),
    CONSTRAINT application_authorization_requests_purpose_check CHECK ((purpose = 'alipay_app_authorization'::text)),
    CONSTRAINT application_authorization_requests_session_hash_check CHECK ((octet_length(session_hash) = 32)),
    CONSTRAINT application_authorization_requests_source_proof_check CHECK ((octet_length(source_proof) = 32)),
    CONSTRAINT application_authorization_requests_state_hash_check CHECK ((octet_length(state_hash) = 32)),
    CONSTRAINT application_authorization_requests_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'processing'::text, 'verified'::text, 'failed'::text, 'revealed'::text])))
);


--
-- Name: authorization_remaining_claims; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.authorization_remaining_claims (
    order_id bigint NOT NULL,
    source_id bigint NOT NULL,
    source_revision bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    transaction_id xid8 DEFAULT pg_current_xact_id() NOT NULL,
    proof_hash bytea NOT NULL,
    CONSTRAINT authorization_remaining_claims_proof_hash_check CHECK ((octet_length(proof_hash) = 32))
);


--
-- Name: authorization_remaining_sources; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.authorization_remaining_sources (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    revision bigint NOT NULL,
    previous_id bigint,
    previous_hash bytea,
    observation_id text NOT NULL,
    terms jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    transaction_id xid8 DEFAULT pg_current_xact_id() NOT NULL,
    proof_hash bytea NOT NULL,
    CONSTRAINT authorization_remaining_sources_check CHECK ((((revision = 1) AND (previous_id IS NULL) AND (previous_hash IS NULL)) OR ((revision > 1) AND (previous_id IS NOT NULL) AND (previous_hash IS NOT NULL) AND (octet_length(previous_hash) = 32)))),
    CONSTRAINT authorization_remaining_sources_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT authorization_remaining_sources_revision_check CHECK (((revision >= 1) AND (revision <= 100))),
    CONSTRAINT authorization_remaining_sources_terms_check CHECK ((jsonb_typeof(terms) = 'object'::text))
);


--
-- Name: authorization_remaining_sources_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.authorization_remaining_sources_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: authorization_remaining_sources_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.authorization_remaining_sources_id_seq OWNED BY member72_1c1acaaf36d7e39a.authorization_remaining_sources.id;


--
-- Name: backoffice_audit; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.backoffice_audit (
    id bigint NOT NULL,
    actor_role text NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    resource text NOT NULL,
    resource_id bigint NOT NULL,
    operation text NOT NULL,
    changes jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: backoffice_audit_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.backoffice_audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: backoffice_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.backoffice_audit_id_seq OWNED BY member72_1c1acaaf36d7e39a.backoffice_audit.id;


--
-- Name: backoffice_records; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.backoffice_records (
    id bigint NOT NULL,
    resource text NOT NULL,
    owner_id bigint,
    body jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT backoffice_records_body_check CHECK ((jsonb_typeof(body) = 'object'::text)),
    CONSTRAINT backoffice_records_resource_check CHECK ((resource = ANY (ARRAY['groups'::text, 'domains'::text, 'invitation-codes'::text, 'announcements'::text, 'settings'::text, 'channels'::text, 'blacklist'::text, 'collection-styles'::text, 'profitsharing-rules'::text, 'pay-types'::text, 'pay-rolls'::text, 'weixin-apps'::text, 'onboarding-channels'::text, 'onboarding-applications'::text, 'subchannels'::text, 'merchant-risk'::text, 'complaints'::text, 'complaint-tasks'::text, 'risk-records'::text, 'cron-tasks'::text, 'settlement-settings'::text, 'collection-codes'::text, 'plugin-configs'::text, 'template-configs'::text, 'addon-configs'::text, 'order-subject-policies'::text])))
);


--
-- Name: backoffice_records_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.backoffice_records_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: backoffice_records_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.backoffice_records_id_seq OWNED BY member72_1c1acaaf36d7e39a.backoffice_records.id;


--
-- Name: bank_transfer_lifecycle; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.bank_transfer_lifecycle (
    transfer_id bigint NOT NULL,
    state text DEFAULT 'processing'::text NOT NULL,
    bank_fee_amount bigint,
    settled boolean DEFAULT false NOT NULL,
    return_observed boolean DEFAULT false NOT NULL,
    service_fee_held bigint DEFAULT 0 NOT NULL,
    returned_principal bigint DEFAULT 0 NOT NULL,
    returned_service_fee bigint DEFAULT 0 NOT NULL,
    returned_bank_fee bigint DEFAULT 0 NOT NULL,
    last_provider_state text DEFAULT ''::text NOT NULL,
    review_reason text DEFAULT ''::text NOT NULL,
    next_check_at timestamp with time zone,
    generation bigint DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    provider_kind text DEFAULT 'wxpay_v2'::text NOT NULL,
    CONSTRAINT bank_transfer_lifecycle_bank_fee_amount_check CHECK ((bank_fee_amount >= 0)),
    CONSTRAINT bank_transfer_lifecycle_generation_check CHECK ((generation >= 0)),
    CONSTRAINT bank_transfer_lifecycle_provider_kind_check CHECK ((provider_kind = ANY (ARRAY['wxpay_v2'::text, 'alipay_bankcard'::text]))),
    CONSTRAINT bank_transfer_lifecycle_returned_bank_fee_check CHECK ((returned_bank_fee >= 0)),
    CONSTRAINT bank_transfer_lifecycle_returned_principal_check CHECK ((returned_principal >= 0)),
    CONSTRAINT bank_transfer_lifecycle_returned_service_fee_check CHECK ((returned_service_fee >= 0)),
    CONSTRAINT bank_transfer_lifecycle_service_fee_held_check CHECK ((service_fee_held >= 0)),
    CONSTRAINT bank_transfer_lifecycle_state_check CHECK ((state = ANY (ARRAY['processing'::text, 'succeeded'::text, 'reversal_pending'::text, 'reversed'::text, 'failed'::text, 'cancelled'::text])))
);


--
-- Name: bank_transfer_observations; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.bank_transfer_observations (
    id bigint NOT NULL,
    transfer_id bigint NOT NULL,
    provider_state text NOT NULL,
    provider_transfer_no text NOT NULL,
    amount bigint NOT NULL,
    bank_fee_amount bigint,
    result_state text NOT NULL,
    reason text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT bank_transfer_observations_amount_check CHECK ((amount > 0)),
    CONSTRAINT bank_transfer_observations_bank_fee_amount_check CHECK ((bank_fee_amount >= 0))
);


--
-- Name: bank_transfer_observations_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.bank_transfer_observations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bank_transfer_observations_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.bank_transfer_observations_id_seq OWNED BY member72_1c1acaaf36d7e39a.bank_transfer_observations.id;


--
-- Name: case_comments; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.case_comments (
    id bigint NOT NULL,
    record_id bigint NOT NULL,
    actor_role text NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    content text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT case_comments_content_check CHECK (((length(content) >= 1) AND (length(content) <= 10000)))
);


--
-- Name: case_comments_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.case_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: case_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.case_comments_id_seq OWNED BY member72_1c1acaaf36d7e39a.case_comments.id;


--
-- Name: channel_sharing_completions; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.channel_sharing_completions (
    order_id bigint NOT NULL,
    sharing_id bigint NOT NULL,
    proof_kind text NOT NULL,
    expected_unsplit bigint NOT NULL,
    observed_remaining bigint,
    proof_hash bytea NOT NULL,
    release_amount bigint NOT NULL,
    release_journal_id bigint,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    CONSTRAINT channel_sharing_completions_check CHECK (((release_amount = 0) = (release_journal_id IS NULL))),
    CONSTRAINT channel_sharing_completions_check1 CHECK ((((proof_kind = 'wechat_remaining_zero'::text) AND (observed_remaining = 0) AND (observed_remaining IS NOT NULL)) OR ((proof_kind = 'alipay_royalty_finish'::text) AND (observed_remaining IS NULL)))),
    CONSTRAINT channel_sharing_completions_expected_unsplit_check CHECK ((expected_unsplit >= 0)),
    CONSTRAINT channel_sharing_completions_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT channel_sharing_completions_proof_kind_check CHECK ((proof_kind = ANY (ARRAY['wechat_remaining_zero'::text, 'alipay_royalty_finish'::text]))),
    CONSTRAINT channel_sharing_completions_release_amount_check CHECK ((release_amount >= 0))
);


--
-- Name: channel_sharing_finish_observations; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.channel_sharing_finish_observations (
    id bigint NOT NULL,
    finish_id bigint NOT NULL,
    fingerprint bytea NOT NULL,
    source text NOT NULL,
    provider_order_no text NOT NULL,
    state text NOT NULL,
    unsplit_amount bigint NOT NULL,
    actor_role text NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    CONSTRAINT channel_sharing_finish_observations_check CHECK (((source <> 'submit'::text) OR (state = 'pending'::text))),
    CONSTRAINT channel_sharing_finish_observations_fingerprint_check CHECK ((octet_length(fingerprint) = 32)),
    CONSTRAINT channel_sharing_finish_observations_provider_order_no_check CHECK (((length(provider_order_no) >= 1) AND (length(provider_order_no) <= 64))),
    CONSTRAINT channel_sharing_finish_observations_source_check CHECK ((source = ANY (ARRAY['submit'::text, 'query'::text]))),
    CONSTRAINT channel_sharing_finish_observations_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'succeeded'::text, 'failed'::text]))),
    CONSTRAINT channel_sharing_finish_observations_unsplit_amount_check CHECK ((unsplit_amount >= 0))
);


--
-- Name: channel_sharing_finishes; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.channel_sharing_finishes (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    external_no text NOT NULL,
    out_no text NOT NULL,
    provider_trade_no text NOT NULL,
    gross_amount bigint NOT NULL,
    merchant_net bigint NOT NULL,
    shared_amount bigint DEFAULT 0 NOT NULL,
    expected_unsplit bigint NOT NULL,
    release_amount bigint NOT NULL,
    request_hash bytea NOT NULL,
    original_sharing_id bigint,
    previous_finish_id bigint,
    state text DEFAULT 'unsent'::text NOT NULL,
    provider_order_no text DEFAULT ''::text NOT NULL,
    last_observation_id bigint,
    release_journal_id bigint,
    failure_proof bytea,
    actor_role text NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    actor_class text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    claimed_at timestamp with time zone,
    CONSTRAINT channel_sharing_finishes_actor_id_check CHECK ((actor_id > 0)),
    CONSTRAINT channel_sharing_finishes_actor_role_check CHECK ((actor_role = ANY (ARRAY['merchant'::text, 'admin'::text]))),
    CONSTRAINT channel_sharing_finishes_check CHECK (((expected_unsplit = (gross_amount - shared_amount)) AND (expected_unsplit > 0))),
    CONSTRAINT channel_sharing_finishes_check1 CHECK ((release_amount = (merchant_net - shared_amount))),
    CONSTRAINT channel_sharing_finishes_check2 CHECK (((state = 'unsent'::text) = (claimed_at IS NULL))),
    CONSTRAINT channel_sharing_finishes_check3 CHECK (((state = 'succeeded'::text) = (release_journal_id IS NOT NULL))),
    CONSTRAINT channel_sharing_finishes_check4 CHECK ((((state = 'failed'::text) AND (last_observation_id IS NULL)) = (failure_proof IS NOT NULL))),
    CONSTRAINT channel_sharing_finishes_external_no_check CHECK ((external_no ~ '^[A-Za-z0-9_-]{1,128}$'::text)),
    CONSTRAINT channel_sharing_finishes_failure_proof_check CHECK (((failure_proof IS NULL) OR (octet_length(failure_proof) = 32))),
    CONSTRAINT channel_sharing_finishes_gross_amount_check CHECK ((gross_amount > 0)),
    CONSTRAINT channel_sharing_finishes_merchant_net_check CHECK ((merchant_net > 0)),
    CONSTRAINT channel_sharing_finishes_out_no_check CHECK ((out_no ~ '^PF[a-f0-9]{30}$'::text)),
    CONSTRAINT channel_sharing_finishes_provider_order_no_check CHECK ((length(provider_order_no) <= 64)),
    CONSTRAINT channel_sharing_finishes_provider_trade_no_check CHECK (((length(provider_trade_no) >= 1) AND (length(provider_trade_no) <= 64))),
    CONSTRAINT channel_sharing_finishes_request_hash_check CHECK ((octet_length(request_hash) = 32)),
    CONSTRAINT channel_sharing_finishes_shared_amount_check CHECK ((shared_amount = 0)),
    CONSTRAINT channel_sharing_finishes_state_check CHECK ((state = ANY (ARRAY['unsent'::text, 'claimed'::text, 'pending'::text, 'unknown'::text, 'succeeded'::text, 'failed'::text])))
);


--
-- Name: channel_sharing_fundings; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.channel_sharing_fundings (
    order_id bigint NOT NULL,
    account_id bigint NOT NULL,
    amount bigint NOT NULL,
    reserve_journal_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    CONSTRAINT channel_sharing_fundings_amount_check CHECK ((amount > 0))
);


--
-- Name: channel_sharing_orders; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.channel_sharing_orders (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    external_no text NOT NULL,
    out_no text NOT NULL,
    provider_trade_no text NOT NULL,
    request_hash bytea NOT NULL,
    auto_finish boolean NOT NULL,
    receiver_count integer NOT NULL,
    state text DEFAULT 'unsent'::text NOT NULL,
    provider_order_no text DEFAULT ''::text NOT NULL,
    completed boolean DEFAULT false NOT NULL,
    last_observation_id bigint,
    failure_proof bytea,
    actor_role text NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    actor_class text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    claimed_at timestamp with time zone,
    CONSTRAINT channel_sharing_orders_actor_id_check CHECK ((actor_id > 0)),
    CONSTRAINT channel_sharing_orders_actor_role_check CHECK ((actor_role = ANY (ARRAY['admin'::text, 'merchant'::text]))),
    CONSTRAINT channel_sharing_orders_auto_finish_check CHECK (auto_finish),
    CONSTRAINT channel_sharing_orders_check CHECK (((state = 'unsent'::text) = (claimed_at IS NULL))),
    CONSTRAINT channel_sharing_orders_check1 CHECK (((NOT completed) OR (state = ANY (ARRAY['succeeded'::text, 'failed'::text, 'partial'::text])))),
    CONSTRAINT channel_sharing_orders_check2 CHECK (((state <> ALL (ARRAY['succeeded'::text, 'partial'::text])) OR completed)),
    CONSTRAINT channel_sharing_orders_check3 CHECK ((((state = 'failed'::text) AND (last_observation_id IS NULL)) = (failure_proof IS NOT NULL))),
    CONSTRAINT channel_sharing_orders_external_no_check CHECK ((external_no ~ '^[A-Za-z0-9_-]{1,128}$'::text)),
    CONSTRAINT channel_sharing_orders_failure_proof_check CHECK (((failure_proof IS NULL) OR (octet_length(failure_proof) = 32))),
    CONSTRAINT channel_sharing_orders_out_no_check CHECK ((out_no ~ '^PS[a-f0-9]{30}$'::text)),
    CONSTRAINT channel_sharing_orders_provider_order_no_check CHECK ((length(provider_order_no) <= 64)),
    CONSTRAINT channel_sharing_orders_provider_trade_no_check CHECK (((length(provider_trade_no) >= 1) AND (length(provider_trade_no) <= 64))),
    CONSTRAINT channel_sharing_orders_receiver_count_check CHECK (((receiver_count >= 1) AND (receiver_count <= 50))),
    CONSTRAINT channel_sharing_orders_request_hash_check CHECK ((octet_length(request_hash) = 32)),
    CONSTRAINT channel_sharing_orders_state_check CHECK ((state = ANY (ARRAY['unsent'::text, 'claimed'::text, 'pending'::text, 'unknown'::text, 'succeeded'::text, 'failed'::text, 'partial'::text])))
);


--
-- Name: journals; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.journals (
    id bigint NOT NULL,
    event_key text NOT NULL,
    description text NOT NULL,
    transaction_id xid8 DEFAULT pg_current_xact_id() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ledger_entries; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.ledger_entries (
    id bigint NOT NULL,
    journal_id bigint NOT NULL,
    account_id bigint NOT NULL,
    amount bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ledger_entries_amount_check CHECK ((amount <> 0))
);


--
-- Name: orders; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.orders (
    id bigint NOT NULL,
    trade_no text NOT NULL,
    merchant_id bigint NOT NULL,
    out_trade_no text NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    amount bigint NOT NULL,
    version text DEFAULT 'v1'::text NOT NULL,
    notify_url text DEFAULT ''::text NOT NULL,
    return_url text DEFAULT ''::text NOT NULL,
    param text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'created'::text NOT NULL,
    provider_event_id text,
    paid_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    fee_policy text DEFAULT 'none'::text NOT NULL,
    fee_rate_bps integer DEFAULT 0 NOT NULL,
    fee_group_id bigint DEFAULT 0 NOT NULL,
    merchant_amount bigint NOT NULL,
    platform_fee bigint DEFAULT 0 NOT NULL,
    refund_fee_payer text DEFAULT 'platform'::text NOT NULL,
    referral_source_version integer DEFAULT 0 NOT NULL,
    referral_source_hash bytea,
    CONSTRAINT order_fee_balanced CHECK (((merchant_amount >= 0) AND ((merchant_amount + platform_fee) = amount))),
    CONSTRAINT orders_amount_check CHECK ((amount > 0)),
    CONSTRAINT orders_fee_group_id_check CHECK ((fee_group_id >= 0)),
    CONSTRAINT orders_fee_policy_check CHECK ((fee_policy = ANY (ARRAY['none'::text, 'merchant_deduct'::text]))),
    CONSTRAINT orders_fee_rate_bps_check CHECK (((fee_rate_bps >= 0) AND (fee_rate_bps <= 10000))),
    CONSTRAINT orders_platform_fee_check CHECK ((platform_fee >= 0)),
    CONSTRAINT orders_referral_source_shape CHECK ((((referral_source_version = 0) AND (referral_source_hash IS NULL)) OR ((referral_source_version = 3) AND (referral_source_hash IS NOT NULL) AND (octet_length(referral_source_hash) = 32)))),
    CONSTRAINT orders_refund_fee_payer_check CHECK ((refund_fee_payer = ANY (ARRAY['platform'::text, 'merchant'::text]))),
    CONSTRAINT orders_status_check CHECK ((status = ANY (ARRAY['created'::text, 'submitting'::text, 'pending'::text, 'paid'::text, 'closed'::text, 'failed'::text, 'unknown'::text]))),
    CONSTRAINT orders_version_check CHECK ((version = ANY (ARRAY['v1'::text, 'v2'::text])))
);


--
-- Name: provider_attempt_sharing; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.provider_attempt_sharing (
    attempt_id bigint NOT NULL,
    order_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    method text NOT NULL,
    provider text NOT NULL,
    app_id text NOT NULL,
    product text NOT NULL,
    account_hash bytea NOT NULL,
    request_hash bytea NOT NULL,
    rule_id bigint,
    declared boolean NOT NULL,
    gross_amount bigint NOT NULL,
    merchant_net bigint NOT NULL,
    refund_mode text NOT NULL,
    auto_finish boolean NOT NULL,
    receiver_count integer NOT NULL,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    purpose text DEFAULT 'payment'::text NOT NULL,
    CONSTRAINT provider_attempt_sharing_account_hash_check CHECK ((octet_length(account_hash) = 32)),
    CONSTRAINT provider_attempt_sharing_app_id_check CHECK ((length(app_id) <= 256)),
    CONSTRAINT provider_attempt_sharing_channel_id_check CHECK ((channel_id > 0)),
    CONSTRAINT provider_attempt_sharing_check CHECK (((merchant_net >= 0) AND (merchant_net <= gross_amount))),
    CONSTRAINT provider_attempt_sharing_check1 CHECK (((declared AND (rule_id IS NOT NULL) AND (receiver_count > 0) AND (refund_mode = 'merchant_funded'::text) AND auto_finish AND (((provider = 'wxpay'::text) AND (product = 'wxpay_v3_direct'::text)) OR ((provider = 'alipay'::text) AND (product = 'alipay_direct'::text)))) OR ((NOT declared) AND (receiver_count = 0) AND (refund_mode = ''::text) AND (NOT auto_finish) AND (product = ''::text)))),
    CONSTRAINT provider_attempt_sharing_gross_amount_check CHECK ((gross_amount > 0)),
    CONSTRAINT provider_attempt_sharing_provider_check CHECK (((length(provider) >= 1) AND (length(provider) <= 32))),
    CONSTRAINT provider_attempt_sharing_purpose_check CHECK ((purpose = ANY (ARRAY['payment'::text, 'recharge'::text]))),
    CONSTRAINT provider_attempt_sharing_receiver_count_check CHECK (((receiver_count >= 0) AND (receiver_count <= 50))),
    CONSTRAINT provider_attempt_sharing_request_hash_check CHECK ((octet_length(request_hash) = 32))
);


--
-- Name: verified_payment_receipts; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.verified_payment_receipts (
    order_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    provider_trade_no text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT verified_payment_receipts_channel_id_check CHECK ((channel_id > 0)),
    CONSTRAINT verified_payment_receipts_provider_trade_no_check CHECK (((octet_length(provider_trade_no) >= 1) AND (octet_length(provider_trade_no) <= 256)))
);


--
-- Name: channel_sharing_finish_invariants; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.channel_sharing_finish_invariants AS
 SELECT p.id AS finish_id,
    p.order_id,
    (d.declared AND (d.purpose = 'payment'::text) AND (d.product = 'wxpay_v3_direct'::text) AND (o.status = 'paid'::text) AND ((p.merchant_id = o.merchant_id) AND (p.gross_amount = o.amount) AND (p.merchant_net = o.merchant_amount) AND (p.release_amount = f.amount) AND (p.shared_amount = 0) AND (p.expected_unsplit = o.amount)) AND ((a.owner_id = o.merchant_id) AND (a.kind = 'channel_sharing_reserve'::text) AND (a.scope_id = o.id)) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.verified_payment_receipts v
          WHERE ((v.order_id = o.id) AND (v.channel_id = d.channel_id) AND (v.provider_trade_no = p.provider_trade_no)))) AND (NOT (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.channel_sharing_completions
          WHERE (channel_sharing_completions.order_id = o.id)))) AND (((p.original_sharing_id IS NULL) AND (NOT (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.channel_sharing_orders
          WHERE (channel_sharing_orders.order_id = o.id))))) OR (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.channel_sharing_orders s
          WHERE ((s.id = p.original_sharing_id) AND (s.order_id = o.id) AND (s.state = 'failed'::text) AND (NOT s.completed) AND (s.last_observation_id IS NULL) AND (s.failure_proof IS NOT NULL))))) AND ((p.previous_finish_id IS NULL) OR (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.channel_sharing_finishes old
          WHERE ((old.id = p.previous_finish_id) AND (old.order_id = p.order_id) AND (old.id < p.id) AND (old.state = 'failed'::text))))) AND (p.state <> 'unsent'::text) AND (p.claimed_at IS NOT NULL) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.backoffice_audit b
          WHERE ((b.resource = 'channel-sharing-finishes'::text) AND (b.resource_id = p.id) AND (b.operation = 'submit'::text) AND ((b.changes ->> 'state'::text) = 'claimed'::text) AND ((b.actor_role = p.actor_role) AND (b.actor_id = p.actor_id) AND (b.actor_name = p.actor_name))))) AND (((p.last_observation_id IS NULL) AND (p.state = ANY (ARRAY['claimed'::text, 'unknown'::text, 'failed'::text])) AND (p.provider_order_no = ''::text)) OR (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.channel_sharing_finish_observations v
          WHERE ((v.id = p.last_observation_id) AND ((v.finish_id = p.id) AND (v.provider_order_no = p.provider_order_no) AND (v.state = p.state)))))) AND ((p.last_observation_id IS NOT NULL) OR (p.state = 'claimed'::text) OR (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.backoffice_audit b
          WHERE ((b.resource = 'channel-sharing-finishes'::text) AND (b.resource_id = p.id) AND (b.operation = 'submit-result'::text) AND ((b.changes ->> 'state'::text) = p.state) AND ((b.actor_role = p.actor_role) AND (b.actor_id = p.actor_id) AND (b.actor_name = p.actor_name)))))) AND ((p.last_observation_id IS NULL) OR (p.last_observation_id = ( SELECT max(v.id) AS max
           FROM member72_1c1acaaf36d7e39a.channel_sharing_finish_observations v
          WHERE (v.finish_id = p.id)))) AND (NOT (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.channel_sharing_finish_observations v
          WHERE ((v.finish_id = p.id) AND ((v.provider_order_no <> p.provider_order_no) OR ((v.state <> 'pending'::text) AND ((v.id IS DISTINCT FROM p.last_observation_id) OR (v.state <> p.state))) OR ((v.state = 'succeeded'::text) AND ((v.source <> 'query'::text) OR (v.unsplit_amount <> p.expected_unsplit))) OR ((v.state <> 'succeeded'::text) AND (v.unsplit_amount <> 0)) OR (NOT (EXISTS ( SELECT 1
                   FROM member72_1c1acaaf36d7e39a.backoffice_audit b
                  WHERE ((b.resource = 'channel-sharing-finishes'::text) AND (b.resource_id = p.id) AND (b.operation = (v.source || '-result'::text)) AND ((b.changes ->> 'state'::text) = v.state) AND ((b.actor_role = v.actor_role) AND (b.actor_id = v.actor_id) AND (b.actor_name = v.actor_name))))))))))) AND (((p.state <> 'succeeded'::text) AND (p.release_journal_id IS NULL)) OR (EXISTS ( SELECT 1
           FROM (member72_1c1acaaf36d7e39a.channel_sharing_finish_observations v
             JOIN member72_1c1acaaf36d7e39a.journals j ON ((j.id = p.release_journal_id)))
          WHERE ((v.id = p.last_observation_id) AND (v.source = 'query'::text) AND (v.state = 'succeeded'::text) AND (v.unsplit_amount = p.expected_unsplit) AND (j.event_key = (('channel-sharing-finish:'::text || (p.id)::text) || ':release'::text)) AND ( SELECT (count(*) = 2)
                   FROM member72_1c1acaaf36d7e39a.ledger_entries e
                  WHERE (e.journal_id = j.id)) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                   FROM member72_1c1acaaf36d7e39a.ledger_entries e
                  WHERE ((e.journal_id = j.id) AND (e.account_id = f.account_id))) = ((- p.release_amount))::numeric) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                   FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                     JOIN member72_1c1acaaf36d7e39a.accounts av ON ((av.id = e.account_id)))
                  WHERE ((e.journal_id = j.id) AND ((av.owner_id = p.merchant_id) AND (av.kind = 'available'::text) AND (av.scope_id = 0)))) = (p.release_amount)::numeric)))))) AS valid
   FROM ((((member72_1c1acaaf36d7e39a.channel_sharing_finishes p
     JOIN member72_1c1acaaf36d7e39a.channel_sharing_fundings f ON ((f.order_id = p.order_id)))
     JOIN member72_1c1acaaf36d7e39a.orders o ON ((o.id = p.order_id)))
     JOIN member72_1c1acaaf36d7e39a.provider_attempt_sharing d ON ((d.order_id = p.order_id)))
     JOIN member72_1c1acaaf36d7e39a.accounts a ON ((a.id = f.account_id)));


--
-- Name: channel_sharing_finish_observations_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.channel_sharing_finish_observations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: channel_sharing_finish_observations_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.channel_sharing_finish_observations_id_seq OWNED BY member72_1c1acaaf36d7e39a.channel_sharing_finish_observations.id;


--
-- Name: channel_sharing_finishes_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.channel_sharing_finishes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: channel_sharing_finishes_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.channel_sharing_finishes_id_seq OWNED BY member72_1c1acaaf36d7e39a.channel_sharing_finishes.id;


--
-- Name: channel_sharing_fund_releases; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.channel_sharing_fund_releases AS
 SELECT channel_sharing_completions.order_id,
    channel_sharing_completions.release_amount
   FROM member72_1c1acaaf36d7e39a.channel_sharing_completions
UNION ALL
 SELECT p.order_id,
    p.release_amount
   FROM member72_1c1acaaf36d7e39a.channel_sharing_finishes p
  WHERE ((p.state = 'succeeded'::text) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.channel_sharing_finish_invariants v
          WHERE ((v.finish_id = p.id) AND (v.valid IS TRUE)))));


--
-- Name: channel_sharing_order_items; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.channel_sharing_order_items (
    sharing_id bigint NOT NULL,
    "position" integer NOT NULL,
    receiver_id bigint NOT NULL,
    amount bigint NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    provider_detail_no text DEFAULT ''::text NOT NULL,
    failure_code text DEFAULT ''::text NOT NULL,
    last_observation_id bigint,
    paid_journal_id bigint,
    CONSTRAINT channel_sharing_order_items_amount_check CHECK ((amount > 0)),
    CONSTRAINT channel_sharing_order_items_check CHECK (((state = 'succeeded'::text) = (paid_journal_id IS NOT NULL))),
    CONSTRAINT channel_sharing_order_items_check1 CHECK (((state <> 'succeeded'::text) OR (length(provider_detail_no) > 0))),
    CONSTRAINT channel_sharing_order_items_failure_code_check CHECK ((length(failure_code) <= 256)),
    CONSTRAINT channel_sharing_order_items_position_check CHECK ((("position" >= 1) AND ("position" <= 50))),
    CONSTRAINT channel_sharing_order_items_provider_detail_no_check CHECK ((length(provider_detail_no) <= 64)),
    CONSTRAINT channel_sharing_order_items_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'succeeded'::text, 'failed'::text])))
);


--
-- Name: channel_sharing_funding_invariants; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.channel_sharing_funding_invariants AS
 SELECT f.order_id,
    (d.declared AND (o.status = 'paid'::text) AND (f.amount = d.merchant_net) AND (d.merchant_net = o.merchant_amount) AND ((a.owner_id = o.merchant_id) AND (a.kind = 'channel_sharing_reserve'::text) AND (a.scope_id = o.id)) AND (j.event_key = (('channel-sharing:'::text || (o.id)::text) || ':reserve'::text)) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.verified_payment_receipts p
          WHERE ((p.order_id = o.id) AND (p.channel_id = d.channel_id) AND (length(p.provider_trade_no) > 0)))) AND ((a.balance)::numeric = (((f.amount)::numeric - COALESCE(( SELECT sum(i.amount) AS sum
           FROM (member72_1c1acaaf36d7e39a.channel_sharing_order_items i
             JOIN member72_1c1acaaf36d7e39a.channel_sharing_orders s ON ((s.id = i.sharing_id)))
          WHERE ((s.order_id = o.id) AND (i.state = 'succeeded'::text))), (0)::numeric)) - ((COALESCE(c.release_amount, (0)::bigint) + COALESCE(pf.release_amount, (0)::bigint)))::numeric)) AND (( SELECT count(*) AS count
           FROM member72_1c1acaaf36d7e39a.ledger_entries e
          WHERE (e.account_id = a.id)) = ((1 + ( SELECT count(*) AS count
           FROM (member72_1c1acaaf36d7e39a.channel_sharing_order_items i
             JOIN member72_1c1acaaf36d7e39a.channel_sharing_orders s ON ((s.id = i.sharing_id)))
          WHERE ((s.order_id = o.id) AND (i.state = 'succeeded'::text)))) +
        CASE
            WHEN ((c.release_amount > 0) OR (pf.release_amount > 0)) THEN 1
            ELSE 0
        END)) AND ( SELECT (count(*) = 2)
           FROM member72_1c1acaaf36d7e39a.ledger_entries e
          WHERE (e.journal_id = j.id)) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
           FROM member72_1c1acaaf36d7e39a.ledger_entries e
          WHERE ((e.journal_id = j.id) AND (e.account_id = a.id))) = (f.amount)::numeric) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
           FROM (member72_1c1acaaf36d7e39a.ledger_entries e
             JOIN member72_1c1acaaf36d7e39a.accounts av ON ((av.id = e.account_id)))
          WHERE ((e.journal_id = j.id) AND ((av.owner_id = o.merchant_id) AND (av.kind = 'available'::text) AND (av.scope_id = 0)))) = ((- f.amount))::numeric) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.journals p
          WHERE ((p.event_key = ('payment:'::text || o.trade_no)) AND ( SELECT (count(*) = 2)
                   FROM member72_1c1acaaf36d7e39a.ledger_entries e
                  WHERE (e.journal_id = p.id)) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                   FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                     JOIN member72_1c1acaaf36d7e39a.accounts av ON ((av.id = e.account_id)))
                  WHERE ((e.journal_id = p.id) AND ((av.owner_id = o.merchant_id) AND (av.kind = 'available'::text) AND (av.scope_id = 0)))) = (f.amount)::numeric) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                   FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                     JOIN member72_1c1acaaf36d7e39a.accounts cl ON ((cl.id = e.account_id)))
                  WHERE ((e.journal_id = p.id) AND ((cl.owner_id = 0) AND (cl.kind = 'clearing'::text) AND (cl.scope_id = 0)))) = ((- f.amount))::numeric)))) AND (NOT (EXISTS ( SELECT 1
           FROM (member72_1c1acaaf36d7e39a.channel_sharing_order_items i
             JOIN member72_1c1acaaf36d7e39a.channel_sharing_orders s ON ((s.id = i.sharing_id)))
          WHERE ((s.order_id = o.id) AND (i.state = 'succeeded'::text) AND (NOT (EXISTS ( SELECT 1
                   FROM member72_1c1acaaf36d7e39a.journals q
                  WHERE ((q.id = i.paid_journal_id) AND (q.event_key = (((('channel-sharing:'::text || (s.id)::text) || ':receiver:'::text) || (i.receiver_id)::text) || ':paid'::text)) AND ( SELECT (count(*) = 2)
                           FROM member72_1c1acaaf36d7e39a.ledger_entries e
                          WHERE (e.journal_id = q.id)) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                           FROM member72_1c1acaaf36d7e39a.ledger_entries e
                          WHERE ((e.journal_id = q.id) AND (e.account_id = a.id))) = ((- i.amount))::numeric) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                           FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                             JOIN member72_1c1acaaf36d7e39a.accounts cl ON ((cl.id = e.account_id)))
                          WHERE ((e.journal_id = q.id) AND ((cl.owner_id = 0) AND (cl.kind = 'clearing'::text) AND (cl.scope_id = 0)))) = (i.amount)::numeric))))))))) AND (NOT ((c.order_id IS NOT NULL) AND (pf.order_id IS NOT NULL))) AND ((pf.order_id IS NULL) OR ((pf.state = 'succeeded'::text) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.channel_sharing_finish_invariants z
          WHERE ((z.finish_id = pf.id) AND (z.valid IS TRUE)))))) AND ((c.order_id IS NULL) OR (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.channel_sharing_orders s
          WHERE ((s.id = c.sharing_id) AND (s.order_id = o.id) AND s.completed AND s.auto_finish AND (((d.provider = 'wxpay'::text) AND (c.proof_kind = 'wechat_remaining_zero'::text)) OR ((d.provider = 'alipay'::text) AND (c.proof_kind = 'alipay_royalty_finish'::text))) AND ((c.release_amount)::numeric = ((f.amount)::numeric - COALESCE(( SELECT sum(i.amount) AS sum
                   FROM member72_1c1acaaf36d7e39a.channel_sharing_order_items i
                  WHERE ((i.sharing_id = s.id) AND (i.state = 'succeeded'::text))), (0)::numeric))) AND ((c.expected_unsplit)::numeric = ((d.gross_amount)::numeric - COALESCE(( SELECT sum(i.amount) AS sum
                   FROM member72_1c1acaaf36d7e39a.channel_sharing_order_items i
                  WHERE ((i.sharing_id = s.id) AND (i.state = 'succeeded'::text))), (0)::numeric))) AND ((c.release_amount = 0) OR (EXISTS ( SELECT 1
                   FROM member72_1c1acaaf36d7e39a.journals q
                  WHERE ((q.id = c.release_journal_id) AND (q.event_key = (('channel-sharing:'::text || (s.id)::text) || ':release'::text)) AND ( SELECT (count(*) = 2)
                           FROM member72_1c1acaaf36d7e39a.ledger_entries e
                          WHERE (e.journal_id = q.id)) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                           FROM member72_1c1acaaf36d7e39a.ledger_entries e
                          WHERE ((e.journal_id = q.id) AND (e.account_id = a.id))) = ((- c.release_amount))::numeric) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                           FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                             JOIN member72_1c1acaaf36d7e39a.accounts av ON ((av.id = e.account_id)))
                          WHERE ((e.journal_id = q.id) AND ((av.owner_id = o.merchant_id) AND (av.kind = 'available'::text) AND (av.scope_id = 0)))) = (c.release_amount)::numeric)))))))))) AS valid
   FROM ((((((member72_1c1acaaf36d7e39a.channel_sharing_fundings f
     JOIN member72_1c1acaaf36d7e39a.provider_attempt_sharing d ON ((d.order_id = f.order_id)))
     JOIN member72_1c1acaaf36d7e39a.orders o ON ((o.id = f.order_id)))
     JOIN member72_1c1acaaf36d7e39a.accounts a ON ((a.id = f.account_id)))
     JOIN member72_1c1acaaf36d7e39a.journals j ON ((j.id = f.reserve_journal_id)))
     LEFT JOIN member72_1c1acaaf36d7e39a.channel_sharing_completions c ON ((c.order_id = f.order_id)))
     LEFT JOIN member72_1c1acaaf36d7e39a.channel_sharing_finishes pf ON (((pf.order_id = f.order_id) AND (pf.state = 'succeeded'::text))));


--
-- Name: channel_sharing_observations; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.channel_sharing_observations (
    id bigint NOT NULL,
    sharing_id bigint NOT NULL,
    fingerprint bytea NOT NULL,
    source text NOT NULL,
    provider_order_no text NOT NULL,
    state text NOT NULL,
    items jsonb NOT NULL,
    actor_role text NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    CONSTRAINT channel_sharing_observations_fingerprint_check CHECK ((octet_length(fingerprint) = 32)),
    CONSTRAINT channel_sharing_observations_items_check CHECK (((jsonb_typeof(items) = 'array'::text) AND ((jsonb_array_length(items) >= 1) AND (jsonb_array_length(items) <= 50)))),
    CONSTRAINT channel_sharing_observations_provider_order_no_check CHECK ((length(provider_order_no) <= 64)),
    CONSTRAINT channel_sharing_observations_source_check CHECK ((source = ANY (ARRAY['submit'::text, 'query'::text]))),
    CONSTRAINT channel_sharing_observations_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'succeeded'::text, 'failed'::text, 'partial'::text])))
);


--
-- Name: channel_sharing_observations_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.channel_sharing_observations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: channel_sharing_observations_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.channel_sharing_observations_id_seq OWNED BY member72_1c1acaaf36d7e39a.channel_sharing_observations.id;


--
-- Name: channel_sharing_orders_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.channel_sharing_orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: channel_sharing_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.channel_sharing_orders_id_seq OWNED BY member72_1c1acaaf36d7e39a.channel_sharing_orders.id;


--
-- Name: channel_sharing_receiver_operations; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations (
    id bigint NOT NULL,
    receiver_id bigint NOT NULL,
    action text NOT NULL,
    out_no text NOT NULL,
    external_no text NOT NULL,
    request_hash bytea NOT NULL,
    state text DEFAULT 'unsent'::text NOT NULL,
    actor_role text NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    actor_class text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    claimed_at timestamp with time zone,
    relation_id bigint NOT NULL,
    source text DEFAULT 'remote'::text NOT NULL,
    reference_operation_id bigint,
    CONSTRAINT channel_sharing_receiver_operations_action_check CHECK ((action = ANY (ARRAY['bind'::text, 'unbind'::text]))),
    CONSTRAINT channel_sharing_receiver_operations_actor_id_check CHECK ((actor_id > 0)),
    CONSTRAINT channel_sharing_receiver_operations_actor_role_check CHECK ((actor_role = ANY (ARRAY['admin'::text, 'merchant'::text]))),
    CONSTRAINT channel_sharing_receiver_operations_check CHECK (((out_no ~ '^P[BU][a-f0-9]{30}$'::text) AND ("left"(out_no, 2) =
CASE
    WHEN (action = 'bind'::text) THEN 'PB'::text
    ELSE 'PU'::text
END))),
    CONSTRAINT channel_sharing_receiver_operations_check1 CHECK (((state = 'unsent'::text) = (claimed_at IS NULL))),
    CONSTRAINT channel_sharing_receiver_operations_external_no_check CHECK ((external_no ~ '^[A-Za-z0-9_-]{1,128}$'::text)),
    CONSTRAINT channel_sharing_receiver_operations_request_hash_check CHECK ((octet_length(request_hash) = 32)),
    CONSTRAINT channel_sharing_receiver_operations_source_check CHECK ((source = ANY (ARRAY['remote'::text, 'reference'::text]))),
    CONSTRAINT channel_sharing_receiver_operations_state_check CHECK ((state = ANY (ARRAY['unsent'::text, 'claimed'::text, 'succeeded'::text, 'failed'::text, 'unknown'::text]))),
    CONSTRAINT channel_sharing_reference_proof_shape CHECK ((((source = 'remote'::text) AND (reference_operation_id IS NULL)) OR ((source = 'reference'::text) AND (reference_operation_id IS NOT NULL))))
);


--
-- Name: channel_sharing_receiver_operations_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: channel_sharing_receiver_operations_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations_id_seq OWNED BY member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations.id;


--
-- Name: channel_sharing_receivers; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.channel_sharing_receivers (
    id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    external_no text NOT NULL,
    provider text NOT NULL,
    app_id text NOT NULL,
    product text NOT NULL,
    account_hash bytea NOT NULL,
    input_hash bytea NOT NULL,
    relation_account_hash bytea NOT NULL,
    relation_hash bytea NOT NULL,
    relation_auth_hash bytea NOT NULL,
    receiver_cipher bytea NOT NULL,
    state text DEFAULT 'draft'::text NOT NULL,
    last_operation_id bigint,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    CONSTRAINT channel_sharing_receivers_account_hash_check CHECK ((octet_length(account_hash) = 32)),
    CONSTRAINT channel_sharing_receivers_app_id_check CHECK (((length(app_id) >= 1) AND (length(app_id) <= 128))),
    CONSTRAINT channel_sharing_receivers_channel_id_check CHECK ((channel_id > 0)),
    CONSTRAINT channel_sharing_receivers_check CHECK ((((provider = 'wxpay'::text) AND (product = 'wxpay_v3_direct'::text)) OR ((provider = 'alipay'::text) AND (product = 'alipay_direct'::text)))),
    CONSTRAINT channel_sharing_receivers_external_no_check CHECK ((external_no ~ '^[A-Za-z0-9_-]{1,128}$'::text)),
    CONSTRAINT channel_sharing_receivers_input_hash_check CHECK ((octet_length(input_hash) = 32)),
    CONSTRAINT channel_sharing_receivers_product_check CHECK ((product = ANY (ARRAY['wxpay_v3_direct'::text, 'alipay_direct'::text]))),
    CONSTRAINT channel_sharing_receivers_provider_check CHECK ((provider = ANY (ARRAY['wxpay'::text, 'alipay'::text]))),
    CONSTRAINT channel_sharing_receivers_receiver_cipher_check CHECK (((octet_length(receiver_cipher) >= 28) AND (octet_length(receiver_cipher) <= 16384))),
    CONSTRAINT channel_sharing_receivers_relation_account_hash_check CHECK ((octet_length(relation_account_hash) = 32)),
    CONSTRAINT channel_sharing_receivers_relation_auth_hash_check CHECK ((octet_length(relation_auth_hash) = 32)),
    CONSTRAINT channel_sharing_receivers_relation_hash_check CHECK ((octet_length(relation_hash) = 32)),
    CONSTRAINT channel_sharing_receivers_state_check CHECK ((state = ANY (ARRAY['draft'::text, 'binding'::text, 'bound'::text, 'unbinding'::text, 'unbound'::text, 'unknown'::text])))
);


--
-- Name: channel_sharing_receivers_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.channel_sharing_receivers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: channel_sharing_receivers_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.channel_sharing_receivers_id_seq OWNED BY member72_1c1acaaf36d7e39a.channel_sharing_receivers.id;


--
-- Name: channel_sharing_relation_leases; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.channel_sharing_relation_leases (
    id bigint NOT NULL,
    relation_id bigint NOT NULL,
    receiver_id bigint NOT NULL,
    bind_operation_id bigint NOT NULL,
    released_by_operation_id bigint,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    released_at timestamp with time zone,
    CONSTRAINT channel_sharing_relation_leases_check CHECK (((released_by_operation_id IS NULL) = (released_at IS NULL)))
);


--
-- Name: channel_sharing_relation_leases_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.channel_sharing_relation_leases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: channel_sharing_relation_leases_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.channel_sharing_relation_leases_id_seq OWNED BY member72_1c1acaaf36d7e39a.channel_sharing_relation_leases.id;


--
-- Name: channel_sharing_relations; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.channel_sharing_relations (
    id bigint NOT NULL,
    relation_hash bytea NOT NULL,
    relation_auth_hash bytea NOT NULL,
    source_receiver_id bigint NOT NULL,
    state text DEFAULT 'unbound'::text NOT NULL,
    last_operation_id bigint,
    bound_operation_id bigint,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    CONSTRAINT channel_sharing_relations_relation_auth_hash_check CHECK ((octet_length(relation_auth_hash) = 32)),
    CONSTRAINT channel_sharing_relations_relation_hash_check CHECK ((octet_length(relation_hash) = 32)),
    CONSTRAINT channel_sharing_relations_state_check CHECK ((state = ANY (ARRAY['unbound'::text, 'binding'::text, 'bound'::text, 'unbinding'::text, 'unknown'::text])))
);


--
-- Name: channel_sharing_relations_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.channel_sharing_relations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: channel_sharing_relations_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.channel_sharing_relations_id_seq OWNED BY member72_1c1acaaf36d7e39a.channel_sharing_relations.id;


--
-- Name: channel_sharing_return_observations; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.channel_sharing_return_observations (
    id bigint NOT NULL,
    return_id bigint NOT NULL,
    fingerprint bytea NOT NULL,
    source text NOT NULL,
    provider_return_no text NOT NULL,
    state text NOT NULL,
    amount bigint NOT NULL,
    actor_role text NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    CONSTRAINT channel_sharing_return_observations_amount_check CHECK ((amount > 0)),
    CONSTRAINT channel_sharing_return_observations_fingerprint_check CHECK ((octet_length(fingerprint) = 32)),
    CONSTRAINT channel_sharing_return_observations_provider_return_no_check CHECK ((length(provider_return_no) <= 64)),
    CONSTRAINT channel_sharing_return_observations_source_check CHECK ((source = ANY (ARRAY['submit'::text, 'query'::text]))),
    CONSTRAINT channel_sharing_return_observations_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'succeeded'::text, 'failed'::text])))
);


--
-- Name: channel_sharing_returns; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.channel_sharing_returns (
    id bigint NOT NULL,
    sharing_id bigint NOT NULL,
    order_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    receiver_id bigint NOT NULL,
    external_no text NOT NULL,
    out_no text NOT NULL,
    amount bigint NOT NULL,
    request_hash bytea NOT NULL,
    failure_proof bytea,
    state text DEFAULT 'unsent'::text NOT NULL,
    provider_return_no text DEFAULT ''::text NOT NULL,
    last_observation_id bigint,
    paid_journal_id bigint,
    actor_role text NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    actor_class text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    claimed_at timestamp with time zone,
    CONSTRAINT channel_sharing_returns_actor_id_check CHECK ((actor_id > 0)),
    CONSTRAINT channel_sharing_returns_actor_role_check CHECK ((actor_role = ANY (ARRAY['admin'::text, 'merchant'::text]))),
    CONSTRAINT channel_sharing_returns_amount_check CHECK ((amount > 0)),
    CONSTRAINT channel_sharing_returns_check CHECK (((state = 'unsent'::text) = (claimed_at IS NULL))),
    CONSTRAINT channel_sharing_returns_check1 CHECK (((state = 'succeeded'::text) = (paid_journal_id IS NOT NULL))),
    CONSTRAINT channel_sharing_returns_check2 CHECK ((((state = 'failed'::text) AND (last_observation_id IS NULL)) = (failure_proof IS NOT NULL))),
    CONSTRAINT channel_sharing_returns_external_no_check CHECK ((external_no ~ '^[A-Za-z0-9_-]{1,128}$'::text)),
    CONSTRAINT channel_sharing_returns_failure_proof_check CHECK (((failure_proof IS NULL) OR (octet_length(failure_proof) = 32))),
    CONSTRAINT channel_sharing_returns_out_no_check CHECK ((out_no ~ '^PR[a-f0-9]{30}$'::text)),
    CONSTRAINT channel_sharing_returns_provider_return_no_check CHECK ((length(provider_return_no) <= 64)),
    CONSTRAINT channel_sharing_returns_request_hash_check CHECK ((octet_length(request_hash) = 32)),
    CONSTRAINT channel_sharing_returns_state_check CHECK ((state = ANY (ARRAY['unsent'::text, 'claimed'::text, 'unknown'::text, 'pending'::text, 'succeeded'::text, 'failed'::text])))
);


--
-- Name: channel_sharing_return_invariants; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.channel_sharing_return_invariants AS
 SELECT r.id AS return_id,
    ((s.order_id = r.order_id) AND (s.merchant_id = r.merchant_id) AND s.completed AND (c.order_id = r.order_id) AND (i.state = 'succeeded'::text) AND (i.paid_journal_id IS NOT NULL) AND (r.amount <= i.amount) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.channel_sharing_funding_invariants f
          WHERE ((f.order_id = r.order_id) AND (f.valid IS TRUE)))) AND (( SELECT COALESCE(sum(x.amount), (0)::numeric) AS "coalesce"
           FROM member72_1c1acaaf36d7e39a.channel_sharing_returns x
          WHERE ((x.sharing_id = r.sharing_id) AND (x.receiver_id = r.receiver_id) AND (x.state <> 'failed'::text))) <= (i.amount)::numeric) AND (( SELECT count(*) AS count
           FROM member72_1c1acaaf36d7e39a.channel_sharing_returns x
          WHERE ((x.sharing_id = r.sharing_id) AND (x.receiver_id = r.receiver_id) AND (x.state = ANY (ARRAY['unsent'::text, 'claimed'::text, 'unknown'::text, 'pending'::text])))) <= 1) AND (r.state <> 'unsent'::text) AND (r.claimed_at IS NOT NULL) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.backoffice_audit a
          WHERE ((a.resource = 'channel-sharing-returns'::text) AND (a.resource_id = r.id) AND (a.operation = 'submit'::text) AND ((a.changes ->> 'state'::text) = 'claimed'::text) AND ((a.actor_role = r.actor_role) AND (a.actor_id = r.actor_id) AND (a.actor_name = r.actor_name))))) AND (((r.last_observation_id IS NULL) AND (r.state = ANY (ARRAY['claimed'::text, 'unknown'::text, 'failed'::text])) AND (r.provider_return_no = ''::text) AND ((r.state <> 'failed'::text) OR (r.failure_proof IS NOT NULL)) AND ((r.state <> ALL (ARRAY['failed'::text, 'unknown'::text])) OR (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.backoffice_audit a
          WHERE ((a.resource = 'channel-sharing-returns'::text) AND (a.resource_id = r.id) AND (a.operation = 'submit-result'::text) AND ((a.changes ->> 'state'::text) = r.state) AND ((a.actor_role = r.actor_role) AND (a.actor_id = r.actor_id) AND (a.actor_name = r.actor_name))))))) OR (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.channel_sharing_return_observations v
          WHERE ((v.id = r.last_observation_id) AND ((v.return_id = r.id) AND (v.state = r.state) AND (v.amount = r.amount) AND (v.provider_return_no = r.provider_return_no)) AND (EXISTS ( SELECT 1
                   FROM member72_1c1acaaf36d7e39a.backoffice_audit a
                  WHERE ((a.resource = 'channel-sharing-returns'::text) AND (a.resource_id = r.id) AND (a.operation = (v.source || '-result'::text)) AND ((a.changes ->> 'state'::text) = v.state) AND ((a.actor_role = v.actor_role) AND (a.actor_id = v.actor_id) AND (a.actor_name = v.actor_name))))))))) AND (((r.state <> 'succeeded'::text) AND (r.paid_journal_id IS NULL)) OR (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.journals j
          WHERE ((j.id = r.paid_journal_id) AND (j.event_key = (('channel-sharing-return:'::text || (r.id)::text) || ':paid'::text)) AND ( SELECT (count(*) = 2)
                   FROM member72_1c1acaaf36d7e39a.ledger_entries e
                  WHERE (e.journal_id = j.id)) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                   FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                     JOIN member72_1c1acaaf36d7e39a.accounts a ON ((a.id = e.account_id)))
                  WHERE ((e.journal_id = j.id) AND ((a.owner_id = 0) AND (a.kind = 'clearing'::text) AND (a.scope_id = 0)))) = ((- r.amount))::numeric) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                   FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                     JOIN member72_1c1acaaf36d7e39a.accounts a ON ((a.id = e.account_id)))
                  WHERE ((e.journal_id = j.id) AND ((a.owner_id = r.merchant_id) AND (a.kind = 'available'::text) AND (a.scope_id = 0)))) = (r.amount)::numeric)))))) AS valid
   FROM (((member72_1c1acaaf36d7e39a.channel_sharing_returns r
     JOIN member72_1c1acaaf36d7e39a.channel_sharing_orders s ON ((s.id = r.sharing_id)))
     JOIN member72_1c1acaaf36d7e39a.channel_sharing_order_items i ON (((i.sharing_id = r.sharing_id) AND (i.receiver_id = r.receiver_id))))
     JOIN member72_1c1acaaf36d7e39a.channel_sharing_completions c ON ((c.sharing_id = s.id)));


--
-- Name: channel_sharing_return_observations_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.channel_sharing_return_observations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: channel_sharing_return_observations_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.channel_sharing_return_observations_id_seq OWNED BY member72_1c1acaaf36d7e39a.channel_sharing_return_observations.id;


--
-- Name: channel_sharing_returns_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.channel_sharing_returns_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: channel_sharing_returns_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.channel_sharing_returns_id_seq OWNED BY member72_1c1acaaf36d7e39a.channel_sharing_returns.id;


--
-- Name: channel_sharing_rule_current; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.channel_sharing_rule_current (
    merchant_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    rule_id bigint NOT NULL,
    CONSTRAINT channel_sharing_rule_current_channel_id_check CHECK ((channel_id > 0))
);


--
-- Name: channel_sharing_rule_items; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.channel_sharing_rule_items (
    rule_id bigint NOT NULL,
    "position" integer NOT NULL,
    receiver_id bigint NOT NULL,
    mode text NOT NULL,
    rate_bps bigint DEFAULT 0 NOT NULL,
    fixed_amount bigint DEFAULT 0 NOT NULL,
    CONSTRAINT channel_sharing_rule_items_check CHECK ((((mode = 'rate'::text) AND ((rate_bps >= 1) AND (rate_bps <= 10000)) AND (fixed_amount = 0)) OR ((mode = 'fixed'::text) AND ((fixed_amount >= 1) AND (fixed_amount <= '999999999999'::bigint)) AND (rate_bps = 0)))),
    CONSTRAINT channel_sharing_rule_items_position_check CHECK ((("position" >= 1) AND ("position" <= 50)))
);


--
-- Name: channel_sharing_rules; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.channel_sharing_rules (
    id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    revision bigint NOT NULL,
    provider text NOT NULL,
    app_id text NOT NULL,
    product text NOT NULL,
    account_hash bytea NOT NULL,
    input_hash bytea NOT NULL,
    enabled boolean NOT NULL,
    minimum_amount bigint NOT NULL,
    methods jsonb NOT NULL,
    refund_mode text NOT NULL,
    auto_finish boolean NOT NULL,
    receiver_count integer NOT NULL,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    CONSTRAINT channel_sharing_rules_account_hash_check CHECK ((octet_length(account_hash) = 32)),
    CONSTRAINT channel_sharing_rules_app_id_check CHECK (((length(app_id) >= 1) AND (length(app_id) <= 128))),
    CONSTRAINT channel_sharing_rules_auto_finish_check CHECK (auto_finish),
    CONSTRAINT channel_sharing_rules_channel_id_check CHECK ((channel_id > 0)),
    CONSTRAINT channel_sharing_rules_check CHECK ((((provider = 'wxpay'::text) AND (product = 'wxpay_v3_direct'::text)) OR ((provider = 'alipay'::text) AND (product = 'alipay_direct'::text)))),
    CONSTRAINT channel_sharing_rules_input_hash_check CHECK ((octet_length(input_hash) = 32)),
    CONSTRAINT channel_sharing_rules_methods_check CHECK (((jsonb_typeof(methods) = 'array'::text) AND ((jsonb_array_length(methods) >= 1) AND (jsonb_array_length(methods) <= 10)))),
    CONSTRAINT channel_sharing_rules_minimum_amount_check CHECK (((minimum_amount >= 0) AND (minimum_amount <= '999999999999'::bigint))),
    CONSTRAINT channel_sharing_rules_receiver_count_check CHECK (((receiver_count >= 1) AND (receiver_count <= 50))),
    CONSTRAINT channel_sharing_rules_refund_mode_check CHECK ((refund_mode = 'merchant_funded'::text)),
    CONSTRAINT channel_sharing_rules_revision_check CHECK ((revision > 0))
);


--
-- Name: channel_sharing_rules_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.channel_sharing_rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: channel_sharing_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.channel_sharing_rules_id_seq OWNED BY member72_1c1acaaf36d7e39a.channel_sharing_rules.id;


--
-- Name: channel_stop_events; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.channel_stop_events (
    id bigint NOT NULL,
    channel_id bigint NOT NULL,
    revision bigint NOT NULL,
    previous_id bigint,
    previous_hash bytea,
    action text NOT NULL,
    request_id bigint NOT NULL,
    transfer_id bigint NOT NULL,
    claim_sequence bigint NOT NULL,
    receipt jsonb NOT NULL,
    account_hash bytea NOT NULL,
    actor_role text NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    actor_class text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    transaction_id xid8 DEFAULT pg_current_xact_id() NOT NULL,
    proof_hash bytea NOT NULL,
    CONSTRAINT channel_stop_events_account_hash_check CHECK ((octet_length(account_hash) = 32)),
    CONSTRAINT channel_stop_events_action_check CHECK ((action = ANY (ARRAY['pause'::text, 'resume'::text]))),
    CONSTRAINT channel_stop_events_channel_id_check CHECK ((channel_id > 0)),
    CONSTRAINT channel_stop_events_check CHECK ((((revision = 1) AND (previous_id IS NULL) AND (previous_hash IS NULL) AND (action = 'pause'::text)) OR ((revision > 1) AND (previous_id IS NOT NULL) AND (previous_hash IS NOT NULL) AND (octet_length(previous_hash) = 32)))),
    CONSTRAINT channel_stop_events_check1 CHECK ((((action = 'pause'::text) AND (actor_role = 'system'::text) AND (actor_id = 0) AND (actor_name = 'settlement-auto'::text) AND (actor_class = ''::text)) OR ((action = 'resume'::text) AND (actor_role = 'admin'::text) AND (actor_id > 0) AND (actor_name <> ''::text) AND (actor_class = 'super'::text)))),
    CONSTRAINT channel_stop_events_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT channel_stop_events_receipt_check CHECK ((jsonb_typeof(receipt) = 'object'::text)),
    CONSTRAINT channel_stop_events_revision_check CHECK (((revision >= 1) AND (revision <= 4096)))
);


--
-- Name: channel_stop_events_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.channel_stop_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: channel_stop_events_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.channel_stop_events_id_seq OWNED BY member72_1c1acaaf36d7e39a.channel_stop_events.id;


--
-- Name: channel_stop_heads; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.channel_stop_heads (
    channel_id bigint NOT NULL,
    event_id bigint NOT NULL,
    revision bigint NOT NULL,
    proof_hash bytea NOT NULL,
    CONSTRAINT channel_stop_heads_channel_id_check CHECK ((channel_id > 0)),
    CONSTRAINT channel_stop_heads_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT channel_stop_heads_revision_check CHECK (((revision >= 1) AND (revision <= 4096)))
);


--
-- Name: channel_stop_notice_claims; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.channel_stop_notice_claims (
    event_id bigint NOT NULL,
    job_id bigint NOT NULL,
    recipient_hash bytea NOT NULL,
    lease_hash bytea NOT NULL,
    created_at timestamp with time zone NOT NULL,
    transaction_id xid8 DEFAULT pg_current_xact_id() NOT NULL,
    proof_hash bytea NOT NULL,
    route_version smallint DEFAULT 0 NOT NULL,
    route_mode text DEFAULT ''::text NOT NULL,
    route_scope_hash bytea,
    route_hash bytea,
    CONSTRAINT channel_notice_route_shape CHECK ((((route_version = 0) AND (route_mode = ''::text) AND (route_scope_hash IS NULL) AND (route_hash IS NULL)) OR ((route_version = 1) AND (route_mode = ANY (ARRAY['smtp'::text, 'robot'::text, 'telegram'::text, 'qqbot'::text])) AND (route_scope_hash IS NOT NULL) AND (octet_length(route_scope_hash) = 32) AND (route_hash IS NOT NULL) AND (octet_length(route_hash) = 32)))),
    CONSTRAINT channel_stop_notice_claims_lease_hash_check CHECK ((octet_length(lease_hash) = 32)),
    CONSTRAINT channel_stop_notice_claims_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT channel_stop_notice_claims_recipient_hash_check CHECK ((octet_length(recipient_hash) = 32))
);


--
-- Name: console_login_audit; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.console_login_audit (
    id bigint NOT NULL,
    username text NOT NULL,
    role text NOT NULL,
    ip text NOT NULL,
    success boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT console_login_audit_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'merchant'::text])))
);


--
-- Name: console_login_audit_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.console_login_audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: console_login_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.console_login_audit_id_seq OWNED BY member72_1c1acaaf36d7e39a.console_login_audit.id;


--
-- Name: console_login_throttle; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.console_login_throttle (
    key_hash bytea NOT NULL,
    window_start timestamp with time zone NOT NULL,
    attempts integer NOT NULL,
    updated_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    CONSTRAINT console_login_throttle_attempts_check CHECK ((attempts > 0)),
    CONSTRAINT console_login_throttle_key_hash_check CHECK ((octet_length(key_hash) = 32))
);


--
-- Name: console_mfa; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.console_mfa (
    username text NOT NULL,
    role text NOT NULL,
    secret bytea,
    pending_secret bytea,
    pending_until timestamp with time zone,
    last_counter bigint DEFAULT '-1'::integer NOT NULL
);


--
-- Name: console_session_issuers; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.console_session_issuers (
    token_hash bytea NOT NULL,
    issuer_session_hash bytea NOT NULL,
    issuer_username text NOT NULL,
    issuer_id bigint NOT NULL,
    issuer_auth_version bigint NOT NULL,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    CONSTRAINT console_session_issuers_issuer_session_hash_check CHECK ((octet_length(issuer_session_hash) = 32))
);


--
-- Name: console_sessions; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.console_sessions (
    token_hash bytea NOT NULL,
    username text NOT NULL,
    role text NOT NULL,
    subject_id bigint NOT NULL,
    csrf text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    auth_version bigint NOT NULL,
    CONSTRAINT console_sessions_token_hash_check CHECK ((octet_length(token_hash) = 32))
);


--
-- Name: console_sso_grants; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.console_sso_grants (
    grant_hash bytea NOT NULL,
    issuer_session_hash bytea NOT NULL,
    issuer_username text NOT NULL,
    issuer_id bigint NOT NULL,
    issuer_auth_version bigint NOT NULL,
    target_username text NOT NULL,
    target_id bigint NOT NULL,
    target_auth_version bigint NOT NULL,
    expires_at timestamp with time zone DEFAULT (statement_timestamp() + '00:01:00'::interval) NOT NULL,
    consumed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    CONSTRAINT console_sso_grants_check CHECK (((expires_at > created_at) AND (expires_at <= (created_at + '00:01:00'::interval)))),
    CONSTRAINT console_sso_grants_grant_hash_check CHECK ((octet_length(grant_hash) = 32)),
    CONSTRAINT console_sso_grants_issuer_session_hash_check CHECK ((octet_length(issuer_session_hash) = 32))
);


--
-- Name: console_subject_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.console_subject_seq
    START WITH 10000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: console_users; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.console_users (
    username text NOT NULL,
    role text NOT NULL,
    subject_id bigint NOT NULL,
    display_name text NOT NULL,
    password_hash text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    id bigint NOT NULL,
    auth_version bigint DEFAULT 1 NOT NULL,
    admin_class text DEFAULT 'operator'::text NOT NULL,
    CONSTRAINT console_users_admin_class_check CHECK ((admin_class = ANY (ARRAY['super'::text, 'operator'::text]))),
    CONSTRAINT console_users_role_check CHECK ((role = ANY (ARRAY['admin'::text, 'merchant'::text])))
);


--
-- Name: console_users_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.console_users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: console_users_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.console_users_id_seq OWNED BY member72_1c1acaaf36d7e39a.console_users.id;


--
-- Name: deposit_action_events; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.deposit_action_events (
    id bigint NOT NULL,
    action_id bigint NOT NULL,
    status text NOT NULL,
    actor text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: deposit_action_events_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.deposit_action_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deposit_action_events_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.deposit_action_events_id_seq OWNED BY member72_1c1acaaf36d7e39a.deposit_action_events.id;


--
-- Name: deposit_actions; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.deposit_actions (
    id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    action text NOT NULL,
    external_no text NOT NULL,
    amount bigint NOT NULL,
    status text NOT NULL,
    created_by text NOT NULL,
    reviewed_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    reviewed_at timestamp with time zone,
    CONSTRAINT deposit_actions_action_check CHECK ((action = ANY (ARRAY['hold'::text, 'release'::text]))),
    CONSTRAINT deposit_actions_amount_check CHECK ((amount > 0)),
    CONSTRAINT deposit_actions_status_check CHECK ((status = ANY (ARRAY['held'::text, 'pending'::text, 'approved'::text, 'rejected'::text])))
);


--
-- Name: deposit_actions_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.deposit_actions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: deposit_actions_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.deposit_actions_id_seq OWNED BY member72_1c1acaaf36d7e39a.deposit_actions.id;


--
-- Name: enrollment_challenges; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.enrollment_challenges (
    id text NOT NULL,
    purpose text NOT NULL,
    email_hash bytea NOT NULL,
    source_hash bytea NOT NULL,
    code_hash bytea NOT NULL,
    target_merchant_id bigint,
    target_auth_version bigint,
    state text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone,
    CONSTRAINT enrollment_challenges_attempts_check CHECK (((attempts >= 0) AND (attempts <= 5))),
    CONSTRAINT enrollment_challenges_check CHECK ((expires_at > created_at)),
    CONSTRAINT enrollment_challenges_check1 CHECK (((target_merchant_id IS NULL) = (target_auth_version IS NULL))),
    CONSTRAINT enrollment_challenges_code_hash_check CHECK ((octet_length(code_hash) = 32)),
    CONSTRAINT enrollment_challenges_email_hash_check CHECK ((octet_length(email_hash) = 32)),
    CONSTRAINT enrollment_challenges_id_check CHECK ((length(id) = 43)),
    CONSTRAINT enrollment_challenges_purpose_check CHECK ((purpose = ANY (ARRAY['register'::text, 'recover'::text]))),
    CONSTRAINT enrollment_challenges_source_hash_check CHECK ((octet_length(source_hash) = 32)),
    CONSTRAINT enrollment_challenges_state_check CHECK ((state = ANY (ARRAY['sending'::text, 'sent'::text, 'failed'::text]))),
    CONSTRAINT enrollment_challenges_target_auth_version_check CHECK ((target_auth_version > 0))
);


--
-- Name: enrollment_emails; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.enrollment_emails (
    email text NOT NULL,
    email_hash bytea NOT NULL,
    merchant_id bigint NOT NULL,
    username text NOT NULL,
    role text DEFAULT 'merchant'::text NOT NULL,
    verified_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    CONSTRAINT enrollment_emails_email_check CHECK ((email = lower(email))),
    CONSTRAINT enrollment_emails_email_hash_check CHECK ((octet_length(email_hash) = 32)),
    CONSTRAINT enrollment_emails_role_check CHECK ((role = 'merchant'::text))
);


--
-- Name: enrollment_invitation_uses; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.enrollment_invitation_uses (
    invitation_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL
);


--
-- Name: enrollment_limits; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.enrollment_limits (
    key_hash bytea NOT NULL,
    window_start timestamp with time zone NOT NULL,
    attempts integer NOT NULL,
    CONSTRAINT enrollment_limits_attempts_check CHECK ((attempts > 0)),
    CONSTRAINT enrollment_limits_key_hash_check CHECK ((octet_length(key_hash) = 32))
);


--
-- Name: identity_lookup_events; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.identity_lookup_events (
    id bigint NOT NULL,
    request_id text NOT NULL,
    operation text NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT identity_lookup_events_operation_check CHECK ((operation = ANY (ARRAY['created'::text, 'authorized'::text, 'processing'::text, 'verified'::text, 'failed'::text, 'revealed'::text])))
);


--
-- Name: identity_lookup_events_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.identity_lookup_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: identity_lookup_events_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.identity_lookup_events_id_seq OWNED BY member72_1c1acaaf36d7e39a.identity_lookup_events.id;


--
-- Name: identity_lookup_requests; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.identity_lookup_requests (
    id text NOT NULL,
    authorization_hash bytea NOT NULL,
    session_hash bytea NOT NULL,
    actor_username text NOT NULL,
    actor_role text NOT NULL,
    actor_id bigint NOT NULL,
    actor_auth_version bigint NOT NULL,
    merchant_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    provider text NOT NULL,
    app_id text NOT NULL,
    scope text NOT NULL,
    account_scope_hash bytea NOT NULL,
    purpose text DEFAULT 'identity-lookup'::text NOT NULL,
    browser_hash bytea,
    status text DEFAULT 'pending'::text NOT NULL,
    subject_cipher bytea,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    revealed_at timestamp with time zone,
    CONSTRAINT identity_lookup_requests_account_scope_hash_check CHECK ((octet_length(account_scope_hash) = 32)),
    CONSTRAINT identity_lookup_requests_actor_auth_version_check CHECK ((actor_auth_version > 0)),
    CONSTRAINT identity_lookup_requests_actor_id_check CHECK ((actor_id > 0)),
    CONSTRAINT identity_lookup_requests_actor_role_check CHECK ((actor_role = ANY (ARRAY['admin'::text, 'merchant'::text]))),
    CONSTRAINT identity_lookup_requests_app_id_check CHECK (((length(app_id) >= 1) AND (length(app_id) <= 128))),
    CONSTRAINT identity_lookup_requests_authorization_hash_check CHECK ((octet_length(authorization_hash) = 32)),
    CONSTRAINT identity_lookup_requests_browser_hash_check CHECK ((octet_length(browser_hash) = 32)),
    CONSTRAINT identity_lookup_requests_channel_id_check CHECK ((channel_id > 0)),
    CONSTRAINT identity_lookup_requests_check CHECK ((((provider = 'wxpay'::text) AND (scope = 'snsapi_base'::text)) OR ((provider = 'alipay'::text) AND (scope = 'auth_base'::text)))),
    CONSTRAINT identity_lookup_requests_check1 CHECK (((expires_at > created_at) AND (expires_at <= (created_at + '00:05:00'::interval)))),
    CONSTRAINT identity_lookup_requests_check2 CHECK (((status = ANY (ARRAY['verified'::text, 'revealed'::text])) = (subject_cipher IS NOT NULL))),
    CONSTRAINT identity_lookup_requests_check3 CHECK (((status = 'revealed'::text) = (revealed_at IS NOT NULL))),
    CONSTRAINT identity_lookup_requests_id_check CHECK ((id ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT identity_lookup_requests_provider_check CHECK ((provider = ANY (ARRAY['wxpay'::text, 'alipay'::text]))),
    CONSTRAINT identity_lookup_requests_purpose_check CHECK ((purpose = 'identity-lookup'::text)),
    CONSTRAINT identity_lookup_requests_session_hash_check CHECK ((octet_length(session_hash) = 32)),
    CONSTRAINT identity_lookup_requests_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'processing'::text, 'verified'::text, 'failed'::text, 'revealed'::text])))
);


--
-- Name: identity_lookup_states; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.identity_lookup_states (
    state_hash bytea NOT NULL,
    request_id text NOT NULL,
    purpose text DEFAULT 'identity-lookup'::text NOT NULL,
    browser_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    consumed_at timestamp with time zone,
    CONSTRAINT identity_lookup_states_browser_hash_check CHECK ((octet_length(browser_hash) = 32)),
    CONSTRAINT identity_lookup_states_check CHECK (((expires_at > created_at) AND (expires_at <= (created_at + '00:05:00'::interval)))),
    CONSTRAINT identity_lookup_states_purpose_check CHECK ((purpose = 'identity-lookup'::text)),
    CONSTRAINT identity_lookup_states_state_hash_check CHECK ((octet_length(state_hash) = 32))
);


--
-- Name: inbox; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.inbox (
    provider text NOT NULL,
    event_id text NOT NULL,
    order_id bigint,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: jobs; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.jobs (
    id bigint NOT NULL,
    event_key text NOT NULL,
    kind text NOT NULL,
    payload jsonb NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 12 NOT NULL,
    run_at timestamp with time zone DEFAULT now() NOT NULL,
    lease_until timestamp with time zone,
    lease_token text,
    last_error text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT jobs_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'running'::text, 'succeeded'::text, 'dead'::text])))
);


--
-- Name: jobs_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.jobs_id_seq OWNED BY member72_1c1acaaf36d7e39a.jobs.id;


--
-- Name: journals_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.journals_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: journals_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.journals_id_seq OWNED BY member72_1c1acaaf36d7e39a.journals.id;


--
-- Name: ledger_entries_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.ledger_entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ledger_entries_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.ledger_entries_id_seq OWNED BY member72_1c1acaaf36d7e39a.ledger_entries.id;


--
-- Name: ledger_request_events; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.ledger_request_events (
    id bigint NOT NULL,
    request_id bigint NOT NULL,
    actor text NOT NULL,
    status text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: ledger_request_events_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.ledger_request_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ledger_request_events_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.ledger_request_events_id_seq OWNED BY member72_1c1acaaf36d7e39a.ledger_request_events.id;


--
-- Name: ledger_requests; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.ledger_requests (
    id bigint NOT NULL,
    kind text NOT NULL,
    merchant_id bigint NOT NULL,
    recipient_id bigint,
    external_no text NOT NULL,
    amount bigint NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    settlement_plan_item_id bigint,
    CONSTRAINT ledger_requests_amount_check CHECK ((amount > 0)),
    CONSTRAINT ledger_requests_check CHECK ((((kind = 'settlements'::text) AND (recipient_id IS NULL)) OR ((kind <> 'settlements'::text) AND (recipient_id IS NOT NULL) AND (recipient_id <> merchant_id)))),
    CONSTRAINT ledger_requests_external_no_check CHECK (((length(external_no) >= 1) AND (length(external_no) <= 128))),
    CONSTRAINT ledger_requests_kind_check CHECK ((kind = ANY (ARRAY['settlements'::text, 'internal-transfers'::text, 'profitsharing'::text]))),
    CONSTRAINT ledger_requests_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text])))
);


--
-- Name: ledger_requests_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.ledger_requests_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ledger_requests_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.ledger_requests_id_seq OWNED BY member72_1c1acaaf36d7e39a.ledger_requests.id;


--
-- Name: legacy_import_runs; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.legacy_import_runs (
    export_id text NOT NULL,
    source text NOT NULL,
    sha256 text NOT NULL,
    report jsonb NOT NULL,
    imported_at timestamp with time zone DEFAULT now() NOT NULL,
    refund_history_version smallint DEFAULT 2 NOT NULL,
    refund_history_birth_xid xid8 DEFAULT pg_current_xact_id() NOT NULL,
    CONSTRAINT legacy_import_runs_refund_history_version_check CHECK ((refund_history_version = ANY (ARRAY[1, 2]))),
    CONSTRAINT legacy_import_runs_sha256_check CHECK ((length(sha256) = 64)),
    CONSTRAINT legacy_import_runs_source_check CHECK ((source = ANY (ARRAY['epay_pro'::text, 'epay_release'::text])))
);


--
-- Name: legacy_refund_history; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.legacy_refund_history (
    id bigint NOT NULL,
    export_id text NOT NULL,
    merchant_id bigint NOT NULL,
    order_id bigint NOT NULL,
    trade_no text NOT NULL,
    refund_no text NOT NULL,
    amount bigint NOT NULL,
    legacy_status text NOT NULL,
    source_hash text NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT legacy_refund_history_amount_check CHECK ((amount > 0)),
    CONSTRAINT legacy_refund_history_legacy_status_check CHECK ((legacy_status = ANY (ARRAY['succeeded'::text, 'failed'::text, 'unknown'::text]))),
    CONSTRAINT legacy_refund_history_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT legacy_refund_history_refund_no_check CHECK (((length(refund_no) >= 1) AND (length(refund_no) <= 128))),
    CONSTRAINT legacy_refund_history_source_hash_check CHECK ((source_hash ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT legacy_refund_history_trade_no_check CHECK (((length(trade_no) >= 1) AND (length(trade_no) <= 128)))
);


--
-- Name: legacy_refund_history_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.legacy_refund_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: legacy_refund_history_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.legacy_refund_history_id_seq OWNED BY member72_1c1acaaf36d7e39a.legacy_refund_history.id;


--
-- Name: legacy_refund_manifests; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.legacy_refund_manifests (
    export_id text NOT NULL,
    source text NOT NULL,
    source_hash text NOT NULL,
    refund_count bigint NOT NULL,
    unknown_count bigint NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT legacy_refund_manifests_check CHECK (((unknown_count >= 0) AND (unknown_count <= refund_count))),
    CONSTRAINT legacy_refund_manifests_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT legacy_refund_manifests_refund_count_check CHECK ((refund_count >= 0)),
    CONSTRAINT legacy_refund_manifests_source_check CHECK ((source = ANY (ARRAY['epay_pro'::text, 'epay_release'::text]))),
    CONSTRAINT legacy_refund_manifests_source_hash_check CHECK ((source_hash ~ '^[0-9a-f]{64}$'::text))
);


--
-- Name: membership_baseline_repairs; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.membership_baseline_repairs (
    merchant_id bigint NOT NULL,
    previous_group_id bigint NOT NULL,
    group_id bigint NOT NULL,
    unresolved boolean NOT NULL,
    audit_id bigint,
    reason text NOT NULL,
    repaired_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT membership_baseline_repairs_group_id_check CHECK ((group_id >= 0)),
    CONSTRAINT membership_baseline_repairs_reason_check CHECK ((reason = ANY (ARRAY['pre_purchase_audit'::text, 'distinct_assignment'::text, 'post_migration_assignment'::text, 'explicit_assignment'::text, 'ambiguous_snapshot'::text, 'missing_audit'::text, 'invalid_audit'::text])))
);


--
-- Name: membership_purchases_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.membership_purchases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: membership_purchases_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.membership_purchases_id_seq OWNED BY member72_1c1acaaf36d7e39a.membership_purchases.id;


--
-- Name: membership_referral_events; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.membership_referral_events (
    id bigint NOT NULL,
    purchase_id bigint NOT NULL,
    operation text NOT NULL,
    event_key text NOT NULL,
    actor text NOT NULL,
    subject_hash bytea NOT NULL,
    proof_hash bytea NOT NULL,
    CONSTRAINT membership_referral_events_actor_check CHECK ((length(actor) > 0)),
    CONSTRAINT membership_referral_events_operation_check CHECK ((operation = ANY (ARRAY['source'::text, 'award'::text]))),
    CONSTRAINT membership_referral_events_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT membership_referral_events_subject_hash_check CHECK ((octet_length(subject_hash) = 32))
);


--
-- Name: membership_referral_events_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.membership_referral_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: membership_referral_events_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.membership_referral_events_id_seq OWNED BY member72_1c1acaaf36d7e39a.membership_referral_events.id;


--
-- Name: membership_referral_legacy_purchases; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.membership_referral_legacy_purchases (
    purchase_id bigint NOT NULL,
    row_snapshot jsonb NOT NULL,
    row_hash bytea NOT NULL,
    CONSTRAINT membership_referral_legacy_purchases_check CHECK (((octet_length(row_hash) = 32) AND (row_hash = sha256(convert_to((row_snapshot)::text, 'UTF8'::name))))),
    CONSTRAINT membership_referral_legacy_purchases_row_snapshot_check CHECK ((jsonb_typeof(row_snapshot) = 'object'::text))
);


--
-- Name: membership_referral_policies; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.membership_referral_policies (
    id bigint NOT NULL,
    scope_kind text NOT NULL,
    scope_id bigint NOT NULL,
    revision bigint NOT NULL,
    enabled boolean,
    rate_bps bigint,
    actor_role text NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT membership_referral_policies_actor_id_check CHECK ((actor_id > 0)),
    CONSTRAINT membership_referral_policies_actor_name_check CHECK ((length(actor_name) > 0)),
    CONSTRAINT membership_referral_policies_actor_role_check CHECK ((actor_role = 'admin'::text)),
    CONSTRAINT membership_referral_policies_check CHECK ((((scope_kind = 'global'::text) AND (scope_id = 0) AND (enabled IS NOT NULL) AND (rate_bps IS NOT NULL)) OR ((scope_kind = 'group'::text) AND (scope_id > 0)))),
    CONSTRAINT membership_referral_policies_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT membership_referral_policies_rate_bps_check CHECK (((rate_bps >= 0) AND (rate_bps <= 10000))),
    CONSTRAINT membership_referral_policies_revision_check CHECK ((revision > 0)),
    CONSTRAINT membership_referral_policies_scope_kind_check CHECK ((scope_kind = ANY (ARRAY['global'::text, 'group'::text])))
);


--
-- Name: membership_referral_policies_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.membership_referral_policies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: membership_referral_policies_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.membership_referral_policies_id_seq OWNED BY member72_1c1acaaf36d7e39a.membership_referral_policies.id;


--
-- Name: membership_referral_policy_audits; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.membership_referral_policy_audits (
    policy_id bigint NOT NULL,
    actor_role text NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    CONSTRAINT membership_referral_policy_audits_actor_id_check CHECK ((actor_id > 0)),
    CONSTRAINT membership_referral_policy_audits_actor_name_check CHECK ((length(actor_name) > 0)),
    CONSTRAINT membership_referral_policy_audits_actor_role_check CHECK ((actor_role = 'admin'::text))
);


--
-- Name: membership_referral_policy_heads; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.membership_referral_policy_heads (
    scope_kind text NOT NULL,
    scope_id bigint NOT NULL,
    policy_id bigint NOT NULL
);


--
-- Name: membership_referral_rewards; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.membership_referral_rewards (
    purchase_id bigint NOT NULL,
    promoter_id bigint NOT NULL,
    amount bigint NOT NULL,
    source_hash bytea NOT NULL,
    journal_id bigint NOT NULL,
    proof_hash bytea NOT NULL,
    CONSTRAINT membership_referral_rewards_amount_check CHECK ((amount > 0)),
    CONSTRAINT membership_referral_rewards_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT membership_referral_rewards_source_hash_check CHECK ((octet_length(source_hash) = 32))
);


--
-- Name: membership_referral_sources; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.membership_referral_sources (
    purchase_id bigint NOT NULL,
    source_version integer NOT NULL,
    merchant_id bigint NOT NULL,
    promoter_id bigint,
    relation_id bigint,
    relation_hash bytea,
    payer_group_id bigint NOT NULL,
    promoter_group_id bigint NOT NULL,
    policy_ids jsonb NOT NULL,
    policy_revisions jsonb NOT NULL,
    policy_hashes jsonb NOT NULL,
    buyer_revision bigint NOT NULL,
    promoter_revision bigint NOT NULL,
    promoter_enabled boolean NOT NULL,
    enabled boolean NOT NULL,
    rate_bps bigint NOT NULL,
    price bigint NOT NULL,
    reward_amount bigint NOT NULL,
    reason text NOT NULL,
    income_account_id bigint,
    purchase_journal_id bigint,
    transaction_id xid8 DEFAULT pg_current_xact_id() NOT NULL,
    proof_hash bytea NOT NULL,
    CONSTRAINT membership_referral_sources_buyer_revision_check CHECK ((buyer_revision > 0)),
    CONSTRAINT membership_referral_sources_check CHECK (((reward_amount >= 0) AND (reward_amount <= price))),
    CONSTRAINT membership_referral_sources_check1 CHECK ((((promoter_id IS NULL) AND (relation_id IS NULL) AND (relation_hash IS NULL) AND (promoter_group_id = 0) AND (promoter_revision = 0)) OR ((promoter_id IS NOT NULL) AND (promoter_id <> merchant_id) AND (relation_id IS NOT NULL) AND (relation_hash IS NOT NULL) AND (octet_length(relation_hash) = 32) AND (promoter_revision > 0)))),
    CONSTRAINT membership_referral_sources_check2 CHECK ((((price = 0) AND (reward_amount = 0) AND (income_account_id IS NULL) AND (purchase_journal_id IS NULL)) OR ((price > 0) AND (income_account_id IS NOT NULL) AND (purchase_journal_id IS NOT NULL)))),
    CONSTRAINT membership_referral_sources_check3 CHECK ((((reward_amount = 0) AND (reason <> 'eligible'::text)) OR ((reward_amount > 0) AND (reason = 'eligible'::text) AND enabled AND (promoter_id IS NOT NULL)))),
    CONSTRAINT membership_referral_sources_payer_group_id_check CHECK ((payer_group_id >= 0)),
    CONSTRAINT membership_referral_sources_policy_hashes_check CHECK (((jsonb_typeof(policy_hashes) = 'array'::text) AND (jsonb_array_length(policy_hashes) = 3))),
    CONSTRAINT membership_referral_sources_policy_ids_check CHECK (((jsonb_typeof(policy_ids) = 'array'::text) AND (jsonb_array_length(policy_ids) = 3))),
    CONSTRAINT membership_referral_sources_policy_revisions_check CHECK (((jsonb_typeof(policy_revisions) = 'array'::text) AND (jsonb_array_length(policy_revisions) = 3))),
    CONSTRAINT membership_referral_sources_price_check CHECK ((price >= 0)),
    CONSTRAINT membership_referral_sources_promoter_group_id_check CHECK ((promoter_group_id >= 0)),
    CONSTRAINT membership_referral_sources_promoter_revision_check CHECK ((promoter_revision >= 0)),
    CONSTRAINT membership_referral_sources_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT membership_referral_sources_rate_bps_check CHECK (((rate_bps >= 0) AND (rate_bps <= 10000))),
    CONSTRAINT membership_referral_sources_reason_check CHECK ((reason = ANY (ARRAY['no_relation'::text, 'promoter_disabled'::text, 'disabled'::text, 'zero_price'::text, 'zero_rate'::text, 'rounds_zero'::text, 'eligible'::text]))),
    CONSTRAINT membership_referral_sources_source_version_check CHECK ((source_version = 1))
);


--
-- Name: membership_referral_source_invariants; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.membership_referral_source_invariants AS
 SELECT s.purchase_id,
    (((p.source_version = 1) AND (s.source_version = 1) AND ((p.merchant_id = s.merchant_id) AND (p.price = s.price)) AND (((s.price = 0) AND (s.income_account_id IS NULL) AND (s.purchase_journal_id IS NULL)) OR ((s.price > 0) AND (a.owner_id = 0) AND (a.kind = 'membership_income'::text) AND (a.scope_id = s.purchase_id) AND (a.balance = (s.price - s.reward_amount)) AND (j.event_key = ('membership:'::text || (p.id)::text)) AND (j.transaction_id = s.transaction_id) AND (( SELECT count(*) AS count
           FROM member72_1c1acaaf36d7e39a.ledger_entries e
          WHERE (e.journal_id = j.id)) = 2) AND (( SELECT count(*) AS count
           FROM (member72_1c1acaaf36d7e39a.ledger_entries e
             JOIN member72_1c1acaaf36d7e39a.accounts b ON ((b.id = e.account_id)))
          WHERE ((e.journal_id = j.id) AND (b.owner_id = p.merchant_id) AND (b.kind = 'available'::text) AND (b.scope_id = 0) AND (e.amount = (- s.price)))) = 1) AND (( SELECT count(*) AS count
           FROM member72_1c1acaaf36d7e39a.ledger_entries e
          WHERE ((e.journal_id = j.id) AND (e.account_id = a.id) AND (e.amount = s.price))) = 1))) AND (((s.reward_amount = 0) AND (r.purchase_id IS NULL)) OR ((s.reward_amount > 0) AND (r.purchase_id = s.purchase_id) AND (r.promoter_id = s.promoter_id) AND (r.amount = s.reward_amount) AND (r.source_hash = s.proof_hash) AND (x.event_key = (('membership-referral:'::text || (p.id)::text) || ':award'::text)) AND (x.transaction_id = s.transaction_id) AND (( SELECT count(*) AS count
           FROM member72_1c1acaaf36d7e39a.ledger_entries e
          WHERE (e.journal_id = x.id)) = 2) AND (( SELECT count(*) AS count
           FROM member72_1c1acaaf36d7e39a.ledger_entries e
          WHERE ((e.journal_id = x.id) AND (e.account_id = a.id) AND (e.amount = (- s.reward_amount)))) = 1) AND (( SELECT count(*) AS count
           FROM (member72_1c1acaaf36d7e39a.ledger_entries e
             JOIN member72_1c1acaaf36d7e39a.accounts b ON ((b.id = e.account_id)))
          WHERE ((e.journal_id = x.id) AND (b.owner_id = s.promoter_id) AND (b.kind = 'available'::text) AND (b.scope_id = 0) AND (e.amount = s.reward_amount))) = 1)))) IS TRUE) AS valid
   FROM (((((member72_1c1acaaf36d7e39a.membership_referral_sources s
     JOIN member72_1c1acaaf36d7e39a.membership_purchases p ON ((p.id = s.purchase_id)))
     LEFT JOIN member72_1c1acaaf36d7e39a.accounts a ON ((a.id = s.income_account_id)))
     LEFT JOIN member72_1c1acaaf36d7e39a.journals j ON ((j.id = s.purchase_journal_id)))
     LEFT JOIN member72_1c1acaaf36d7e39a.membership_referral_rewards r ON ((r.purchase_id = s.purchase_id)))
     LEFT JOIN member72_1c1acaaf36d7e39a.journals x ON ((x.id = r.journal_id)));


--
-- Name: memberships; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.memberships (
    merchant_id bigint NOT NULL,
    group_id bigint NOT NULL,
    expires_at timestamp with time zone NOT NULL
);


--
-- Name: merchants; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.merchants (
    id bigint NOT NULL,
    name text NOT NULL,
    api_key bytea NOT NULL,
    rsa_public_key text DEFAULT ''::text NOT NULL,
    signature_algorithm text DEFAULT 'MD5'::text NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    profile jsonb DEFAULT '{}'::jsonb NOT NULL,
    config_revision bigint DEFAULT 1 NOT NULL,
    base_group_id bigint DEFAULT 0 NOT NULL,
    group_baseline_unresolved boolean DEFAULT false NOT NULL,
    CONSTRAINT merchants_base_group_id_check CHECK ((base_group_id >= 0)),
    CONSTRAINT merchants_config_revision_check CHECK ((config_revision > 0)),
    CONSTRAINT merchants_id_check CHECK ((id > 0)),
    CONSTRAINT merchants_profile_check CHECK ((jsonb_typeof(profile) = 'object'::text)),
    CONSTRAINT merchants_signature_algorithm_check CHECK ((signature_algorithm = ANY (ARRAY['MD5'::text, 'RSA'::text])))
);


--
-- Name: mini_oauth_states; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.mini_oauth_states (
    state_hash bytea NOT NULL,
    order_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    provider text NOT NULL,
    app_id text NOT NULL,
    method text NOT NULL,
    purpose text NOT NULL,
    path text NOT NULL,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    expires_at timestamp with time zone DEFAULT (statement_timestamp() + '00:05:00'::interval) NOT NULL,
    consumed_at timestamp with time zone,
    CONSTRAINT mini_oauth_states_check CHECK (((expires_at > created_at) AND (expires_at <= (created_at + '00:05:00'::interval)))),
    CONSTRAINT mini_oauth_states_state_hash_check CHECK ((octet_length(state_hash) = 32))
);


--
-- Name: mini_payment_intents; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.mini_payment_intents (
    order_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    provider text NOT NULL,
    app_id text NOT NULL,
    method text NOT NULL,
    purpose text NOT NULL,
    path text NOT NULL,
    CONSTRAINT mini_payment_intents_app_id_check CHECK (((length(app_id) >= 1) AND (length(app_id) <= 128))),
    CONSTRAINT mini_payment_intents_channel_id_check CHECK ((channel_id > 0)),
    CONSTRAINT mini_payment_intents_check CHECK ((((provider = 'wxpay'::text) AND (method = 'jsapi'::text)) OR ((provider = 'alipay'::text) AND (method = 'mini'::text)))),
    CONSTRAINT mini_payment_intents_path_check CHECK (((length(path) >= 1) AND (length(path) <= 256))),
    CONSTRAINT mini_payment_intents_provider_check CHECK ((provider = ANY (ARRAY['wxpay'::text, 'alipay'::text]))),
    CONSTRAINT mini_payment_intents_purpose_check CHECK ((purpose = 'mini-payment'::text))
);


--
-- Name: notification_resend_requests; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.notification_resend_requests (
    order_id bigint NOT NULL,
    request_hash text NOT NULL,
    job_id bigint NOT NULL,
    actor_role text NOT NULL,
    actor_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    CONSTRAINT notification_resend_requests_actor_role_check CHECK ((actor_role = ANY (ARRAY['admin'::text, 'merchant'::text]))),
    CONSTRAINT notification_resend_requests_request_hash_check CHECK ((request_hash ~ '^[a-f0-9]{64}$'::text))
);


--
-- Name: notification_send_controls; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.notification_send_controls (
    order_id bigint NOT NULL,
    last_manual_at timestamp with time zone NOT NULL
);


--
-- Name: oauth_authorization_code_claims; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.oauth_authorization_code_claims (
    provider text NOT NULL,
    app_id text NOT NULL,
    domain text NOT NULL,
    code_hash bytea NOT NULL,
    claim_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT oauth_authorization_code_claims_app_id_check CHECK (((length(app_id) >= 1) AND (length(app_id) <= 128))),
    CONSTRAINT oauth_authorization_code_claims_claim_hash_check CHECK ((octet_length(claim_hash) = 32)),
    CONSTRAINT oauth_authorization_code_claims_code_hash_check CHECK ((octet_length(code_hash) = 32)),
    CONSTRAINT oauth_authorization_code_claims_domain_check CHECK ((domain = ANY (ARRAY['web'::text, 'mini'::text]))),
    CONSTRAINT oauth_authorization_code_claims_provider_check CHECK ((provider = ANY (ARRAY['wxpay'::text, 'alipay'::text])))
);


--
-- Name: oauth_code_claims; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.oauth_code_claims (
    provider text NOT NULL,
    app_id text NOT NULL,
    code_hash bytea NOT NULL,
    state_hash bytea,
    mini_state_hash bytea,
    CONSTRAINT oauth_code_claims_code_hash_check CHECK ((octet_length(code_hash) = 32)),
    CONSTRAINT oauth_code_exactly_one_state CHECK ((num_nonnulls(state_hash, mini_state_hash) = 1))
);


--
-- Name: oauth_payment_intents; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.oauth_payment_intents (
    order_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    provider text NOT NULL,
    app_id text NOT NULL,
    method text NOT NULL,
    purpose text NOT NULL,
    CONSTRAINT oauth_payment_intents_app_id_check CHECK (((length(app_id) >= 1) AND (length(app_id) <= 128))),
    CONSTRAINT oauth_payment_intents_channel_id_check CHECK ((channel_id > 0)),
    CONSTRAINT oauth_payment_intents_method_check CHECK ((method = 'jsapi'::text)),
    CONSTRAINT oauth_payment_intents_provider_check CHECK ((provider = ANY (ARRAY['wxpay'::text, 'alipay'::text]))),
    CONSTRAINT oauth_payment_intents_purpose_check CHECK ((purpose = 'payment-jsapi'::text))
);


--
-- Name: oauth_states; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.oauth_states (
    state_hash bytea NOT NULL,
    order_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    provider text NOT NULL,
    app_id text NOT NULL,
    method text NOT NULL,
    purpose text NOT NULL,
    browser_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    expires_at timestamp with time zone DEFAULT (now() + '00:05:00'::interval) NOT NULL,
    consumed_at timestamp with time zone,
    CONSTRAINT oauth_states_browser_hash_check CHECK ((octet_length(browser_hash) = 32)),
    CONSTRAINT oauth_states_check CHECK (((expires_at > created_at) AND (expires_at <= (created_at + '00:05:00'::interval)))),
    CONSTRAINT oauth_states_state_hash_check CHECK ((octet_length(state_hash) = 32))
);


--
-- Name: operation_audit; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.operation_audit (
    id bigint NOT NULL,
    operation_kind text NOT NULL,
    operation_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    from_status text,
    to_status text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT operation_audit_operation_kind_check CHECK ((operation_kind = ANY (ARRAY['refund'::text, 'transfer'::text])))
);


--
-- Name: operation_audit_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.operation_audit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: operation_audit_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.operation_audit_id_seq OWNED BY member72_1c1acaaf36d7e39a.operation_audit.id;


--
-- Name: order_income_hold_events; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.order_income_hold_events (
    id bigint NOT NULL,
    hold_id bigint NOT NULL,
    action text NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    actor_class text NOT NULL,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    CONSTRAINT order_income_hold_events_action_check CHECK ((action = ANY (ARRAY['freeze'::text, 'unfreeze'::text]))),
    CONSTRAINT order_income_hold_events_actor_class_check CHECK ((actor_class = ANY (ARRAY['super'::text, 'operator'::text]))),
    CONSTRAINT order_income_hold_events_actor_id_check CHECK ((actor_id > 0)),
    CONSTRAINT order_income_hold_events_actor_name_check CHECK (((length(actor_name) >= 1) AND (length(actor_name) <= 128)))
);


--
-- Name: order_income_hold_events_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.order_income_hold_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_income_hold_events_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.order_income_hold_events_id_seq OWNED BY member72_1c1acaaf36d7e39a.order_income_hold_events.id;


--
-- Name: order_income_hold_fundings; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.order_income_hold_fundings (
    hold_id bigint NOT NULL,
    order_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    account_id bigint NOT NULL,
    amount bigint NOT NULL,
    source_mode text NOT NULL,
    external_no text NOT NULL,
    funding_journal_id bigint NOT NULL,
    legacy_pool_journal_id bigint,
    freeze_actor_id bigint NOT NULL,
    freeze_actor_name text NOT NULL,
    freeze_actor_class text NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    actor_class text NOT NULL,
    request_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT order_income_hold_fundings_actor_class_check CHECK ((actor_class = ANY (ARRAY['super'::text, 'operator'::text]))),
    CONSTRAINT order_income_hold_fundings_actor_id_check CHECK ((actor_id > 0)),
    CONSTRAINT order_income_hold_fundings_amount_check CHECK ((amount > 0)),
    CONSTRAINT order_income_hold_fundings_check CHECK (((source_mode <> 'legacy_adopt'::text) OR (actor_class = 'super'::text))),
    CONSTRAINT order_income_hold_fundings_freeze_actor_class_check CHECK ((freeze_actor_class = ANY (ARRAY['super'::text, 'operator'::text]))),
    CONSTRAINT order_income_hold_fundings_freeze_actor_id_check CHECK ((freeze_actor_id > 0)),
    CONSTRAINT order_income_hold_fundings_request_hash_check CHECK ((octet_length(request_hash) = 32)),
    CONSTRAINT order_income_hold_fundings_source_mode_check CHECK ((source_mode = ANY (ARRAY['fresh'::text, 'legacy_adopt'::text])))
);


--
-- Name: order_income_holds; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.order_income_holds (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    request_no text NOT NULL,
    merchant_net bigint NOT NULL,
    refund_merchant_amount bigint NOT NULL,
    amount bigint NOT NULL,
    state text DEFAULT 'held'::text NOT NULL,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    released_at timestamp with time zone,
    channel_sharing_amount bigint DEFAULT 0 NOT NULL,
    internal_allocated_amount bigint DEFAULT 0 NOT NULL,
    evidence_version integer DEFAULT 2 NOT NULL,
    funding_evidence_version integer DEFAULT 2 NOT NULL,
    CONSTRAINT order_income_holds_amount_check CHECK ((amount > 0)),
    CONSTRAINT order_income_holds_channel_sharing_amount_check CHECK ((channel_sharing_amount >= 0)),
    CONSTRAINT order_income_holds_check1 CHECK ((((state = 'held'::text) AND (released_at IS NULL)) OR ((state = 'released'::text) AND (released_at IS NOT NULL)))),
    CONSTRAINT order_income_holds_evidence_version_check CHECK ((evidence_version = ANY (ARRAY[1, 2]))),
    CONSTRAINT order_income_holds_funding_evidence_version_check CHECK ((funding_evidence_version = ANY (ARRAY[1, 2]))),
    CONSTRAINT order_income_holds_internal_allocated_amount_check CHECK ((internal_allocated_amount >= 0)),
    CONSTRAINT order_income_holds_merchant_net_check CHECK ((merchant_net > 0)),
    CONSTRAINT order_income_holds_refund_merchant_amount_check CHECK ((refund_merchant_amount >= 0)),
    CONSTRAINT order_income_holds_request_no_check CHECK (((length(request_no) >= 1) AND (length(request_no) <= 128))),
    CONSTRAINT order_income_holds_state_check CHECK ((state = ANY (ARRAY['held'::text, 'released'::text]))),
    CONSTRAINT order_income_retained_balanced CHECK ((((((amount)::numeric + (refund_merchant_amount)::numeric) + (channel_sharing_amount)::numeric) + (internal_allocated_amount)::numeric) = (merchant_net)::numeric))
);


--
-- Name: order_income_hold_legacy_evidence; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.order_income_hold_legacy_evidence AS
 SELECT id,
    merchant_id,
    ((EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.journals j
          WHERE ((j.event_key = (('order-income:'::text || (h.id)::text) || ':freeze'::text)) AND ( SELECT (count(*) = 2)
                   FROM member72_1c1acaaf36d7e39a.ledger_entries e
                  WHERE (e.journal_id = j.id)) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                   FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                     JOIN member72_1c1acaaf36d7e39a.accounts av ON ((av.id = e.account_id)))
                  WHERE ((e.journal_id = j.id) AND ((av.owner_id = h.merchant_id) AND (av.kind = 'available'::text) AND (av.scope_id = 0)))) = ((- h.amount))::numeric) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                   FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                     JOIN member72_1c1acaaf36d7e39a.accounts av ON ((av.id = e.account_id)))
                  WHERE ((e.journal_id = j.id) AND ((av.owner_id = h.merchant_id) AND (av.kind = 'order_income_hold'::text) AND (av.scope_id = 0)))) = (h.amount)::numeric)))) AND (EXISTS ( SELECT 1
           FROM (member72_1c1acaaf36d7e39a.order_income_hold_events ev
             JOIN member72_1c1acaaf36d7e39a.backoffice_audit a ON (((a.actor_id = ev.actor_id) AND (a.actor_name = ev.actor_name) AND (a.actor_role = 'admin'::text) AND (a.resource = 'orders'::text) AND (a.resource_id = h.order_id) AND (a.operation = 'freeze-income'::text) AND ((a.changes ->> 'hold_id'::text) = (h.id)::text) AND ((a.changes ->> 'amount'::text) = (h.amount)::text))))
          WHERE ((ev.hold_id = h.id) AND (ev.action = 'freeze'::text)))) AND
        CASE
            WHEN (state = 'held'::text) THEN (NOT (EXISTS ( SELECT 1
               FROM member72_1c1acaaf36d7e39a.journals j
              WHERE (j.event_key = (('order-income:'::text || (h.id)::text) || ':unfreeze'::text)))))
            ELSE ((EXISTS ( SELECT 1
               FROM member72_1c1acaaf36d7e39a.journals j
              WHERE ((j.event_key = (('order-income:'::text || (h.id)::text) || ':unfreeze'::text)) AND ( SELECT (count(*) = 2)
                       FROM member72_1c1acaaf36d7e39a.ledger_entries e
                      WHERE (e.journal_id = j.id)) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                       FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                         JOIN member72_1c1acaaf36d7e39a.accounts av ON ((av.id = e.account_id)))
                      WHERE ((e.journal_id = j.id) AND ((av.owner_id = h.merchant_id) AND (av.kind = 'order_income_hold'::text) AND (av.scope_id = 0)))) = ((- h.amount))::numeric) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                       FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                         JOIN member72_1c1acaaf36d7e39a.accounts av ON ((av.id = e.account_id)))
                      WHERE ((e.journal_id = j.id) AND ((av.owner_id = h.merchant_id) AND (av.kind = 'available'::text) AND (av.scope_id = 0)))) = (h.amount)::numeric)))) AND (EXISTS ( SELECT 1
               FROM (member72_1c1acaaf36d7e39a.order_income_hold_events ev
                 JOIN member72_1c1acaaf36d7e39a.backoffice_audit a ON (((a.actor_id = ev.actor_id) AND (a.actor_name = ev.actor_name) AND (a.actor_role = 'admin'::text) AND (a.resource = 'orders'::text) AND (a.resource_id = h.order_id) AND (a.operation = 'unfreeze-income'::text) AND ((a.changes ->> 'hold_id'::text) = (h.id)::text) AND ((a.changes ->> 'amount'::text) = (h.amount)::text))))
              WHERE ((ev.hold_id = h.id) AND (ev.action = 'unfreeze'::text)))))
        END) AS valid
   FROM member72_1c1acaaf36d7e39a.order_income_holds h;


--
-- Name: order_income_hold_releases; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.order_income_hold_releases (
    hold_id bigint NOT NULL,
    amount bigint NOT NULL,
    consumed_amount bigint NOT NULL,
    journal_id bigint,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    actor_class text NOT NULL,
    request_hash bytea NOT NULL,
    result_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT order_income_hold_releases_actor_class_check CHECK ((actor_class = ANY (ARRAY['super'::text, 'operator'::text]))),
    CONSTRAINT order_income_hold_releases_actor_id_check CHECK ((actor_id > 0)),
    CONSTRAINT order_income_hold_releases_amount_check CHECK ((amount >= 0)),
    CONSTRAINT order_income_hold_releases_consumed_amount_check CHECK ((consumed_amount >= 0)),
    CONSTRAINT order_income_hold_releases_request_hash_check CHECK ((octet_length(request_hash) = 32)),
    CONSTRAINT order_income_hold_releases_result_hash_check CHECK ((octet_length(result_hash) = 32))
);


--
-- Name: refund_fundings; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.refund_fundings (
    refund_id bigint NOT NULL,
    order_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    hold_id bigint,
    hold_funding_hash bytea,
    merchant_amount bigint NOT NULL,
    hold_amount bigint NOT NULL,
    available_amount bigint NOT NULL,
    fee_amount bigint NOT NULL,
    reserve_account_id bigint NOT NULL,
    hold_reserve_journal_id bigint,
    available_reserve_journal_id bigint,
    request_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT refund_fundings_available_amount_check CHECK ((available_amount >= 0)),
    CONSTRAINT refund_fundings_check CHECK ((((hold_amount)::numeric + (available_amount)::numeric) = (merchant_amount)::numeric)),
    CONSTRAINT refund_fundings_check1 CHECK (((hold_id IS NOT NULL) OR ((hold_amount = 0) AND (hold_funding_hash IS NULL)))),
    CONSTRAINT refund_fundings_check2 CHECK (((hold_id IS NULL) OR (octet_length(hold_funding_hash) = 32))),
    CONSTRAINT refund_fundings_fee_amount_check CHECK ((fee_amount >= 0)),
    CONSTRAINT refund_fundings_hold_amount_check CHECK ((hold_amount >= 0)),
    CONSTRAINT refund_fundings_merchant_amount_check CHECK ((merchant_amount >= 0)),
    CONSTRAINT refund_fundings_request_hash_check CHECK ((octet_length(request_hash) = 32))
);


--
-- Name: refunds; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.refunds (
    id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    order_id bigint NOT NULL,
    refund_no text NOT NULL,
    amount bigint NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    merchant_amount bigint NOT NULL,
    fee_amount bigint DEFAULT 0 NOT NULL,
    result_evidence_version smallint DEFAULT 2 NOT NULL,
    funding_evidence_version integer DEFAULT 2 NOT NULL,
    CONSTRAINT refund_allocation_balanced CHECK (((merchant_amount >= 0) AND ((merchant_amount + fee_amount) = amount))),
    CONSTRAINT refunds_amount_check CHECK ((amount > 0)),
    CONSTRAINT refunds_fee_amount_check CHECK ((fee_amount >= 0)),
    CONSTRAINT refunds_funding_evidence_version_check CHECK ((funding_evidence_version = ANY (ARRAY[1, 2]))),
    CONSTRAINT refunds_result_evidence_version_check CHECK ((result_evidence_version = ANY (ARRAY[1, 2]))),
    CONSTRAINT refunds_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'unknown'::text, 'succeeded'::text, 'failed'::text])))
);


--
-- Name: order_income_hold_funding_evidence; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.order_income_hold_funding_evidence AS
 SELECT h.id,
    h.merchant_id,
        CASE
            WHEN (f.hold_id IS NULL) THEN ((h.funding_evidence_version = 1) AND (l.valid IS TRUE))
            ELSE (((f.order_id = h.order_id) AND (f.merchant_id = h.merchant_id) AND (f.amount = h.amount)) AND ((a.owner_id = h.merchant_id) AND (a.kind = 'order_income_reserve'::text) AND (a.scope_id = h.id)) AND (((f.source_mode = 'fresh'::text) AND (h.funding_evidence_version = 2) AND (f.legacy_pool_journal_id IS NULL) AND member72_1c1acaaf36d7e39a.referral_clawback_journal_valid(f.funding_journal_id, (('order-income:'::text || h.id) || ':freeze'::text), av.id, a.id, h.amount)) OR ((f.source_mode = 'legacy_adopt'::text) AND (h.funding_evidence_version = 1) AND member72_1c1acaaf36d7e39a.referral_clawback_journal_valid(f.legacy_pool_journal_id, (('order-income:'::text || h.id) || ':freeze'::text), av.id, pool.id, h.amount) AND member72_1c1acaaf36d7e39a.referral_clawback_journal_valid(f.funding_journal_id, (('order-income:'::text || h.id) || ':adopt'::text), pool.id, a.id, h.amount))) AND (EXISTS ( SELECT 1
               FROM (member72_1c1acaaf36d7e39a.order_income_hold_events e
                 JOIN member72_1c1acaaf36d7e39a.backoffice_audit b ON ((((b.actor_role = 'admin'::text) AND (b.actor_id = e.actor_id) AND (b.actor_name = e.actor_name)) AND (b.resource = 'orders'::text) AND (b.resource_id = h.order_id) AND (b.operation = 'freeze-income'::text) AND ((b.changes ->> 'hold_id'::text) = (h.id)::text) AND ((b.changes ->> 'amount'::text) = (h.amount)::text))))
              WHERE ((e.hold_id = h.id) AND (e.action = 'freeze'::text) AND ((e.actor_id = f.freeze_actor_id) AND (e.actor_name = f.freeze_actor_name) AND (e.actor_class = f.freeze_actor_class))))) AND ((f.source_mode = 'legacy_adopt'::text) OR ((f.freeze_actor_id = f.actor_id) AND (f.freeze_actor_name = f.actor_name) AND (f.freeze_actor_class = f.actor_class))) AND (EXISTS ( SELECT 1
               FROM member72_1c1acaaf36d7e39a.backoffice_audit b
              WHERE ((b.resource = 'income-fundings'::text) AND (b.resource_id = h.id) AND (b.operation = f.source_mode) AND ((b.actor_role = 'admin'::text) AND (b.actor_id = f.actor_id) AND (b.actor_name = f.actor_name))))) AND (( SELECT COALESCE(sum(x.hold_amount), (0)::numeric) AS "coalesce"
               FROM (member72_1c1acaaf36d7e39a.refund_fundings x
                 JOIN member72_1c1acaaf36d7e39a.refunds r ON ((r.id = x.refund_id)))
              WHERE ((x.hold_id = h.id) AND (r.status <> 'failed'::text))) <= (h.amount)::numeric) AND ((a.balance)::numeric = (((h.amount)::numeric - ( SELECT COALESCE(sum(x.hold_amount), (0)::numeric) AS "coalesce"
               FROM (member72_1c1acaaf36d7e39a.refund_fundings x
                 JOIN member72_1c1acaaf36d7e39a.refunds r ON ((r.id = x.refund_id)))
              WHERE ((x.hold_id = h.id) AND (r.status <> 'failed'::text)))) - (COALESCE(rel.amount, (0)::bigint))::numeric)) AND (( SELECT count(*) AS count
               FROM member72_1c1acaaf36d7e39a.ledger_entries x
              WHERE (x.account_id = a.id)) = (((1 + ( SELECT count(*) AS count
               FROM member72_1c1acaaf36d7e39a.refund_fundings x
              WHERE ((x.hold_id = h.id) AND (x.hold_amount > 0)))) + ( SELECT count(*) AS count
               FROM (member72_1c1acaaf36d7e39a.refund_fundings x
                 JOIN member72_1c1acaaf36d7e39a.refunds r ON ((r.id = x.refund_id)))
              WHERE ((x.hold_id = h.id) AND (x.hold_amount > 0) AND (r.status = 'failed'::text)))) +
            CASE
                WHEN (rel.amount > 0) THEN 1
                ELSE 0
            END)) AND
            CASE
                WHEN (h.state = 'held'::text) THEN (rel.hold_id IS NULL)
                ELSE ((rel.request_hash = f.request_hash) AND (((rel.amount)::numeric + (rel.consumed_amount)::numeric) = (h.amount)::numeric) AND (NOT (EXISTS ( SELECT 1
                   FROM (member72_1c1acaaf36d7e39a.refund_fundings x
                     JOIN member72_1c1acaaf36d7e39a.refunds r ON ((r.id = x.refund_id)))
                  WHERE ((x.hold_id = h.id) AND (r.status = ANY (ARRAY['pending'::text, 'unknown'::text])))))) AND member72_1c1acaaf36d7e39a.referral_clawback_journal_valid(rel.journal_id, (('order-income:'::text || h.id) || ':unfreeze'::text), a.id, av.id, rel.amount) AND (EXISTS ( SELECT 1
                   FROM member72_1c1acaaf36d7e39a.backoffice_audit b
                  WHERE ((b.resource = 'income-fundings'::text) AND (b.resource_id = h.id) AND (b.operation = 'release'::text) AND ((b.actor_role = 'admin'::text) AND (b.actor_id = rel.actor_id) AND (b.actor_name = rel.actor_name))))))
            END)
        END AS valid
   FROM ((((((member72_1c1acaaf36d7e39a.order_income_holds h
     LEFT JOIN member72_1c1acaaf36d7e39a.order_income_hold_legacy_evidence l ON ((l.id = h.id)))
     LEFT JOIN member72_1c1acaaf36d7e39a.order_income_hold_fundings f ON ((f.hold_id = h.id)))
     LEFT JOIN member72_1c1acaaf36d7e39a.order_income_hold_releases rel ON ((rel.hold_id = h.id)))
     LEFT JOIN member72_1c1acaaf36d7e39a.accounts a ON ((a.id = f.account_id)))
     JOIN member72_1c1acaaf36d7e39a.accounts av ON (((av.owner_id = h.merchant_id) AND (av.kind = 'available'::text) AND (av.scope_id = 0))))
     JOIN member72_1c1acaaf36d7e39a.accounts pool ON (((pool.owner_id = h.merchant_id) AND (pool.kind = 'order_income_hold'::text) AND (pool.scope_id = 0))));


--
-- Name: order_income_holds_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.order_income_holds_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_income_holds_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.order_income_holds_id_seq OWNED BY member72_1c1acaaf36d7e39a.order_income_holds.id;


--
-- Name: order_profit_allocations; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.order_profit_allocations (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    rule_id bigint NOT NULL,
    request_id bigint NOT NULL,
    amount bigint NOT NULL,
    rate_bps integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT order_profit_allocations_amount_check CHECK ((amount > 0)),
    CONSTRAINT order_profit_allocations_rate_bps_check CHECK (((rate_bps >= 1) AND (rate_bps <= 10000)))
);


--
-- Name: order_income_internal_allocation_evidence; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.order_income_internal_allocation_evidence AS
 SELECT a.id,
    a.order_id,
    a.amount,
    r.status,
    ((r.kind = 'profitsharing'::text) AND (r.merchant_id = o.merchant_id) AND (r.amount = a.amount) AND (r.recipient_id > 0) AND (r.recipient_id <> o.merchant_id) AND (r.external_no = ((('order:'::text || o.trade_no) || ':rule:'::text) || (a.rule_id)::text)) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.journals j
          WHERE ((j.event_key = (('request:'::text || (r.id)::text) || ':reserve'::text)) AND ( SELECT (count(*) = 2)
                   FROM member72_1c1acaaf36d7e39a.ledger_entries e
                  WHERE (e.journal_id = j.id)) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                   FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                     JOIN member72_1c1acaaf36d7e39a.accounts av ON ((av.id = e.account_id)))
                  WHERE ((e.journal_id = j.id) AND ((av.owner_id = o.merchant_id) AND (av.kind = 'available'::text) AND (av.scope_id = 0)))) = ((- a.amount))::numeric) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                   FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                     JOIN member72_1c1acaaf36d7e39a.accounts av ON ((av.id = e.account_id)))
                  WHERE ((e.journal_id = j.id) AND ((av.owner_id = o.merchant_id) AND (av.kind = 'reserved'::text) AND (av.scope_id = 0)))) = (a.amount)::numeric)))) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.ledger_request_events ev
          WHERE ((ev.request_id = r.id) AND (ev.status = 'pending'::text)))) AND
        CASE
            WHEN (r.status = 'pending'::text) THEN (NOT (EXISTS ( SELECT 1
               FROM member72_1c1acaaf36d7e39a.journals j
              WHERE (j.event_key = (('request:'::text || (r.id)::text) || ':review'::text)))))
            ELSE ((EXISTS ( SELECT 1
               FROM member72_1c1acaaf36d7e39a.ledger_request_events ev
              WHERE ((ev.request_id = r.id) AND (ev.status = r.status)))) AND (EXISTS ( SELECT 1
               FROM member72_1c1acaaf36d7e39a.journals j
              WHERE ((j.event_key = (('request:'::text || (r.id)::text) || ':review'::text)) AND ( SELECT (count(*) = 2)
                       FROM member72_1c1acaaf36d7e39a.ledger_entries e
                      WHERE (e.journal_id = j.id)) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                       FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                         JOIN member72_1c1acaaf36d7e39a.accounts av ON ((av.id = e.account_id)))
                      WHERE ((e.journal_id = j.id) AND ((av.owner_id = o.merchant_id) AND (av.kind = 'reserved'::text) AND (av.scope_id = 0)))) = ((- a.amount))::numeric) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                       FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                         JOIN member72_1c1acaaf36d7e39a.accounts av ON ((av.id = e.account_id)))
                      WHERE ((e.journal_id = j.id) AND ((av.owner_id =
                            CASE
                                WHEN (r.status = 'approved'::text) THEN r.recipient_id
                                ELSE o.merchant_id
                            END) AND (av.kind = 'available'::text) AND (av.scope_id = 0)))) = (a.amount)::numeric)))))
        END) AS valid
   FROM ((member72_1c1acaaf36d7e39a.order_profit_allocations a
     JOIN member72_1c1acaaf36d7e39a.ledger_requests r ON ((r.id = a.request_id)))
     JOIN member72_1c1acaaf36d7e39a.orders o ON ((o.id = a.order_id)));


--
-- Name: recharge_intents; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.recharge_intents (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    created_by text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: order_income_source_evidence; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.order_income_source_evidence AS
 SELECT o.id AS order_id,
    o.merchant_id,
    o.merchant_amount AS merchant_net,
    r.gross AS refund_gross,
    r.amount AS refund_merchant_amount,
    r.pending AS pending_refunds,
    p.amount AS channel_sharing_amount,
    a.amount AS internal_allocated_amount,
    (GREATEST((0)::numeric, ((((o.merchant_amount)::numeric - (r.amount)::numeric) - (p.amount)::numeric) - (a.amount)::numeric)))::bigint AS remaining,
    ((o.status = 'paid'::text) AND (o.merchant_amount > 0) AND (NOT (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.recharge_intents z
          WHERE (z.order_id = o.id)))) AND (r.gross <= o.amount) AND r.valid AND a.valid AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.journals j
          WHERE ((j.event_key = ('payment:'::text || o.trade_no)) AND ( SELECT (count(*) = 2)
                   FROM member72_1c1acaaf36d7e39a.ledger_entries e
                  WHERE (e.journal_id = j.id)) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                   FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                     JOIN member72_1c1acaaf36d7e39a.accounts av ON ((av.id = e.account_id)))
                  WHERE ((e.journal_id = j.id) AND ((av.owner_id = o.merchant_id) AND (av.kind = 'available'::text) AND (av.scope_id = 0)))) = (o.merchant_amount)::numeric) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                   FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                     JOIN member72_1c1acaaf36d7e39a.accounts cl ON ((cl.id = e.account_id)))
                  WHERE ((e.journal_id = j.id) AND ((cl.owner_id = 0) AND (cl.kind = 'clearing'::text) AND (cl.scope_id = 0)))) = ((- o.merchant_amount))::numeric)))) AND (NOT (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.channel_sharing_fundings f
          WHERE ((f.order_id = o.id) AND (NOT (EXISTS ( SELECT 1
                   FROM member72_1c1acaaf36d7e39a.channel_sharing_funding_invariants v
                  WHERE ((v.order_id = f.order_id) AND (v.valid IS TRUE))))))))) AND (NOT (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.provider_attempt_sharing d
          WHERE ((d.order_id = o.id) AND d.declared AND (NOT (EXISTS ( SELECT 1
                   FROM member72_1c1acaaf36d7e39a.channel_sharing_fundings f
                  WHERE (f.order_id = d.order_id))))))))) AS valid
   FROM (((member72_1c1acaaf36d7e39a.orders o
     CROSS JOIN LATERAL ( SELECT (COALESCE(sum(f.amount) FILTER (WHERE (f.status = 'succeeded'::text)), (0)::numeric))::bigint AS gross,
            (COALESCE(sum(f.merchant_amount) FILTER (WHERE (f.status = 'succeeded'::text)), (0)::numeric))::bigint AS amount,
            count(*) FILTER (WHERE (f.status = ANY (ARRAY['pending'::text, 'unknown'::text]))) AS pending,
            COALESCE(bool_and(((f.status <> 'succeeded'::text) OR ((member72_1c1acaaf36d7e39a.refund_merchant_reserve_valid(f.id) IS TRUE) AND (member72_1c1acaaf36d7e39a.refund_merchant_resolution_valid(f.id) IS TRUE)))), true) AS valid
           FROM member72_1c1acaaf36d7e39a.refunds f
          WHERE (f.order_id = o.id)) r)
     CROSS JOIN LATERAL ( SELECT member72_1c1acaaf36d7e39a.order_income_channel_sharing_outflow(o.id) AS amount) p)
     CROSS JOIN LATERAL ( SELECT (COALESCE(sum(i.amount) FILTER (WHERE (i.status <> 'rejected'::text)), (0)::numeric))::bigint AS amount,
            COALESCE(bool_and((i.valid IS TRUE)), true) AS valid
           FROM member72_1c1acaaf36d7e39a.order_income_internal_allocation_evidence i
          WHERE (i.order_id = o.id)) a);


--
-- Name: order_print_origins; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.order_print_origins (
    order_id bigint NOT NULL,
    kind text NOT NULL,
    collection_code_id bigint,
    proof_hash bytea NOT NULL,
    CONSTRAINT order_print_origins_check CHECK (((kind = 'collection'::text) = (collection_code_id IS NOT NULL))),
    CONSTRAINT order_print_origins_kind_check CHECK ((kind = ANY (ARRAY['api'::text, 'recharge'::text, 'collection'::text]))),
    CONSTRAINT order_print_origins_proof_hash_check CHECK ((octet_length(proof_hash) = 32))
);


--
-- Name: order_profit_allocations_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.order_profit_allocations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: order_profit_allocations_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.order_profit_allocations_id_seq OWNED BY member72_1c1acaaf36d7e39a.order_profit_allocations.id;


--
-- Name: order_reporting; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.order_reporting (
    order_id bigint NOT NULL,
    buyer text DEFAULT ''::text NOT NULL,
    province text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    client_ip text DEFAULT ''::text NOT NULL,
    CONSTRAINT order_reporting_client_ip_check CHECK ((octet_length(client_ip) <= 45))
);


--
-- Name: orders_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.orders_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: orders_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.orders_id_seq OWNED BY member72_1c1acaaf36d7e39a.orders.id;


--
-- Name: outbox; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.outbox (
    id bigint NOT NULL,
    event_key text NOT NULL,
    kind text NOT NULL,
    payload jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: outbox_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.outbox_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: outbox_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.outbox_id_seq OWNED BY member72_1c1acaaf36d7e39a.outbox.id;


--
-- Name: page_template_assets; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.page_template_assets (
    id text NOT NULL,
    mime text NOT NULL,
    width integer NOT NULL,
    height integer NOT NULL,
    content bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT page_template_assets_check CHECK ((((width)::bigint * (height)::bigint) <= 1048576)),
    CONSTRAINT page_template_assets_content_check CHECK (((octet_length(content) >= 1) AND (octet_length(content) <= 2097152))),
    CONSTRAINT page_template_assets_height_check CHECK (((height >= 1) AND (height <= 2048))),
    CONSTRAINT page_template_assets_id_check CHECK ((id ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT page_template_assets_mime_check CHECK ((mime = ANY (ARRAY['image/png'::text, 'image/jpeg'::text]))),
    CONSTRAINT page_template_assets_width_check CHECK (((width >= 1) AND (width <= 2048)))
);


--
-- Name: page_template_configs; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.page_template_configs (
    kind text NOT NULL,
    name text NOT NULL,
    config jsonb NOT NULL,
    revision bigint NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT page_template_configs_config_check CHECK (((jsonb_typeof(config) = 'object'::text) AND (octet_length((config)::text) <= 8192))),
    CONSTRAINT page_template_configs_name_check CHECK (((length(name) >= 1) AND (length(name) <= 64))),
    CONSTRAINT page_template_configs_revision_check CHECK ((revision > 0))
);


--
-- Name: page_template_heads; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.page_template_heads (
    kind text NOT NULL,
    selected_name text NOT NULL,
    revision bigint DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT page_template_heads_kind_check CHECK ((kind = ANY (ARRAY['home'::text, 'pay'::text, 'qrpay'::text]))),
    CONSTRAINT page_template_heads_revision_check CHECK ((revision >= 0)),
    CONSTRAINT page_template_heads_selected_name_check CHECK (((length(selected_name) >= 1) AND (length(selected_name) <= 64)))
);


--
-- Name: payment_authorization_releases; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.payment_authorization_releases (
    order_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    request_no text NOT NULL,
    auth_no text NOT NULL,
    amount bigint NOT NULL,
    state text DEFAULT 'checking'::text NOT NULL,
    sent boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    remaining_source_id bigint,
    remaining_source_revision bigint DEFAULT 0 CONSTRAINT payment_authorization_releas_remaining_source_revision_not_null NOT NULL,
    remaining_source_hash bytea,
    CONSTRAINT authorization_remaining_head_shape CHECK ((((remaining_source_revision = 0) AND (remaining_source_id IS NULL) AND (remaining_source_hash IS NULL)) OR ((remaining_source_revision > 0) AND (remaining_source_id IS NOT NULL) AND (remaining_source_hash IS NOT NULL) AND (octet_length(remaining_source_hash) = 32)))),
    CONSTRAINT payment_authorization_releases_amount_check CHECK ((amount > 0)),
    CONSTRAINT payment_authorization_releases_channel_id_check CHECK ((channel_id > 0)),
    CONSTRAINT payment_authorization_releases_remaining_source_revision_check CHECK (((remaining_source_revision >= 0) AND (remaining_source_revision <= 100))),
    CONSTRAINT payment_authorization_releases_state_check CHECK ((state = ANY (ARRAY['checking'::text, 'processing'::text, 'reversal_pending'::text, 'unknown'::text, 'failed'::text, 'succeeded'::text])))
);


--
-- Name: payment_authorizations; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.payment_authorizations (
    order_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    auth_no text NOT NULL,
    buyer_id text NOT NULL,
    amount bigint NOT NULL,
    capture_state text DEFAULT 'none'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    release_state text DEFAULT 'none'::text NOT NULL,
    CONSTRAINT payment_authorizations_amount_check CHECK ((amount > 0)),
    CONSTRAINT payment_authorizations_auth_no_check CHECK (((length(auth_no) >= 1) AND (length(auth_no) <= 256))),
    CONSTRAINT payment_authorizations_buyer_id_check CHECK (((length(buyer_id) >= 1) AND (length(buyer_id) <= 256))),
    CONSTRAINT payment_authorizations_capture_state_check CHECK ((capture_state = ANY (ARRAY['none'::text, 'processing'::text, 'unknown'::text, 'failed'::text, 'succeeded'::text]))),
    CONSTRAINT payment_authorizations_channel_id_check CHECK ((channel_id > 0)),
    CONSTRAINT payment_authorizations_release_state_check CHECK ((release_state = ANY (ARRAY['none'::text, 'checking'::text, 'processing'::text, 'reversal_pending'::text, 'unknown'::text, 'failed'::text, 'succeeded'::text])))
);


--
-- Name: payment_print_sources; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.payment_print_sources (
    order_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    body jsonb NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT payment_print_sources_proof_hash_check CHECK ((octet_length(proof_hash) = 32))
);


--
-- Name: preauth_observation_events; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.preauth_observation_events (
    id bigint NOT NULL,
    observation_id text NOT NULL,
    operation text NOT NULL,
    proof bytea NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT preauth_observation_events_operation_check CHECK ((operation = ANY (ARRAY['claimed'::text, 'verified'::text, 'unknown'::text]))),
    CONSTRAINT preauth_observation_events_proof_check CHECK ((octet_length(proof) = 32))
);


--
-- Name: preauth_observation_events_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.preauth_observation_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: preauth_observation_events_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.preauth_observation_events_id_seq OWNED BY member72_1c1acaaf36d7e39a.preauth_observation_events.id;


--
-- Name: preauth_observations; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.preauth_observations (
    id text NOT NULL,
    client_request_no text NOT NULL,
    merchant_id bigint NOT NULL,
    order_id bigint NOT NULL,
    attempt_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    trade_no text NOT NULL,
    app_id text NOT NULL,
    auth_no text NOT NULL,
    buyer_id text NOT NULL,
    amount bigint NOT NULL,
    account_hash bytea NOT NULL,
    merchant_revision bigint NOT NULL,
    session_hash bytea NOT NULL,
    actor_username text NOT NULL,
    actor_role text NOT NULL,
    actor_id bigint NOT NULL,
    actor_auth_version bigint NOT NULL,
    source_proof bytea NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    status text DEFAULT 'processing'::text NOT NULL,
    rest_amount bigint,
    provider_status text DEFAULT ''::text NOT NULL,
    order_status text DEFAULT ''::text NOT NULL,
    operation_type text DEFAULT ''::text NOT NULL,
    observed_at timestamp with time zone,
    result_proof bytea,
    CONSTRAINT preauth_observations_account_hash_check CHECK ((octet_length(account_hash) = 32)),
    CONSTRAINT preauth_observations_actor_auth_version_check CHECK ((actor_auth_version > 0)),
    CONSTRAINT preauth_observations_actor_id_check CHECK ((actor_id > 0)),
    CONSTRAINT preauth_observations_actor_role_check CHECK ((actor_role = ANY (ARRAY['merchant'::text, 'admin'::text]))),
    CONSTRAINT preauth_observations_amount_check CHECK ((amount > 0)),
    CONSTRAINT preauth_observations_channel_id_check CHECK ((channel_id > 0)),
    CONSTRAINT preauth_observations_check CHECK (((expires_at > created_at) AND (expires_at <= (created_at + '00:05:00'::interval)))),
    CONSTRAINT preauth_observations_check1 CHECK (((status = 'processing'::text) = (observed_at IS NULL))),
    CONSTRAINT preauth_observations_check2 CHECK (((status = 'processing'::text) = (result_proof IS NULL))),
    CONSTRAINT preauth_observations_check3 CHECK ((((status = 'verified'::text) AND (rest_amount IS NOT NULL) AND ((rest_amount >= 0) AND (rest_amount <= amount)) AND (provider_status = 'SUCCESS'::text) AND (order_status = ANY (ARRAY['AUTHORIZED'::text, 'FINISH'::text])) AND (operation_type = 'FREEZE'::text)) OR ((status = ANY (ARRAY['processing'::text, 'unknown'::text])) AND (rest_amount IS NULL) AND (provider_status = ''::text) AND (order_status = ''::text) AND (operation_type = ''::text)))),
    CONSTRAINT preauth_observations_client_request_no_check CHECK ((client_request_no ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT preauth_observations_id_check CHECK ((id ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT preauth_observations_merchant_revision_check CHECK ((merchant_revision > 0)),
    CONSTRAINT preauth_observations_result_proof_check CHECK ((octet_length(result_proof) = 32)),
    CONSTRAINT preauth_observations_session_hash_check CHECK ((octet_length(session_hash) = 32)),
    CONSTRAINT preauth_observations_source_proof_check CHECK ((octet_length(source_proof) = 32)),
    CONSTRAINT preauth_observations_status_check CHECK ((status = ANY (ARRAY['processing'::text, 'verified'::text, 'unknown'::text])))
);


--
-- Name: printing_claims; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.printing_claims (
    intent_id bigint NOT NULL,
    token bytea NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT printing_claims_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT printing_claims_token_check CHECK ((octet_length(token) = 32))
);


--
-- Name: printing_intents; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.printing_intents (
    id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    order_id bigint NOT NULL,
    source text NOT NULL,
    external_no text NOT NULL,
    request_no text NOT NULL,
    platform_config_id bigint NOT NULL,
    merchant_config_id bigint NOT NULL,
    body jsonb NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT printing_intents_external_no_check CHECK (((length(external_no) >= 1) AND (length(external_no) <= 64))),
    CONSTRAINT printing_intents_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT printing_intents_source_check CHECK ((source = ANY (ARRAY['auto'::text, 'manual'::text])))
);


--
-- Name: printing_merchant_configs; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.printing_merchant_configs (
    id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    revision bigint NOT NULL,
    mode smallint NOT NULL,
    device_cipher bytea,
    copies smallint NOT NULL,
    voice boolean NOT NULL,
    actor_name text NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT printing_merchant_configs_check CHECK (((mode = 0) OR (device_cipher IS NOT NULL))),
    CONSTRAINT printing_merchant_configs_copies_check CHECK (((copies >= 1) AND (copies <= 5))),
    CONSTRAINT printing_merchant_configs_mode_check CHECK (((mode >= 0) AND (mode <= 2))),
    CONSTRAINT printing_merchant_configs_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT printing_merchant_configs_revision_check CHECK ((revision > 0))
);


--
-- Name: printing_platform_configs; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.printing_platform_configs (
    id bigint NOT NULL,
    revision bigint NOT NULL,
    enabled boolean NOT NULL,
    provider text NOT NULL,
    credential_cipher bytea,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT printing_platform_configs_actor_id_check CHECK ((actor_id > 0)),
    CONSTRAINT printing_platform_configs_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT printing_platform_configs_provider_check CHECK ((provider = ANY (ARRAY['local_fake'::text, 'excelsecu'::text]))),
    CONSTRAINT printing_platform_configs_revision_check CHECK ((revision > 0))
);


--
-- Name: printing_intent_invariants; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.printing_intent_invariants AS
 SELECT i.id,
    ((s.merchant_id = i.merchant_id) AND (m.merchant_id = i.merchant_id) AND (m.mode > 0) AND p.enabled AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.backoffice_audit a
          WHERE ((a.resource = 'printing-intents'::text) AND (a.resource_id = i.id) AND (a.operation = 'create'::text) AND (a.actor_name = (i.body ->> 'actor_name'::text)) AND (((i.source = 'manual'::text) AND (a.actor_role = 'merchant'::text) AND (a.actor_id = i.merchant_id)) OR ((i.source = 'auto'::text) AND (a.actor_role = 'system'::text) AND (a.actor_id = 0) AND (a.actor_name = 'receipt-printer'::text))))))) AS valid
   FROM (((member72_1c1acaaf36d7e39a.printing_intents i
     JOIN member72_1c1acaaf36d7e39a.payment_print_sources s ON ((s.order_id = i.order_id)))
     JOIN member72_1c1acaaf36d7e39a.printing_platform_configs p ON ((p.id = i.platform_config_id)))
     JOIN member72_1c1acaaf36d7e39a.printing_merchant_configs m ON ((m.id = i.merchant_config_id)));


--
-- Name: printing_intents_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.printing_intents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: printing_intents_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.printing_intents_id_seq OWNED BY member72_1c1acaaf36d7e39a.printing_intents.id;


--
-- Name: printing_merchant_configs_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.printing_merchant_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: printing_merchant_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.printing_merchant_configs_id_seq OWNED BY member72_1c1acaaf36d7e39a.printing_merchant_configs.id;


--
-- Name: printing_merchant_heads; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.printing_merchant_heads (
    merchant_id bigint NOT NULL,
    config_id bigint NOT NULL,
    revision bigint NOT NULL
);


--
-- Name: printing_platform_configs_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.printing_platform_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: printing_platform_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.printing_platform_configs_id_seq OWNED BY member72_1c1acaaf36d7e39a.printing_platform_configs.id;


--
-- Name: printing_platform_head; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.printing_platform_head (
    singleton boolean DEFAULT true NOT NULL,
    config_id bigint NOT NULL,
    revision bigint NOT NULL,
    CONSTRAINT printing_platform_head_singleton_check CHECK (singleton)
);


--
-- Name: printing_recoveries; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.printing_recoveries (
    id bigint NOT NULL,
    intent_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    expected_task_id bigint NOT NULL,
    new_task_id bigint NOT NULL,
    sequence_no smallint NOT NULL,
    actor_name text NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT printing_recoveries_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT printing_recoveries_sequence_no_check CHECK (((sequence_no >= 1) AND (sequence_no <= 5)))
);


--
-- Name: printing_recoveries_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.printing_recoveries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: printing_recoveries_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.printing_recoveries_id_seq OWNED BY member72_1c1acaaf36d7e39a.printing_recoveries.id;


--
-- Name: printing_results; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.printing_results (
    intent_id bigint NOT NULL,
    state text NOT NULL,
    reason text NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT printing_results_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT printing_results_reason_check CHECK ((reason = ANY (ARRAY['gateway_accepted'::text, 'gateway_rejected'::text, 'transport_unknown'::text, 'connector_unavailable'::text, 'scope_changed'::text, 'claim_recovered'::text]))),
    CONSTRAINT printing_results_state_check CHECK ((state = ANY (ARRAY['accepted'::text, 'rejected'::text, 'unknown'::text])))
);


--
-- Name: profile_identity_link_events; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.profile_identity_link_events (
    request_id text NOT NULL,
    operation text NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT profile_identity_link_events_operation_check CHECK ((operation = ANY (ARRAY['created'::text, 'claimed'::text, 'ready'::text, 'failed'::text, 'unknown'::text])))
);


--
-- Name: profile_identity_links; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.profile_identity_links (
    request_id text NOT NULL,
    parent_proof bytea NOT NULL,
    parent_created_at timestamp with time zone NOT NULL,
    actor_class text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    requested_expires_at timestamp with time zone NOT NULL,
    birth_xid xid8 DEFAULT pg_current_xact_id() NOT NULL,
    source_proof bytea NOT NULL,
    state_proof bytea NOT NULL,
    status text NOT NULL,
    link_cipher bytea,
    completed_at timestamp with time zone,
    CONSTRAINT profile_identity_links_check CHECK (((parent_created_at <= created_at) AND (created_at < expires_at) AND (expires_at <= (parent_created_at + '00:05:00'::interval)))),
    CONSTRAINT profile_identity_links_check1 CHECK ((requested_expires_at = date_trunc('second'::text, expires_at))),
    CONSTRAINT profile_identity_links_check2 CHECK ((((status = 'creating'::text) AND (completed_at IS NULL) AND (link_cipher IS NULL)) OR ((status = 'ready'::text) AND (completed_at IS NOT NULL) AND (link_cipher IS NOT NULL) AND (octet_length(link_cipher) > 28)) OR ((status = ANY (ARRAY['failed'::text, 'unknown'::text])) AND (completed_at IS NOT NULL) AND (link_cipher IS NULL)))),
    CONSTRAINT profile_identity_links_parent_proof_check CHECK ((octet_length(parent_proof) = 32)),
    CONSTRAINT profile_identity_links_source_proof_check CHECK ((octet_length(source_proof) = 32)),
    CONSTRAINT profile_identity_links_state_proof_check CHECK ((octet_length(state_proof) = 32)),
    CONSTRAINT profile_identity_links_status_check CHECK ((status = ANY (ARRAY['creating'::text, 'ready'::text, 'failed'::text, 'unknown'::text])))
);


--
-- Name: profile_identity_lookup_events; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.profile_identity_lookup_events (
    id bigint NOT NULL,
    request_id text NOT NULL,
    operation text NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT profile_identity_lookup_events_operation_check CHECK ((operation = ANY (ARRAY['created'::text, 'authorized'::text, 'processing'::text, 'verified'::text, 'failed'::text, 'revealed'::text])))
);


--
-- Name: profile_identity_lookup_events_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.profile_identity_lookup_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: profile_identity_lookup_events_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.profile_identity_lookup_events_id_seq OWNED BY member72_1c1acaaf36d7e39a.profile_identity_lookup_events.id;


--
-- Name: profile_identity_lookup_requests; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.profile_identity_lookup_requests (
    id text NOT NULL,
    merchant_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    merchant_revision bigint NOT NULL,
    profile_id bigint NOT NULL,
    profile_revision bigint NOT NULL,
    provider text NOT NULL,
    app_id text NOT NULL,
    kind text NOT NULL,
    path text NOT NULL,
    profile_hash bytea NOT NULL,
    session_hash bytea NOT NULL,
    actor_username text NOT NULL,
    actor_role text NOT NULL,
    actor_id bigint NOT NULL,
    actor_auth_version bigint NOT NULL,
    authorization_hash bytea,
    source_proof bytea NOT NULL,
    state_hash bytea,
    browser_hash bytea,
    launch_proof bytea,
    status text DEFAULT 'pending'::text NOT NULL,
    subject_cipher bytea,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    completed_at timestamp with time zone,
    revealed_at timestamp with time zone,
    CONSTRAINT profile_identity_lookup_requests_actor_auth_version_check CHECK ((actor_auth_version > 0)),
    CONSTRAINT profile_identity_lookup_requests_actor_id_check CHECK ((actor_id > 0)),
    CONSTRAINT profile_identity_lookup_requests_actor_role_check CHECK ((actor_role = ANY (ARRAY['admin'::text, 'merchant'::text]))),
    CONSTRAINT profile_identity_lookup_requests_app_id_check CHECK (((length(app_id) >= 1) AND (length(app_id) <= 128))),
    CONSTRAINT profile_identity_lookup_requests_authorization_hash_check CHECK ((octet_length(authorization_hash) = 32)),
    CONSTRAINT profile_identity_lookup_requests_browser_hash_check CHECK ((octet_length(browser_hash) = 32)),
    CONSTRAINT profile_identity_lookup_requests_channel_id_check CHECK ((channel_id > 0)),
    CONSTRAINT profile_identity_lookup_requests_check CHECK (((expires_at > created_at) AND (expires_at <= (created_at + '00:05:00'::interval)))),
    CONSTRAINT profile_identity_lookup_requests_check1 CHECK ((((kind = 'web'::text) AND (path = ''::text) AND (authorization_hash IS NOT NULL)) OR ((kind = 'mini'::text) AND ((length(path) >= 1) AND (length(path) <= 256)) AND (authorization_hash IS NULL)))),
    CONSTRAINT profile_identity_lookup_requests_check2 CHECK (((state_hash IS NULL) = (launch_proof IS NULL))),
    CONSTRAINT profile_identity_lookup_requests_check3 CHECK (((kind <> 'mini'::text) OR (state_hash IS NOT NULL))),
    CONSTRAINT profile_identity_lookup_requests_check4 CHECK (((kind <> 'mini'::text) OR (browser_hash IS NULL))),
    CONSTRAINT profile_identity_lookup_requests_check5 CHECK (((status <> ALL (ARRAY['verified'::text, 'revealed'::text])) OR (subject_cipher IS NOT NULL))),
    CONSTRAINT profile_identity_lookup_requests_check6 CHECK (((status = 'revealed'::text) = (revealed_at IS NOT NULL))),
    CONSTRAINT profile_identity_lookup_requests_id_check CHECK ((id ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT profile_identity_lookup_requests_kind_check CHECK ((kind = ANY (ARRAY['web'::text, 'mini'::text]))),
    CONSTRAINT profile_identity_lookup_requests_launch_proof_check CHECK ((octet_length(launch_proof) = 32)),
    CONSTRAINT profile_identity_lookup_requests_merchant_revision_check CHECK ((merchant_revision > 0)),
    CONSTRAINT profile_identity_lookup_requests_profile_hash_check CHECK ((octet_length(profile_hash) = 32)),
    CONSTRAINT profile_identity_lookup_requests_profile_id_check CHECK ((profile_id > 0)),
    CONSTRAINT profile_identity_lookup_requests_profile_revision_check CHECK ((profile_revision > 0)),
    CONSTRAINT profile_identity_lookup_requests_provider_check CHECK ((provider = ANY (ARRAY['wxpay'::text, 'alipay'::text]))),
    CONSTRAINT profile_identity_lookup_requests_session_hash_check CHECK ((octet_length(session_hash) = 32)),
    CONSTRAINT profile_identity_lookup_requests_source_proof_check CHECK ((octet_length(source_proof) = 32)),
    CONSTRAINT profile_identity_lookup_requests_state_hash_check CHECK ((octet_length(state_hash) = 32)),
    CONSTRAINT profile_identity_lookup_requests_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'processing'::text, 'verified'::text, 'failed'::text, 'revealed'::text])))
);


--
-- Name: provider_attempt_accounts; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.provider_attempt_accounts (
    attempt_id bigint NOT NULL,
    account_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    recovery_version smallint DEFAULT 0 NOT NULL,
    recovery_source_hash bytea,
    CONSTRAINT provider_attempt_accounts_account_hash_check CHECK ((octet_length(account_hash) = 32)),
    CONSTRAINT scan_recovery_account_shape CHECK ((((recovery_version = 0) AND (recovery_source_hash IS NULL)) OR ((recovery_version = 1) AND (recovery_source_hash IS NOT NULL) AND (octet_length(recovery_source_hash) = 32))))
);


--
-- Name: provider_attempt_identities; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.provider_attempt_identities (
    attempt_id bigint NOT NULL,
    request_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT provider_attempt_identities_request_hash_check CHECK ((octet_length(request_hash) = 32))
);


--
-- Name: provider_attempt_sharing_items; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.provider_attempt_sharing_items (
    attempt_id bigint NOT NULL,
    "position" integer NOT NULL,
    receiver_id bigint NOT NULL,
    amount bigint NOT NULL,
    CONSTRAINT provider_attempt_sharing_items_amount_check CHECK ((amount > 0)),
    CONSTRAINT provider_attempt_sharing_items_position_check CHECK ((("position" >= 1) AND ("position" <= 50)))
);


--
-- Name: provider_attempts; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.provider_attempts (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    method text NOT NULL,
    state text DEFAULT 'processing'::text NOT NULL,
    material_type text DEFAULT ''::text NOT NULL,
    material text DEFAULT ''::text NOT NULL,
    provider_trade_no text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT provider_attempts_channel_id_check CHECK ((channel_id > 0)),
    CONSTRAINT provider_attempts_material_check CHECK ((octet_length(material) <= 1048576)),
    CONSTRAINT provider_attempts_method_check CHECK ((method ~ '^[a-z][a-z0-9_]{0,31}$'::text)),
    CONSTRAINT provider_attempts_provider_trade_no_check CHECK ((octet_length(provider_trade_no) <= 256)),
    CONSTRAINT provider_attempts_state_check CHECK ((state = ANY (ARRAY['processing'::text, 'pending'::text, 'unknown'::text, 'failed'::text])))
);


--
-- Name: provider_attempts_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.provider_attempts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: provider_attempts_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.provider_attempts_id_seq OWNED BY member72_1c1acaaf36d7e39a.provider_attempts.id;


--
-- Name: provider_operations; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.provider_operations (
    id bigint NOT NULL,
    kind text NOT NULL,
    business_key text NOT NULL,
    order_id bigint NOT NULL,
    refund_id bigint,
    channel_id bigint NOT NULL,
    state text DEFAULT 'processing'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT provider_operations_kind_check CHECK ((kind = ANY (ARRAY['close'::text, 'refund'::text]))),
    CONSTRAINT provider_operations_state_check CHECK ((state = ANY (ARRAY['processing'::text, 'pending'::text, 'unknown'::text, 'succeeded'::text, 'failed'::text])))
);


--
-- Name: provider_operations_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.provider_operations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: provider_operations_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.provider_operations_id_seq OWNED BY member72_1c1acaaf36d7e39a.provider_operations.id;


--
-- Name: provider_reconciliations; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.provider_reconciliations (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    previous_status text NOT NULL,
    event_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: provider_reconciliations_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.provider_reconciliations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: provider_reconciliations_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.provider_reconciliations_id_seq OWNED BY member72_1c1acaaf36d7e39a.provider_reconciliations.id;


--
-- Name: provider_refund_result_evidence; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.provider_refund_result_evidence (
    refund_id bigint NOT NULL,
    operation_id bigint,
    order_id bigint NOT NULL,
    channel_id bigint,
    amount bigint NOT NULL,
    refund_no text NOT NULL,
    prior_refund_state text NOT NULL,
    prior_operation_state text,
    source text NOT NULL,
    state text NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT provider_refund_result_evidence_amount_check CHECK ((amount > 0)),
    CONSTRAINT provider_refund_result_evidence_channel_id_check CHECK ((channel_id > 0)),
    CONSTRAINT provider_refund_result_evidence_check CHECK ((((source = 'provider'::text) AND (operation_id IS NOT NULL) AND (channel_id IS NOT NULL) AND (prior_operation_state IS NOT NULL)) OR ((source = 'internal'::text) AND (operation_id IS NULL) AND (channel_id IS NULL) AND (prior_operation_state IS NULL)))),
    CONSTRAINT provider_refund_result_evidence_prior_operation_state_check CHECK ((prior_operation_state = ANY (ARRAY['processing'::text, 'pending'::text, 'unknown'::text, 'succeeded'::text, 'failed'::text]))),
    CONSTRAINT provider_refund_result_evidence_prior_refund_state_check CHECK ((prior_refund_state = ANY (ARRAY['pending'::text, 'unknown'::text]))),
    CONSTRAINT provider_refund_result_evidence_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT provider_refund_result_evidence_source_check CHECK ((source = ANY (ARRAY['provider'::text, 'internal'::text]))),
    CONSTRAINT provider_refund_result_evidence_state_check CHECK ((state = ANY (ARRAY['succeeded'::text, 'failed'::text])))
);


--
-- Name: provider_refund_result_invariants; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.provider_refund_result_invariants AS
 SELECT e.refund_id,
    (((r.order_id = e.order_id) AND (r.amount = e.amount) AND (r.refund_no = e.refund_no) AND (r.status = e.state)) AND ((e.source = 'internal'::text) OR ((p.kind = 'refund'::text) AND (p.order_id = e.order_id) AND (p.refund_id = e.refund_id) AND (p.channel_id = e.channel_id) AND (p.state = e.state))) AND (e.prior_refund_state = ANY (ARRAY['pending'::text, 'unknown'::text])) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.operation_audit a
          WHERE ((a.operation_kind = 'refund'::text) AND (a.operation_id = r.id) AND (a.to_status = e.state)))) AND (member72_1c1acaaf36d7e39a.refund_merchant_resolution_valid(r.id) IS TRUE) AND
        CASE
            WHEN (r.fee_amount > 0) THEN (EXISTS ( SELECT 1
               FROM member72_1c1acaaf36d7e39a.journals j
              WHERE ((j.event_key = (('refund-fee:'::text || (r.id)::text) || ':resolve'::text)) AND ( SELECT (count(*) = 2)
                       FROM member72_1c1acaaf36d7e39a.ledger_entries x
                      WHERE (x.journal_id = j.id)) AND ( SELECT (COALESCE(sum(x.amount), (0)::numeric) = ((- r.fee_amount))::numeric)
                       FROM (member72_1c1acaaf36d7e39a.ledger_entries x
                         JOIN member72_1c1acaaf36d7e39a.accounts a ON ((a.id = x.account_id)))
                      WHERE ((x.journal_id = j.id) AND (a.owner_id = 0) AND (a.kind = 'fee_reserved'::text) AND (a.scope_id = 0))) AND ( SELECT (COALESCE(sum(x.amount), (0)::numeric) = (r.fee_amount)::numeric)
                       FROM (member72_1c1acaaf36d7e39a.ledger_entries x
                         JOIN member72_1c1acaaf36d7e39a.accounts a ON ((a.id = x.account_id)))
                      WHERE ((x.journal_id = j.id) AND (a.owner_id = 0) AND (a.scope_id = 0) AND (a.kind =
                            CASE
                                WHEN (e.state = 'succeeded'::text) THEN 'clearing'::text
                                ELSE 'fees'::text
                            END))))))
            ELSE true
        END) AS valid
   FROM ((member72_1c1acaaf36d7e39a.provider_refund_result_evidence e
     JOIN member72_1c1acaaf36d7e39a.refunds r ON ((r.id = e.refund_id)))
     LEFT JOIN member72_1c1acaaf36d7e39a.provider_operations p ON ((p.id = e.operation_id)));


--
-- Name: provider_route_assignments; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.provider_route_assignments (
    merchant_id bigint NOT NULL,
    out_trade_no text NOT NULL,
    channel_id bigint NOT NULL,
    method text NOT NULL,
    pay_type text NOT NULL,
    amount bigint NOT NULL,
    request_hash bytea NOT NULL,
    rule_id bigint,
    rule_snapshot jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT provider_route_assignments_amount_check CHECK ((amount > 0)),
    CONSTRAINT provider_route_assignments_channel_id_check CHECK ((channel_id > 0)),
    CONSTRAINT provider_route_assignments_method_check CHECK ((method ~ '^[a-z][a-z0-9_]{0,31}$'::text)),
    CONSTRAINT provider_route_assignments_out_trade_no_check CHECK (((octet_length(out_trade_no) >= 1) AND (octet_length(out_trade_no) <= 128))),
    CONSTRAINT provider_route_assignments_pay_type_check CHECK ((pay_type = ANY (ARRAY['wxpay'::text, 'alipay'::text]))),
    CONSTRAINT provider_route_assignments_request_hash_check CHECK ((octet_length(request_hash) = 32)),
    CONSTRAINT provider_route_assignments_rule_snapshot_check CHECK ((jsonb_typeof(rule_snapshot) = 'object'::text))
);


--
-- Name: provider_route_counters; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.provider_route_counters (
    rule_id bigint NOT NULL,
    cursor bigint DEFAULT 0 NOT NULL,
    assigned bigint DEFAULT 0 NOT NULL,
    CONSTRAINT provider_route_counters_assigned_check CHECK ((assigned >= 0)),
    CONSTRAINT provider_route_counters_cursor_check CHECK ((cursor >= 0))
);


--
-- Name: provider_subject_snapshots; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.provider_subject_snapshots (
    order_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    subject text NOT NULL,
    configured boolean NOT NULL,
    policy_snapshot jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT provider_subject_snapshots_channel_id_check CHECK ((channel_id > 0)),
    CONSTRAINT provider_subject_snapshots_check CHECK (((configured AND ((octet_length(subject) >= 1) AND (octet_length(subject) <= 128))) OR ((NOT configured) AND (octet_length(subject) <= 256)))),
    CONSTRAINT provider_subject_snapshots_policy_snapshot_check CHECK ((jsonb_typeof(policy_snapshot) = 'object'::text))
);


--
-- Name: provider_transfer_accounts; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.provider_transfer_accounts (
    transfer_id bigint NOT NULL,
    account_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT provider_transfer_accounts_account_hash_check CHECK ((octet_length(account_hash) = 32))
);


--
-- Name: provider_transfer_attempts; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.provider_transfer_attempts (
    transfer_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    recipient_cipher bytea NOT NULL,
    state text DEFAULT 'processing'::text NOT NULL,
    provider_transfer_no text DEFAULT ''::text NOT NULL,
    pay_date text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT provider_transfer_attempts_channel_id_check CHECK ((channel_id > 0)),
    CONSTRAINT provider_transfer_attempts_state_check CHECK ((state = ANY (ARRAY['processing'::text, 'pending'::text, 'unknown'::text, 'succeeded'::text, 'failed'::text])))
);


--
-- Name: provider_transfer_policies; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.provider_transfer_policies (
    transfer_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    recipient_hash bytea NOT NULL,
    request_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT provider_transfer_policies_recipient_hash_check CHECK ((octet_length(recipient_hash) = 32)),
    CONSTRAINT provider_transfer_policies_request_hash_check CHECK ((octet_length(request_hash) = 32))
);


--
-- Name: provider_transfer_proofs; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.provider_transfer_proofs (
    transfer_id bigint NOT NULL,
    state text NOT NULL,
    file_id text DEFAULT ''::text NOT NULL,
    download_cipher bytea,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT provider_transfer_proofs_state_check CHECK ((state = ANY (ARRAY['applying'::text, 'pending'::text, 'unknown'::text, 'succeeded'::text, 'failed'::text])))
);


--
-- Name: recharge_intents_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.recharge_intents_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: recharge_intents_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.recharge_intents_id_seq OWNED BY member72_1c1acaaf36d7e39a.recharge_intents.id;


--
-- Name: referral_clawback_audits; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.referral_clawback_audits (
    refund_id bigint NOT NULL,
    state text NOT NULL,
    event_key text NOT NULL,
    actor_role text NOT NULL,
    actor_name text NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT referral_clawback_audits_actor_name_check CHECK ((actor_name = 'refund-engine'::text)),
    CONSTRAINT referral_clawback_audits_actor_role_check CHECK ((actor_role = 'system'::text)),
    CONSTRAINT referral_clawback_audits_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT referral_clawback_audits_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'unknown'::text, 'succeeded'::text, 'failed'::text])))
);


--
-- Name: referral_order_terms; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.referral_order_terms (
    order_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    relation_id bigint,
    promoter_id bigint,
    purpose text NOT NULL,
    enabled boolean NOT NULL,
    reason text NOT NULL,
    rate_bps integer NOT NULL,
    platform_fee bigint NOT NULL,
    reward_amount bigint NOT NULL,
    refund_policy text NOT NULL,
    policy_versions jsonb NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT referral_order_terms_check CHECK (((reward_amount >= 0) AND (reward_amount <= platform_fee))),
    CONSTRAINT referral_order_terms_check1 CHECK (((relation_id IS NULL) = (promoter_id IS NULL))),
    CONSTRAINT referral_order_terms_check2 CHECK (((promoter_id IS NULL) OR (promoter_id <> merchant_id))),
    CONSTRAINT referral_order_terms_check3 CHECK ((enabled = (reward_amount > 0))),
    CONSTRAINT referral_order_terms_check4 CHECK (((reason = 'eligible'::text) = enabled)),
    CONSTRAINT referral_order_terms_check5 CHECK (((NOT enabled) OR ((purpose = 'payment'::text) AND (promoter_id IS NOT NULL) AND (rate_bps > 0)))),
    CONSTRAINT referral_order_terms_check6 CHECK (((purpose <> 'recharge'::text) OR ((NOT enabled) AND (reason = 'recharge'::text)))),
    CONSTRAINT referral_order_terms_platform_fee_check CHECK ((platform_fee >= 0)),
    CONSTRAINT referral_order_terms_policy_versions_check CHECK (((jsonb_typeof(policy_versions) = 'array'::text) AND (jsonb_array_length(policy_versions) = 5))),
    CONSTRAINT referral_order_terms_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT referral_order_terms_purpose_check CHECK ((purpose = ANY (ARRAY['payment'::text, 'recharge'::text]))),
    CONSTRAINT referral_order_terms_rate_bps_check CHECK (((rate_bps >= 0) AND (rate_bps <= 10000))),
    CONSTRAINT referral_order_terms_reason_check CHECK ((reason = ANY (ARRAY['eligible'::text, 'disabled'::text, 'no_relation'::text, 'promoter_disabled'::text, 'zero_fee'::text, 'zero_rate'::text, 'recharge'::text]))),
    CONSTRAINT referral_order_terms_refund_policy_check CHECK ((refund_policy = 'any_successful_refund_voids_reward'::text))
);


--
-- Name: referral_refund_clawbacks; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.referral_refund_clawbacks (
    refund_id bigint NOT NULL,
    reward_id bigint NOT NULL,
    order_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    promoter_id bigint NOT NULL,
    amount bigint NOT NULL,
    original_fee bigint NOT NULL,
    prior_fee_used bigint NOT NULL,
    refund_fee bigint NOT NULL,
    fee_contribution bigint NOT NULL,
    escrow_account_id bigint NOT NULL,
    promoter_account_id bigint NOT NULL,
    fees_account_id bigint NOT NULL,
    fee_reserved_account_id bigint NOT NULL,
    reward_hash bytea NOT NULL,
    request_hash bytea NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    reserve_journal_id bigint NOT NULL,
    contribution_journal_id bigint,
    restore_contribution_journal_id bigint,
    restore_reward_journal_id bigint,
    release_remainder_journal_id bigint,
    result_hash bytea,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    resolved_at timestamp with time zone,
    CONSTRAINT referral_refund_clawbacks_amount_check CHECK ((amount > 0)),
    CONSTRAINT referral_refund_clawbacks_check CHECK ((original_fee >= amount)),
    CONSTRAINT referral_refund_clawbacks_check1 CHECK (((prior_fee_used >= 0) AND (prior_fee_used <= (original_fee - amount)))),
    CONSTRAINT referral_refund_clawbacks_check2 CHECK (((refund_fee >= 0) AND (refund_fee <= (original_fee - prior_fee_used)))),
    CONSTRAINT referral_refund_clawbacks_check3 CHECK (((fee_contribution >= 0) AND (fee_contribution <= amount) AND (fee_contribution <= refund_fee))),
    CONSTRAINT referral_refund_clawbacks_check4 CHECK ((fee_contribution = GREATEST((0)::bigint, (refund_fee - ((original_fee - amount) - prior_fee_used))))),
    CONSTRAINT referral_refund_clawbacks_check5 CHECK (((fee_contribution = 0) = (contribution_journal_id IS NULL))),
    CONSTRAINT referral_refund_clawbacks_check6 CHECK (((state = 'pending'::text) = (result_hash IS NULL))),
    CONSTRAINT referral_refund_clawbacks_check7 CHECK (((state = ANY (ARRAY['succeeded'::text, 'failed'::text])) = (resolved_at IS NOT NULL))),
    CONSTRAINT referral_refund_clawbacks_request_hash_check CHECK ((octet_length(request_hash) = 32)),
    CONSTRAINT referral_refund_clawbacks_result_hash_check CHECK (((result_hash IS NULL) OR (octet_length(result_hash) = 32))),
    CONSTRAINT referral_refund_clawbacks_reward_hash_check CHECK ((octet_length(reward_hash) = 32)),
    CONSTRAINT referral_refund_clawbacks_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'unknown'::text, 'succeeded'::text, 'failed'::text])))
);


--
-- Name: referral_reward_audits; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.referral_reward_audits (
    reward_id bigint NOT NULL,
    event_key text NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL
);


--
-- Name: referral_rewards; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.referral_rewards (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    promoter_id bigint NOT NULL,
    amount bigint NOT NULL,
    terms_hash bytea NOT NULL,
    journal_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    provider_trade_no text NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT referral_rewards_amount_check CHECK ((amount > 0)),
    CONSTRAINT referral_rewards_check CHECK ((merchant_id <> promoter_id)),
    CONSTRAINT referral_rewards_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT referral_rewards_provider_trade_no_check CHECK (((length(provider_trade_no) >= 1) AND (length(provider_trade_no) <= 256))),
    CONSTRAINT referral_rewards_terms_hash_check CHECK ((octet_length(terms_hash) = 32))
);


--
-- Name: referral_reward_invariants; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.referral_reward_invariants AS
 SELECT r.id AS reward_id,
    ((o.status = 'paid'::text) AND t.enabled AND (t.purpose = 'payment'::text) AND (t.reason = 'eligible'::text) AND ((r.merchant_id = t.merchant_id) AND (r.promoter_id = t.promoter_id) AND (r.amount = t.reward_amount) AND (r.terms_hash = t.proof_hash)) AND (o.merchant_id = t.merchant_id) AND (o.platform_fee = t.platform_fee) AND (r.amount <= o.platform_fee) AND (NOT (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.recharge_intents i
          WHERE (i.order_id = o.id)))) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.verified_payment_receipts v
          WHERE ((v.order_id = o.id) AND (v.channel_id = r.channel_id) AND (v.provider_trade_no = r.provider_trade_no)))) AND (j.event_key = ('referral-award:'::text || (o.id)::text)) AND ( SELECT (count(*) = 2)
           FROM member72_1c1acaaf36d7e39a.ledger_entries e
          WHERE (e.journal_id = j.id)) AND ( SELECT (COALESCE(sum(e.amount), (0)::numeric) = ((- r.amount))::numeric)
           FROM (member72_1c1acaaf36d7e39a.ledger_entries e
             JOIN member72_1c1acaaf36d7e39a.accounts a ON ((a.id = e.account_id)))
          WHERE ((e.journal_id = j.id) AND (a.owner_id = 0) AND (a.kind = 'fees'::text) AND (a.scope_id = 0))) AND ( SELECT (COALESCE(sum(e.amount), (0)::numeric) = (r.amount)::numeric)
           FROM (member72_1c1acaaf36d7e39a.ledger_entries e
             JOIN member72_1c1acaaf36d7e39a.accounts a ON ((a.id = e.account_id)))
          WHERE ((e.journal_id = j.id) AND (a.owner_id = r.promoter_id) AND (a.kind = 'available'::text) AND (a.scope_id = 0))) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.journals fj
          WHERE ((fj.event_key = ('payment-fee:'::text || o.trade_no)) AND ( SELECT (count(*) = 2)
                   FROM member72_1c1acaaf36d7e39a.ledger_entries e
                  WHERE (e.journal_id = fj.id)) AND ( SELECT (COALESCE(sum(e.amount), (0)::numeric) = (o.platform_fee)::numeric)
                   FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                     JOIN member72_1c1acaaf36d7e39a.accounts a ON ((a.id = e.account_id)))
                  WHERE ((e.journal_id = fj.id) AND (a.owner_id = 0) AND (a.kind = 'fees'::text) AND (a.scope_id = 0))) AND ( SELECT (COALESCE(sum(e.amount), (0)::numeric) = ((- o.platform_fee))::numeric)
                   FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                     JOIN member72_1c1acaaf36d7e39a.accounts a ON ((a.id = e.account_id)))
                  WHERE ((e.journal_id = fj.id) AND (a.owner_id = 0) AND (a.kind = 'clearing'::text) AND (a.scope_id = 0)))))) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.referral_reward_audits a
          WHERE ((a.reward_id = r.id) AND (a.event_key = ('referral-award:'::text || (o.id)::text)))))) AS valid
   FROM (((member72_1c1acaaf36d7e39a.referral_rewards r
     JOIN member72_1c1acaaf36d7e39a.referral_order_terms t ON ((t.order_id = r.order_id)))
     JOIN member72_1c1acaaf36d7e39a.orders o ON ((o.id = r.order_id)))
     JOIN member72_1c1acaaf36d7e39a.journals j ON ((j.id = r.journal_id)));


--
-- Name: referral_clawback_invariants; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.referral_clawback_invariants AS
 SELECT c.refund_id,
    (((c.reward_id = w.id) AND (c.order_id = w.order_id) AND (c.merchant_id = w.merchant_id) AND (c.promoter_id = w.promoter_id) AND (c.amount = w.amount) AND (c.original_fee = o.platform_fee) AND (c.reward_hash = w.proof_hash)) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.referral_reward_invariants v
          WHERE ((v.reward_id = w.id) AND (v.valid IS TRUE)))) AND ((f.order_id = c.order_id) AND (f.merchant_id = c.merchant_id) AND (f.fee_amount = c.refund_fee) AND (f.status = c.state)) AND ((a.owner_id = 0) AND (a.kind = 'referral_clawback_reserve'::text) AND (a.scope_id = c.refund_id)) AND ((pa.owner_id = c.promoter_id) AND (pa.kind = 'available'::text) AND (pa.scope_id = 0)) AND ((fa.owner_id = 0) AND (fa.kind = 'fees'::text) AND (fa.scope_id = 0)) AND ((fh.owner_id = 0) AND (fh.kind = 'fee_reserved'::text) AND (fh.scope_id = 0)) AND (a.balance =
        CASE
            WHEN (c.state = ANY (ARRAY['pending'::text, 'unknown'::text])) THEN (c.amount - c.fee_contribution)
            ELSE (0)::bigint
        END) AND (( SELECT count(*) AS count
           FROM member72_1c1acaaf36d7e39a.ledger_entries e
          WHERE (e.account_id = a.id)) = ((1 +
        CASE
            WHEN (c.fee_contribution > 0) THEN 1
            ELSE 0
        END) +
        CASE
            WHEN (c.state = 'failed'::text) THEN (1 +
            CASE
                WHEN (c.fee_contribution > 0) THEN 1
                ELSE 0
            END)
            WHEN ((c.state = 'succeeded'::text) AND (c.amount > c.fee_contribution)) THEN 1
            ELSE 0
        END)) AND member72_1c1acaaf36d7e39a.referral_clawback_journal_valid(c.reserve_journal_id, (('referral-clawback:'::text || c.refund_id) || ':reserve'::text), pa.id, a.id, c.amount) AND member72_1c1acaaf36d7e39a.referral_clawback_journal_valid(c.contribution_journal_id, (('referral-clawback:'::text || c.refund_id) || ':fee-contribution'::text), a.id, fa.id, c.fee_contribution) AND
        CASE
            WHEN (c.state = 'failed'::text) THEN (member72_1c1acaaf36d7e39a.referral_clawback_journal_valid(c.restore_contribution_journal_id, (('referral-clawback:'::text || c.refund_id) || ':restore-contribution'::text), fa.id, a.id, c.fee_contribution) AND member72_1c1acaaf36d7e39a.referral_clawback_journal_valid(c.restore_reward_journal_id, (('referral-clawback:'::text || c.refund_id) || ':restore-reward'::text), a.id, pa.id, c.amount) AND (c.release_remainder_journal_id IS NULL))
            WHEN (c.state = 'succeeded'::text) THEN (member72_1c1acaaf36d7e39a.referral_clawback_journal_valid(c.release_remainder_journal_id, (('referral-clawback:'::text || c.refund_id) || ':release-remainder'::text), a.id, fa.id, (c.amount - c.fee_contribution)) AND (c.restore_contribution_journal_id IS NULL) AND (c.restore_reward_journal_id IS NULL))
            ELSE ((c.restore_contribution_journal_id IS NULL) AND (c.restore_reward_journal_id IS NULL) AND (c.release_remainder_journal_id IS NULL))
        END AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.referral_clawback_audits b
          WHERE ((b.refund_id = c.refund_id) AND (b.state = 'pending'::text) AND (b.event_key = (('referral-clawback:'::text || c.refund_id) || ':pending'::text)) AND (b.proof_hash = c.request_hash)))) AND ((c.state = 'pending'::text) OR (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.referral_clawback_audits b
          WHERE ((b.refund_id = c.refund_id) AND (b.state = c.state) AND (b.event_key = ((('referral-clawback:'::text || c.refund_id) || ':'::text) || c.state)) AND (b.proof_hash = c.result_hash))))) AND (member72_1c1acaaf36d7e39a.refund_merchant_reserve_valid(f.id) IS TRUE) AND (member72_1c1acaaf36d7e39a.refund_merchant_resolution_valid(f.id) IS TRUE) AND member72_1c1acaaf36d7e39a.referral_clawback_journal_valid(( SELECT j.id
           FROM member72_1c1acaaf36d7e39a.journals j
          WHERE (j.event_key = (('refund-fee:'::text || f.id) || ':reserve'::text))), (('refund-fee:'::text || f.id) || ':reserve'::text), fa.id, fh.id, f.fee_amount) AND ((f.status = ANY (ARRAY['pending'::text, 'unknown'::text])) OR member72_1c1acaaf36d7e39a.referral_clawback_journal_valid(( SELECT j.id
           FROM member72_1c1acaaf36d7e39a.journals j
          WHERE (j.event_key = (('refund-fee:'::text || f.id) || ':resolve'::text))), (('refund-fee:'::text || f.id) || ':resolve'::text), fh.id,
        CASE
            WHEN (f.status = 'failed'::text) THEN fa.id
            ELSE ( SELECT accounts.id
               FROM member72_1c1acaaf36d7e39a.accounts
              WHERE ((accounts.owner_id = 0) AND (accounts.kind = 'clearing'::text) AND (accounts.scope_id = 0)))
        END, f.fee_amount))) AS valid
   FROM (((((((member72_1c1acaaf36d7e39a.referral_refund_clawbacks c
     JOIN member72_1c1acaaf36d7e39a.referral_rewards w ON ((w.id = c.reward_id)))
     JOIN member72_1c1acaaf36d7e39a.orders o ON ((o.id = c.order_id)))
     JOIN member72_1c1acaaf36d7e39a.refunds f ON ((f.id = c.refund_id)))
     JOIN member72_1c1acaaf36d7e39a.accounts a ON ((a.id = c.escrow_account_id)))
     JOIN member72_1c1acaaf36d7e39a.accounts pa ON ((pa.id = c.promoter_account_id)))
     JOIN member72_1c1acaaf36d7e39a.accounts fa ON ((fa.id = c.fees_account_id)))
     JOIN member72_1c1acaaf36d7e39a.accounts fh ON ((fh.id = c.fee_reserved_account_id)));


--
-- Name: referral_daily_awards; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.referral_daily_awards (
    order_id bigint NOT NULL,
    reward_id bigint NOT NULL,
    release_journal_id bigint NOT NULL,
    executed_at timestamp with time zone NOT NULL,
    source_hash bytea NOT NULL,
    CONSTRAINT referral_daily_awards_source_hash_check CHECK ((octet_length(source_hash) = 32))
);


--
-- Name: referral_daily_events; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.referral_daily_events (
    id bigint NOT NULL,
    order_id bigint NOT NULL,
    operation text NOT NULL,
    reference_id bigint NOT NULL,
    event_key text NOT NULL,
    actor_role text DEFAULT 'system'::text NOT NULL,
    actor_name text NOT NULL,
    subject_hash bytea NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT referral_daily_events_actor_name_check CHECK ((actor_name = ANY (ARRAY['payment-engine'::text, 'daily-referral-engine'::text, 'refund-engine'::text]))),
    CONSTRAINT referral_daily_events_actor_role_check CHECK ((actor_role = 'system'::text)),
    CONSTRAINT referral_daily_events_operation_check CHECK ((operation = ANY (ARRAY['birth'::text, 'funded'::text, 'awarded'::text, 'refund-pending'::text, 'refund-unknown'::text, 'refund-failed'::text, 'refund-succeeded'::text]))),
    CONSTRAINT referral_daily_events_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT referral_daily_events_reference_id_check CHECK ((reference_id >= 0)),
    CONSTRAINT referral_daily_events_subject_hash_check CHECK ((octet_length(subject_hash) = 32))
);


--
-- Name: referral_daily_liabilities; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.referral_daily_liabilities (
    order_id bigint NOT NULL,
    activated_at timestamp with time zone NOT NULL,
    business_day date NOT NULL,
    eligible_day date NOT NULL,
    channel_id bigint NOT NULL,
    provider_trade_no text NOT NULL,
    fees_account_id bigint NOT NULL,
    pending_account_id bigint NOT NULL,
    funding_journal_id bigint NOT NULL,
    source_hash bytea NOT NULL,
    CONSTRAINT referral_daily_liabilities_channel_id_check CHECK ((channel_id > 0)),
    CONSTRAINT referral_daily_liabilities_check CHECK ((business_day = (((activated_at AT TIME ZONE 'UTC'::text) + '08:00:00'::interval))::date)),
    CONSTRAINT referral_daily_liabilities_check1 CHECK ((eligible_day = (business_day + 1))),
    CONSTRAINT referral_daily_liabilities_provider_trade_no_check CHECK (((length(provider_trade_no) >= 1) AND (length(provider_trade_no) <= 256))),
    CONSTRAINT referral_daily_liabilities_source_hash_check CHECK ((octet_length(source_hash) = 32))
);


--
-- Name: referral_daily_terms; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.referral_daily_terms (
    order_id bigint NOT NULL,
    source_version integer DEFAULT 2 NOT NULL,
    mode text DEFAULT 'daily'::text NOT NULL,
    timezone text DEFAULT 'Asia/Shanghai-UTC+08'::text NOT NULL,
    merchant_id bigint NOT NULL,
    promoter_id bigint NOT NULL,
    amount bigint NOT NULL,
    platform_fee bigint NOT NULL,
    reward_amount bigint NOT NULL,
    basis text NOT NULL,
    policy_versions jsonb NOT NULL,
    pending_account_id bigint NOT NULL,
    terms_hash bytea NOT NULL,
    source_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT referral_daily_terms_amount_check CHECK ((amount > 0)),
    CONSTRAINT referral_daily_terms_basis_check CHECK ((basis = ANY (ARRAY['fee'::text, 'gross'::text, 'profit'::text]))),
    CONSTRAINT referral_daily_terms_check CHECK (((platform_fee > 0) AND (platform_fee <= amount))),
    CONSTRAINT referral_daily_terms_check1 CHECK (((reward_amount > 0) AND (reward_amount <= platform_fee))),
    CONSTRAINT referral_daily_terms_check2 CHECK ((merchant_id <> promoter_id)),
    CONSTRAINT referral_daily_terms_mode_check CHECK ((mode = 'daily'::text)),
    CONSTRAINT referral_daily_terms_policy_versions_check CHECK (((jsonb_typeof(policy_versions) = 'array'::text) AND (jsonb_array_length(policy_versions) = 5))),
    CONSTRAINT referral_daily_terms_source_hash_check CHECK ((octet_length(source_hash) = 32)),
    CONSTRAINT referral_daily_terms_source_version_check CHECK ((source_version = 2)),
    CONSTRAINT referral_daily_terms_terms_hash_check CHECK ((octet_length(terms_hash) = 32)),
    CONSTRAINT referral_daily_terms_timezone_check CHECK ((timezone = 'Asia/Shanghai-UTC+08'::text))
);


--
-- Name: referral_daily_liability_sources; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.referral_daily_liability_sources AS
 SELECT l.order_id,
    ((o.status = 'paid'::text) AND b.enabled AND (b.purpose = 'payment'::text) AND ((d.merchant_id = o.merchant_id) AND (d.promoter_id = b.promoter_id) AND (d.amount = o.amount) AND (d.platform_fee = o.platform_fee) AND (d.reward_amount = b.reward_amount) AND (d.terms_hash = b.proof_hash) AND (d.policy_versions = b.policy_versions)) AND (d.source_version = 2) AND (d.mode = 'daily'::text) AND (d.timezone = 'Asia/Shanghai-UTC+08'::text) AND ((p.id = d.pending_account_id) AND (p.owner_id = (0)::bigint) AND (p.kind = 'referral_daily_pending'::text) AND (p.scope_id = o.id)) AND (l.pending_account_id = p.id) AND (f.owner_id = 0) AND (f.kind = 'fees'::text) AND (f.scope_id = 0) AND (l.activated_at >= o.created_at) AND (l.business_day = (((l.activated_at AT TIME ZONE 'UTC'::text) + '08:00:00'::interval))::date) AND (l.eligible_day = (l.business_day + 1)) AND ((v.channel_id = l.channel_id) AND (v.provider_trade_no = l.provider_trade_no)) AND (j.event_key = ('referral-daily-funding:'::text || (o.id)::text)) AND ( SELECT (count(*) = 2)
           FROM member72_1c1acaaf36d7e39a.ledger_entries e
          WHERE (e.journal_id = j.id)) AND ( SELECT (COALESCE(sum(e.amount), (0)::numeric) = ((- d.reward_amount))::numeric)
           FROM member72_1c1acaaf36d7e39a.ledger_entries e
          WHERE ((e.journal_id = j.id) AND (e.account_id = f.id))) AND ( SELECT (COALESCE(sum(e.amount), (0)::numeric) = (d.reward_amount)::numeric)
           FROM member72_1c1acaaf36d7e39a.ledger_entries e
          WHERE ((e.journal_id = j.id) AND (e.account_id = p.id))) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.journals fj
          WHERE ((fj.event_key = ('payment-fee:'::text || o.trade_no)) AND (fj.transaction_id = j.transaction_id) AND ( SELECT (count(*) = 2)
                   FROM member72_1c1acaaf36d7e39a.ledger_entries e
                  WHERE (e.journal_id = fj.id)) AND ( SELECT (COALESCE(sum(e.amount), (0)::numeric) = (o.platform_fee)::numeric)
                   FROM member72_1c1acaaf36d7e39a.ledger_entries e
                  WHERE ((e.journal_id = fj.id) AND (e.account_id = f.id))) AND ( SELECT (COALESCE(sum(e.amount), (0)::numeric) = ((- o.platform_fee))::numeric)
                   FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                     JOIN member72_1c1acaaf36d7e39a.accounts a ON ((a.id = e.account_id)))
                  WHERE ((e.journal_id = fj.id) AND (a.owner_id = 0) AND (a.kind = 'clearing'::text) AND (a.scope_id = 0)))))) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.referral_daily_events e
          WHERE ((e.order_id = o.id) AND (e.operation = 'funded'::text) AND (e.reference_id = 0) AND (e.actor_name = 'payment-engine'::text))))) AS valid
   FROM (((((((member72_1c1acaaf36d7e39a.referral_daily_liabilities l
     JOIN member72_1c1acaaf36d7e39a.referral_daily_terms d ON ((d.order_id = l.order_id)))
     JOIN member72_1c1acaaf36d7e39a.referral_order_terms b ON ((b.order_id = l.order_id)))
     JOIN member72_1c1acaaf36d7e39a.orders o ON ((o.id = l.order_id)))
     JOIN member72_1c1acaaf36d7e39a.accounts p ON ((p.id = l.pending_account_id)))
     JOIN member72_1c1acaaf36d7e39a.accounts f ON ((f.id = l.fees_account_id)))
     JOIN member72_1c1acaaf36d7e39a.journals j ON ((j.id = l.funding_journal_id)))
     JOIN member72_1c1acaaf36d7e39a.verified_payment_receipts v ON ((v.order_id = l.order_id)));


--
-- Name: referral_daily_award_invariants; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.referral_daily_award_invariants AS
 SELECT a.order_id,
    ((src.valid IS TRUE) AND (old.valid IS TRUE) AND (r.order_id = a.order_id) AND (r.amount = d.reward_amount) AND (j.event_key = ('referral-daily-release:'::text || (a.order_id)::text)) AND (j.transaction_id = awardj.transaction_id) AND ((((a.executed_at AT TIME ZONE 'UTC'::text) + '08:00:00'::interval))::date >= l.eligible_day) AND ( SELECT (count(*) = 2)
           FROM member72_1c1acaaf36d7e39a.ledger_entries e
          WHERE (e.journal_id = j.id)) AND ( SELECT (COALESCE(sum(e.amount), (0)::numeric) = ((- d.reward_amount))::numeric)
           FROM member72_1c1acaaf36d7e39a.ledger_entries e
          WHERE ((e.journal_id = j.id) AND (e.account_id = d.pending_account_id))) AND ( SELECT (COALESCE(sum(e.amount), (0)::numeric) = (d.reward_amount)::numeric)
           FROM member72_1c1acaaf36d7e39a.ledger_entries e
          WHERE ((e.journal_id = j.id) AND (e.account_id = l.fees_account_id))) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.referral_daily_events e
          WHERE ((e.order_id = a.order_id) AND (e.operation = 'awarded'::text) AND (e.reference_id = r.id) AND (e.actor_name = 'daily-referral-engine'::text))))) AS valid
   FROM (((((((member72_1c1acaaf36d7e39a.referral_daily_awards a
     JOIN member72_1c1acaaf36d7e39a.referral_daily_liabilities l ON ((l.order_id = a.order_id)))
     JOIN member72_1c1acaaf36d7e39a.referral_daily_terms d ON ((d.order_id = a.order_id)))
     JOIN member72_1c1acaaf36d7e39a.referral_daily_liability_sources src ON ((src.order_id = a.order_id)))
     JOIN member72_1c1acaaf36d7e39a.referral_rewards r ON ((r.id = a.reward_id)))
     JOIN member72_1c1acaaf36d7e39a.referral_reward_invariants old ON ((old.reward_id = r.id)))
     JOIN member72_1c1acaaf36d7e39a.journals j ON ((j.id = a.release_journal_id)))
     JOIN member72_1c1acaaf36d7e39a.journals awardj ON ((awardj.id = r.journal_id)));


--
-- Name: referral_daily_events_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.referral_daily_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: referral_daily_events_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.referral_daily_events_id_seq OWNED BY member72_1c1acaaf36d7e39a.referral_daily_events.id;


--
-- Name: referral_daily_refund_reservations; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.referral_daily_refund_reservations (
    refund_id bigint NOT NULL,
    order_id bigint NOT NULL,
    amount bigint NOT NULL,
    original_fee bigint NOT NULL,
    refund_fee bigint NOT NULL,
    fee_contribution bigint NOT NULL,
    pending_account_id bigint NOT NULL,
    escrow_account_id bigint NOT NULL,
    fees_account_id bigint NOT NULL,
    fee_reserved_account_id bigint CONSTRAINT referral_daily_refund_reservat_fee_reserved_account_id_not_null NOT NULL,
    reserve_journal_id bigint NOT NULL,
    contribution_journal_id bigint,
    restore_contribution_journal_id bigint,
    restore_pending_journal_id bigint,
    release_remainder_journal_id bigint,
    request_hash bytea NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    result_hash bytea,
    previous_result_hash bytea,
    result_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT referral_daily_refund_reservations_amount_check CHECK ((amount > 0)),
    CONSTRAINT referral_daily_refund_reservations_check CHECK ((original_fee >= amount)),
    CONSTRAINT referral_daily_refund_reservations_check1 CHECK (((refund_fee >= 0) AND (refund_fee <= original_fee))),
    CONSTRAINT referral_daily_refund_reservations_check2 CHECK (((fee_contribution >= 0) AND (fee_contribution <= amount))),
    CONSTRAINT referral_daily_refund_reservations_check3 CHECK ((fee_contribution = GREATEST((0)::bigint, (refund_fee - (original_fee - amount))))),
    CONSTRAINT referral_daily_refund_reservations_check4 CHECK (((fee_contribution = 0) = (contribution_journal_id IS NULL))),
    CONSTRAINT referral_daily_refund_reservations_check5 CHECK (((state = 'pending'::text) = (result_hash IS NULL))),
    CONSTRAINT referral_daily_refund_reservations_check6 CHECK (((state = 'pending'::text) = (result_at IS NULL))),
    CONSTRAINT referral_daily_refund_reservations_check7 CHECK (((state = ANY (ARRAY['failed'::text, 'succeeded'::text])) OR (previous_result_hash IS NULL))),
    CONSTRAINT referral_daily_refund_reservations_check8 CHECK ((((state = 'failed'::text) AND (restore_pending_journal_id IS NOT NULL) AND ((fee_contribution = 0) = (restore_contribution_journal_id IS NULL)) AND (release_remainder_journal_id IS NULL)) OR ((state = 'succeeded'::text) AND (restore_pending_journal_id IS NULL) AND (restore_contribution_journal_id IS NULL) AND ((amount = fee_contribution) = (release_remainder_journal_id IS NULL))) OR ((state = ANY (ARRAY['pending'::text, 'unknown'::text])) AND (restore_pending_journal_id IS NULL) AND (restore_contribution_journal_id IS NULL) AND (release_remainder_journal_id IS NULL)))),
    CONSTRAINT referral_daily_refund_reservations_previous_result_hash_check CHECK (((previous_result_hash IS NULL) OR (octet_length(previous_result_hash) = 32))),
    CONSTRAINT referral_daily_refund_reservations_request_hash_check CHECK ((octet_length(request_hash) = 32)),
    CONSTRAINT referral_daily_refund_reservations_result_hash_check CHECK (((result_hash IS NULL) OR (octet_length(result_hash) = 32))),
    CONSTRAINT referral_daily_refund_reservations_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'unknown'::text, 'failed'::text, 'succeeded'::text])))
);


--
-- Name: referral_daily_refund_invariants; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.referral_daily_refund_invariants AS
 SELECT c.refund_id,
    ((src.valid IS TRUE) AND ((r.order_id = c.order_id) AND (r.fee_amount = c.refund_fee) AND (r.status = c.state)) AND ((c.amount = d.reward_amount) AND (c.original_fee = d.platform_fee) AND (c.pending_account_id = d.pending_account_id) AND (c.fees_account_id = l.fees_account_id)) AND (es.owner_id = 0) AND (es.kind = 'referral_daily_refund_reserve'::text) AND (es.scope_id = r.id) AND (fr.owner_id = 0) AND (fr.kind = 'fee_reserved'::text) AND (fr.scope_id = 0) AND (es.balance =
        CASE
            WHEN (c.state = ANY (ARRAY['pending'::text, 'unknown'::text])) THEN (c.amount - c.fee_contribution)
            ELSE (0)::bigint
        END) AND ((c.state = 'failed'::text) OR (NOT (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.referral_daily_awards a
          WHERE (a.order_id = c.order_id))))) AND member72_1c1acaaf36d7e39a.referral_daily_journal_valid(c.reserve_journal_id, c.pending_account_id, c.escrow_account_id, c.amount, (('referral-daily-refund:'::text || (r.id)::text) || ':reserve'::text)) AND member72_1c1acaaf36d7e39a.referral_daily_journal_valid(c.contribution_journal_id, c.escrow_account_id, c.fees_account_id, c.fee_contribution, (('referral-daily-refund:'::text || (r.id)::text) || ':fee-contribution'::text)) AND member72_1c1acaaf36d7e39a.referral_daily_journal_valid(fj.id, c.fees_account_id, c.fee_reserved_account_id, c.refund_fee, (('refund-fee:'::text || (r.id)::text) || ':reserve'::text)) AND ((c.state <> 'failed'::text) OR (member72_1c1acaaf36d7e39a.referral_daily_journal_valid(c.restore_contribution_journal_id, c.fees_account_id, c.escrow_account_id, c.fee_contribution, (('referral-daily-refund:'::text || (r.id)::text) || ':restore-contribution'::text)) AND member72_1c1acaaf36d7e39a.referral_daily_journal_valid(c.restore_pending_journal_id, c.escrow_account_id, c.pending_account_id, c.amount, (('referral-daily-refund:'::text || (r.id)::text) || ':restore-pending'::text)))) AND ((c.state <> 'succeeded'::text) OR member72_1c1acaaf36d7e39a.referral_daily_journal_valid(c.release_remainder_journal_id, c.escrow_account_id, c.fees_account_id, (c.amount - c.fee_contribution), (('referral-daily-refund:'::text || (r.id)::text) || ':release-remainder'::text))) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.referral_daily_events e
          WHERE ((e.order_id = c.order_id) AND (e.operation = 'refund-pending'::text) AND (e.reference_id = r.id) AND (e.subject_hash = c.request_hash) AND (e.actor_name = 'refund-engine'::text)))) AND ((c.state = 'pending'::text) OR (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.referral_daily_events e
          WHERE ((e.order_id = c.order_id) AND (e.operation = ('refund-'::text || c.state)) AND (e.reference_id = r.id) AND (e.subject_hash = c.result_hash) AND (e.actor_name = 'refund-engine'::text))))) AND ((c.previous_result_hash IS NULL) OR (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.referral_daily_events e
          WHERE ((e.order_id = c.order_id) AND (e.operation = 'refund-unknown'::text) AND (e.reference_id = r.id) AND (e.subject_hash = c.previous_result_hash) AND (e.actor_name = 'refund-engine'::text)))))) AS valid
   FROM (((((((member72_1c1acaaf36d7e39a.referral_daily_refund_reservations c
     JOIN member72_1c1acaaf36d7e39a.refunds r ON ((r.id = c.refund_id)))
     JOIN member72_1c1acaaf36d7e39a.referral_daily_liabilities l ON ((l.order_id = c.order_id)))
     JOIN member72_1c1acaaf36d7e39a.referral_daily_terms d ON ((d.order_id = c.order_id)))
     JOIN member72_1c1acaaf36d7e39a.referral_daily_liability_sources src ON ((src.order_id = c.order_id)))
     JOIN member72_1c1acaaf36d7e39a.accounts es ON ((es.id = c.escrow_account_id)))
     JOIN member72_1c1acaaf36d7e39a.accounts fr ON ((fr.id = c.fee_reserved_account_id)))
     LEFT JOIN member72_1c1acaaf36d7e39a.journals fj ON ((fj.event_key = (('refund-fee:'::text || (r.id)::text) || ':reserve'::text))));


--
-- Name: referral_daily_liability_invariants; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.referral_daily_liability_invariants AS
 SELECT l.order_id,
    ((src.valid IS TRUE) AND (NOT (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.referral_daily_refund_reservations c
          WHERE ((c.order_id = l.order_id) AND (NOT (EXISTS ( SELECT 1
                   FROM member72_1c1acaaf36d7e39a.referral_daily_refund_invariants v
                  WHERE ((v.refund_id = c.refund_id) AND (v.valid IS TRUE))))))))) AND (NOT ((EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.referral_daily_refund_reservations c
          WHERE ((c.order_id = l.order_id) AND (c.state = 'succeeded'::text)))) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.referral_daily_refund_reservations c
          WHERE ((c.order_id = l.order_id) AND (c.state = ANY (ARRAY['pending'::text, 'unknown'::text]))))))) AND
        CASE
            WHEN (EXISTS ( SELECT 1
               FROM member72_1c1acaaf36d7e39a.referral_daily_awards a
              WHERE (a.order_id = l.order_id))) THEN ((EXISTS ( SELECT 1
               FROM member72_1c1acaaf36d7e39a.referral_daily_award_invariants a
              WHERE ((a.order_id = l.order_id) AND (a.valid IS TRUE)))) AND (p.balance = 0) AND (NOT (EXISTS ( SELECT 1
               FROM member72_1c1acaaf36d7e39a.referral_daily_refund_reservations c
              WHERE ((c.order_id = l.order_id) AND (c.state <> 'failed'::text))))))
            ELSE ((NOT (EXISTS ( SELECT 1
               FROM member72_1c1acaaf36d7e39a.referral_rewards r
              WHERE (r.order_id = l.order_id)))) AND (p.balance =
            CASE
                WHEN (EXISTS ( SELECT 1
                   FROM member72_1c1acaaf36d7e39a.referral_daily_refund_reservations c
                  WHERE ((c.order_id = l.order_id) AND (c.state <> 'failed'::text)))) THEN (0)::bigint
                ELSE d.reward_amount
            END) AND (NOT (EXISTS ( SELECT 1
               FROM member72_1c1acaaf36d7e39a.refunds r
              WHERE ((r.order_id = l.order_id) AND (NOT (EXISTS ( SELECT 1
                       FROM member72_1c1acaaf36d7e39a.referral_daily_refund_reservations c
                      WHERE (c.refund_id = r.id)))) AND (NOT (EXISTS ( SELECT 1
                       FROM member72_1c1acaaf36d7e39a.referral_daily_refund_reservations c
                      WHERE ((c.order_id = l.order_id) AND (c.state = 'succeeded'::text) AND (c.refund_id < r.id))))))))))
        END) AS valid
   FROM (((member72_1c1acaaf36d7e39a.referral_daily_liabilities l
     JOIN member72_1c1acaaf36d7e39a.referral_daily_terms d ON ((d.order_id = l.order_id)))
     JOIN member72_1c1acaaf36d7e39a.accounts p ON ((p.id = d.pending_account_id)))
     JOIN member72_1c1acaaf36d7e39a.referral_daily_liability_sources src ON ((src.order_id = l.order_id)));


--
-- Name: referral_policies; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.referral_policies (
    id bigint NOT NULL,
    scope_kind text NOT NULL,
    scope_id bigint NOT NULL,
    revision bigint NOT NULL,
    enabled boolean,
    rate_bps integer,
    mode text NOT NULL,
    basis text NOT NULL,
    refund_policy text NOT NULL,
    actor_role text NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT referral_policies_actor_id_check CHECK ((actor_id > 0)),
    CONSTRAINT referral_policies_actor_name_check CHECK (((length(actor_name) >= 1) AND (length(actor_name) <= 128))),
    CONSTRAINT referral_policies_actor_role_check CHECK ((actor_role = 'admin'::text)),
    CONSTRAINT referral_policies_basis_check CHECK ((basis = ANY (ARRAY['fee'::text, 'gross'::text, 'profit'::text]))),
    CONSTRAINT referral_policies_check CHECK ((((scope_kind = 'global'::text) AND (scope_id = 0)) OR ((scope_kind = 'group'::text) AND (scope_id > 0)))),
    CONSTRAINT referral_policies_check1 CHECK (((scope_kind <> 'global'::text) OR ((enabled IS NOT NULL) AND (rate_bps IS NOT NULL)))),
    CONSTRAINT referral_policies_mode_check CHECK ((mode = ANY (ARRAY['immediate'::text, 'daily'::text]))),
    CONSTRAINT referral_policies_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT referral_policies_rate_bps_check CHECK (((rate_bps >= 0) AND (rate_bps <= 10000))),
    CONSTRAINT referral_policies_refund_policy_check CHECK ((refund_policy = 'any_successful_refund_voids_reward'::text)),
    CONSTRAINT referral_policies_revision_check CHECK ((revision > 0)),
    CONSTRAINT referral_policies_scope_kind_check CHECK ((scope_kind = ANY (ARRAY['global'::text, 'group'::text])))
);


--
-- Name: referral_policies_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.referral_policies_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: referral_policies_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.referral_policies_id_seq OWNED BY member72_1c1acaaf36d7e39a.referral_policies.id;


--
-- Name: referral_policy_audits; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.referral_policy_audits (
    policy_id bigint NOT NULL,
    actor_role text NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL
);


--
-- Name: referral_policy_heads; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.referral_policy_heads (
    scope_kind text NOT NULL,
    scope_id bigint NOT NULL,
    policy_id bigint NOT NULL
);


--
-- Name: referral_profit_cost_events; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.referral_profit_cost_events (
    order_id bigint NOT NULL,
    event_key text NOT NULL,
    actor text NOT NULL,
    subject_hash bytea NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT referral_profit_cost_events_actor_check CHECK ((actor = 'payment-engine'::text)),
    CONSTRAINT referral_profit_cost_events_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT referral_profit_cost_events_subject_hash_check CHECK ((octet_length(subject_hash) = 32))
);


--
-- Name: referral_profit_costs; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.referral_profit_costs (
    order_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    source_version integer NOT NULL,
    channel_id bigint NOT NULL,
    method text NOT NULL,
    provider text NOT NULL,
    app_id text NOT NULL,
    account_hash bytea NOT NULL,
    config_revision text NOT NULL,
    rate_units bigint NOT NULL,
    amount bigint NOT NULL,
    platform_fee bigint NOT NULL,
    cost_whole bigint NOT NULL,
    cost_remainder bigint NOT NULL,
    profit_amount bigint NOT NULL,
    reward_amount bigint NOT NULL,
    terms_hash bytea NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT referral_profit_costs_account_hash_check CHECK ((octet_length(account_hash) = 32)),
    CONSTRAINT referral_profit_costs_amount_check CHECK ((amount > 0)),
    CONSTRAINT referral_profit_costs_app_id_check CHECK (((length(app_id) >= 1) AND (length(app_id) <= 256))),
    CONSTRAINT referral_profit_costs_channel_id_check CHECK ((channel_id > 0)),
    CONSTRAINT referral_profit_costs_check CHECK (((platform_fee >= 0) AND (platform_fee <= amount))),
    CONSTRAINT referral_profit_costs_check1 CHECK (((cost_whole >= 0) AND (cost_whole <= amount))),
    CONSTRAINT referral_profit_costs_check2 CHECK (((profit_amount >= 0) AND (profit_amount <= platform_fee))),
    CONSTRAINT referral_profit_costs_check3 CHECK (((reward_amount >= 0) AND (reward_amount <= profit_amount))),
    CONSTRAINT referral_profit_costs_check4 CHECK ((cost_whole = (((amount / 100000000) * rate_units) + (((amount % (100000000)::bigint) * rate_units) / 100000000)))),
    CONSTRAINT referral_profit_costs_check5 CHECK ((cost_remainder = (((amount % (100000000)::bigint) * rate_units) % (100000000)::bigint))),
    CONSTRAINT referral_profit_costs_check6 CHECK ((profit_amount = GREATEST(((platform_fee - cost_whole) -
CASE
    WHEN (cost_remainder > 50000000) THEN 1
    ELSE 0
END), (0)::bigint))),
    CONSTRAINT referral_profit_costs_config_revision_check CHECK ((config_revision ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT referral_profit_costs_cost_remainder_check CHECK (((cost_remainder >= 0) AND (cost_remainder <= 99999999))),
    CONSTRAINT referral_profit_costs_method_check CHECK ((method ~ '^[a-z][a-z0-9_]{0,31}$'::text)),
    CONSTRAINT referral_profit_costs_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT referral_profit_costs_provider_check CHECK ((provider = ANY (ARRAY['alipay'::text, 'wxpay'::text]))),
    CONSTRAINT referral_profit_costs_rate_units_check CHECK (((rate_units >= 0) AND (rate_units <= 100000000))),
    CONSTRAINT referral_profit_costs_source_version_check CHECK ((source_version = 3)),
    CONSTRAINT referral_profit_costs_terms_hash_check CHECK ((octet_length(terms_hash) = 32))
);


--
-- Name: referral_relations; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.referral_relations (
    id bigint NOT NULL,
    invited_id bigint NOT NULL,
    promoter_id bigint NOT NULL,
    token_id bigint NOT NULL,
    token_version bigint NOT NULL,
    challenge_id text NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT referral_relations_check CHECK ((invited_id <> promoter_id)),
    CONSTRAINT referral_relations_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT referral_relations_token_version_check CHECK ((token_version > 0))
);


--
-- Name: referral_tokens; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.referral_tokens (
    id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    version bigint NOT NULL,
    enabled boolean NOT NULL,
    token_hash bytea,
    token_cipher bytea,
    token_masked text DEFAULT ''::text NOT NULL,
    actor_name text NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    expires_at timestamp with time zone,
    CONSTRAINT referral_tokens_actor_name_check CHECK (((length(actor_name) >= 1) AND (length(actor_name) <= 128))),
    CONSTRAINT referral_tokens_check CHECK (((enabled AND (token_hash IS NOT NULL) AND (octet_length(token_hash) = 32) AND (token_cipher IS NOT NULL) AND (octet_length(token_cipher) >= 60) AND (length(token_masked) > 0) AND (expires_at IS NOT NULL) AND (expires_at > created_at)) OR ((NOT enabled) AND (token_hash IS NULL) AND (token_cipher IS NULL) AND (token_masked = ''::text) AND (expires_at IS NULL)))),
    CONSTRAINT referral_tokens_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT referral_tokens_token_masked_check CHECK ((length(token_masked) <= 32)),
    CONSTRAINT referral_tokens_version_check CHECK ((version > 0))
);


--
-- Name: referral_relation_evidence; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.referral_relation_evidence AS
 SELECT r.id,
    ((i.created_at = r.created_at) AND (r.invited_id <> r.promoter_id) AND t.enabled AND ((t.merchant_id = r.promoter_id) AND (t.version = r.token_version)) AND (EXISTS ( SELECT 1
           FROM ((member72_1c1acaaf36d7e39a.enrollment_emails e
             JOIN member72_1c1acaaf36d7e39a.console_users u ON (((u.username = e.username) AND (u.role = 'merchant'::text) AND (u.subject_id = e.merchant_id))))
             JOIN member72_1c1acaaf36d7e39a.enrollment_challenges c ON (((c.id = r.challenge_id) AND (c.email_hash = e.email_hash))))
          WHERE ((e.merchant_id = r.invited_id) AND (e.verified_at >= i.created_at) AND (c.purpose = 'register'::text) AND (c.state = 'sent'::text) AND (c.consumed_at IS NOT NULL) AND (c.consumed_at >= i.created_at) AND (c.consumed_at < c.expires_at) AND (c.target_merchant_id IS NULL)))) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.backoffice_audit b
          WHERE ((b.resource = 'enrollment'::text) AND (b.resource_id = r.invited_id) AND (b.operation = 'register'::text) AND (b.actor_role = 'public'::text) AND (b.actor_id = r.invited_id)))) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.backoffice_audit b
          WHERE ((b.resource = 'referral-relations'::text) AND (b.resource_id = r.id) AND (b.operation = 'bind'::text) AND (b.actor_role = 'public'::text) AND (b.actor_id = r.invited_id) AND ((b.changes ->> 'invited_id'::text) = (r.invited_id)::text) AND ((b.changes ->> 'promoter_id'::text) = (r.promoter_id)::text) AND ((b.changes ->> 'token_version'::text) = (r.token_version)::text))))) AS valid
   FROM ((member72_1c1acaaf36d7e39a.referral_relations r
     JOIN member72_1c1acaaf36d7e39a.merchants i ON ((i.id = r.invited_id)))
     JOIN member72_1c1acaaf36d7e39a.referral_tokens t ON ((t.id = r.token_id)));


--
-- Name: referral_relations_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.referral_relations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: referral_relations_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.referral_relations_id_seq OWNED BY member72_1c1acaaf36d7e39a.referral_relations.id;


--
-- Name: referral_rewards_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.referral_rewards_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: referral_rewards_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.referral_rewards_id_seq OWNED BY member72_1c1acaaf36d7e39a.referral_rewards.id;


--
-- Name: referral_token_current; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.referral_token_current (
    merchant_id bigint NOT NULL,
    token_id bigint NOT NULL,
    version bigint NOT NULL,
    CONSTRAINT referral_token_current_version_check CHECK ((version > 0))
);


--
-- Name: referral_tokens_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.referral_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: referral_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.referral_tokens_id_seq OWNED BY member72_1c1acaaf36d7e39a.referral_tokens.id;


--
-- Name: refund_funding_invariants; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.refund_funding_invariants AS
 SELECT f.refund_id,
    (((f.order_id = r.order_id) AND (f.merchant_id = r.merchant_id) AND (f.merchant_amount = r.merchant_amount) AND (f.fee_amount = r.fee_amount)) AND ((a.owner_id = r.merchant_id) AND (a.kind =
        CASE
            WHEN (f.hold_id IS NULL) THEN 'reserved'::text
            ELSE 'order_income_refund_reserve'::text
        END) AND (a.scope_id =
        CASE
            WHEN (f.hold_id IS NULL) THEN (0)::bigint
            ELSE r.id
        END)) AND ((f.hold_id IS NULL) OR ((h.order_id = r.order_id) AND (h.merchant_id = r.merchant_id) AND (h.request_hash = f.hold_funding_hash))) AND ((f.hold_id IS NULL) OR (a.balance =
        CASE
            WHEN (r.status = ANY (ARRAY['pending'::text, 'unknown'::text])) THEN r.merchant_amount
            ELSE (0)::bigint
        END)) AND ((f.hold_id IS NULL) OR (( SELECT count(*) AS count
           FROM member72_1c1acaaf36d7e39a.ledger_entries x
          WHERE (x.account_id = a.id)) = ((
        CASE
            WHEN (f.hold_amount > 0) THEN 1
            ELSE 0
        END +
        CASE
            WHEN (f.available_amount > 0) THEN 1
            ELSE 0
        END) +
        CASE
            WHEN (r.status = ANY (ARRAY['pending'::text, 'unknown'::text])) THEN 0
            WHEN (r.status = 'succeeded'::text) THEN
            CASE
                WHEN (r.merchant_amount > 0) THEN 1
                ELSE 0
            END
            ELSE (
            CASE
                WHEN (f.hold_amount > 0) THEN 1
                ELSE 0
            END +
            CASE
                WHEN (f.available_amount > 0) THEN 1
                ELSE 0
            END)
        END))) AND (( SELECT COALESCE(sum(q.amount), (0)::numeric) AS "coalesce"
           FROM member72_1c1acaaf36d7e39a.refunds q
          WHERE ((q.order_id = r.order_id) AND (q.status <> 'failed'::text))) <= (o.amount)::numeric) AND (((o.refund_fee_payer = 'merchant'::text) AND (r.fee_amount = 0)) OR ((o.refund_fee_payer = 'platform'::text) AND (( SELECT COALESCE(sum(q.merchant_amount), (0)::numeric) AS "coalesce"
           FROM member72_1c1acaaf36d7e39a.refunds q
          WHERE ((q.order_id = r.order_id) AND (q.status <> 'failed'::text))) <= (o.merchant_amount)::numeric) AND (( SELECT COALESCE(sum(q.fee_amount), (0)::numeric) AS "coalesce"
           FROM member72_1c1acaaf36d7e39a.refunds q
          WHERE ((q.order_id = r.order_id) AND (q.status <> 'failed'::text))) <= (o.platform_fee)::numeric))) AND (member72_1c1acaaf36d7e39a.refund_merchant_reserve_valid(r.id) IS TRUE) AND (member72_1c1acaaf36d7e39a.refund_merchant_resolution_valid(r.id) IS TRUE) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.backoffice_audit b
          WHERE ((b.resource = 'refund-fundings'::text) AND (b.resource_id = r.id) AND (b.operation = 'reserve'::text) AND ((b.actor_role = 'system'::text) AND (b.actor_id = 0) AND (b.actor_name = 'refund-engine'::text))))) AND ((r.status = ANY (ARRAY['pending'::text, 'unknown'::text])) OR (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.backoffice_audit b
          WHERE ((b.resource = 'refund-fundings'::text) AND (b.resource_id = r.id) AND (b.operation = r.status) AND ((b.actor_role = 'system'::text) AND (b.actor_id = 0) AND (b.actor_name = 'refund-engine'::text))))))) AS valid
   FROM ((((member72_1c1acaaf36d7e39a.refund_fundings f
     JOIN member72_1c1acaaf36d7e39a.refunds r ON ((r.id = f.refund_id)))
     JOIN member72_1c1acaaf36d7e39a.orders o ON ((o.id = r.order_id)))
     JOIN member72_1c1acaaf36d7e39a.accounts a ON ((a.id = f.reserve_account_id)))
     LEFT JOIN member72_1c1acaaf36d7e39a.order_income_hold_fundings h ON ((h.hold_id = f.hold_id)));


--
-- Name: refund_funding_resolutions; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.refund_funding_resolutions (
    refund_id bigint NOT NULL,
    state text NOT NULL,
    held_return_journal_id bigint,
    available_return_journal_id bigint,
    consume_journal_id bigint,
    request_hash bytea NOT NULL,
    result_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT refund_funding_resolutions_request_hash_check CHECK ((octet_length(request_hash) = 32)),
    CONSTRAINT refund_funding_resolutions_result_hash_check CHECK ((octet_length(result_hash) = 32)),
    CONSTRAINT refund_funding_resolutions_state_check CHECK ((state = ANY (ARRAY['succeeded'::text, 'failed'::text])))
);


--
-- Name: refunds_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.refunds_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: refunds_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.refunds_id_seq OWNED BY member72_1c1acaaf36d7e39a.refunds.id;


--
-- Name: scan_cancellation_claims; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.scan_cancellation_claims (
    attempt_id bigint NOT NULL,
    job_id bigint NOT NULL,
    source_hash bytea NOT NULL,
    eligibility_hash bytea NOT NULL,
    query_head_hash bytea NOT NULL,
    lease_hash bytea NOT NULL,
    product text NOT NULL,
    provider_trade_no text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    transaction_id text NOT NULL,
    proof_hash bytea NOT NULL,
    CONSTRAINT scan_cancellation_claims_eligibility_hash_check CHECK ((octet_length(eligibility_hash) = 32)),
    CONSTRAINT scan_cancellation_claims_lease_hash_check CHECK ((octet_length(lease_hash) = 32)),
    CONSTRAINT scan_cancellation_claims_product_check CHECK ((product = ANY (ARRAY['alipay.trade.cancel'::text, '/secapi/pay/reverse'::text]))),
    CONSTRAINT scan_cancellation_claims_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT scan_cancellation_claims_query_head_hash_check CHECK ((octet_length(query_head_hash) = 32)),
    CONSTRAINT scan_cancellation_claims_source_hash_check CHECK ((octet_length(source_hash) = 32)),
    CONSTRAINT scan_cancellation_claims_transaction_id_check CHECK ((transaction_id <> ''::text))
);


--
-- Name: scan_cancellation_results; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.scan_cancellation_results (
    attempt_id bigint NOT NULL,
    claim_hash bytea NOT NULL,
    state text NOT NULL,
    receipt jsonb,
    created_at timestamp with time zone NOT NULL,
    transaction_id text NOT NULL,
    proof_hash bytea NOT NULL,
    CONSTRAINT scan_cancellation_results_check CHECK ((((state = 'unknown'::text) AND (receipt IS NULL)) OR ((state = 'cancelled'::text) AND (receipt IS NOT NULL) AND (jsonb_typeof(receipt) = 'object'::text)))),
    CONSTRAINT scan_cancellation_results_claim_hash_check CHECK ((octet_length(claim_hash) = 32)),
    CONSTRAINT scan_cancellation_results_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT scan_cancellation_results_state_check CHECK ((state = ANY (ARRAY['unknown'::text, 'cancelled'::text]))),
    CONSTRAINT scan_cancellation_results_transaction_id_check CHECK ((transaction_id <> ''::text))
);


--
-- Name: scan_recovery_eligibility; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.scan_recovery_eligibility (
    attempt_id bigint NOT NULL,
    source_hash bytea NOT NULL,
    receipt jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    transaction_id text NOT NULL,
    proof_hash bytea NOT NULL,
    CONSTRAINT scan_recovery_eligibility_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT scan_recovery_eligibility_receipt_check CHECK ((jsonb_typeof(receipt) = 'object'::text)),
    CONSTRAINT scan_recovery_eligibility_source_hash_check CHECK ((octet_length(source_hash) = 32)),
    CONSTRAINT scan_recovery_eligibility_transaction_id_check CHECK ((transaction_id <> ''::text))
);


--
-- Name: scan_recovery_origins; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.scan_recovery_origins (
    attempt_id bigint NOT NULL,
    order_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    trade_no text NOT NULL,
    provider text NOT NULL,
    amount bigint NOT NULL,
    request_identity_hash bytea NOT NULL,
    account_scope_hash bytea NOT NULL,
    policy text NOT NULL,
    minimum_wait_seconds integer NOT NULL,
    query_interval_seconds integer NOT NULL,
    maximum_queries integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    transaction_id text NOT NULL,
    proof_hash bytea NOT NULL,
    CONSTRAINT scan_recovery_origins_account_scope_hash_check CHECK ((octet_length(account_scope_hash) = 32)),
    CONSTRAINT scan_recovery_origins_amount_check CHECK ((amount > 0)),
    CONSTRAINT scan_recovery_origins_channel_id_check CHECK ((channel_id > 0)),
    CONSTRAINT scan_recovery_origins_check CHECK ((expires_at = (created_at + '00:02:00'::interval))),
    CONSTRAINT scan_recovery_origins_maximum_queries_check CHECK ((maximum_queries = 6)),
    CONSTRAINT scan_recovery_origins_minimum_wait_seconds_check CHECK ((minimum_wait_seconds = 15)),
    CONSTRAINT scan_recovery_origins_policy_check CHECK ((policy = 'original-barcode-v1'::text)),
    CONSTRAINT scan_recovery_origins_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT scan_recovery_origins_provider_check CHECK ((provider = ANY (ARRAY['alipay'::text, 'wxpay'::text]))),
    CONSTRAINT scan_recovery_origins_query_interval_seconds_check CHECK ((query_interval_seconds = 3)),
    CONSTRAINT scan_recovery_origins_request_identity_hash_check CHECK ((octet_length(request_identity_hash) = 32)),
    CONSTRAINT scan_recovery_origins_transaction_id_check CHECK ((transaction_id <> ''::text))
);


--
-- Name: scan_recovery_query_events; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.scan_recovery_query_events (
    id bigint NOT NULL,
    attempt_id bigint NOT NULL,
    revision integer NOT NULL,
    kind text NOT NULL,
    query_number integer NOT NULL,
    query_claim_id bigint NOT NULL,
    job_id bigint NOT NULL,
    lease_hash bytea NOT NULL,
    query_provider_no text NOT NULL,
    previous_hash bytea NOT NULL,
    receipt jsonb,
    created_at timestamp with time zone NOT NULL,
    transaction_id text NOT NULL,
    proof_hash bytea NOT NULL,
    CONSTRAINT scan_recovery_query_events_check CHECK ((((kind = 'query'::text) AND (revision = ((2 * query_number) - 1)) AND (query_claim_id = id) AND (receipt IS NULL)) OR ((kind = ANY (ARRAY['observed'::text, 'error'::text])) AND (revision = (2 * query_number)) AND (query_claim_id <> id) AND (((kind = 'observed'::text) AND (receipt IS NOT NULL) AND (jsonb_typeof(receipt) = 'object'::text)) OR ((kind = 'error'::text) AND (receipt IS NULL)))))),
    CONSTRAINT scan_recovery_query_events_kind_check CHECK ((kind = ANY (ARRAY['query'::text, 'observed'::text, 'error'::text]))),
    CONSTRAINT scan_recovery_query_events_lease_hash_check CHECK ((octet_length(lease_hash) = 32)),
    CONSTRAINT scan_recovery_query_events_previous_hash_check CHECK ((octet_length(previous_hash) = 32)),
    CONSTRAINT scan_recovery_query_events_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT scan_recovery_query_events_query_number_check CHECK (((query_number >= 1) AND (query_number <= 6))),
    CONSTRAINT scan_recovery_query_events_revision_check CHECK (((revision >= 1) AND (revision <= 12))),
    CONSTRAINT scan_recovery_query_events_transaction_id_check CHECK ((transaction_id <> ''::text))
);


--
-- Name: scan_recovery_query_events_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.scan_recovery_query_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: scan_recovery_query_events_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.scan_recovery_query_events_id_seq OWNED BY member72_1c1acaaf36d7e39a.scan_recovery_query_events.id;


--
-- Name: scan_recovery_query_heads; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.scan_recovery_query_heads (
    attempt_id bigint NOT NULL,
    eligibility_hash bytea NOT NULL,
    revision integer NOT NULL,
    event_id bigint,
    event_hash bytea,
    proof_hash bytea NOT NULL,
    CONSTRAINT scan_recovery_query_heads_check CHECK ((((revision = 0) AND (event_id IS NULL) AND (event_hash IS NULL)) OR ((revision > 0) AND (event_id IS NOT NULL) AND (event_hash IS NOT NULL) AND (octet_length(event_hash) = 32)))),
    CONSTRAINT scan_recovery_query_heads_eligibility_hash_check CHECK ((octet_length(eligibility_hash) = 32)),
    CONSTRAINT scan_recovery_query_heads_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT scan_recovery_query_heads_revision_check CHECK (((revision >= 0) AND (revision <= 12)))
);


--
-- Name: settlement_auto_authorizations; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_auto_authorizations (
    id bigint NOT NULL,
    plan_id bigint NOT NULL,
    plan_revision bigint NOT NULL,
    generation_authorization_id bigint CONSTRAINT settlement_auto_authorizati_generation_authorization_i_not_null NOT NULL,
    expected_authorization_id bigint,
    input jsonb NOT NULL,
    scope_snapshot jsonb NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT settlement_auto_authorizations_actor_id_check CHECK ((actor_id > 0)),
    CONSTRAINT settlement_auto_authorizations_actor_name_check CHECK ((length(actor_name) > 0)),
    CONSTRAINT settlement_auto_authorizations_check CHECK (((expected_authorization_id IS NULL) OR (expected_authorization_id < id))),
    CONSTRAINT settlement_auto_authorizations_input_check CHECK ((jsonb_typeof(input) = 'object'::text)),
    CONSTRAINT settlement_auto_authorizations_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT settlement_auto_authorizations_scope_snapshot_check CHECK ((jsonb_typeof(scope_snapshot) = 'object'::text))
);


--
-- Name: settlement_auto_authorizations_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.settlement_auto_authorizations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settlement_auto_authorizations_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.settlement_auto_authorizations_id_seq OWNED BY member72_1c1acaaf36d7e39a.settlement_auto_authorizations.id;


--
-- Name: settlement_auto_claims; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_auto_claims (
    claim_seq bigint NOT NULL,
    request_id bigint NOT NULL,
    plan_id bigint NOT NULL,
    authorization_id bigint NOT NULL,
    run_id bigint NOT NULL,
    item_id bigint NOT NULL,
    transfer_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    gross bigint NOT NULL,
    net bigint NOT NULL,
    fee bigint NOT NULL,
    business_date date NOT NULL,
    claimed_at timestamp with time zone NOT NULL,
    transaction_id xid8 DEFAULT pg_current_xact_id() NOT NULL,
    proof_hash bytea NOT NULL,
    CONSTRAINT settlement_auto_claims_check CHECK ((gross = (net + fee))),
    CONSTRAINT settlement_auto_claims_fee_check CHECK ((fee >= 0)),
    CONSTRAINT settlement_auto_claims_gross_check CHECK ((gross > 0)),
    CONSTRAINT settlement_auto_claims_net_check CHECK ((net > 0)),
    CONSTRAINT settlement_auto_claims_proof_hash_check CHECK ((octet_length(proof_hash) = 32))
);


--
-- Name: settlement_auto_claims_claim_seq_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.settlement_auto_claims_claim_seq_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settlement_auto_claims_claim_seq_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.settlement_auto_claims_claim_seq_seq OWNED BY member72_1c1acaaf36d7e39a.settlement_auto_claims.claim_seq;


--
-- Name: settlement_auto_heads; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_auto_heads (
    plan_id bigint NOT NULL,
    authorization_id bigint NOT NULL
);


--
-- Name: settlement_auto_revocations; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_auto_revocations (
    authorization_id bigint NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT settlement_auto_revocations_actor_id_check CHECK ((actor_id > 0)),
    CONSTRAINT settlement_auto_revocations_actor_name_check CHECK ((length(actor_name) > 0)),
    CONSTRAINT settlement_auto_revocations_proof_hash_check CHECK ((octet_length(proof_hash) = 32))
);


--
-- Name: settlement_bank_payouts; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_bank_payouts (
    request_id bigint NOT NULL,
    transfer_id bigint NOT NULL,
    bank_product text NOT NULL,
    fee_policy text DEFAULT 'hold-and-return-v1'::text NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT settlement_bank_payouts_bank_product_check CHECK ((bank_product = ANY (ARRAY['wxpay_v2'::text, 'alipay_bankcard'::text]))),
    CONSTRAINT settlement_bank_payouts_fee_policy_check CHECK ((fee_policy = 'hold-and-return-v1'::text))
);


--
-- Name: settlement_fundings; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_fundings (
    request_id bigint NOT NULL,
    account_id bigint NOT NULL,
    gross_amount bigint NOT NULL,
    reserve_journal_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT settlement_fundings_gross_amount_check CHECK ((gross_amount > 0))
);


--
-- Name: settlement_payout_cancellations; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_payout_cancellations (
    request_id bigint NOT NULL,
    transfer_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: settlement_payouts; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_payouts (
    request_id bigint NOT NULL,
    transfer_id bigint NOT NULL,
    channel_id bigint NOT NULL,
    provider_kind text NOT NULL,
    app_id text NOT NULL,
    recipient_hash bytea NOT NULL,
    gross_amount bigint NOT NULL,
    net_amount bigint NOT NULL,
    fee_amount bigint NOT NULL,
    send_state text DEFAULT 'unsent'::text NOT NULL,
    claimed_at timestamp with time zone,
    cancelled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    auto_authorization_id bigint,
    CONSTRAINT settlement_payouts_app_id_check CHECK (((length(app_id) >= 1) AND (length(app_id) <= 128))),
    CONSTRAINT settlement_payouts_channel_id_check CHECK ((channel_id > 0)),
    CONSTRAINT settlement_payouts_check CHECK ((gross_amount = (net_amount + fee_amount))),
    CONSTRAINT settlement_payouts_check1 CHECK ((((send_state = 'unsent'::text) AND (claimed_at IS NULL) AND (cancelled_at IS NULL)) OR ((send_state = 'claimed'::text) AND (claimed_at IS NOT NULL) AND (cancelled_at IS NULL)) OR ((send_state = 'cancelled'::text) AND (claimed_at IS NULL) AND (cancelled_at IS NOT NULL)))),
    CONSTRAINT settlement_payouts_fee_amount_check CHECK ((fee_amount >= 0)),
    CONSTRAINT settlement_payouts_gross_amount_check CHECK ((gross_amount > 0)),
    CONSTRAINT settlement_payouts_net_amount_check CHECK ((net_amount > 0)),
    CONSTRAINT settlement_payouts_provider_kind_check CHECK ((provider_kind = ANY (ARRAY['wxpay'::text, 'alipay'::text]))),
    CONSTRAINT settlement_payouts_recipient_hash_check CHECK ((octet_length(recipient_hash) = 32)),
    CONSTRAINT settlement_payouts_send_state_check CHECK ((send_state = ANY (ARRAY['unsent'::text, 'claimed'::text, 'cancelled'::text])))
);


--
-- Name: settlement_recipient_configs; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_recipient_configs (
    id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    recipient_type text NOT NULL,
    app_id text NOT NULL,
    identity_hash bytea NOT NULL,
    recipient_cipher bytea NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT settlement_recipient_configs_app_id_check CHECK ((length(app_id) <= 128)),
    CONSTRAINT settlement_recipient_configs_check CHECK (((recipient_type <> 'wxpay'::text) OR (length(app_id) > 0))),
    CONSTRAINT settlement_recipient_configs_identity_hash_check CHECK ((octet_length(identity_hash) = 32)),
    CONSTRAINT settlement_recipient_configs_recipient_cipher_check CHECK ((octet_length(recipient_cipher) > 28)),
    CONSTRAINT settlement_recipient_configs_recipient_type_check CHECK ((recipient_type = ANY (ARRAY['alipay'::text, 'wxpay'::text, 'bank'::text])))
);


--
-- Name: settlement_recipients; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_recipients (
    request_id bigint NOT NULL,
    config_id bigint NOT NULL,
    identity_hash bytea NOT NULL,
    recipient_cipher bytea NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT settlement_recipients_identity_hash_check CHECK ((octet_length(identity_hash) = 32)),
    CONSTRAINT settlement_recipients_recipient_cipher_check CHECK ((octet_length(recipient_cipher) > 28))
);


--
-- Name: settlement_request_terms; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_request_terms (
    request_id bigint NOT NULL,
    gross_amount bigint NOT NULL,
    fee_amount bigint NOT NULL,
    net_amount bigint NOT NULL,
    fee_rate_bps bigint NOT NULL,
    fee_minimum_cents bigint NOT NULL,
    fee_maximum_cents bigint NOT NULL,
    retained_cents bigint NOT NULL,
    daily_limit bigint NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT settlement_request_terms_check CHECK (((fee_amount <= gross_amount) AND (net_amount = (gross_amount - fee_amount)))),
    CONSTRAINT settlement_request_terms_daily_limit_check CHECK (((daily_limit >= 0) AND (daily_limit <= 1000000))),
    CONSTRAINT settlement_request_terms_fee_amount_check CHECK ((fee_amount >= 0)),
    CONSTRAINT settlement_request_terms_fee_maximum_cents_check CHECK (((fee_maximum_cents >= 0) AND (fee_maximum_cents <= '100000000000'::bigint))),
    CONSTRAINT settlement_request_terms_fee_minimum_cents_check CHECK (((fee_minimum_cents >= 0) AND (fee_minimum_cents <= '100000000000'::bigint))),
    CONSTRAINT settlement_request_terms_fee_rate_bps_check CHECK (((fee_rate_bps >= 0) AND (fee_rate_bps <= 10000))),
    CONSTRAINT settlement_request_terms_gross_amount_check CHECK ((gross_amount > 0)),
    CONSTRAINT settlement_request_terms_net_amount_check CHECK ((net_amount > 0)),
    CONSTRAINT settlement_request_terms_retained_cents_check CHECK (((retained_cents >= 0) AND (retained_cents <= '100000000000'::bigint)))
);


--
-- Name: transfer_batch_items; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.transfer_batch_items (
    batch_id bigint NOT NULL,
    "position" integer NOT NULL,
    transfer_id bigint NOT NULL,
    provider_kind text NOT NULL,
    app_id text NOT NULL,
    bank_product text DEFAULT ''::text NOT NULL,
    state text DEFAULT 'unsent'::text NOT NULL,
    claimed_at timestamp with time zone,
    cancelled_at timestamp with time zone,
    CONSTRAINT transfer_batch_items_app_id_check CHECK (((length(app_id) >= 1) AND (length(app_id) <= 128))),
    CONSTRAINT transfer_batch_items_check CHECK ((((state = 'unsent'::text) AND (claimed_at IS NULL) AND (cancelled_at IS NULL)) OR ((state = 'claimed'::text) AND (claimed_at IS NOT NULL) AND (cancelled_at IS NULL)) OR ((state = 'cancelled'::text) AND (claimed_at IS NULL) AND (cancelled_at IS NOT NULL)))),
    CONSTRAINT transfer_batch_items_position_check CHECK ((("position" >= 1) AND ("position" <= 100))),
    CONSTRAINT transfer_batch_items_provider_kind_check CHECK ((provider_kind = ANY (ARRAY['wxpay'::text, 'alipay'::text]))),
    CONSTRAINT transfer_batch_items_state_check CHECK ((state = ANY (ARRAY['unsent'::text, 'claimed'::text, 'cancelled'::text])))
);


--
-- Name: transfers; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.transfers (
    id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    transfer_no text NOT NULL,
    amount bigint NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    biz_no text NOT NULL,
    cost_amount bigint NOT NULL,
    fee_amount bigint DEFAULT 0 NOT NULL,
    fee_rate_bps integer DEFAULT 0 NOT NULL,
    resolved_at timestamp with time zone,
    CONSTRAINT transfer_cost_balanced CHECK ((cost_amount = (amount + fee_amount))),
    CONSTRAINT transfers_amount_check CHECK ((amount > 0)),
    CONSTRAINT transfers_fee_amount_check CHECK ((fee_amount >= 0)),
    CONSTRAINT transfers_fee_rate_bps_check CHECK (((fee_rate_bps >= 0) AND (fee_rate_bps <= 10000))),
    CONSTRAINT transfers_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'unknown'::text, 'succeeded'::text, 'failed'::text])))
);


--
-- Name: settlement_bank_funding_invariants; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.settlement_bank_funding_invariants AS
 SELECT f.request_id,
    COALESCE(((r.kind = 'settlements'::text) AND (r.status = 'approved'::text) AND (r.amount = f.gross_amount) AND (a.owner_id = r.merchant_id) AND (a.kind = 'settlement_reserve'::text) AND (a.scope_id = r.id) AND (reserve.event_key = (('request:'::text || (r.id)::text) || ':reserve'::text)) AND member72_1c1acaaf36d7e39a.settlement_journal_matches(reserve.event_key, available.id, a.id, f.gross_amount) AND (p.gross_amount = f.gross_amount) AND (p.net_amount = st.net_amount) AND (p.fee_amount = st.fee_amount) AND (t.merchant_id = r.merchant_id) AND (t.amount = p.net_amount) AND (t.cost_amount = p.net_amount) AND (t.fee_amount = 0) AND (t.fee_rate_bps = 0) AND (pa.channel_id = p.channel_id) AND (sr.identity_hash = p.recipient_hash) AND (c.recipient_type = 'bank'::text) AND (c.app_id = ''::text) AND (bp.transfer_id = t.id) AND (bp.bank_product = b.provider_kind) AND (((bp.bank_product = 'wxpay_v2'::text) AND (p.provider_kind = 'wxpay'::text)) OR ((bp.bank_product = 'alipay_bankcard'::text) AND (p.provider_kind = 'alipay'::text))) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.provider_transfer_accounts acc
          WHERE (acc.transfer_id = t.id))) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.provider_transfer_policies pol
          WHERE ((pol.transfer_id = t.id) AND (pol.merchant_id = r.merchant_id)))) AND ((bp.bank_product <> 'alipay_bankcard'::text) OR (EXISTS ( SELECT 1
           FROM (member72_1c1acaaf36d7e39a.alipay_bank_bindings ab
             JOIN member72_1c1acaaf36d7e39a.provider_transfer_policies pol ON ((pol.transfer_id = ab.transfer_id)))
          WHERE ((ab.transfer_id = t.id) AND (ab.request_digest = pol.request_hash))))) AND (NOT (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.transfer_batch_items bi
          WHERE (bi.transfer_id = t.id)))) AND (b.service_fee_held = 0) AND (b.returned_service_fee = 0) AND
        CASE
            WHEN (t.status = ANY (ARRAY['pending'::text, 'unknown'::text])) THEN ((p.send_state = ANY (ARRAY['unsent'::text, 'claimed'::text])) AND ((p.send_state = 'claimed'::text) OR ((t.status = 'pending'::text) AND (pa.state = 'processing'::text) AND (pa.provider_transfer_no = ''::text))) AND (pa.state = ANY (ARRAY['processing'::text, 'pending'::text, 'unknown'::text])) AND ((t.status <> 'unknown'::text) OR (pa.state = 'unknown'::text)) AND (NOT b.settled) AND (b.state = ANY (ARRAY['processing'::text, 'reversal_pending'::text])) AND (b.returned_principal = 0) AND (a.balance = f.gross_amount) AND ( SELECT (count(*) = 1)
               FROM member72_1c1acaaf36d7e39a.ledger_entries e
              WHERE (e.account_id = a.id)))
            WHEN (t.status = 'failed'::text) THEN ((pa.state = 'failed'::text) AND (NOT b.settled) AND (a.balance = 0) AND ( SELECT (count(*) = 2)
               FROM member72_1c1acaaf36d7e39a.ledger_entries e
              WHERE (e.account_id = a.id)) AND member72_1c1acaaf36d7e39a.settlement_journal_matches((('settlement-payout:'::text || (r.id)::text) || ':release'::text), a.id, available.id, p.gross_amount) AND (((p.send_state = 'cancelled'::text) AND (b.state = 'cancelled'::text) AND (NOT b.return_observed) AND (EXISTS ( SELECT 1
               FROM member72_1c1acaaf36d7e39a.settlement_payout_cancellations pc
              WHERE ((pc.request_id = p.request_id) AND (pc.transfer_id = t.id))))) OR ((p.send_state = 'claimed'::text) AND (((b.state = 'failed'::text) AND (b.returned_principal = 0)) OR ((b.state = 'reversed'::text) AND b.return_observed AND (b.returned_principal = p.net_amount))))))
            WHEN (t.status = 'succeeded'::text) THEN ((p.send_state = 'claimed'::text) AND (pa.state = 'succeeded'::text) AND (pa.provider_transfer_no <> ''::text) AND b.settled AND member72_1c1acaaf36d7e39a.settlement_journal_matches((('settlement-payout:'::text || (r.id)::text) || ':principal'::text), a.id, clearing.id, p.net_amount) AND (NOT (EXISTS ( SELECT 1
               FROM member72_1c1acaaf36d7e39a.journals j
              WHERE (j.event_key = (('settlement-payout:'::text || (r.id)::text) || ':fee'::text))))) AND
            CASE
                WHEN (b.state = ANY (ARRAY['succeeded'::text, 'reversal_pending'::text])) THEN ((b.returned_principal = 0) AND (a.balance = p.fee_amount) AND ( SELECT (count(*) = 2)
                   FROM member72_1c1acaaf36d7e39a.ledger_entries e
                  WHERE (e.account_id = a.id)))
                WHEN (b.state = 'reversed'::text) THEN (b.return_observed AND (b.returned_principal = p.net_amount) AND (a.balance = 0) AND ( SELECT (count(*) =
                        CASE
                            WHEN (p.fee_amount > 0) THEN 3
                            ELSE 2
                        END)
                   FROM member72_1c1acaaf36d7e39a.ledger_entries e
                  WHERE (e.account_id = a.id)) AND member72_1c1acaaf36d7e39a.settlement_journal_matches((('transfer:'::text || (t.id)::text) || ':bank-return:settlement-principal'::text), clearing.id, available.id, p.net_amount) AND ((p.fee_amount = 0) OR member72_1c1acaaf36d7e39a.settlement_journal_matches((('transfer:'::text || (t.id)::text) || ':bank-return:settlement-fee'::text), a.id, available.id, p.fee_amount)))
                ELSE false
            END)
            ELSE false
        END), false) AS valid
   FROM (((((((((((((member72_1c1acaaf36d7e39a.settlement_fundings f
     JOIN member72_1c1acaaf36d7e39a.ledger_requests r ON ((r.id = f.request_id)))
     JOIN member72_1c1acaaf36d7e39a.accounts a ON ((a.id = f.account_id)))
     JOIN member72_1c1acaaf36d7e39a.journals reserve ON ((reserve.id = f.reserve_journal_id)))
     JOIN member72_1c1acaaf36d7e39a.settlement_payouts p ON ((p.request_id = r.id)))
     JOIN member72_1c1acaaf36d7e39a.settlement_bank_payouts bp ON ((bp.request_id = r.id)))
     JOIN member72_1c1acaaf36d7e39a.settlement_request_terms st ON ((st.request_id = r.id)))
     JOIN member72_1c1acaaf36d7e39a.transfers t ON ((t.id = p.transfer_id)))
     JOIN member72_1c1acaaf36d7e39a.provider_transfer_attempts pa ON ((pa.transfer_id = t.id)))
     JOIN member72_1c1acaaf36d7e39a.bank_transfer_lifecycle b ON ((b.transfer_id = t.id)))
     JOIN member72_1c1acaaf36d7e39a.settlement_recipients sr ON ((sr.request_id = r.id)))
     JOIN member72_1c1acaaf36d7e39a.settlement_recipient_configs c ON ((c.id = sr.config_id)))
     JOIN member72_1c1acaaf36d7e39a.accounts available ON (((available.owner_id = r.merchant_id) AND (available.kind = 'available'::text) AND (available.scope_id = 0))))
     JOIN member72_1c1acaaf36d7e39a.accounts clearing ON (((clearing.owner_id = 0) AND (clearing.kind = 'clearing'::text) AND (clearing.scope_id = 0))));


--
-- Name: settlement_wallet_funding_invariants; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.settlement_wallet_funding_invariants AS
 SELECT f.request_id,
    ((r.kind = 'settlements'::text) AND (r.amount = f.gross_amount) AND (a.owner_id = r.merchant_id) AND (a.kind = 'settlement_reserve'::text) AND (a.scope_id = r.id) AND (j.event_key = (('request:'::text || (r.id)::text) || ':reserve'::text)) AND ( SELECT (count(*) = 2)
           FROM member72_1c1acaaf36d7e39a.ledger_entries e
          WHERE (e.journal_id = j.id)) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
           FROM member72_1c1acaaf36d7e39a.ledger_entries e
          WHERE ((e.journal_id = j.id) AND (e.account_id = a.id))) = (f.gross_amount)::numeric) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
           FROM (member72_1c1acaaf36d7e39a.ledger_entries e
             JOIN member72_1c1acaaf36d7e39a.accounts x ON ((x.id = e.account_id)))
          WHERE ((e.journal_id = j.id) AND (x.owner_id = r.merchant_id) AND (x.kind = 'available'::text) AND (x.scope_id = 0))) = ((- f.gross_amount))::numeric) AND
        CASE
            WHEN (p.request_id IS NULL) THEN
            CASE
                WHEN (r.status = ANY (ARRAY['pending'::text, 'approved'::text])) THEN ((a.balance = f.gross_amount) AND ( SELECT (count(*) = 1)
                   FROM member72_1c1acaaf36d7e39a.ledger_entries e
                  WHERE (e.account_id = a.id)))
                WHEN (r.status = 'rejected'::text) THEN ((a.balance = 0) AND ( SELECT (count(*) = 2)
                   FROM member72_1c1acaaf36d7e39a.ledger_entries e
                  WHERE (e.account_id = a.id)) AND (EXISTS ( SELECT 1
                   FROM member72_1c1acaaf36d7e39a.journals q
                  WHERE ((q.event_key = (('request:'::text || (r.id)::text) || ':review'::text)) AND ( SELECT (count(*) = 2)
                           FROM member72_1c1acaaf36d7e39a.ledger_entries e
                          WHERE (e.journal_id = q.id)) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                           FROM member72_1c1acaaf36d7e39a.ledger_entries e
                          WHERE ((e.journal_id = q.id) AND (e.account_id = a.id))) = ((- f.gross_amount))::numeric) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                           FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                             JOIN member72_1c1acaaf36d7e39a.accounts x ON ((x.id = e.account_id)))
                          WHERE ((e.journal_id = q.id) AND (x.owner_id = r.merchant_id) AND (x.kind = 'available'::text) AND (x.scope_id = 0))) = (f.gross_amount)::numeric)))))
                ELSE false
            END
            ELSE ((r.status = 'approved'::text) AND (p.gross_amount = f.gross_amount) AND (p.net_amount = st.net_amount) AND (p.fee_amount = st.fee_amount) AND (t.merchant_id = r.merchant_id) AND (t.amount = p.net_amount) AND (t.cost_amount = p.net_amount) AND (t.fee_amount = 0) AND (t.fee_rate_bps = 0) AND (pa.channel_id = p.channel_id) AND (sr.identity_hash = p.recipient_hash) AND (c.recipient_type = p.provider_kind) AND ((c.app_id = ''::text) OR (c.app_id = p.app_id)) AND (NOT (EXISTS ( SELECT 1
               FROM member72_1c1acaaf36d7e39a.transfer_batch_items bi
              WHERE (bi.transfer_id = p.transfer_id)))) AND
            CASE
                WHEN (t.status = ANY (ARRAY['pending'::text, 'unknown'::text])) THEN ((p.send_state = ANY (ARRAY['unsent'::text, 'claimed'::text])) AND ((p.send_state = 'claimed'::text) OR ((t.status = 'pending'::text) AND (pa.state = 'processing'::text) AND (pa.provider_transfer_no = ''::text))) AND (pa.state = ANY (ARRAY['processing'::text, 'pending'::text, 'unknown'::text])) AND ((t.status <> 'unknown'::text) OR (pa.state = 'unknown'::text)) AND (a.balance = f.gross_amount) AND ( SELECT (count(*) = 1)
                   FROM member72_1c1acaaf36d7e39a.ledger_entries e
                  WHERE (e.account_id = a.id)))
                WHEN (t.status = 'succeeded'::text) THEN ((p.send_state = 'claimed'::text) AND (pa.state = 'succeeded'::text) AND (pa.provider_transfer_no <> ''::text) AND (a.balance = 0) AND ( SELECT (count(*) =
                        CASE
                            WHEN (p.fee_amount > 0) THEN 3
                            ELSE 2
                        END)
                   FROM member72_1c1acaaf36d7e39a.ledger_entries e
                  WHERE (e.account_id = a.id)) AND (EXISTS ( SELECT 1
                   FROM member72_1c1acaaf36d7e39a.journals q
                  WHERE ((q.event_key = (('settlement-payout:'::text || (r.id)::text) || ':principal'::text)) AND ( SELECT (count(*) = 2)
                           FROM member72_1c1acaaf36d7e39a.ledger_entries e
                          WHERE (e.journal_id = q.id)) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                           FROM member72_1c1acaaf36d7e39a.ledger_entries e
                          WHERE ((e.journal_id = q.id) AND (e.account_id = a.id))) = ((- p.net_amount))::numeric) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                           FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                             JOIN member72_1c1acaaf36d7e39a.accounts x ON ((x.id = e.account_id)))
                          WHERE ((e.journal_id = q.id) AND (x.owner_id = 0) AND (x.kind = 'clearing'::text) AND (x.scope_id = 0))) = (p.net_amount)::numeric)))) AND ((p.fee_amount = 0) OR (EXISTS ( SELECT 1
                   FROM member72_1c1acaaf36d7e39a.journals q
                  WHERE ((q.event_key = (('settlement-payout:'::text || (r.id)::text) || ':fee'::text)) AND ( SELECT (count(*) = 2)
                           FROM member72_1c1acaaf36d7e39a.ledger_entries e
                          WHERE (e.journal_id = q.id)) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                           FROM member72_1c1acaaf36d7e39a.ledger_entries e
                          WHERE ((e.journal_id = q.id) AND (e.account_id = a.id))) = ((- p.fee_amount))::numeric) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                           FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                             JOIN member72_1c1acaaf36d7e39a.accounts x ON ((x.id = e.account_id)))
                          WHERE ((e.journal_id = q.id) AND (x.owner_id = 0) AND (x.kind = 'fees'::text) AND (x.scope_id = 0))) = (p.fee_amount)::numeric))))))
                WHEN (t.status = 'failed'::text) THEN ((pa.state = 'failed'::text) AND ((p.send_state = 'claimed'::text) OR ((p.send_state = 'cancelled'::text) AND (EXISTS ( SELECT 1
                   FROM member72_1c1acaaf36d7e39a.settlement_payout_cancellations pc
                  WHERE ((pc.request_id = p.request_id) AND (pc.transfer_id = p.transfer_id)))))) AND (a.balance = 0) AND ( SELECT (count(*) = 2)
                   FROM member72_1c1acaaf36d7e39a.ledger_entries e
                  WHERE (e.account_id = a.id)) AND (EXISTS ( SELECT 1
                   FROM member72_1c1acaaf36d7e39a.journals q
                  WHERE ((q.event_key = (('settlement-payout:'::text || (r.id)::text) || ':release'::text)) AND ( SELECT (count(*) = 2)
                           FROM member72_1c1acaaf36d7e39a.ledger_entries e
                          WHERE (e.journal_id = q.id)) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                           FROM member72_1c1acaaf36d7e39a.ledger_entries e
                          WHERE ((e.journal_id = q.id) AND (e.account_id = a.id))) = ((- p.gross_amount))::numeric) AND (( SELECT COALESCE(sum(e.amount), (0)::numeric) AS "coalesce"
                           FROM (member72_1c1acaaf36d7e39a.ledger_entries e
                             JOIN member72_1c1acaaf36d7e39a.accounts x ON ((x.id = e.account_id)))
                          WHERE ((e.journal_id = q.id) AND (x.owner_id = r.merchant_id) AND (x.kind = 'available'::text) AND (x.scope_id = 0))) = (p.gross_amount)::numeric)))))
                ELSE false
            END)
        END) AS valid
   FROM (((((((((member72_1c1acaaf36d7e39a.settlement_fundings f
     JOIN member72_1c1acaaf36d7e39a.ledger_requests r ON ((r.id = f.request_id)))
     JOIN member72_1c1acaaf36d7e39a.accounts a ON ((a.id = f.account_id)))
     JOIN member72_1c1acaaf36d7e39a.journals j ON ((j.id = f.reserve_journal_id)))
     LEFT JOIN member72_1c1acaaf36d7e39a.settlement_payouts p ON ((p.request_id = r.id)))
     LEFT JOIN member72_1c1acaaf36d7e39a.settlement_request_terms st ON ((st.request_id = r.id)))
     LEFT JOIN member72_1c1acaaf36d7e39a.transfers t ON ((t.id = p.transfer_id)))
     LEFT JOIN member72_1c1acaaf36d7e39a.provider_transfer_attempts pa ON ((pa.transfer_id = t.id)))
     LEFT JOIN member72_1c1acaaf36d7e39a.settlement_recipients sr ON ((sr.request_id = r.id)))
     LEFT JOIN member72_1c1acaaf36d7e39a.settlement_recipient_configs c ON ((c.id = sr.config_id)));


--
-- Name: settlement_funding_invariants; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.settlement_funding_invariants AS
 SELECT w.request_id,
    w.valid
   FROM member72_1c1acaaf36d7e39a.settlement_wallet_funding_invariants w
  WHERE (NOT (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.settlement_bank_payouts bp
          WHERE (bp.request_id = w.request_id))))
UNION ALL
 SELECT b.request_id,
    b.valid
   FROM member72_1c1acaaf36d7e39a.settlement_bank_funding_invariants b;


--
-- Name: settlement_payout_events; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_payout_events (
    id bigint NOT NULL,
    request_id bigint NOT NULL,
    action text NOT NULL,
    actor_role text NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    result_state text NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT settlement_payout_event_actor CHECK ((((actor_role = ANY (ARRAY['admin'::text, 'merchant'::text])) AND (actor_id > 0)) OR ((actor_role = 'system'::text) AND (actor_id = 0) AND (actor_name = 'settlement-auto'::text)))),
    CONSTRAINT settlement_payout_events_action_check CHECK ((action = ANY (ARRAY['prepare'::text, 'claim'::text, 'result'::text, 'query'::text, 'cancel'::text]))),
    CONSTRAINT settlement_payout_events_actor_name_check CHECK (((length(actor_name) >= 1) AND (length(actor_name) <= 128))),
    CONSTRAINT settlement_payout_events_result_state_check CHECK ((length(result_state) <= 64))
);


--
-- Name: settlement_payout_events_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.settlement_payout_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settlement_payout_events_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.settlement_payout_events_id_seq OWNED BY member72_1c1acaaf36d7e39a.settlement_payout_events.id;


--
-- Name: settlement_plan_authorizations; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_plan_authorizations (
    id bigint NOT NULL,
    plan_id bigint NOT NULL,
    plan_revision bigint NOT NULL,
    expected_authorization_id bigint,
    valid_from timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    max_item_gross bigint NOT NULL,
    max_run_gross bigint NOT NULL,
    max_day_gross bigint NOT NULL,
    max_day_items bigint NOT NULL,
    scope_snapshot jsonb NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT settlement_plan_authorizations_actor_id_check CHECK ((actor_id > 0)),
    CONSTRAINT settlement_plan_authorizations_check CHECK (((expires_at > valid_from) AND (expires_at <= (valid_from + '31 days'::interval)))),
    CONSTRAINT settlement_plan_authorizations_check1 CHECK (((max_item_gross <= max_run_gross) AND (max_run_gross <= max_day_gross))),
    CONSTRAINT settlement_plan_authorizations_max_day_gross_check CHECK (((max_day_gross >= 1) AND (max_day_gross <= '100000000000'::bigint))),
    CONSTRAINT settlement_plan_authorizations_max_day_items_check CHECK (((max_day_items >= 1) AND (max_day_items <= 100))),
    CONSTRAINT settlement_plan_authorizations_max_item_gross_check CHECK (((max_item_gross >= 1) AND (max_item_gross <= '100000000000'::bigint))),
    CONSTRAINT settlement_plan_authorizations_max_run_gross_check CHECK (((max_run_gross >= 1) AND (max_run_gross <= '100000000000'::bigint))),
    CONSTRAINT settlement_plan_authorizations_proof_hash_check CHECK ((octet_length(proof_hash) = 32))
);


--
-- Name: settlement_plan_revocations; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_plan_revocations (
    authorization_id bigint NOT NULL,
    plan_id bigint NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT settlement_plan_revocations_actor_id_check CHECK ((actor_id > 0)),
    CONSTRAINT settlement_plan_revocations_proof_hash_check CHECK ((octet_length(proof_hash) = 32))
);


--
-- Name: settlement_plan_versions; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_plan_versions (
    id bigint NOT NULL,
    plan_id bigint NOT NULL,
    revision bigint NOT NULL,
    name text NOT NULL,
    mode text NOT NULL,
    schedule jsonb NOT NULL,
    merchant_ids bigint[] NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT settlement_plan_versions_actor_id_check CHECK ((actor_id > 0)),
    CONSTRAINT settlement_plan_versions_merchant_ids_check CHECK (((cardinality(merchant_ids) >= 1) AND (cardinality(merchant_ids) <= 100))),
    CONSTRAINT settlement_plan_versions_mode_check CHECK ((mode = ANY (ARRAY['generate_only'::text, 'balance_threshold'::text]))),
    CONSTRAINT settlement_plan_versions_name_check CHECK (((length(name) >= 1) AND (length(name) <= 100))),
    CONSTRAINT settlement_plan_versions_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT settlement_plan_versions_revision_check CHECK ((revision > 0))
);


--
-- Name: settlement_plan_authorization_invariants; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.settlement_plan_authorization_invariants AS
 SELECT id,
    ((EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.settlement_plan_versions v
          WHERE (((v.plan_id = a.plan_id) AND (v.revision = a.plan_revision)) AND ((v.id)::text = (a.scope_snapshot ->> 'definition_id'::text)) AND (encode(v.proof_hash, 'base64'::text) = (a.scope_snapshot ->> 'definition_hash'::text))))) AND (NOT (expected_authorization_id IS DISTINCT FROM ( SELECT max(x.id) AS max
           FROM member72_1c1acaaf36d7e39a.settlement_plan_authorizations x
          WHERE ((x.plan_id = a.plan_id) AND (x.id < a.id))))) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.backoffice_audit b
          WHERE ((b.resource = 'settlement-plan-authorizations'::text) AND (b.resource_id = a.id) AND (b.operation = 'authorize'::text) AND ((b.actor_role = 'admin'::text) AND (b.actor_id = a.actor_id) AND (b.actor_name = a.actor_name))))) AND (NOT (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.settlement_plan_revocations r
          WHERE ((r.authorization_id = a.id) AND ((r.plan_id <> a.plan_id) OR (NOT (EXISTS ( SELECT 1
                   FROM member72_1c1acaaf36d7e39a.backoffice_audit b
                  WHERE ((b.resource = 'settlement-plan-authorizations'::text) AND (b.resource_id = a.id) AND (b.operation = 'revoke'::text) AND ((b.actor_role = 'admin'::text) AND (b.actor_id = r.actor_id) AND (b.actor_name = r.actor_name)))))))))))) AS valid
   FROM member72_1c1acaaf36d7e39a.settlement_plan_authorizations a;


--
-- Name: settlement_plan_authorizations_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.settlement_plan_authorizations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settlement_plan_authorizations_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.settlement_plan_authorizations_id_seq OWNED BY member72_1c1acaaf36d7e39a.settlement_plan_authorizations.id;


--
-- Name: settlement_plan_budget_uses; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_plan_budget_uses (
    item_id bigint NOT NULL,
    authorization_id bigint NOT NULL,
    plan_id bigint NOT NULL,
    business_date date NOT NULL,
    gross bigint NOT NULL,
    fee bigint NOT NULL,
    net bigint NOT NULL,
    CONSTRAINT settlement_plan_budget_uses_check CHECK ((gross = (fee + net))),
    CONSTRAINT settlement_plan_budget_uses_fee_check CHECK ((fee >= 0)),
    CONSTRAINT settlement_plan_budget_uses_gross_check CHECK ((gross > 0)),
    CONSTRAINT settlement_plan_budget_uses_net_check CHECK ((net > 0))
);


--
-- Name: settlement_plans; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_plans (
    id bigint NOT NULL,
    revision bigint DEFAULT 1 NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    last_authorization_id bigint,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT settlement_plans_revision_check CHECK ((revision > 0))
);


--
-- Name: settlement_plan_definition_invariants; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.settlement_plan_definition_invariants AS
 SELECT id,
    ((EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.settlement_plans p
          WHERE ((p.id = v.plan_id) AND (p.revision >= v.revision)))) AND (revision = ( SELECT count(*) AS count
           FROM member72_1c1acaaf36d7e39a.settlement_plan_versions x
          WHERE ((x.plan_id = v.plan_id) AND (x.revision <= v.revision)))) AND (NOT (EXISTS ( SELECT 1
           FROM unnest(v.merchant_ids) mid(mid)
          WHERE (NOT (EXISTS ( SELECT 1
                   FROM member72_1c1acaaf36d7e39a.merchants m
                  WHERE (m.id = mid.mid))))))) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.backoffice_audit a
          WHERE ((a.resource = 'settlement-plan-versions'::text) AND (a.resource_id = v.id) AND (a.operation = 'define'::text) AND ((a.actor_role = 'admin'::text) AND (a.actor_id = v.actor_id) AND (a.actor_name = v.actor_name)))))) AS valid
   FROM member72_1c1acaaf36d7e39a.settlement_plan_versions v;


--
-- Name: settlement_plan_head_invariants; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.settlement_plan_head_invariants AS
 SELECT id,
    ((EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.settlement_plan_versions v
          WHERE ((v.plan_id = p.id) AND (v.revision = p.revision)))) AND (revision = ( SELECT count(*) AS count
           FROM member72_1c1acaaf36d7e39a.settlement_plan_versions v
          WHERE (v.plan_id = p.id))) AND (revision = ( SELECT max(v.revision) AS max
           FROM member72_1c1acaaf36d7e39a.settlement_plan_versions v
          WHERE (v.plan_id = p.id))) AND (NOT (last_authorization_id IS DISTINCT FROM ( SELECT max(a.id) AS max
           FROM member72_1c1acaaf36d7e39a.settlement_plan_authorizations a
          WHERE (a.plan_id = p.id)))) AND ((NOT enabled) OR (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.settlement_plan_authorizations a
          WHERE ((a.id = p.last_authorization_id) AND ((a.plan_id = p.id) AND (a.plan_revision = p.revision)) AND (NOT (EXISTS ( SELECT 1
                   FROM member72_1c1acaaf36d7e39a.settlement_plan_revocations r
                  WHERE (r.authorization_id = a.id))))))))) AS valid
   FROM member72_1c1acaaf36d7e39a.settlement_plans p;


--
-- Name: settlement_plan_items; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_plan_items (
    id bigint NOT NULL,
    run_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    state text NOT NULL,
    reason text NOT NULL,
    request_id bigint,
    recipient_config_id bigint,
    ledger_available bigint NOT NULL,
    eligible bigint NOT NULL,
    retained bigint NOT NULL,
    gross bigint NOT NULL,
    fee bigint NOT NULL,
    net bigint NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT settlement_plan_items_check CHECK (((eligible >= 0) AND (eligible <= ledger_available))),
    CONSTRAINT settlement_plan_items_check1 CHECK ((gross = (fee + net))),
    CONSTRAINT settlement_plan_items_check2 CHECK (((state = 'created'::text) = (request_id IS NOT NULL))),
    CONSTRAINT settlement_plan_items_check3 CHECK (((state = 'created'::text) OR (gross = 0))),
    CONSTRAINT settlement_plan_items_check4 CHECK (((state <> 'created'::text) OR (net > 0))),
    CONSTRAINT settlement_plan_items_fee_check CHECK ((fee >= 0)),
    CONSTRAINT settlement_plan_items_gross_check CHECK ((gross >= 0)),
    CONSTRAINT settlement_plan_items_ledger_available_check CHECK ((ledger_available >= 0)),
    CONSTRAINT settlement_plan_items_net_check CHECK ((net >= 0)),
    CONSTRAINT settlement_plan_items_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT settlement_plan_items_retained_check CHECK ((retained >= 0)),
    CONSTRAINT settlement_plan_items_state_check CHECK ((state = ANY (ARRAY['created'::text, 'skipped'::text, 'blocked'::text])))
);


--
-- Name: settlement_plan_runs; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_plan_runs (
    id bigint NOT NULL,
    plan_id bigint NOT NULL,
    plan_revision bigint NOT NULL,
    authorization_id bigint NOT NULL,
    slot_no bigint NOT NULL,
    business_date date NOT NULL,
    scheduled_at timestamp with time zone NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    threshold_source_version smallint DEFAULT 0 NOT NULL,
    threshold_source_hash bytea,
    threshold_source_sequence bigint DEFAULT 0 NOT NULL,
    CONSTRAINT settlement_plan_runs_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT settlement_plan_runs_slot_no_check CHECK ((slot_no >= 0)),
    CONSTRAINT settlement_plan_runs_threshold_source_version_check CHECK ((threshold_source_version = ANY (ARRAY[0, 1]))),
    CONSTRAINT threshold_run_source_shape CHECK ((((threshold_source_version = 0) AND (threshold_source_hash IS NULL) AND (threshold_source_sequence = 0)) OR ((threshold_source_version = 1) AND (threshold_source_hash IS NOT NULL) AND (octet_length(threshold_source_hash) = 32) AND (threshold_source_sequence > 0))))
);


--
-- Name: settlement_scheduled_intents; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_scheduled_intents (
    merchant_id bigint NOT NULL,
    business_date date NOT NULL,
    item_id bigint NOT NULL,
    request_id bigint NOT NULL
);


--
-- Name: settlement_threshold_intents; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_threshold_intents (
    run_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    item_id bigint NOT NULL,
    request_id bigint NOT NULL
);


--
-- Name: settlement_threshold_selections; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_threshold_selections (
    run_id bigint NOT NULL,
    source_sequence bigint NOT NULL,
    snapshot jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    transaction_id xid8 DEFAULT pg_current_xact_id() NOT NULL,
    proof_hash bytea NOT NULL,
    CONSTRAINT settlement_threshold_selections_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT settlement_threshold_selections_snapshot_check CHECK ((((jsonb_typeof(snapshot) = 'object'::text) AND (jsonb_typeof((snapshot -> 'candidates'::text)) = 'array'::text) AND (jsonb_typeof((snapshot -> 'selected'::text)) = 'array'::text)) IS TRUE)),
    CONSTRAINT settlement_threshold_selections_snapshot_check1 CHECK (((jsonb_array_length((snapshot -> 'candidates'::text)) >= 1) AND (jsonb_array_length((snapshot -> 'candidates'::text)) <= 100))),
    CONSTRAINT settlement_threshold_selections_snapshot_check2 CHECK ((jsonb_array_length((snapshot -> 'selected'::text)) <= 5))
);


--
-- Name: settlement_plan_item_invariants; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.settlement_plan_item_invariants AS
 SELECT i.id,
    ((i.merchant_id = ANY (v.merchant_ids)) AND ((a.plan_id = r.plan_id) AND (a.plan_revision = r.plan_revision)) AND (((v.mode = 'generate_only'::text) AND (r.threshold_source_version = 0) AND (NOT (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.settlement_threshold_intents z
          WHERE (z.item_id = i.id))))) OR ((v.mode = 'balance_threshold'::text) AND (r.threshold_source_version = 1) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.settlement_threshold_selections z
          WHERE ((z.run_id = r.id) AND (z.source_sequence = r.threshold_source_sequence) AND (z.proof_hash = r.threshold_source_hash)))) AND (NOT (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.settlement_scheduled_intents z
          WHERE (z.item_id = i.id)))))) AND ((i.state <> 'created'::text) OR ((q.kind = 'settlements'::text) AND (q.merchant_id = i.merchant_id) AND (q.status = ANY (ARRAY['pending'::text, 'approved'::text, 'rejected'::text])) AND (q.amount = i.gross) AND (q.settlement_plan_item_id = i.id) AND ((t.gross_amount = i.gross) AND (t.fee_amount = i.fee) AND (t.net_amount = i.net)) AND (sr.config_id = i.recipient_config_id) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.settlement_funding_invariants f
          WHERE ((f.request_id = q.id) AND (f.valid IS TRUE)))) AND (((v.mode = 'generate_only'::text) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.settlement_scheduled_intents x
          WHERE ((x.merchant_id = i.merchant_id) AND (x.business_date = r.business_date) AND (x.item_id = i.id) AND (x.request_id = q.id))))) OR ((v.mode = 'balance_threshold'::text) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.settlement_threshold_intents x
          WHERE ((x.run_id = r.id) AND (x.merchant_id = i.merchant_id) AND (x.item_id = i.id) AND (x.request_id = q.id)))))) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.settlement_plan_budget_uses b
          WHERE ((b.item_id = i.id) AND (b.authorization_id = r.authorization_id) AND (b.plan_id = r.plan_id) AND (b.business_date = r.business_date) AND (b.gross = i.gross) AND (b.fee = i.fee) AND (b.net = i.net)))) AND (i.gross <= a.max_item_gross) AND (( SELECT COALESCE(sum(x.gross), (0)::numeric) AS "coalesce"
           FROM member72_1c1acaaf36d7e39a.settlement_plan_items x
          WHERE ((x.run_id = r.id) AND (x.id <= i.id))) <= (a.max_run_gross)::numeric) AND (( SELECT COALESCE(sum(b.gross), (0)::numeric) AS "coalesce"
           FROM member72_1c1acaaf36d7e39a.settlement_plan_budget_uses b
          WHERE ((b.plan_id = r.plan_id) AND (b.business_date = r.business_date) AND (b.item_id <= i.id))) <= (a.max_day_gross)::numeric) AND (( SELECT count(*) AS count
           FROM member72_1c1acaaf36d7e39a.settlement_plan_budget_uses b
          WHERE ((b.plan_id = r.plan_id) AND (b.business_date = r.business_date) AND (b.item_id <= i.id))) <= a.max_day_items))) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.backoffice_audit b
          WHERE ((b.resource = 'settlement-plan-items'::text) AND (b.resource_id = i.id) AND (b.operation = 'generate'::text) AND (b.actor_role = 'system'::text) AND (b.actor_id = 0) AND (b.actor_name = 'settlement-scheduler'::text))))) AS valid
   FROM ((((((member72_1c1acaaf36d7e39a.settlement_plan_items i
     JOIN member72_1c1acaaf36d7e39a.settlement_plan_runs r ON ((r.id = i.run_id)))
     JOIN member72_1c1acaaf36d7e39a.settlement_plan_versions v ON (((v.plan_id = r.plan_id) AND (v.revision = r.plan_revision))))
     JOIN member72_1c1acaaf36d7e39a.settlement_plan_authorizations a ON ((a.id = r.authorization_id)))
     LEFT JOIN member72_1c1acaaf36d7e39a.ledger_requests q ON ((q.id = i.request_id)))
     LEFT JOIN member72_1c1acaaf36d7e39a.settlement_request_terms t ON ((t.request_id = q.id)))
     LEFT JOIN member72_1c1acaaf36d7e39a.settlement_recipients sr ON ((sr.request_id = q.id)));


--
-- Name: settlement_plan_items_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.settlement_plan_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settlement_plan_items_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.settlement_plan_items_id_seq OWNED BY member72_1c1acaaf36d7e39a.settlement_plan_items.id;


--
-- Name: settlement_schedule_preference_heads; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_schedule_preference_heads (
    merchant_id bigint NOT NULL,
    preference_id bigint NOT NULL,
    revision bigint NOT NULL
);


--
-- Name: settlement_schedule_preferences; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_schedule_preferences (
    id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    revision bigint NOT NULL,
    enabled boolean NOT NULL,
    recipient_config_id bigint,
    actor_name text NOT NULL,
    proof_hash bytea NOT NULL,
    created_at timestamp with time zone DEFAULT transaction_timestamp() NOT NULL,
    CONSTRAINT settlement_schedule_preferences_check CHECK (((NOT enabled) OR (recipient_config_id IS NOT NULL))),
    CONSTRAINT settlement_schedule_preferences_proof_hash_check CHECK ((octet_length(proof_hash) = 32)),
    CONSTRAINT settlement_schedule_preferences_revision_check CHECK ((revision > 0))
);


--
-- Name: settlement_plan_preference_invariants; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.settlement_plan_preference_invariants AS
 SELECT id,
    ((EXISTS ( SELECT 1
           FROM (member72_1c1acaaf36d7e39a.settlement_schedule_preference_heads h
             JOIN member72_1c1acaaf36d7e39a.settlement_schedule_preferences latest ON ((latest.id = h.preference_id)))
          WHERE ((h.merchant_id = p.merchant_id) AND ((latest.merchant_id = h.merchant_id) AND (latest.revision = h.revision)) AND (h.revision = ( SELECT max(x.revision) AS max
                   FROM member72_1c1acaaf36d7e39a.settlement_schedule_preferences x
                  WHERE (x.merchant_id = p.merchant_id)))))) AND (revision = ( SELECT count(*) AS count
           FROM member72_1c1acaaf36d7e39a.settlement_schedule_preferences x
          WHERE ((x.merchant_id = p.merchant_id) AND (x.revision <= p.revision)))) AND ((recipient_config_id IS NULL) OR (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.settlement_recipient_configs c
          WHERE ((c.id = p.recipient_config_id) AND (c.merchant_id = p.merchant_id))))) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.backoffice_audit a
          WHERE ((a.resource = 'settlement-schedule-preferences'::text) AND (a.resource_id = p.id) AND (a.operation = 'configure'::text) AND ((a.actor_role = 'merchant'::text) AND (a.actor_id = p.merchant_id) AND (a.actor_name = p.actor_name)))))) AS valid
   FROM member72_1c1acaaf36d7e39a.settlement_schedule_preferences p;


--
-- Name: settlement_plan_run_invariants; Type: VIEW; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE VIEW member72_1c1acaaf36d7e39a.settlement_plan_run_invariants AS
 SELECT id,
    ((EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.settlement_plan_authorizations a
          WHERE ((a.id = r.authorization_id) AND ((a.plan_id = r.plan_id) AND (a.plan_revision = r.plan_revision))))) AND (((scheduled_at AT TIME ZONE 'Asia/Shanghai'::text))::date = business_date) AND (EXISTS ( SELECT 1
           FROM member72_1c1acaaf36d7e39a.backoffice_audit b
          WHERE ((b.resource = 'settlement-plan-runs'::text) AND (b.resource_id = r.id) AND (b.operation = 'schedule'::text) AND (b.actor_role = 'system'::text) AND (b.actor_id = 0) AND (b.actor_name = 'settlement-scheduler'::text))))) AS valid
   FROM member72_1c1acaaf36d7e39a.settlement_plan_runs r;


--
-- Name: settlement_plan_runs_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.settlement_plan_runs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settlement_plan_runs_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.settlement_plan_runs_id_seq OWNED BY member72_1c1acaaf36d7e39a.settlement_plan_runs.id;


--
-- Name: settlement_plan_versions_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.settlement_plan_versions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settlement_plan_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.settlement_plan_versions_id_seq OWNED BY member72_1c1acaaf36d7e39a.settlement_plan_versions.id;


--
-- Name: settlement_plans_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.settlement_plans_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settlement_plans_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.settlement_plans_id_seq OWNED BY member72_1c1acaaf36d7e39a.settlement_plans.id;


--
-- Name: settlement_recipient_configs_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.settlement_recipient_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settlement_recipient_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.settlement_recipient_configs_id_seq OWNED BY member72_1c1acaaf36d7e39a.settlement_recipient_configs.id;


--
-- Name: settlement_recipient_current; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.settlement_recipient_current (
    merchant_id bigint NOT NULL,
    config_id bigint NOT NULL
);


--
-- Name: settlement_schedule_preferences_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.settlement_schedule_preferences_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settlement_schedule_preferences_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.settlement_schedule_preferences_id_seq OWNED BY member72_1c1acaaf36d7e39a.settlement_schedule_preferences.id;


--
-- Name: settlement_threshold_selections_source_sequence_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.settlement_threshold_selections_source_sequence_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: settlement_threshold_selections_source_sequence_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.settlement_threshold_selections_source_sequence_seq OWNED BY member72_1c1acaaf36d7e39a.settlement_threshold_selections.source_sequence;


--
-- Name: trade_no_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.trade_no_seq
    START WITH 1000000000000000000
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transfer_batch_events; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.transfer_batch_events (
    id bigint NOT NULL,
    batch_id bigint NOT NULL,
    transfer_id bigint,
    action text NOT NULL,
    actor_role text NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    result_state text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    CONSTRAINT transfer_batch_events_action_check CHECK ((action = ANY (ARRAY['prepare'::text, 'claim'::text, 'result'::text, 'cancel'::text, 'query'::text]))),
    CONSTRAINT transfer_batch_events_actor_id_check CHECK ((actor_id > 0)),
    CONSTRAINT transfer_batch_events_actor_role_check CHECK ((actor_role = ANY (ARRAY['admin'::text, 'merchant'::text])))
);


--
-- Name: transfer_batch_events_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.transfer_batch_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transfer_batch_events_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.transfer_batch_events_id_seq OWNED BY member72_1c1acaaf36d7e39a.transfer_batch_events.id;


--
-- Name: transfer_batch_execution_claims; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.transfer_batch_execution_claims (
    transfer_id bigint NOT NULL,
    execution_no text NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: transfer_batch_executions; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.transfer_batch_executions (
    execution_no text NOT NULL,
    batch_id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    actor_role text NOT NULL,
    actor_id bigint NOT NULL,
    actor_name text NOT NULL,
    transfer_ids bigint[] NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT transfer_batch_executions_actor_id_check CHECK ((actor_id > 0)),
    CONSTRAINT transfer_batch_executions_actor_name_check CHECK (((length(actor_name) > 0) AND (length(actor_name) <= 128))),
    CONSTRAINT transfer_batch_executions_actor_role_check CHECK ((actor_role = ANY (ARRAY['admin'::text, 'merchant'::text]))),
    CONSTRAINT transfer_batch_executions_execution_no_check CHECK ((execution_no ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT transfer_batch_executions_transfer_ids_check CHECK (((cardinality(transfer_ids) >= 1) AND (cardinality(transfer_ids) <= 100)))
);


--
-- Name: transfer_batches; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.transfer_batches (
    id bigint NOT NULL,
    merchant_id bigint NOT NULL,
    external_no text NOT NULL,
    intent_hash bytea NOT NULL,
    item_count integer NOT NULL,
    amount bigint NOT NULL,
    cost_amount bigint NOT NULL,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    CONSTRAINT transfer_batches_amount_check CHECK ((amount > 0)),
    CONSTRAINT transfer_batches_check CHECK ((cost_amount >= amount)),
    CONSTRAINT transfer_batches_external_no_check CHECK (((length(external_no) >= 1) AND (length(external_no) <= 128))),
    CONSTRAINT transfer_batches_intent_hash_check CHECK ((octet_length(intent_hash) = 32)),
    CONSTRAINT transfer_batches_item_count_check CHECK (((item_count >= 1) AND (item_count <= 100)))
);


--
-- Name: transfer_batches_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.transfer_batches_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transfer_batches_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.transfer_batches_id_seq OWNED BY member72_1c1acaaf36d7e39a.transfer_batches.id;


--
-- Name: transfer_unsent_cancellations; Type: TABLE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TABLE member72_1c1acaaf36d7e39a.transfer_unsent_cancellations (
    transfer_id bigint NOT NULL,
    cost_amount bigint NOT NULL,
    created_at timestamp with time zone DEFAULT statement_timestamp() NOT NULL,
    CONSTRAINT transfer_unsent_cancellations_cost_amount_check CHECK ((cost_amount > 0))
);


--
-- Name: transfers_id_seq; Type: SEQUENCE; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE SEQUENCE member72_1c1acaaf36d7e39a.transfers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: transfers_id_seq; Type: SEQUENCE OWNED BY; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER SEQUENCE member72_1c1acaaf36d7e39a.transfers_id_seq OWNED BY member72_1c1acaaf36d7e39a.transfers.id;


--
-- Name: accounts id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.accounts ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.accounts_id_seq'::regclass);


--
-- Name: admin_funds_audit id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.admin_funds_audit ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.admin_funds_audit_id_seq'::regclass);


--
-- Name: alipay_bank_observations id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.alipay_bank_observations ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.alipay_bank_observations_id_seq'::regclass);


--
-- Name: application_authorization_events id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.application_authorization_events ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.application_authorization_events_id_seq'::regclass);


--
-- Name: authorization_remaining_sources id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.authorization_remaining_sources ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.authorization_remaining_sources_id_seq'::regclass);


--
-- Name: backoffice_audit id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.backoffice_audit ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.backoffice_audit_id_seq'::regclass);


--
-- Name: backoffice_records id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.backoffice_records ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.backoffice_records_id_seq'::regclass);


--
-- Name: bank_transfer_observations id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.bank_transfer_observations ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.bank_transfer_observations_id_seq'::regclass);


--
-- Name: case_comments id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.case_comments ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.case_comments_id_seq'::regclass);


--
-- Name: channel_sharing_finish_observations id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_finish_observations ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.channel_sharing_finish_observations_id_seq'::regclass);


--
-- Name: channel_sharing_finishes id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_finishes ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.channel_sharing_finishes_id_seq'::regclass);


--
-- Name: channel_sharing_observations id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_observations ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.channel_sharing_observations_id_seq'::regclass);


--
-- Name: channel_sharing_orders id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_orders ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.channel_sharing_orders_id_seq'::regclass);


--
-- Name: channel_sharing_receiver_operations id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations_id_seq'::regclass);


--
-- Name: channel_sharing_receivers id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_receivers ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.channel_sharing_receivers_id_seq'::regclass);


--
-- Name: channel_sharing_relation_leases id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_relation_leases ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.channel_sharing_relation_leases_id_seq'::regclass);


--
-- Name: channel_sharing_relations id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_relations ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.channel_sharing_relations_id_seq'::regclass);


--
-- Name: channel_sharing_return_observations id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_return_observations ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.channel_sharing_return_observations_id_seq'::regclass);


--
-- Name: channel_sharing_returns id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_returns ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.channel_sharing_returns_id_seq'::regclass);


--
-- Name: channel_sharing_rules id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_rules ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.channel_sharing_rules_id_seq'::regclass);


--
-- Name: channel_stop_events id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_stop_events ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.channel_stop_events_id_seq'::regclass);


--
-- Name: console_login_audit id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.console_login_audit ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.console_login_audit_id_seq'::regclass);


--
-- Name: console_users id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.console_users ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.console_users_id_seq'::regclass);


--
-- Name: deposit_action_events id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.deposit_action_events ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.deposit_action_events_id_seq'::regclass);


--
-- Name: deposit_actions id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.deposit_actions ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.deposit_actions_id_seq'::regclass);


--
-- Name: identity_lookup_events id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.identity_lookup_events ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.identity_lookup_events_id_seq'::regclass);


--
-- Name: jobs id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.jobs ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.jobs_id_seq'::regclass);


--
-- Name: journals id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.journals ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.journals_id_seq'::regclass);


--
-- Name: ledger_entries id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.ledger_entries ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.ledger_entries_id_seq'::regclass);


--
-- Name: ledger_request_events id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.ledger_request_events ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.ledger_request_events_id_seq'::regclass);


--
-- Name: ledger_requests id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.ledger_requests ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.ledger_requests_id_seq'::regclass);


--
-- Name: legacy_refund_history id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.legacy_refund_history ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.legacy_refund_history_id_seq'::regclass);


--
-- Name: membership_purchases id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_purchases ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.membership_purchases_id_seq'::regclass);


--
-- Name: membership_referral_events id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_events ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.membership_referral_events_id_seq'::regclass);


--
-- Name: membership_referral_policies id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_policies ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.membership_referral_policies_id_seq'::regclass);


--
-- Name: operation_audit id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.operation_audit ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.operation_audit_id_seq'::regclass);


--
-- Name: order_income_hold_events id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_income_hold_events ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.order_income_hold_events_id_seq'::regclass);


--
-- Name: order_income_holds id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_income_holds ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.order_income_holds_id_seq'::regclass);


--
-- Name: order_profit_allocations id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_profit_allocations ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.order_profit_allocations_id_seq'::regclass);


--
-- Name: orders id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.orders ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.orders_id_seq'::regclass);


--
-- Name: outbox id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.outbox ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.outbox_id_seq'::regclass);


--
-- Name: preauth_observation_events id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.preauth_observation_events ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.preauth_observation_events_id_seq'::regclass);


--
-- Name: printing_intents id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_intents ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.printing_intents_id_seq'::regclass);


--
-- Name: printing_merchant_configs id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_merchant_configs ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.printing_merchant_configs_id_seq'::regclass);


--
-- Name: printing_platform_configs id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_platform_configs ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.printing_platform_configs_id_seq'::regclass);


--
-- Name: printing_recoveries id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_recoveries ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.printing_recoveries_id_seq'::regclass);


--
-- Name: profile_identity_lookup_events id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.profile_identity_lookup_events ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.profile_identity_lookup_events_id_seq'::regclass);


--
-- Name: provider_attempts id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_attempts ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.provider_attempts_id_seq'::regclass);


--
-- Name: provider_operations id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_operations ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.provider_operations_id_seq'::regclass);


--
-- Name: provider_reconciliations id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_reconciliations ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.provider_reconciliations_id_seq'::regclass);


--
-- Name: recharge_intents id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.recharge_intents ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.recharge_intents_id_seq'::regclass);


--
-- Name: referral_daily_events id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_events ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.referral_daily_events_id_seq'::regclass);


--
-- Name: referral_policies id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_policies ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.referral_policies_id_seq'::regclass);


--
-- Name: referral_relations id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_relations ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.referral_relations_id_seq'::regclass);


--
-- Name: referral_rewards id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_rewards ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.referral_rewards_id_seq'::regclass);


--
-- Name: referral_tokens id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_tokens ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.referral_tokens_id_seq'::regclass);


--
-- Name: refunds id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.refunds ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.refunds_id_seq'::regclass);


--
-- Name: scan_recovery_query_events id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.scan_recovery_query_events ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.scan_recovery_query_events_id_seq'::regclass);


--
-- Name: settlement_auto_authorizations id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_authorizations ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.settlement_auto_authorizations_id_seq'::regclass);


--
-- Name: settlement_auto_claims claim_seq; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_claims ALTER COLUMN claim_seq SET DEFAULT nextval('member72_1c1acaaf36d7e39a.settlement_auto_claims_claim_seq_seq'::regclass);


--
-- Name: settlement_payout_events id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_payout_events ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.settlement_payout_events_id_seq'::regclass);


--
-- Name: settlement_plan_authorizations id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_authorizations ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.settlement_plan_authorizations_id_seq'::regclass);


--
-- Name: settlement_plan_items id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_items ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.settlement_plan_items_id_seq'::regclass);


--
-- Name: settlement_plan_runs id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_runs ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.settlement_plan_runs_id_seq'::regclass);


--
-- Name: settlement_plan_versions id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_versions ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.settlement_plan_versions_id_seq'::regclass);


--
-- Name: settlement_plans id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plans ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.settlement_plans_id_seq'::regclass);


--
-- Name: settlement_recipient_configs id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_recipient_configs ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.settlement_recipient_configs_id_seq'::regclass);


--
-- Name: settlement_schedule_preferences id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_schedule_preferences ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.settlement_schedule_preferences_id_seq'::regclass);


--
-- Name: settlement_threshold_selections source_sequence; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_threshold_selections ALTER COLUMN source_sequence SET DEFAULT nextval('member72_1c1acaaf36d7e39a.settlement_threshold_selections_source_sequence_seq'::regclass);


--
-- Name: transfer_batch_events id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfer_batch_events ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.transfer_batch_events_id_seq'::regclass);


--
-- Name: transfer_batches id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfer_batches ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.transfer_batches_id_seq'::regclass);


--
-- Name: transfers id; Type: DEFAULT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfers ALTER COLUMN id SET DEFAULT nextval('member72_1c1acaaf36d7e39a.transfers_id_seq'::regclass);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.accounts (id, owner_id, kind, balance, scope_id) VALUES (2, 0, 'fees', 0, 0);
INSERT INTO member72_1c1acaaf36d7e39a.accounts (id, owner_id, kind, balance, scope_id) VALUES (3, 0, 'fee_reserved', 0, 0);
INSERT INTO member72_1c1acaaf36d7e39a.accounts (id, owner_id, kind, balance, scope_id) VALUES (4, 0, 'bank_service_fee_hold', 0, 0);
INSERT INTO member72_1c1acaaf36d7e39a.accounts (id, owner_id, kind, balance, scope_id) VALUES (5, 0, 'bank_fee_expense', 0, 0);
INSERT INTO member72_1c1acaaf36d7e39a.accounts (id, owner_id, kind, balance, scope_id) VALUES (7, 751, 'reserved', 0, 0);
INSERT INTO member72_1c1acaaf36d7e39a.accounts (id, owner_id, kind, balance, scope_id) VALUES (1, 0, 'clearing', -1000, 0);
INSERT INTO member72_1c1acaaf36d7e39a.accounts (id, owner_id, kind, balance, scope_id) VALUES (6, 751, 'available', 0, 0);
INSERT INTO member72_1c1acaaf36d7e39a.accounts (id, owner_id, kind, balance, scope_id) VALUES (8, 751, 'channel_sharing_reserve', 1000, 1);


--
-- Data for Name: admin_funds_audit; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: admin_funds_challenges; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: admin_funds_credentials; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: admin_funds_grants; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: admin_funds_throttle; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: alipay_bank_bindings; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: alipay_bank_observations; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: application_authorization_code_claims; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: application_authorization_events; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: application_authorization_requests; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: authorization_remaining_claims; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: authorization_remaining_sources; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: backoffice_audit; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.backoffice_audit (id, actor_role, actor_id, actor_name, resource, resource_id, operation, changes, created_at) VALUES (1, 'merchant', 751, 'sharing-owner', 'channel-sharing-receivers', 1, 'create', '{"id": "1", "state": "draft"}', '2026-10-26 00:31:32.509684+00');
INSERT INTO member72_1c1acaaf36d7e39a.backoffice_audit (id, actor_role, actor_id, actor_name, resource, resource_id, operation, changes, created_at) VALUES (2, 'merchant', 751, 'sharing-owner', 'channel-sharing-receiver-operations', 1, 'bind', '{"id": "1", "state": "claimed"}', '2026-10-26 00:31:32.537737+00');
INSERT INTO member72_1c1acaaf36d7e39a.backoffice_audit (id, actor_role, actor_id, actor_name, resource, resource_id, operation, changes, created_at) VALUES (3, 'merchant', 751, 'sharing-owner', 'channel-sharing-receiver-operations', 1, 'bind', '{"id": "1", "state": "succeeded"}', '2026-10-26 00:31:32.606473+00');
INSERT INTO member72_1c1acaaf36d7e39a.backoffice_audit (id, actor_role, actor_id, actor_name, resource, resource_id, operation, changes, created_at) VALUES (4, 'merchant', 751, 'sharing-owner', 'channel-sharing-rules', 1, 'configure', '{"id": "1", "state": "enabled"}', '2026-10-26 00:31:32.641742+00');
INSERT INTO member72_1c1acaaf36d7e39a.backoffice_audit (id, actor_role, actor_id, actor_name, resource, resource_id, operation, changes, created_at) VALUES (5, 'system', 0, 'scan-recovery', 'scan-recovery-origins', 2, 'create', '{"proof": "6d278a01a323a9c246356dac9c728e493c98c90e52519033ac84165a7cfe8de1", "order_id": "2"}', '2026-10-26 00:31:33.026518+00');


--
-- Data for Name: backoffice_records; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: bank_transfer_lifecycle; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: bank_transfer_observations; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: case_comments; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: channel_sharing_completions; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: channel_sharing_finish_observations; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: channel_sharing_finishes; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: channel_sharing_fundings; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.channel_sharing_fundings (order_id, account_id, amount, reserve_journal_id, created_at) VALUES (1, 8, 1000, 2, '2026-10-26 00:31:32.870988+00');


--
-- Data for Name: channel_sharing_observations; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: channel_sharing_order_items; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: channel_sharing_orders; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: channel_sharing_receiver_operations; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations (id, receiver_id, action, out_no, external_no, request_hash, state, actor_role, actor_id, actor_name, actor_class, created_at, claimed_at, relation_id, source, reference_operation_id) VALUES (1, 1, 'bind', 'PB569ea5d961e1ce8ca431dc2857f6cd', 'payment-receiver-bind', '\x136296d22027eb1c0102f4b32164d77dcff4c5fe45e936a2573fbc68d6158fc2', 'succeeded', 'merchant', 751, 'sharing-owner', '', '2026-10-26 00:31:32.557814+00', '2026-10-26 00:31:32.561819+00', 1, 'remote', NULL);


--
-- Data for Name: channel_sharing_receivers; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.channel_sharing_receivers (id, merchant_id, channel_id, external_no, provider, app_id, product, account_hash, input_hash, relation_account_hash, relation_hash, relation_auth_hash, receiver_cipher, state, last_operation_id, created_at) VALUES (1, 751, 7, 'payment-receiver', 'wxpay', 'local-app', 'wxpay_v3_direct', '\x11c591317bd86aa590e4a6f961629b432a2da6a2f5cc6795bce4d0d88d9ab2ab', '\x0fd0e24de1d18d4eadcc41bd3571092849ea6565ca5c0875cce69a183928c175', '\x75af8d8e7b5d5c05f522ba9392701df68baa72b071b153f885acfc84bc5785e1', '\xc8f788535257f20c60c4ac1a5417fd76ae6ae09f06281e7538f8007fef4e89b0', '\xc8f788535257f20c60c4ac1a5417fd76ae6ae09f06281e7538f8007fef4e89b0', '\x69495794143093c1f1e73205a0f155aab407d2100906a02050f1c5ced6282f3bc56023f6033630669d1c4214e899d8cbef8d51a716d690eb0c32840c499beee812df9ad1475958936b4288076bf46cdd9409fc4c21a6ae1810a937d7bf99cd98f9c935a1bc1a58dfe50b7468e8fff65816de9eb3eb1f22fd2ef1ba14d9d92d750d6ea77c9bee331f8a616d00ec4a544cec33c6ea81eebedf2cedeb3b0b81', 'bound', 1, '2026-10-26 00:31:32.527042+00');


--
-- Data for Name: channel_sharing_relation_leases; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.channel_sharing_relation_leases (id, relation_id, receiver_id, bind_operation_id, released_by_operation_id, created_at, released_at) VALUES (1, 1, 1, 1, NULL, '2026-10-26 00:31:32.619065+00', NULL);


--
-- Data for Name: channel_sharing_relations; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.channel_sharing_relations (id, relation_hash, relation_auth_hash, source_receiver_id, state, last_operation_id, bound_operation_id, created_at) VALUES (1, '\xc8f788535257f20c60c4ac1a5417fd76ae6ae09f06281e7538f8007fef4e89b0', '\xc8f788535257f20c60c4ac1a5417fd76ae6ae09f06281e7538f8007fef4e89b0', 1, 'bound', 1, 1, '2026-10-26 00:31:32.549332+00');


--
-- Data for Name: channel_sharing_return_observations; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: channel_sharing_returns; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: channel_sharing_rule_current; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.channel_sharing_rule_current (merchant_id, channel_id, rule_id) VALUES (751, 7, 1);


--
-- Data for Name: channel_sharing_rule_items; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.channel_sharing_rule_items (rule_id, "position", receiver_id, mode, rate_bps, fixed_amount) VALUES (1, 1, 1, 'rate', 2000, 0);


--
-- Data for Name: channel_sharing_rules; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.channel_sharing_rules (id, merchant_id, channel_id, revision, provider, app_id, product, account_hash, input_hash, enabled, minimum_amount, methods, refund_mode, auto_finish, receiver_count, created_at) VALUES (1, 751, 7, 1, 'wxpay', 'local-app', 'wxpay_v3_direct', '\x11c591317bd86aa590e4a6f961629b432a2da6a2f5cc6795bce4d0d88d9ab2ab', '\x629c3d09595adabc5c4a6ac0917b48e096f88a7c320322c45398903d82e9ad5f', true, 0, '["native"]', 'merchant_funded', true, 1, '2026-10-26 00:31:32.6499+00');


--
-- Data for Name: channel_stop_events; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: channel_stop_heads; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: channel_stop_notice_claims; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: console_login_audit; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: console_login_throttle; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: console_mfa; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: console_session_issuers; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: console_sessions; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: console_sso_grants; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: console_users; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: deposit_action_events; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: deposit_actions; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: enrollment_challenges; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: enrollment_emails; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: enrollment_invitation_uses; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: enrollment_limits; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: identity_lookup_events; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: identity_lookup_requests; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: identity_lookup_states; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: inbox; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.inbox (provider, event_id, order_id, created_at) VALUES ('payment', 'old-paid78', 1, '2026-10-26 00:31:32.807281+00');


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.jobs (id, event_key, kind, payload, state, attempts, max_attempts, run_at, lease_until, lease_token, last_error, created_at) VALUES (1, 'payment-reconcile:1000000000000000000', 'payment.reconcile', '{"trade_no": "1000000000000000000"}', 'pending', 0, 12, '2026-10-26 00:32:02.739184+00', NULL, NULL, '', '2026-10-26 00:31:32.739184+00');
INSERT INTO member72_1c1acaaf36d7e39a.jobs (id, event_key, kind, payload, state, attempts, max_attempts, run_at, lease_until, lease_token, last_error, created_at) VALUES (2, 'receipt-paid:1', 'receipt-print.prepare', '{"order_id": "1"}', 'pending', 0, 12, '2026-10-26 00:31:32.807281+00', NULL, NULL, '', '2026-10-26 00:31:32.807281+00');
INSERT INTO member72_1c1acaaf36d7e39a.jobs (id, event_key, kind, payload, state, attempts, max_attempts, run_at, lease_until, lease_token, last_error, created_at) VALUES (3, 'payment-reconcile:1000000000000000001', 'payment.reconcile', '{"trade_no": "1000000000000000001"}', 'pending', 0, 12, '2026-10-26 00:32:03.026518+00', NULL, NULL, '', '2026-10-26 00:31:33.026518+00');


--
-- Data for Name: journals; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.journals (id, event_key, description, transaction_id, created_at) VALUES (1, 'payment:1000000000000000000', 'payment net credit', '71371', '2026-10-26 00:31:32.807281+00');
INSERT INTO member72_1c1acaaf36d7e39a.journals (id, event_key, description, transaction_id, created_at) VALUES (2, 'channel-sharing:1:reserve', 'original channel sharing payment reserve', '71371', '2026-10-26 00:31:32.807281+00');


--
-- Data for Name: ledger_entries; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.ledger_entries (id, journal_id, account_id, amount, created_at) VALUES (1, 1, 1, -1000, '2026-10-26 00:31:32.807281+00');
INSERT INTO member72_1c1acaaf36d7e39a.ledger_entries (id, journal_id, account_id, amount, created_at) VALUES (2, 1, 6, 1000, '2026-10-26 00:31:32.807281+00');
INSERT INTO member72_1c1acaaf36d7e39a.ledger_entries (id, journal_id, account_id, amount, created_at) VALUES (3, 2, 6, -1000, '2026-10-26 00:31:32.807281+00');
INSERT INTO member72_1c1acaaf36d7e39a.ledger_entries (id, journal_id, account_id, amount, created_at) VALUES (4, 2, 8, 1000, '2026-10-26 00:31:32.807281+00');


--
-- Data for Name: ledger_request_events; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: ledger_requests; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: legacy_import_runs; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: legacy_refund_history; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: legacy_refund_manifests; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: membership_baseline_repairs; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: membership_purchases; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: membership_referral_events; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: membership_referral_legacy_purchases; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: membership_referral_policies; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: membership_referral_policy_audits; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: membership_referral_policy_heads; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: membership_referral_rewards; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: membership_referral_sources; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: memberships; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: merchants; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.merchants (id, name, api_key, rsa_public_key, signature_algorithm, enabled, created_at, profile, config_revision, base_group_id, group_baseline_unresolved) VALUES (751, 'sharing-owner', '\xc4d5bd04930c5aab464817a584094064987ec325272467300613f1b68f434d49ca4a53e5a58a', '', 'MD5', true, '2026-10-26 00:31:30.257195+00', '{}', 1, 0, false);


--
-- Data for Name: mini_oauth_states; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: mini_payment_intents; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: notification_resend_requests; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: notification_send_controls; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: oauth_authorization_code_claims; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: oauth_code_claims; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: oauth_payment_intents; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: oauth_states; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: operation_audit; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: order_income_hold_events; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: order_income_hold_fundings; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: order_income_hold_releases; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: order_income_holds; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: order_print_origins; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.order_print_origins (order_id, kind, collection_code_id, proof_hash) VALUES (1, 'api', NULL, '\x10fd539e43e1e32612416cbbe93ca8e54c56f704c869094719cb1bc8d0a118c4');
INSERT INTO member72_1c1acaaf36d7e39a.order_print_origins (order_id, kind, collection_code_id, proof_hash) VALUES (2, 'api', NULL, '\x2c015330fa73e1f3efdb7308f059a060d60d223108f935dbd4928f39304d1b7c');


--
-- Data for Name: order_profit_allocations; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: order_reporting; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: orders; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.orders (id, trade_no, merchant_id, out_trade_no, name, type, amount, version, notify_url, return_url, param, status, provider_event_id, paid_at, created_at, fee_policy, fee_rate_bps, fee_group_id, merchant_amount, platform_fee, refund_fee_payer, referral_source_version, referral_source_hash) VALUES (1, '1000000000000000000', 751, 'old-positive78', 'local78', 'wxpay', 1000, 'v1', '', '', '', 'paid', 'old-paid78', '2026-10-26 00:31:32.873242+00', '2026-10-26 00:31:32.662067+00', 'none', 0, 0, 1000, 0, 'platform', 3, '\xa4a37d441c20076971485bde5826fe7a1e4c0d239f9df0154424fc4ef3bba570');
INSERT INTO member72_1c1acaaf36d7e39a.orders (id, trade_no, merchant_id, out_trade_no, name, type, amount, version, notify_url, return_url, param, status, provider_event_id, paid_at, created_at, fee_policy, fee_rate_bps, fee_group_id, merchant_amount, platform_fee, refund_fee_payer, referral_source_version, referral_source_hash) VALUES (2, '1000000000000000001', 751, 'old-negative78', 'local78', 'wxpay', 123, 'v1', '', '', '', 'submitting', NULL, NULL, '2026-10-26 00:31:33.01109+00', 'none', 0, 0, 123, 0, 'platform', 3, '\x297e44195655038cdb63fdcd5a8a5e45d8ca1f208172364b15bc8a5d755b1b3d');


--
-- Data for Name: outbox; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.outbox (id, event_key, kind, payload, created_at) VALUES (1, 'payment:1000000000000000000', 'payment.paid', '{"trade_no": "1000000000000000000", "merchant_id": 751}', '2026-10-26 00:31:32.807281+00');


--
-- Data for Name: page_template_assets; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: page_template_configs; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: page_template_heads; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.page_template_heads (kind, selected_name, revision, updated_at) VALUES ('home', 'default', 0, '2026-10-26 00:31:29.612233+00');
INSERT INTO member72_1c1acaaf36d7e39a.page_template_heads (kind, selected_name, revision, updated_at) VALUES ('pay', 'default', 0, '2026-10-26 00:31:29.612233+00');
INSERT INTO member72_1c1acaaf36d7e39a.page_template_heads (kind, selected_name, revision, updated_at) VALUES ('qrpay', 'default', 0, '2026-10-26 00:31:29.612233+00');


--
-- Data for Name: payment_authorization_releases; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: payment_authorizations; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: payment_print_sources; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.payment_print_sources (order_id, merchant_id, body, proof_hash, created_at) VALUES (1, 751, '{"mode": 0, "name": "local78", "type": "wxpay", "fresh": true, "amount": "1000", "origin": "api", "remark": "", "paid_at": "2026-10-26T00:31:32.873242Z", "order_id": "1", "trade_no": "1000000000000000000", "channel_id": "7", "merchant_id": "751", "platform_fee": "0", "snapshot_state": "captured", "merchant_amount": "1000", "platform_enabled": false, "provider_trade_no": "OLD_TX78", "collection_code_id": "0", "merchant_config_id": "0", "platform_config_id": "0"}', '\xc18a1489a3166d0c2dd4a9a18281a8f65e17de5a7030beaddb5e419b71e65e32', '2026-10-26 00:31:32.807281+00');


--
-- Data for Name: preauth_observation_events; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: preauth_observations; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: printing_claims; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: printing_intents; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: printing_merchant_configs; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: printing_merchant_heads; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: printing_platform_configs; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: printing_platform_head; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: printing_recoveries; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: printing_results; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: profile_identity_link_events; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: profile_identity_links; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: profile_identity_lookup_events; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: profile_identity_lookup_requests; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: provider_attempt_accounts; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.provider_attempt_accounts (attempt_id, account_hash, created_at, recovery_version, recovery_source_hash) VALUES (1, '\xd590505b8481f9d1fd709f09c2a1014003760a029f2c267f97e271a219a8d32f', '2026-10-26 00:31:32.760392+00', 0, NULL);
INSERT INTO member72_1c1acaaf36d7e39a.provider_attempt_accounts (attempt_id, account_hash, created_at, recovery_version, recovery_source_hash) VALUES (2, '\xbc059cc6df26fe679e72dbeab2d867f665118a65434f345b1e93a956f5192e0d', '2026-10-26 00:31:33.041061+00', 1, '\x6d278a01a323a9c246356dac9c728e493c98c90e52519033ac84165a7cfe8de1');


--
-- Data for Name: provider_attempt_identities; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.provider_attempt_identities (attempt_id, request_hash, created_at) VALUES (1, '\x833803479ac975110ec2f9f880bbaf0b08abdb8827c8e12006e6e6bb5d78f108', '2026-10-26 00:31:32.739184+00');
INSERT INTO member72_1c1acaaf36d7e39a.provider_attempt_identities (attempt_id, request_hash, created_at) VALUES (2, '\x4115f5d5d5d553c3b77bc0d44d62fb5c2065cc7a3bf4125c0441ff4fea548d99', '2026-10-26 00:31:33.026518+00');


--
-- Data for Name: provider_attempt_sharing; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.provider_attempt_sharing (attempt_id, order_id, merchant_id, channel_id, method, provider, app_id, product, account_hash, request_hash, rule_id, declared, gross_amount, merchant_net, refund_mode, auto_finish, receiver_count, created_at, purpose) VALUES (1, 1, 751, 7, 'native', 'wxpay', 'local-app', 'wxpay_v3_direct', '\x11c591317bd86aa590e4a6f961629b432a2da6a2f5cc6795bce4d0d88d9ab2ab', '\x79f036da384f846eae2d4d3f31f79329b04ff81fe64f52394cdfb144aa06c9d8', 1, true, 1000, 1000, 'merchant_funded', true, 1, '2026-10-26 00:31:32.768643+00', 'payment');
INSERT INTO member72_1c1acaaf36d7e39a.provider_attempt_sharing (attempt_id, order_id, merchant_id, channel_id, method, provider, app_id, product, account_hash, request_hash, rule_id, declared, gross_amount, merchant_net, refund_mode, auto_finish, receiver_count, created_at, purpose) VALUES (2, 2, 751, 7, 'scan', 'wxpay', 'local-app', '', '\x2d20705b7d27e2df75e882b368dbb3e85aec34c84f9c97a3792d450d0ee801de', '\x14923d23aa896d8f533e4b7d79f7c1112ca27030234fe6d9212f3e3efacffe6c', 1, false, 123, 123, '', false, 0, '2026-10-26 00:31:33.047257+00', 'payment');


--
-- Data for Name: provider_attempt_sharing_items; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.provider_attempt_sharing_items (attempt_id, "position", receiver_id, amount) VALUES (1, 1, 1, 200);


--
-- Data for Name: provider_attempts; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.provider_attempts (id, order_id, channel_id, method, state, material_type, material, provider_trade_no, created_at, updated_at) VALUES (1, 1, 7, 'native', 'pending', 'qrcode', 'weixin://wxpay/bizpayurl?pr=local-pg-sharing', '', '2026-10-26 00:31:32.739184+00', '2026-10-26 00:31:32.793778+00');
INSERT INTO member72_1c1acaaf36d7e39a.provider_attempts (id, order_id, channel_id, method, state, material_type, material, provider_trade_no, created_at, updated_at) VALUES (2, 2, 7, 'scan', 'processing', '', '', '', '2026-10-26 00:31:33.026518+00', '2026-10-26 00:31:33.026518+00');


--
-- Data for Name: provider_operations; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: provider_reconciliations; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: provider_refund_result_evidence; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: provider_route_assignments; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: provider_route_counters; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: provider_subject_snapshots; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: provider_transfer_accounts; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: provider_transfer_attempts; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: provider_transfer_policies; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: provider_transfer_proofs; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: recharge_intents; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: referral_clawback_audits; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: referral_daily_awards; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: referral_daily_events; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: referral_daily_liabilities; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: referral_daily_refund_reservations; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: referral_daily_terms; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: referral_order_terms; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.referral_order_terms (order_id, merchant_id, relation_id, promoter_id, purpose, enabled, reason, rate_bps, platform_fee, reward_amount, refund_policy, policy_versions, proof_hash, created_at) VALUES (1, 751, NULL, NULL, 'payment', false, 'no_relation', 0, 0, 0, 'any_successful_refund_voids_reward', '[0, 0, 0, 0, 0]', '\xded986149bae55b7bc6811a13895f95a8be54b14b5cecf705a50bab8d447be8f', '2026-10-26 00:31:32.662067+00');
INSERT INTO member72_1c1acaaf36d7e39a.referral_order_terms (order_id, merchant_id, relation_id, promoter_id, purpose, enabled, reason, rate_bps, platform_fee, reward_amount, refund_policy, policy_versions, proof_hash, created_at) VALUES (2, 751, NULL, NULL, 'payment', false, 'no_relation', 0, 0, 0, 'any_successful_refund_voids_reward', '[0, 0, 0, 0, 0]', '\x235e3f99af7c84f06c378117783cd657bfa0eaf2a9d3e3cd81002dfc38cc4499', '2026-10-26 00:31:33.01109+00');


--
-- Data for Name: referral_policies; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: referral_policy_audits; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: referral_policy_heads; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: referral_profit_cost_events; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: referral_profit_costs; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: referral_refund_clawbacks; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: referral_relations; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: referral_reward_audits; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: referral_rewards; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: referral_token_current; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: referral_tokens; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: refund_funding_resolutions; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: refund_fundings; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: refunds; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: scan_cancellation_claims; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: scan_cancellation_results; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: scan_recovery_eligibility; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: scan_recovery_origins; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.scan_recovery_origins (attempt_id, order_id, merchant_id, channel_id, trade_no, provider, amount, request_identity_hash, account_scope_hash, policy, minimum_wait_seconds, query_interval_seconds, maximum_queries, created_at, expires_at, transaction_id, proof_hash) VALUES (2, 2, 751, 7, '1000000000000000001', 'wxpay', 123, '\x4115f5d5d5d553c3b77bc0d44d62fb5c2065cc7a3bf4125c0441ff4fea548d99', '\xd6a08820e2d249c20979c2700294a49e21349fab26689e5e67bfa17cc245f4e2', 'original-barcode-v1', 15, 3, 6, '2026-10-26 00:31:33.037522+00', '2026-10-26 00:33:33.037522+00', '71380', '\x6d278a01a323a9c246356dac9c728e493c98c90e52519033ac84165a7cfe8de1');


--
-- Data for Name: scan_recovery_query_events; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: scan_recovery_query_heads; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_auto_authorizations; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_auto_claims; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_auto_heads; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_auto_revocations; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_bank_payouts; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_fundings; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_payout_cancellations; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_payout_events; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_payouts; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_plan_authorizations; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_plan_budget_uses; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_plan_items; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_plan_revocations; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_plan_runs; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_plan_versions; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_plans; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_recipient_configs; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_recipient_current; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_recipients; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_request_terms; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_schedule_preference_heads; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_schedule_preferences; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_scheduled_intents; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_threshold_intents; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: settlement_threshold_selections; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: transfer_batch_events; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: transfer_batch_execution_claims; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: transfer_batch_executions; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: transfer_batch_items; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: transfer_batches; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: transfer_unsent_cancellations; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: transfers; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--



--
-- Data for Name: verified_payment_receipts; Type: TABLE DATA; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

INSERT INTO member72_1c1acaaf36d7e39a.verified_payment_receipts (order_id, channel_id, provider_trade_no, created_at) VALUES (1, 7, 'OLD_TX78', '2026-10-26 00:31:32.807281+00');


--
-- Name: accounts_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.accounts_id_seq', 8, true);


--
-- Name: admin_funds_audit_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.admin_funds_audit_id_seq', 1, false);


--
-- Name: alipay_bank_observations_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.alipay_bank_observations_id_seq', 1, false);


--
-- Name: application_authorization_events_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.application_authorization_events_id_seq', 1, false);


--
-- Name: authorization_remaining_sources_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.authorization_remaining_sources_id_seq', 1, false);


--
-- Name: backoffice_audit_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.backoffice_audit_id_seq', 5, true);


--
-- Name: backoffice_records_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.backoffice_records_id_seq', 1, false);


--
-- Name: bank_transfer_observations_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.bank_transfer_observations_id_seq', 1, false);


--
-- Name: case_comments_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.case_comments_id_seq', 1, false);


--
-- Name: channel_sharing_finish_observations_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.channel_sharing_finish_observations_id_seq', 1, false);


--
-- Name: channel_sharing_finishes_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.channel_sharing_finishes_id_seq', 1, false);


--
-- Name: channel_sharing_observations_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.channel_sharing_observations_id_seq', 1, false);


--
-- Name: channel_sharing_orders_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.channel_sharing_orders_id_seq', 1, false);


--
-- Name: channel_sharing_receiver_operations_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations_id_seq', 1, true);


--
-- Name: channel_sharing_receivers_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.channel_sharing_receivers_id_seq', 1, true);


--
-- Name: channel_sharing_relation_leases_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.channel_sharing_relation_leases_id_seq', 1, true);


--
-- Name: channel_sharing_relations_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.channel_sharing_relations_id_seq', 1, true);


--
-- Name: channel_sharing_return_observations_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.channel_sharing_return_observations_id_seq', 1, false);


--
-- Name: channel_sharing_returns_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.channel_sharing_returns_id_seq', 1, false);


--
-- Name: channel_sharing_rules_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.channel_sharing_rules_id_seq', 1, true);


--
-- Name: channel_stop_events_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.channel_stop_events_id_seq', 1, false);


--
-- Name: console_login_audit_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.console_login_audit_id_seq', 1, false);


--
-- Name: console_subject_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.console_subject_seq', 10000, false);


--
-- Name: console_users_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.console_users_id_seq', 1, false);


--
-- Name: deposit_action_events_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.deposit_action_events_id_seq', 1, false);


--
-- Name: deposit_actions_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.deposit_actions_id_seq', 1, false);


--
-- Name: identity_lookup_events_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.identity_lookup_events_id_seq', 1, false);


--
-- Name: jobs_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.jobs_id_seq', 3, true);


--
-- Name: journals_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.journals_id_seq', 2, true);


--
-- Name: ledger_entries_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.ledger_entries_id_seq', 4, true);


--
-- Name: ledger_request_events_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.ledger_request_events_id_seq', 1, false);


--
-- Name: ledger_requests_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.ledger_requests_id_seq', 1, false);


--
-- Name: legacy_refund_history_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.legacy_refund_history_id_seq', 1, false);


--
-- Name: membership_purchases_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.membership_purchases_id_seq', 1, false);


--
-- Name: membership_referral_events_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.membership_referral_events_id_seq', 1, false);


--
-- Name: membership_referral_policies_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.membership_referral_policies_id_seq', 1, false);


--
-- Name: operation_audit_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.operation_audit_id_seq', 1, false);


--
-- Name: order_income_hold_events_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.order_income_hold_events_id_seq', 1, false);


--
-- Name: order_income_holds_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.order_income_holds_id_seq', 1, false);


--
-- Name: order_profit_allocations_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.order_profit_allocations_id_seq', 1, false);


--
-- Name: orders_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.orders_id_seq', 2, true);


--
-- Name: outbox_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.outbox_id_seq', 1, true);


--
-- Name: preauth_observation_events_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.preauth_observation_events_id_seq', 1, false);


--
-- Name: printing_intents_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.printing_intents_id_seq', 1, false);


--
-- Name: printing_merchant_configs_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.printing_merchant_configs_id_seq', 1, false);


--
-- Name: printing_platform_configs_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.printing_platform_configs_id_seq', 1, false);


--
-- Name: printing_recoveries_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.printing_recoveries_id_seq', 1, false);


--
-- Name: profile_identity_lookup_events_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.profile_identity_lookup_events_id_seq', 1, false);


--
-- Name: provider_attempts_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.provider_attempts_id_seq', 2, true);


--
-- Name: provider_operations_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.provider_operations_id_seq', 1, false);


--
-- Name: provider_reconciliations_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.provider_reconciliations_id_seq', 1, false);


--
-- Name: recharge_intents_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.recharge_intents_id_seq', 1, false);


--
-- Name: referral_daily_events_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.referral_daily_events_id_seq', 1, false);


--
-- Name: referral_policies_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.referral_policies_id_seq', 1, false);


--
-- Name: referral_relations_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.referral_relations_id_seq', 1, false);


--
-- Name: referral_rewards_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.referral_rewards_id_seq', 1, false);


--
-- Name: referral_tokens_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.referral_tokens_id_seq', 1, false);


--
-- Name: refunds_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.refunds_id_seq', 1, false);


--
-- Name: scan_recovery_query_events_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.scan_recovery_query_events_id_seq', 1, false);


--
-- Name: settlement_auto_authorizations_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.settlement_auto_authorizations_id_seq', 1, false);


--
-- Name: settlement_auto_claims_claim_seq_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.settlement_auto_claims_claim_seq_seq', 1, false);


--
-- Name: settlement_payout_events_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.settlement_payout_events_id_seq', 1, false);


--
-- Name: settlement_plan_authorizations_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.settlement_plan_authorizations_id_seq', 1, false);


--
-- Name: settlement_plan_items_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.settlement_plan_items_id_seq', 1, false);


--
-- Name: settlement_plan_runs_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.settlement_plan_runs_id_seq', 1, false);


--
-- Name: settlement_plan_versions_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.settlement_plan_versions_id_seq', 1, false);


--
-- Name: settlement_plans_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.settlement_plans_id_seq', 1, false);


--
-- Name: settlement_recipient_configs_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.settlement_recipient_configs_id_seq', 1, false);


--
-- Name: settlement_schedule_preferences_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.settlement_schedule_preferences_id_seq', 1, false);


--
-- Name: settlement_threshold_selections_source_sequence_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.settlement_threshold_selections_source_sequence_seq', 1, false);


--
-- Name: trade_no_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.trade_no_seq', 1000000000000000001, true);


--
-- Name: transfer_batch_events_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.transfer_batch_events_id_seq', 1, false);


--
-- Name: transfer_batches_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.transfer_batches_id_seq', 1, false);


--
-- Name: transfers_id_seq; Type: SEQUENCE SET; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

SELECT pg_catalog.setval('member72_1c1acaaf36d7e39a.transfers_id_seq', 1, false);


--
-- Name: accounts accounts_owner_kind_scope_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.accounts
    ADD CONSTRAINT accounts_owner_kind_scope_key UNIQUE (owner_id, kind, scope_id);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: admin_funds_audit admin_funds_audit_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.admin_funds_audit
    ADD CONSTRAINT admin_funds_audit_pkey PRIMARY KEY (id);


--
-- Name: admin_funds_challenges admin_funds_challenges_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.admin_funds_challenges
    ADD CONSTRAINT admin_funds_challenges_pkey PRIMARY KEY (challenge_hash);


--
-- Name: admin_funds_credentials admin_funds_credentials_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.admin_funds_credentials
    ADD CONSTRAINT admin_funds_credentials_pkey PRIMARY KEY (username);


--
-- Name: admin_funds_grants admin_funds_grants_challenge_hash_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.admin_funds_grants
    ADD CONSTRAINT admin_funds_grants_challenge_hash_key UNIQUE (challenge_hash);


--
-- Name: admin_funds_grants admin_funds_grants_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.admin_funds_grants
    ADD CONSTRAINT admin_funds_grants_pkey PRIMARY KEY (grant_hash);


--
-- Name: admin_funds_throttle admin_funds_throttle_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.admin_funds_throttle
    ADD CONSTRAINT admin_funds_throttle_pkey PRIMARY KEY (key_hash);


--
-- Name: alipay_bank_bindings alipay_bank_bindings_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.alipay_bank_bindings
    ADD CONSTRAINT alipay_bank_bindings_pkey PRIMARY KEY (transfer_id);


--
-- Name: alipay_bank_observations alipay_bank_observations_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.alipay_bank_observations
    ADD CONSTRAINT alipay_bank_observations_pkey PRIMARY KEY (id);


--
-- Name: application_authorization_code_claims application_authorization_code_claims_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.application_authorization_code_claims
    ADD CONSTRAINT application_authorization_code_claims_pkey PRIMARY KEY (issuer_app_id, code_hash);


--
-- Name: application_authorization_code_claims application_authorization_code_claims_request_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.application_authorization_code_claims
    ADD CONSTRAINT application_authorization_code_claims_request_id_key UNIQUE (request_id);


--
-- Name: application_authorization_events application_authorization_events_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.application_authorization_events
    ADD CONSTRAINT application_authorization_events_pkey PRIMARY KEY (id);


--
-- Name: application_authorization_events application_authorization_events_request_id_operation_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.application_authorization_events
    ADD CONSTRAINT application_authorization_events_request_id_operation_key UNIQUE (request_id, operation);


--
-- Name: application_authorization_requests application_authorization_requests_authorization_hash_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.application_authorization_requests
    ADD CONSTRAINT application_authorization_requests_authorization_hash_key UNIQUE (authorization_hash);


--
-- Name: application_authorization_requests application_authorization_requests_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.application_authorization_requests
    ADD CONSTRAINT application_authorization_requests_pkey PRIMARY KEY (id);


--
-- Name: application_authorization_requests application_authorization_requests_state_hash_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.application_authorization_requests
    ADD CONSTRAINT application_authorization_requests_state_hash_key UNIQUE (state_hash);


--
-- Name: authorization_remaining_claims authorization_remaining_claims_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.authorization_remaining_claims
    ADD CONSTRAINT authorization_remaining_claims_pkey PRIMARY KEY (order_id);


--
-- Name: authorization_remaining_claims authorization_remaining_claims_source_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.authorization_remaining_claims
    ADD CONSTRAINT authorization_remaining_claims_source_id_key UNIQUE (source_id);


--
-- Name: authorization_remaining_sources authorization_remaining_sources_id_order_id_revision_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.authorization_remaining_sources
    ADD CONSTRAINT authorization_remaining_sources_id_order_id_revision_key UNIQUE (id, order_id, revision);


--
-- Name: authorization_remaining_sources authorization_remaining_sources_order_id_revision_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.authorization_remaining_sources
    ADD CONSTRAINT authorization_remaining_sources_order_id_revision_key UNIQUE (order_id, revision);


--
-- Name: authorization_remaining_sources authorization_remaining_sources_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.authorization_remaining_sources
    ADD CONSTRAINT authorization_remaining_sources_pkey PRIMARY KEY (id);


--
-- Name: backoffice_audit backoffice_audit_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.backoffice_audit
    ADD CONSTRAINT backoffice_audit_pkey PRIMARY KEY (id);


--
-- Name: backoffice_records backoffice_records_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.backoffice_records
    ADD CONSTRAINT backoffice_records_pkey PRIMARY KEY (id);


--
-- Name: bank_transfer_lifecycle bank_transfer_lifecycle_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.bank_transfer_lifecycle
    ADD CONSTRAINT bank_transfer_lifecycle_pkey PRIMARY KEY (transfer_id);


--
-- Name: bank_transfer_observations bank_transfer_observations_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.bank_transfer_observations
    ADD CONSTRAINT bank_transfer_observations_pkey PRIMARY KEY (id);


--
-- Name: case_comments case_comments_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.case_comments
    ADD CONSTRAINT case_comments_pkey PRIMARY KEY (id);


--
-- Name: channel_sharing_completions channel_sharing_completions_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_completions
    ADD CONSTRAINT channel_sharing_completions_pkey PRIMARY KEY (order_id);


--
-- Name: channel_sharing_completions channel_sharing_completions_release_journal_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_completions
    ADD CONSTRAINT channel_sharing_completions_release_journal_id_key UNIQUE (release_journal_id);


--
-- Name: channel_sharing_completions channel_sharing_completions_sharing_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_completions
    ADD CONSTRAINT channel_sharing_completions_sharing_id_key UNIQUE (sharing_id);


--
-- Name: channel_sharing_finish_observations channel_sharing_finish_observations_finish_id_fingerprint_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_finish_observations
    ADD CONSTRAINT channel_sharing_finish_observations_finish_id_fingerprint_key UNIQUE (finish_id, fingerprint);


--
-- Name: channel_sharing_finish_observations channel_sharing_finish_observations_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_finish_observations
    ADD CONSTRAINT channel_sharing_finish_observations_pkey PRIMARY KEY (id);


--
-- Name: channel_sharing_finishes channel_sharing_finishes_merchant_id_external_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_finishes
    ADD CONSTRAINT channel_sharing_finishes_merchant_id_external_no_key UNIQUE (merchant_id, external_no);


--
-- Name: channel_sharing_finishes channel_sharing_finishes_out_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_finishes
    ADD CONSTRAINT channel_sharing_finishes_out_no_key UNIQUE (out_no);


--
-- Name: channel_sharing_finishes channel_sharing_finishes_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_finishes
    ADD CONSTRAINT channel_sharing_finishes_pkey PRIMARY KEY (id);


--
-- Name: channel_sharing_finishes channel_sharing_finishes_release_journal_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_finishes
    ADD CONSTRAINT channel_sharing_finishes_release_journal_id_key UNIQUE (release_journal_id);


--
-- Name: channel_sharing_fundings channel_sharing_fundings_account_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_fundings
    ADD CONSTRAINT channel_sharing_fundings_account_id_key UNIQUE (account_id);


--
-- Name: channel_sharing_fundings channel_sharing_fundings_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_fundings
    ADD CONSTRAINT channel_sharing_fundings_pkey PRIMARY KEY (order_id);


--
-- Name: channel_sharing_fundings channel_sharing_fundings_reserve_journal_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_fundings
    ADD CONSTRAINT channel_sharing_fundings_reserve_journal_id_key UNIQUE (reserve_journal_id);


--
-- Name: channel_sharing_observations channel_sharing_observations_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_observations
    ADD CONSTRAINT channel_sharing_observations_pkey PRIMARY KEY (id);


--
-- Name: channel_sharing_observations channel_sharing_observations_sharing_id_fingerprint_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_observations
    ADD CONSTRAINT channel_sharing_observations_sharing_id_fingerprint_key UNIQUE (sharing_id, fingerprint);


--
-- Name: channel_sharing_order_items channel_sharing_order_items_paid_journal_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_order_items
    ADD CONSTRAINT channel_sharing_order_items_paid_journal_id_key UNIQUE (paid_journal_id);


--
-- Name: channel_sharing_order_items channel_sharing_order_items_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_order_items
    ADD CONSTRAINT channel_sharing_order_items_pkey PRIMARY KEY (sharing_id, receiver_id);


--
-- Name: channel_sharing_order_items channel_sharing_order_items_sharing_id_position_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_order_items
    ADD CONSTRAINT channel_sharing_order_items_sharing_id_position_key UNIQUE (sharing_id, "position");


--
-- Name: channel_sharing_orders channel_sharing_orders_merchant_id_external_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_orders
    ADD CONSTRAINT channel_sharing_orders_merchant_id_external_no_key UNIQUE (merchant_id, external_no);


--
-- Name: channel_sharing_orders channel_sharing_orders_order_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_orders
    ADD CONSTRAINT channel_sharing_orders_order_id_key UNIQUE (order_id);


--
-- Name: channel_sharing_orders channel_sharing_orders_out_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_orders
    ADD CONSTRAINT channel_sharing_orders_out_no_key UNIQUE (out_no);


--
-- Name: channel_sharing_orders channel_sharing_orders_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_orders
    ADD CONSTRAINT channel_sharing_orders_pkey PRIMARY KEY (id);


--
-- Name: channel_sharing_receiver_operations channel_sharing_receiver_operations_out_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations
    ADD CONSTRAINT channel_sharing_receiver_operations_out_no_key UNIQUE (out_no);


--
-- Name: channel_sharing_receiver_operations channel_sharing_receiver_operations_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations
    ADD CONSTRAINT channel_sharing_receiver_operations_pkey PRIMARY KEY (id);


--
-- Name: channel_sharing_receiver_operations channel_sharing_receiver_operations_receiver_id_external_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations
    ADD CONSTRAINT channel_sharing_receiver_operations_receiver_id_external_no_key UNIQUE (receiver_id, external_no);


--
-- Name: channel_sharing_receivers channel_sharing_receivers_merchant_id_external_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_receivers
    ADD CONSTRAINT channel_sharing_receivers_merchant_id_external_no_key UNIQUE (merchant_id, external_no);


--
-- Name: channel_sharing_receivers channel_sharing_receivers_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_receivers
    ADD CONSTRAINT channel_sharing_receivers_pkey PRIMARY KEY (id);


--
-- Name: channel_sharing_relation_leases channel_sharing_relation_leases_bind_operation_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_relation_leases
    ADD CONSTRAINT channel_sharing_relation_leases_bind_operation_id_key UNIQUE (bind_operation_id);


--
-- Name: channel_sharing_relation_leases channel_sharing_relation_leases_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_relation_leases
    ADD CONSTRAINT channel_sharing_relation_leases_pkey PRIMARY KEY (id);


--
-- Name: channel_sharing_relation_leases channel_sharing_relation_leases_released_by_operation_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_relation_leases
    ADD CONSTRAINT channel_sharing_relation_leases_released_by_operation_id_key UNIQUE (released_by_operation_id);


--
-- Name: channel_sharing_relations channel_sharing_relations_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_relations
    ADD CONSTRAINT channel_sharing_relations_pkey PRIMARY KEY (id);


--
-- Name: channel_sharing_relations channel_sharing_relations_relation_hash_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_relations
    ADD CONSTRAINT channel_sharing_relations_relation_hash_key UNIQUE (relation_hash);


--
-- Name: channel_sharing_return_observations channel_sharing_return_observations_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_return_observations
    ADD CONSTRAINT channel_sharing_return_observations_pkey PRIMARY KEY (id);


--
-- Name: channel_sharing_return_observations channel_sharing_return_observations_return_id_fingerprint_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_return_observations
    ADD CONSTRAINT channel_sharing_return_observations_return_id_fingerprint_key UNIQUE (return_id, fingerprint);


--
-- Name: channel_sharing_returns channel_sharing_returns_merchant_id_external_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_returns
    ADD CONSTRAINT channel_sharing_returns_merchant_id_external_no_key UNIQUE (merchant_id, external_no);


--
-- Name: channel_sharing_returns channel_sharing_returns_out_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_returns
    ADD CONSTRAINT channel_sharing_returns_out_no_key UNIQUE (out_no);


--
-- Name: channel_sharing_returns channel_sharing_returns_paid_journal_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_returns
    ADD CONSTRAINT channel_sharing_returns_paid_journal_id_key UNIQUE (paid_journal_id);


--
-- Name: channel_sharing_returns channel_sharing_returns_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_returns
    ADD CONSTRAINT channel_sharing_returns_pkey PRIMARY KEY (id);


--
-- Name: channel_sharing_rule_current channel_sharing_rule_current_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_rule_current
    ADD CONSTRAINT channel_sharing_rule_current_pkey PRIMARY KEY (merchant_id, channel_id);


--
-- Name: channel_sharing_rule_current channel_sharing_rule_current_rule_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_rule_current
    ADD CONSTRAINT channel_sharing_rule_current_rule_id_key UNIQUE (rule_id);


--
-- Name: channel_sharing_rule_items channel_sharing_rule_items_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_rule_items
    ADD CONSTRAINT channel_sharing_rule_items_pkey PRIMARY KEY (rule_id, "position");


--
-- Name: channel_sharing_rule_items channel_sharing_rule_items_rule_id_receiver_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_rule_items
    ADD CONSTRAINT channel_sharing_rule_items_rule_id_receiver_id_key UNIQUE (rule_id, receiver_id);


--
-- Name: channel_sharing_rules channel_sharing_rules_merchant_id_channel_id_revision_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_rules
    ADD CONSTRAINT channel_sharing_rules_merchant_id_channel_id_revision_key UNIQUE (merchant_id, channel_id, revision);


--
-- Name: channel_sharing_rules channel_sharing_rules_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_rules
    ADD CONSTRAINT channel_sharing_rules_pkey PRIMARY KEY (id);


--
-- Name: channel_stop_events channel_stop_events_channel_id_revision_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_stop_events
    ADD CONSTRAINT channel_stop_events_channel_id_revision_key UNIQUE (channel_id, revision);


--
-- Name: channel_stop_events channel_stop_events_id_channel_id_revision_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_stop_events
    ADD CONSTRAINT channel_stop_events_id_channel_id_revision_key UNIQUE (id, channel_id, revision);


--
-- Name: channel_stop_events channel_stop_events_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_stop_events
    ADD CONSTRAINT channel_stop_events_pkey PRIMARY KEY (id);


--
-- Name: channel_stop_heads channel_stop_heads_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_stop_heads
    ADD CONSTRAINT channel_stop_heads_pkey PRIMARY KEY (channel_id);


--
-- Name: channel_stop_notice_claims channel_stop_notice_claims_job_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_stop_notice_claims
    ADD CONSTRAINT channel_stop_notice_claims_job_id_key UNIQUE (job_id);


--
-- Name: channel_stop_notice_claims channel_stop_notice_claims_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_stop_notice_claims
    ADD CONSTRAINT channel_stop_notice_claims_pkey PRIMARY KEY (event_id);


--
-- Name: console_login_audit console_login_audit_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.console_login_audit
    ADD CONSTRAINT console_login_audit_pkey PRIMARY KEY (id);


--
-- Name: console_login_throttle console_login_throttle_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.console_login_throttle
    ADD CONSTRAINT console_login_throttle_pkey PRIMARY KEY (key_hash);


--
-- Name: console_mfa console_mfa_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.console_mfa
    ADD CONSTRAINT console_mfa_pkey PRIMARY KEY (username, role);


--
-- Name: console_session_issuers console_session_issuers_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.console_session_issuers
    ADD CONSTRAINT console_session_issuers_pkey PRIMARY KEY (token_hash);


--
-- Name: console_sessions console_sessions_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.console_sessions
    ADD CONSTRAINT console_sessions_pkey PRIMARY KEY (token_hash);


--
-- Name: console_sso_grants console_sso_grants_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.console_sso_grants
    ADD CONSTRAINT console_sso_grants_pkey PRIMARY KEY (grant_hash);


--
-- Name: console_users console_users_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.console_users
    ADD CONSTRAINT console_users_id_key UNIQUE (id);


--
-- Name: console_users console_users_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.console_users
    ADD CONSTRAINT console_users_pkey PRIMARY KEY (username, role);


--
-- Name: deposit_action_events deposit_action_events_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.deposit_action_events
    ADD CONSTRAINT deposit_action_events_pkey PRIMARY KEY (id);


--
-- Name: deposit_actions deposit_actions_merchant_id_external_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.deposit_actions
    ADD CONSTRAINT deposit_actions_merchant_id_external_no_key UNIQUE (merchant_id, external_no);


--
-- Name: deposit_actions deposit_actions_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.deposit_actions
    ADD CONSTRAINT deposit_actions_pkey PRIMARY KEY (id);


--
-- Name: enrollment_challenges enrollment_challenges_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.enrollment_challenges
    ADD CONSTRAINT enrollment_challenges_pkey PRIMARY KEY (id);


--
-- Name: enrollment_emails enrollment_emails_email_hash_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.enrollment_emails
    ADD CONSTRAINT enrollment_emails_email_hash_key UNIQUE (email_hash);


--
-- Name: enrollment_emails enrollment_emails_merchant_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.enrollment_emails
    ADD CONSTRAINT enrollment_emails_merchant_id_key UNIQUE (merchant_id);


--
-- Name: enrollment_emails enrollment_emails_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.enrollment_emails
    ADD CONSTRAINT enrollment_emails_pkey PRIMARY KEY (email);


--
-- Name: enrollment_invitation_uses enrollment_invitation_uses_merchant_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.enrollment_invitation_uses
    ADD CONSTRAINT enrollment_invitation_uses_merchant_id_key UNIQUE (merchant_id);


--
-- Name: enrollment_invitation_uses enrollment_invitation_uses_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.enrollment_invitation_uses
    ADD CONSTRAINT enrollment_invitation_uses_pkey PRIMARY KEY (invitation_id, merchant_id);


--
-- Name: enrollment_limits enrollment_limits_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.enrollment_limits
    ADD CONSTRAINT enrollment_limits_pkey PRIMARY KEY (key_hash);


--
-- Name: identity_lookup_events identity_lookup_events_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.identity_lookup_events
    ADD CONSTRAINT identity_lookup_events_pkey PRIMARY KEY (id);


--
-- Name: identity_lookup_events identity_lookup_events_request_id_operation_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.identity_lookup_events
    ADD CONSTRAINT identity_lookup_events_request_id_operation_key UNIQUE (request_id, operation);


--
-- Name: identity_lookup_requests identity_lookup_requests_authorization_hash_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.identity_lookup_requests
    ADD CONSTRAINT identity_lookup_requests_authorization_hash_key UNIQUE (authorization_hash);


--
-- Name: identity_lookup_requests identity_lookup_requests_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.identity_lookup_requests
    ADD CONSTRAINT identity_lookup_requests_pkey PRIMARY KEY (id);


--
-- Name: identity_lookup_states identity_lookup_states_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.identity_lookup_states
    ADD CONSTRAINT identity_lookup_states_pkey PRIMARY KEY (state_hash);


--
-- Name: identity_lookup_states identity_lookup_states_request_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.identity_lookup_states
    ADD CONSTRAINT identity_lookup_states_request_id_key UNIQUE (request_id);


--
-- Name: inbox inbox_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.inbox
    ADD CONSTRAINT inbox_pkey PRIMARY KEY (provider, event_id);


--
-- Name: jobs jobs_event_key_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.jobs
    ADD CONSTRAINT jobs_event_key_key UNIQUE (event_key);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: journals journals_event_key_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.journals
    ADD CONSTRAINT journals_event_key_key UNIQUE (event_key);


--
-- Name: journals journals_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.journals
    ADD CONSTRAINT journals_pkey PRIMARY KEY (id);


--
-- Name: ledger_entries ledger_entries_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.ledger_entries
    ADD CONSTRAINT ledger_entries_pkey PRIMARY KEY (id);


--
-- Name: ledger_request_events ledger_request_events_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.ledger_request_events
    ADD CONSTRAINT ledger_request_events_pkey PRIMARY KEY (id);


--
-- Name: ledger_requests ledger_requests_kind_merchant_id_external_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.ledger_requests
    ADD CONSTRAINT ledger_requests_kind_merchant_id_external_no_key UNIQUE (kind, merchant_id, external_no);


--
-- Name: ledger_requests ledger_requests_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.ledger_requests
    ADD CONSTRAINT ledger_requests_pkey PRIMARY KEY (id);


--
-- Name: ledger_requests ledger_requests_settlement_plan_item_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.ledger_requests
    ADD CONSTRAINT ledger_requests_settlement_plan_item_id_key UNIQUE (settlement_plan_item_id);


--
-- Name: legacy_import_runs legacy_import_runs_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.legacy_import_runs
    ADD CONSTRAINT legacy_import_runs_pkey PRIMARY KEY (export_id);


--
-- Name: legacy_refund_history legacy_refund_history_merchant_id_refund_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.legacy_refund_history
    ADD CONSTRAINT legacy_refund_history_merchant_id_refund_no_key UNIQUE (merchant_id, refund_no);


--
-- Name: legacy_refund_history legacy_refund_history_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.legacy_refund_history
    ADD CONSTRAINT legacy_refund_history_pkey PRIMARY KEY (id);


--
-- Name: legacy_refund_manifests legacy_refund_manifests_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.legacy_refund_manifests
    ADD CONSTRAINT legacy_refund_manifests_pkey PRIMARY KEY (export_id);


--
-- Name: membership_baseline_repairs membership_baseline_repairs_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_baseline_repairs
    ADD CONSTRAINT membership_baseline_repairs_pkey PRIMARY KEY (merchant_id);


--
-- Name: membership_purchases membership_purchases_merchant_id_external_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_purchases
    ADD CONSTRAINT membership_purchases_merchant_id_external_no_key UNIQUE (merchant_id, external_no);


--
-- Name: membership_purchases membership_purchases_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_purchases
    ADD CONSTRAINT membership_purchases_pkey PRIMARY KEY (id);


--
-- Name: membership_referral_events membership_referral_events_event_key_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_events
    ADD CONSTRAINT membership_referral_events_event_key_key UNIQUE (event_key);


--
-- Name: membership_referral_events membership_referral_events_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_events
    ADD CONSTRAINT membership_referral_events_pkey PRIMARY KEY (id);


--
-- Name: membership_referral_events membership_referral_events_purchase_id_operation_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_events
    ADD CONSTRAINT membership_referral_events_purchase_id_operation_key UNIQUE (purchase_id, operation);


--
-- Name: membership_referral_legacy_purchases membership_referral_legacy_purchases_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_legacy_purchases
    ADD CONSTRAINT membership_referral_legacy_purchases_pkey PRIMARY KEY (purchase_id);


--
-- Name: membership_referral_policies membership_referral_policies_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_policies
    ADD CONSTRAINT membership_referral_policies_pkey PRIMARY KEY (id);


--
-- Name: membership_referral_policies membership_referral_policies_scope_kind_scope_id_revision_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_policies
    ADD CONSTRAINT membership_referral_policies_scope_kind_scope_id_revision_key UNIQUE (scope_kind, scope_id, revision);


--
-- Name: membership_referral_policy_audits membership_referral_policy_audits_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_policy_audits
    ADD CONSTRAINT membership_referral_policy_audits_pkey PRIMARY KEY (policy_id);


--
-- Name: membership_referral_policy_heads membership_referral_policy_heads_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_policy_heads
    ADD CONSTRAINT membership_referral_policy_heads_pkey PRIMARY KEY (scope_kind, scope_id);


--
-- Name: membership_referral_policy_heads membership_referral_policy_heads_policy_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_policy_heads
    ADD CONSTRAINT membership_referral_policy_heads_policy_id_key UNIQUE (policy_id);


--
-- Name: membership_referral_rewards membership_referral_rewards_journal_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_rewards
    ADD CONSTRAINT membership_referral_rewards_journal_id_key UNIQUE (journal_id);


--
-- Name: membership_referral_rewards membership_referral_rewards_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_rewards
    ADD CONSTRAINT membership_referral_rewards_pkey PRIMARY KEY (purchase_id);


--
-- Name: membership_referral_sources membership_referral_sources_income_account_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_sources
    ADD CONSTRAINT membership_referral_sources_income_account_id_key UNIQUE (income_account_id);


--
-- Name: membership_referral_sources membership_referral_sources_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_sources
    ADD CONSTRAINT membership_referral_sources_pkey PRIMARY KEY (purchase_id);


--
-- Name: membership_referral_sources membership_referral_sources_purchase_journal_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_sources
    ADD CONSTRAINT membership_referral_sources_purchase_journal_id_key UNIQUE (purchase_journal_id);


--
-- Name: memberships memberships_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.memberships
    ADD CONSTRAINT memberships_pkey PRIMARY KEY (merchant_id);


--
-- Name: merchants merchants_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.merchants
    ADD CONSTRAINT merchants_pkey PRIMARY KEY (id);


--
-- Name: mini_oauth_states mini_oauth_states_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.mini_oauth_states
    ADD CONSTRAINT mini_oauth_states_pkey PRIMARY KEY (state_hash);


--
-- Name: mini_oauth_states mini_oauth_states_state_hash_provider_app_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.mini_oauth_states
    ADD CONSTRAINT mini_oauth_states_state_hash_provider_app_id_key UNIQUE (state_hash, provider, app_id);


--
-- Name: mini_payment_intents mini_payment_intents_order_id_channel_id_provider_app_id_me_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.mini_payment_intents
    ADD CONSTRAINT mini_payment_intents_order_id_channel_id_provider_app_id_me_key UNIQUE (order_id, channel_id, provider, app_id, method, purpose, path);


--
-- Name: mini_payment_intents mini_payment_intents_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.mini_payment_intents
    ADD CONSTRAINT mini_payment_intents_pkey PRIMARY KEY (order_id);


--
-- Name: notification_resend_requests notification_resend_requests_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.notification_resend_requests
    ADD CONSTRAINT notification_resend_requests_pkey PRIMARY KEY (order_id, request_hash);


--
-- Name: notification_send_controls notification_send_controls_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.notification_send_controls
    ADD CONSTRAINT notification_send_controls_pkey PRIMARY KEY (order_id);


--
-- Name: oauth_authorization_code_claims oauth_authorization_code_claims_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.oauth_authorization_code_claims
    ADD CONSTRAINT oauth_authorization_code_claims_pkey PRIMARY KEY (provider, app_id, domain, code_hash);


--
-- Name: oauth_code_claims oauth_code_claims_mini_state_hash_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.oauth_code_claims
    ADD CONSTRAINT oauth_code_claims_mini_state_hash_key UNIQUE (mini_state_hash);


--
-- Name: oauth_code_claims oauth_code_claims_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.oauth_code_claims
    ADD CONSTRAINT oauth_code_claims_pkey PRIMARY KEY (provider, app_id, code_hash);


--
-- Name: oauth_code_claims oauth_code_claims_state_hash_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.oauth_code_claims
    ADD CONSTRAINT oauth_code_claims_state_hash_key UNIQUE (state_hash);


--
-- Name: oauth_payment_intents oauth_payment_intents_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.oauth_payment_intents
    ADD CONSTRAINT oauth_payment_intents_pkey PRIMARY KEY (order_id);


--
-- Name: oauth_states oauth_states_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.oauth_states
    ADD CONSTRAINT oauth_states_pkey PRIMARY KEY (state_hash);


--
-- Name: operation_audit operation_audit_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.operation_audit
    ADD CONSTRAINT operation_audit_pkey PRIMARY KEY (id);


--
-- Name: order_income_hold_events order_income_hold_events_hold_id_action_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_income_hold_events
    ADD CONSTRAINT order_income_hold_events_hold_id_action_key UNIQUE (hold_id, action);


--
-- Name: order_income_hold_events order_income_hold_events_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_income_hold_events
    ADD CONSTRAINT order_income_hold_events_pkey PRIMARY KEY (id);


--
-- Name: order_income_hold_fundings order_income_hold_fundings_account_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_income_hold_fundings
    ADD CONSTRAINT order_income_hold_fundings_account_id_key UNIQUE (account_id);


--
-- Name: order_income_hold_fundings order_income_hold_fundings_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_income_hold_fundings
    ADD CONSTRAINT order_income_hold_fundings_pkey PRIMARY KEY (hold_id);


--
-- Name: order_income_hold_releases order_income_hold_releases_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_income_hold_releases
    ADD CONSTRAINT order_income_hold_releases_pkey PRIMARY KEY (hold_id);


--
-- Name: order_income_holds order_income_holds_merchant_id_request_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_income_holds
    ADD CONSTRAINT order_income_holds_merchant_id_request_no_key UNIQUE (merchant_id, request_no);


--
-- Name: order_income_holds order_income_holds_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_income_holds
    ADD CONSTRAINT order_income_holds_pkey PRIMARY KEY (id);


--
-- Name: order_print_origins order_print_origins_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_print_origins
    ADD CONSTRAINT order_print_origins_pkey PRIMARY KEY (order_id);


--
-- Name: order_profit_allocations order_profit_allocations_order_id_rule_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_profit_allocations
    ADD CONSTRAINT order_profit_allocations_order_id_rule_id_key UNIQUE (order_id, rule_id);


--
-- Name: order_profit_allocations order_profit_allocations_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_profit_allocations
    ADD CONSTRAINT order_profit_allocations_pkey PRIMARY KEY (id);


--
-- Name: order_profit_allocations order_profit_allocations_request_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_profit_allocations
    ADD CONSTRAINT order_profit_allocations_request_id_key UNIQUE (request_id);


--
-- Name: order_reporting order_reporting_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_reporting
    ADD CONSTRAINT order_reporting_pkey PRIMARY KEY (order_id);


--
-- Name: orders orders_merchant_id_out_trade_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.orders
    ADD CONSTRAINT orders_merchant_id_out_trade_no_key UNIQUE (merchant_id, out_trade_no);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: orders orders_trade_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.orders
    ADD CONSTRAINT orders_trade_no_key UNIQUE (trade_no);


--
-- Name: outbox outbox_event_key_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.outbox
    ADD CONSTRAINT outbox_event_key_key UNIQUE (event_key);


--
-- Name: outbox outbox_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.outbox
    ADD CONSTRAINT outbox_pkey PRIMARY KEY (id);


--
-- Name: page_template_assets page_template_assets_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.page_template_assets
    ADD CONSTRAINT page_template_assets_pkey PRIMARY KEY (id);


--
-- Name: page_template_configs page_template_configs_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.page_template_configs
    ADD CONSTRAINT page_template_configs_pkey PRIMARY KEY (kind, name);


--
-- Name: page_template_heads page_template_heads_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.page_template_heads
    ADD CONSTRAINT page_template_heads_pkey PRIMARY KEY (kind);


--
-- Name: payment_authorization_releases payment_authorization_releases_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.payment_authorization_releases
    ADD CONSTRAINT payment_authorization_releases_pkey PRIMARY KEY (order_id);


--
-- Name: payment_authorization_releases payment_authorization_releases_request_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.payment_authorization_releases
    ADD CONSTRAINT payment_authorization_releases_request_no_key UNIQUE (request_no);


--
-- Name: payment_authorizations payment_authorizations_channel_id_auth_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.payment_authorizations
    ADD CONSTRAINT payment_authorizations_channel_id_auth_no_key UNIQUE (channel_id, auth_no);


--
-- Name: payment_authorizations payment_authorizations_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.payment_authorizations
    ADD CONSTRAINT payment_authorizations_pkey PRIMARY KEY (order_id);


--
-- Name: payment_print_sources payment_print_sources_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.payment_print_sources
    ADD CONSTRAINT payment_print_sources_pkey PRIMARY KEY (order_id);


--
-- Name: preauth_observation_events preauth_observation_events_observation_id_operation_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.preauth_observation_events
    ADD CONSTRAINT preauth_observation_events_observation_id_operation_key UNIQUE (observation_id, operation);


--
-- Name: preauth_observation_events preauth_observation_events_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.preauth_observation_events
    ADD CONSTRAINT preauth_observation_events_pkey PRIMARY KEY (id);


--
-- Name: preauth_observations preauth_observations_merchant_id_order_id_client_request_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.preauth_observations
    ADD CONSTRAINT preauth_observations_merchant_id_order_id_client_request_no_key UNIQUE (merchant_id, order_id, client_request_no);


--
-- Name: preauth_observations preauth_observations_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.preauth_observations
    ADD CONSTRAINT preauth_observations_pkey PRIMARY KEY (id);


--
-- Name: printing_claims printing_claims_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_claims
    ADD CONSTRAINT printing_claims_pkey PRIMARY KEY (intent_id);


--
-- Name: printing_intents printing_intents_merchant_id_external_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_intents
    ADD CONSTRAINT printing_intents_merchant_id_external_no_key UNIQUE (merchant_id, external_no);


--
-- Name: printing_intents printing_intents_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_intents
    ADD CONSTRAINT printing_intents_pkey PRIMARY KEY (id);


--
-- Name: printing_intents printing_intents_request_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_intents
    ADD CONSTRAINT printing_intents_request_no_key UNIQUE (request_no);


--
-- Name: printing_merchant_configs printing_merchant_configs_merchant_id_revision_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_merchant_configs
    ADD CONSTRAINT printing_merchant_configs_merchant_id_revision_key UNIQUE (merchant_id, revision);


--
-- Name: printing_merchant_configs printing_merchant_configs_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_merchant_configs
    ADD CONSTRAINT printing_merchant_configs_pkey PRIMARY KEY (id);


--
-- Name: printing_merchant_heads printing_merchant_heads_config_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_merchant_heads
    ADD CONSTRAINT printing_merchant_heads_config_id_key UNIQUE (config_id);


--
-- Name: printing_merchant_heads printing_merchant_heads_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_merchant_heads
    ADD CONSTRAINT printing_merchant_heads_pkey PRIMARY KEY (merchant_id);


--
-- Name: printing_platform_configs printing_platform_configs_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_platform_configs
    ADD CONSTRAINT printing_platform_configs_pkey PRIMARY KEY (id);


--
-- Name: printing_platform_configs printing_platform_configs_revision_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_platform_configs
    ADD CONSTRAINT printing_platform_configs_revision_key UNIQUE (revision);


--
-- Name: printing_platform_head printing_platform_head_config_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_platform_head
    ADD CONSTRAINT printing_platform_head_config_id_key UNIQUE (config_id);


--
-- Name: printing_platform_head printing_platform_head_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_platform_head
    ADD CONSTRAINT printing_platform_head_pkey PRIMARY KEY (singleton);


--
-- Name: printing_recoveries printing_recoveries_expected_task_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_recoveries
    ADD CONSTRAINT printing_recoveries_expected_task_id_key UNIQUE (expected_task_id);


--
-- Name: printing_recoveries printing_recoveries_intent_id_sequence_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_recoveries
    ADD CONSTRAINT printing_recoveries_intent_id_sequence_no_key UNIQUE (intent_id, sequence_no);


--
-- Name: printing_recoveries printing_recoveries_new_task_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_recoveries
    ADD CONSTRAINT printing_recoveries_new_task_id_key UNIQUE (new_task_id);


--
-- Name: printing_recoveries printing_recoveries_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_recoveries
    ADD CONSTRAINT printing_recoveries_pkey PRIMARY KEY (id);


--
-- Name: printing_results printing_results_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_results
    ADD CONSTRAINT printing_results_pkey PRIMARY KEY (intent_id);


--
-- Name: profile_identity_link_events profile_identity_link_events_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.profile_identity_link_events
    ADD CONSTRAINT profile_identity_link_events_pkey PRIMARY KEY (request_id, operation);


--
-- Name: profile_identity_links profile_identity_links_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.profile_identity_links
    ADD CONSTRAINT profile_identity_links_pkey PRIMARY KEY (request_id);


--
-- Name: profile_identity_lookup_events profile_identity_lookup_events_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.profile_identity_lookup_events
    ADD CONSTRAINT profile_identity_lookup_events_pkey PRIMARY KEY (id);


--
-- Name: profile_identity_lookup_events profile_identity_lookup_events_request_id_operation_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.profile_identity_lookup_events
    ADD CONSTRAINT profile_identity_lookup_events_request_id_operation_key UNIQUE (request_id, operation);


--
-- Name: profile_identity_lookup_requests profile_identity_lookup_requests_authorization_hash_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.profile_identity_lookup_requests
    ADD CONSTRAINT profile_identity_lookup_requests_authorization_hash_key UNIQUE (authorization_hash);


--
-- Name: profile_identity_lookup_requests profile_identity_lookup_requests_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.profile_identity_lookup_requests
    ADD CONSTRAINT profile_identity_lookup_requests_pkey PRIMARY KEY (id);


--
-- Name: profile_identity_lookup_requests profile_identity_lookup_requests_state_hash_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.profile_identity_lookup_requests
    ADD CONSTRAINT profile_identity_lookup_requests_state_hash_key UNIQUE (state_hash);


--
-- Name: provider_attempt_accounts provider_attempt_accounts_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_attempt_accounts
    ADD CONSTRAINT provider_attempt_accounts_pkey PRIMARY KEY (attempt_id);


--
-- Name: provider_attempt_identities provider_attempt_identities_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_attempt_identities
    ADD CONSTRAINT provider_attempt_identities_pkey PRIMARY KEY (attempt_id);


--
-- Name: provider_attempt_sharing_items provider_attempt_sharing_items_attempt_id_receiver_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_attempt_sharing_items
    ADD CONSTRAINT provider_attempt_sharing_items_attempt_id_receiver_id_key UNIQUE (attempt_id, receiver_id);


--
-- Name: provider_attempt_sharing_items provider_attempt_sharing_items_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_attempt_sharing_items
    ADD CONSTRAINT provider_attempt_sharing_items_pkey PRIMARY KEY (attempt_id, "position");


--
-- Name: provider_attempt_sharing provider_attempt_sharing_order_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_attempt_sharing
    ADD CONSTRAINT provider_attempt_sharing_order_id_key UNIQUE (order_id);


--
-- Name: provider_attempt_sharing provider_attempt_sharing_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_attempt_sharing
    ADD CONSTRAINT provider_attempt_sharing_pkey PRIMARY KEY (attempt_id);


--
-- Name: provider_attempts provider_attempts_order_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_attempts
    ADD CONSTRAINT provider_attempts_order_id_key UNIQUE (order_id);


--
-- Name: provider_attempts provider_attempts_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_attempts
    ADD CONSTRAINT provider_attempts_pkey PRIMARY KEY (id);


--
-- Name: provider_operations provider_operations_kind_business_key_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_operations
    ADD CONSTRAINT provider_operations_kind_business_key_key UNIQUE (kind, business_key);


--
-- Name: provider_operations provider_operations_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_operations
    ADD CONSTRAINT provider_operations_pkey PRIMARY KEY (id);


--
-- Name: provider_reconciliations provider_reconciliations_order_id_event_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_reconciliations
    ADD CONSTRAINT provider_reconciliations_order_id_event_id_key UNIQUE (order_id, event_id);


--
-- Name: provider_reconciliations provider_reconciliations_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_reconciliations
    ADD CONSTRAINT provider_reconciliations_pkey PRIMARY KEY (id);


--
-- Name: provider_refund_result_evidence provider_refund_result_evidence_operation_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_refund_result_evidence
    ADD CONSTRAINT provider_refund_result_evidence_operation_id_key UNIQUE (operation_id);


--
-- Name: provider_refund_result_evidence provider_refund_result_evidence_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_refund_result_evidence
    ADD CONSTRAINT provider_refund_result_evidence_pkey PRIMARY KEY (refund_id);


--
-- Name: provider_route_assignments provider_route_assignments_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_route_assignments
    ADD CONSTRAINT provider_route_assignments_pkey PRIMARY KEY (merchant_id, out_trade_no);


--
-- Name: provider_route_counters provider_route_counters_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_route_counters
    ADD CONSTRAINT provider_route_counters_pkey PRIMARY KEY (rule_id);


--
-- Name: provider_subject_snapshots provider_subject_snapshots_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_subject_snapshots
    ADD CONSTRAINT provider_subject_snapshots_pkey PRIMARY KEY (order_id);


--
-- Name: provider_transfer_accounts provider_transfer_accounts_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_transfer_accounts
    ADD CONSTRAINT provider_transfer_accounts_pkey PRIMARY KEY (transfer_id);


--
-- Name: provider_transfer_attempts provider_transfer_attempts_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_transfer_attempts
    ADD CONSTRAINT provider_transfer_attempts_pkey PRIMARY KEY (transfer_id);


--
-- Name: provider_transfer_policies provider_transfer_policies_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_transfer_policies
    ADD CONSTRAINT provider_transfer_policies_pkey PRIMARY KEY (transfer_id);


--
-- Name: provider_transfer_proofs provider_transfer_proofs_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_transfer_proofs
    ADD CONSTRAINT provider_transfer_proofs_pkey PRIMARY KEY (transfer_id);


--
-- Name: recharge_intents recharge_intents_order_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.recharge_intents
    ADD CONSTRAINT recharge_intents_order_id_key UNIQUE (order_id);


--
-- Name: recharge_intents recharge_intents_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.recharge_intents
    ADD CONSTRAINT recharge_intents_pkey PRIMARY KEY (id);


--
-- Name: referral_clawback_audits referral_clawback_audits_event_key_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_clawback_audits
    ADD CONSTRAINT referral_clawback_audits_event_key_key UNIQUE (event_key);


--
-- Name: referral_clawback_audits referral_clawback_audits_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_clawback_audits
    ADD CONSTRAINT referral_clawback_audits_pkey PRIMARY KEY (refund_id, state);


--
-- Name: referral_daily_awards referral_daily_awards_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_awards
    ADD CONSTRAINT referral_daily_awards_pkey PRIMARY KEY (order_id);


--
-- Name: referral_daily_awards referral_daily_awards_release_journal_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_awards
    ADD CONSTRAINT referral_daily_awards_release_journal_id_key UNIQUE (release_journal_id);


--
-- Name: referral_daily_awards referral_daily_awards_reward_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_awards
    ADD CONSTRAINT referral_daily_awards_reward_id_key UNIQUE (reward_id);


--
-- Name: referral_daily_events referral_daily_events_event_key_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_events
    ADD CONSTRAINT referral_daily_events_event_key_key UNIQUE (event_key);


--
-- Name: referral_daily_events referral_daily_events_order_id_operation_reference_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_events
    ADD CONSTRAINT referral_daily_events_order_id_operation_reference_id_key UNIQUE (order_id, operation, reference_id);


--
-- Name: referral_daily_events referral_daily_events_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_events
    ADD CONSTRAINT referral_daily_events_pkey PRIMARY KEY (id);


--
-- Name: referral_daily_liabilities referral_daily_liabilities_funding_journal_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_liabilities
    ADD CONSTRAINT referral_daily_liabilities_funding_journal_id_key UNIQUE (funding_journal_id);


--
-- Name: referral_daily_liabilities referral_daily_liabilities_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_liabilities
    ADD CONSTRAINT referral_daily_liabilities_pkey PRIMARY KEY (order_id);


--
-- Name: referral_daily_refund_reservations referral_daily_refund_reserva_restore_contribution_journal__key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_refund_reservations
    ADD CONSTRAINT referral_daily_refund_reserva_restore_contribution_journal__key UNIQUE (restore_contribution_journal_id);


--
-- Name: referral_daily_refund_reservations referral_daily_refund_reservat_release_remainder_journal_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_refund_reservations
    ADD CONSTRAINT referral_daily_refund_reservat_release_remainder_journal_id_key UNIQUE (release_remainder_journal_id);


--
-- Name: referral_daily_refund_reservations referral_daily_refund_reservatio_restore_pending_journal_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_refund_reservations
    ADD CONSTRAINT referral_daily_refund_reservatio_restore_pending_journal_id_key UNIQUE (restore_pending_journal_id);


--
-- Name: referral_daily_refund_reservations referral_daily_refund_reservations_contribution_journal_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_refund_reservations
    ADD CONSTRAINT referral_daily_refund_reservations_contribution_journal_id_key UNIQUE (contribution_journal_id);


--
-- Name: referral_daily_refund_reservations referral_daily_refund_reservations_escrow_account_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_refund_reservations
    ADD CONSTRAINT referral_daily_refund_reservations_escrow_account_id_key UNIQUE (escrow_account_id);


--
-- Name: referral_daily_refund_reservations referral_daily_refund_reservations_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_refund_reservations
    ADD CONSTRAINT referral_daily_refund_reservations_pkey PRIMARY KEY (refund_id);


--
-- Name: referral_daily_refund_reservations referral_daily_refund_reservations_reserve_journal_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_refund_reservations
    ADD CONSTRAINT referral_daily_refund_reservations_reserve_journal_id_key UNIQUE (reserve_journal_id);


--
-- Name: referral_daily_terms referral_daily_terms_pending_account_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_terms
    ADD CONSTRAINT referral_daily_terms_pending_account_id_key UNIQUE (pending_account_id);


--
-- Name: referral_daily_terms referral_daily_terms_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_terms
    ADD CONSTRAINT referral_daily_terms_pkey PRIMARY KEY (order_id);


--
-- Name: referral_order_terms referral_order_terms_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_order_terms
    ADD CONSTRAINT referral_order_terms_pkey PRIMARY KEY (order_id);


--
-- Name: referral_policies referral_policies_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_policies
    ADD CONSTRAINT referral_policies_pkey PRIMARY KEY (id);


--
-- Name: referral_policies referral_policies_scope_kind_scope_id_revision_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_policies
    ADD CONSTRAINT referral_policies_scope_kind_scope_id_revision_key UNIQUE (scope_kind, scope_id, revision);


--
-- Name: referral_policy_audits referral_policy_audits_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_policy_audits
    ADD CONSTRAINT referral_policy_audits_pkey PRIMARY KEY (policy_id);


--
-- Name: referral_policy_heads referral_policy_heads_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_policy_heads
    ADD CONSTRAINT referral_policy_heads_pkey PRIMARY KEY (scope_kind, scope_id);


--
-- Name: referral_policy_heads referral_policy_heads_policy_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_policy_heads
    ADD CONSTRAINT referral_policy_heads_policy_id_key UNIQUE (policy_id);


--
-- Name: referral_profit_cost_events referral_profit_cost_events_event_key_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_profit_cost_events
    ADD CONSTRAINT referral_profit_cost_events_event_key_key UNIQUE (event_key);


--
-- Name: referral_profit_cost_events referral_profit_cost_events_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_profit_cost_events
    ADD CONSTRAINT referral_profit_cost_events_pkey PRIMARY KEY (order_id);


--
-- Name: referral_profit_costs referral_profit_costs_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_profit_costs
    ADD CONSTRAINT referral_profit_costs_pkey PRIMARY KEY (order_id);


--
-- Name: referral_refund_clawbacks referral_refund_clawbacks_contribution_journal_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_refund_clawbacks
    ADD CONSTRAINT referral_refund_clawbacks_contribution_journal_id_key UNIQUE (contribution_journal_id);


--
-- Name: referral_refund_clawbacks referral_refund_clawbacks_escrow_account_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_refund_clawbacks
    ADD CONSTRAINT referral_refund_clawbacks_escrow_account_id_key UNIQUE (escrow_account_id);


--
-- Name: referral_refund_clawbacks referral_refund_clawbacks_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_refund_clawbacks
    ADD CONSTRAINT referral_refund_clawbacks_pkey PRIMARY KEY (refund_id);


--
-- Name: referral_refund_clawbacks referral_refund_clawbacks_release_remainder_journal_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_refund_clawbacks
    ADD CONSTRAINT referral_refund_clawbacks_release_remainder_journal_id_key UNIQUE (release_remainder_journal_id);


--
-- Name: referral_refund_clawbacks referral_refund_clawbacks_reserve_journal_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_refund_clawbacks
    ADD CONSTRAINT referral_refund_clawbacks_reserve_journal_id_key UNIQUE (reserve_journal_id);


--
-- Name: referral_refund_clawbacks referral_refund_clawbacks_restore_contribution_journal_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_refund_clawbacks
    ADD CONSTRAINT referral_refund_clawbacks_restore_contribution_journal_id_key UNIQUE (restore_contribution_journal_id);


--
-- Name: referral_refund_clawbacks referral_refund_clawbacks_restore_reward_journal_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_refund_clawbacks
    ADD CONSTRAINT referral_refund_clawbacks_restore_reward_journal_id_key UNIQUE (restore_reward_journal_id);


--
-- Name: referral_relations referral_relations_challenge_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_relations
    ADD CONSTRAINT referral_relations_challenge_id_key UNIQUE (challenge_id);


--
-- Name: referral_relations referral_relations_invited_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_relations
    ADD CONSTRAINT referral_relations_invited_id_key UNIQUE (invited_id);


--
-- Name: referral_relations referral_relations_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_relations
    ADD CONSTRAINT referral_relations_pkey PRIMARY KEY (id);


--
-- Name: referral_reward_audits referral_reward_audits_event_key_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_reward_audits
    ADD CONSTRAINT referral_reward_audits_event_key_key UNIQUE (event_key);


--
-- Name: referral_reward_audits referral_reward_audits_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_reward_audits
    ADD CONSTRAINT referral_reward_audits_pkey PRIMARY KEY (reward_id);


--
-- Name: referral_rewards referral_rewards_journal_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_rewards
    ADD CONSTRAINT referral_rewards_journal_id_key UNIQUE (journal_id);


--
-- Name: referral_rewards referral_rewards_order_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_rewards
    ADD CONSTRAINT referral_rewards_order_id_key UNIQUE (order_id);


--
-- Name: referral_rewards referral_rewards_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_rewards
    ADD CONSTRAINT referral_rewards_pkey PRIMARY KEY (id);


--
-- Name: referral_token_current referral_token_current_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_token_current
    ADD CONSTRAINT referral_token_current_pkey PRIMARY KEY (merchant_id);


--
-- Name: referral_token_current referral_token_current_token_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_token_current
    ADD CONSTRAINT referral_token_current_token_id_key UNIQUE (token_id);


--
-- Name: referral_tokens referral_tokens_merchant_id_version_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_tokens
    ADD CONSTRAINT referral_tokens_merchant_id_version_key UNIQUE (merchant_id, version);


--
-- Name: referral_tokens referral_tokens_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_tokens
    ADD CONSTRAINT referral_tokens_pkey PRIMARY KEY (id);


--
-- Name: referral_tokens referral_tokens_token_hash_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_tokens
    ADD CONSTRAINT referral_tokens_token_hash_key UNIQUE (token_hash);


--
-- Name: refund_funding_resolutions refund_funding_resolutions_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.refund_funding_resolutions
    ADD CONSTRAINT refund_funding_resolutions_pkey PRIMARY KEY (refund_id);


--
-- Name: refund_fundings refund_fundings_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.refund_fundings
    ADD CONSTRAINT refund_fundings_pkey PRIMARY KEY (refund_id);


--
-- Name: refunds refunds_merchant_id_refund_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.refunds
    ADD CONSTRAINT refunds_merchant_id_refund_no_key UNIQUE (merchant_id, refund_no);


--
-- Name: refunds refunds_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.refunds
    ADD CONSTRAINT refunds_pkey PRIMARY KEY (id);


--
-- Name: scan_cancellation_claims scan_cancellation_claims_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.scan_cancellation_claims
    ADD CONSTRAINT scan_cancellation_claims_pkey PRIMARY KEY (attempt_id);


--
-- Name: scan_cancellation_results scan_cancellation_results_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.scan_cancellation_results
    ADD CONSTRAINT scan_cancellation_results_pkey PRIMARY KEY (attempt_id);


--
-- Name: scan_recovery_eligibility scan_recovery_eligibility_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.scan_recovery_eligibility
    ADD CONSTRAINT scan_recovery_eligibility_pkey PRIMARY KEY (attempt_id);


--
-- Name: scan_recovery_origins scan_recovery_origins_order_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.scan_recovery_origins
    ADD CONSTRAINT scan_recovery_origins_order_id_key UNIQUE (order_id);


--
-- Name: scan_recovery_origins scan_recovery_origins_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.scan_recovery_origins
    ADD CONSTRAINT scan_recovery_origins_pkey PRIMARY KEY (attempt_id);


--
-- Name: scan_recovery_query_events scan_recovery_query_events_attempt_id_query_number_kind_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.scan_recovery_query_events
    ADD CONSTRAINT scan_recovery_query_events_attempt_id_query_number_kind_key UNIQUE (attempt_id, query_number, kind);


--
-- Name: scan_recovery_query_events scan_recovery_query_events_attempt_id_revision_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.scan_recovery_query_events
    ADD CONSTRAINT scan_recovery_query_events_attempt_id_revision_key UNIQUE (attempt_id, revision);


--
-- Name: scan_recovery_query_events scan_recovery_query_events_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.scan_recovery_query_events
    ADD CONSTRAINT scan_recovery_query_events_pkey PRIMARY KEY (id);


--
-- Name: scan_recovery_query_heads scan_recovery_query_heads_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.scan_recovery_query_heads
    ADD CONSTRAINT scan_recovery_query_heads_pkey PRIMARY KEY (attempt_id);


--
-- Name: settlement_auto_authorizations settlement_auto_authorization_plan_id_expected_authorizatio_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_authorizations
    ADD CONSTRAINT settlement_auto_authorization_plan_id_expected_authorizatio_key UNIQUE (plan_id, expected_authorization_id);


--
-- Name: settlement_auto_authorizations settlement_auto_authorizations_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_authorizations
    ADD CONSTRAINT settlement_auto_authorizations_pkey PRIMARY KEY (id);


--
-- Name: settlement_auto_claims settlement_auto_claims_claim_seq_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_claims
    ADD CONSTRAINT settlement_auto_claims_claim_seq_key UNIQUE (claim_seq);


--
-- Name: settlement_auto_claims settlement_auto_claims_item_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_claims
    ADD CONSTRAINT settlement_auto_claims_item_id_key UNIQUE (item_id);


--
-- Name: settlement_auto_claims settlement_auto_claims_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_claims
    ADD CONSTRAINT settlement_auto_claims_pkey PRIMARY KEY (request_id);


--
-- Name: settlement_auto_claims settlement_auto_claims_transfer_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_claims
    ADD CONSTRAINT settlement_auto_claims_transfer_id_key UNIQUE (transfer_id);


--
-- Name: settlement_auto_heads settlement_auto_heads_authorization_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_heads
    ADD CONSTRAINT settlement_auto_heads_authorization_id_key UNIQUE (authorization_id);


--
-- Name: settlement_auto_heads settlement_auto_heads_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_heads
    ADD CONSTRAINT settlement_auto_heads_pkey PRIMARY KEY (plan_id);


--
-- Name: settlement_auto_revocations settlement_auto_revocations_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_revocations
    ADD CONSTRAINT settlement_auto_revocations_pkey PRIMARY KEY (authorization_id);


--
-- Name: settlement_bank_payouts settlement_bank_payouts_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_bank_payouts
    ADD CONSTRAINT settlement_bank_payouts_pkey PRIMARY KEY (request_id);


--
-- Name: settlement_bank_payouts settlement_bank_payouts_transfer_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_bank_payouts
    ADD CONSTRAINT settlement_bank_payouts_transfer_id_key UNIQUE (transfer_id);


--
-- Name: settlement_fundings settlement_fundings_account_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_fundings
    ADD CONSTRAINT settlement_fundings_account_id_key UNIQUE (account_id);


--
-- Name: settlement_fundings settlement_fundings_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_fundings
    ADD CONSTRAINT settlement_fundings_pkey PRIMARY KEY (request_id);


--
-- Name: settlement_fundings settlement_fundings_reserve_journal_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_fundings
    ADD CONSTRAINT settlement_fundings_reserve_journal_id_key UNIQUE (reserve_journal_id);


--
-- Name: settlement_payout_cancellations settlement_payout_cancellations_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_payout_cancellations
    ADD CONSTRAINT settlement_payout_cancellations_pkey PRIMARY KEY (request_id);


--
-- Name: settlement_payout_cancellations settlement_payout_cancellations_transfer_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_payout_cancellations
    ADD CONSTRAINT settlement_payout_cancellations_transfer_id_key UNIQUE (transfer_id);


--
-- Name: settlement_payout_events settlement_payout_events_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_payout_events
    ADD CONSTRAINT settlement_payout_events_pkey PRIMARY KEY (id);


--
-- Name: settlement_payouts settlement_payouts_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_payouts
    ADD CONSTRAINT settlement_payouts_pkey PRIMARY KEY (request_id);


--
-- Name: settlement_payouts settlement_payouts_request_id_transfer_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_payouts
    ADD CONSTRAINT settlement_payouts_request_id_transfer_id_key UNIQUE (request_id, transfer_id);


--
-- Name: settlement_payouts settlement_payouts_transfer_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_payouts
    ADD CONSTRAINT settlement_payouts_transfer_id_key UNIQUE (transfer_id);


--
-- Name: settlement_plan_authorizations settlement_plan_authorizations_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_authorizations
    ADD CONSTRAINT settlement_plan_authorizations_pkey PRIMARY KEY (id);


--
-- Name: settlement_plan_budget_uses settlement_plan_budget_uses_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_budget_uses
    ADD CONSTRAINT settlement_plan_budget_uses_pkey PRIMARY KEY (item_id);


--
-- Name: settlement_plan_items settlement_plan_items_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_items
    ADD CONSTRAINT settlement_plan_items_pkey PRIMARY KEY (id);


--
-- Name: settlement_plan_items settlement_plan_items_request_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_items
    ADD CONSTRAINT settlement_plan_items_request_id_key UNIQUE (request_id);


--
-- Name: settlement_plan_items settlement_plan_items_run_id_merchant_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_items
    ADD CONSTRAINT settlement_plan_items_run_id_merchant_id_key UNIQUE (run_id, merchant_id);


--
-- Name: settlement_plan_revocations settlement_plan_revocations_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_revocations
    ADD CONSTRAINT settlement_plan_revocations_pkey PRIMARY KEY (authorization_id);


--
-- Name: settlement_plan_runs settlement_plan_runs_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_runs
    ADD CONSTRAINT settlement_plan_runs_pkey PRIMARY KEY (id);


--
-- Name: settlement_plan_runs settlement_plan_runs_plan_id_slot_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_runs
    ADD CONSTRAINT settlement_plan_runs_plan_id_slot_no_key UNIQUE (plan_id, slot_no);


--
-- Name: settlement_plan_versions settlement_plan_versions_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_versions
    ADD CONSTRAINT settlement_plan_versions_pkey PRIMARY KEY (id);


--
-- Name: settlement_plan_versions settlement_plan_versions_plan_id_revision_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_versions
    ADD CONSTRAINT settlement_plan_versions_plan_id_revision_key UNIQUE (plan_id, revision);


--
-- Name: settlement_plans settlement_plans_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plans
    ADD CONSTRAINT settlement_plans_pkey PRIMARY KEY (id);


--
-- Name: settlement_recipient_configs settlement_recipient_configs_merchant_id_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_recipient_configs
    ADD CONSTRAINT settlement_recipient_configs_merchant_id_id_key UNIQUE (merchant_id, id);


--
-- Name: settlement_recipient_configs settlement_recipient_configs_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_recipient_configs
    ADD CONSTRAINT settlement_recipient_configs_pkey PRIMARY KEY (id);


--
-- Name: settlement_recipient_current settlement_recipient_current_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_recipient_current
    ADD CONSTRAINT settlement_recipient_current_pkey PRIMARY KEY (merchant_id);


--
-- Name: settlement_recipients settlement_recipients_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_recipients
    ADD CONSTRAINT settlement_recipients_pkey PRIMARY KEY (request_id);


--
-- Name: settlement_request_terms settlement_request_terms_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_request_terms
    ADD CONSTRAINT settlement_request_terms_pkey PRIMARY KEY (request_id);


--
-- Name: settlement_schedule_preference_heads settlement_schedule_preference_heads_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_schedule_preference_heads
    ADD CONSTRAINT settlement_schedule_preference_heads_pkey PRIMARY KEY (merchant_id);


--
-- Name: settlement_schedule_preference_heads settlement_schedule_preference_heads_preference_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_schedule_preference_heads
    ADD CONSTRAINT settlement_schedule_preference_heads_preference_id_key UNIQUE (preference_id);


--
-- Name: settlement_schedule_preferences settlement_schedule_preferences_merchant_id_revision_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_schedule_preferences
    ADD CONSTRAINT settlement_schedule_preferences_merchant_id_revision_key UNIQUE (merchant_id, revision);


--
-- Name: settlement_schedule_preferences settlement_schedule_preferences_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_schedule_preferences
    ADD CONSTRAINT settlement_schedule_preferences_pkey PRIMARY KEY (id);


--
-- Name: settlement_scheduled_intents settlement_scheduled_intents_item_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_scheduled_intents
    ADD CONSTRAINT settlement_scheduled_intents_item_id_key UNIQUE (item_id);


--
-- Name: settlement_scheduled_intents settlement_scheduled_intents_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_scheduled_intents
    ADD CONSTRAINT settlement_scheduled_intents_pkey PRIMARY KEY (merchant_id, business_date);


--
-- Name: settlement_scheduled_intents settlement_scheduled_intents_request_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_scheduled_intents
    ADD CONSTRAINT settlement_scheduled_intents_request_id_key UNIQUE (request_id);


--
-- Name: settlement_threshold_intents settlement_threshold_intents_item_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_threshold_intents
    ADD CONSTRAINT settlement_threshold_intents_item_id_key UNIQUE (item_id);


--
-- Name: settlement_threshold_intents settlement_threshold_intents_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_threshold_intents
    ADD CONSTRAINT settlement_threshold_intents_pkey PRIMARY KEY (run_id, merchant_id);


--
-- Name: settlement_threshold_intents settlement_threshold_intents_request_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_threshold_intents
    ADD CONSTRAINT settlement_threshold_intents_request_id_key UNIQUE (request_id);


--
-- Name: settlement_threshold_selections settlement_threshold_selections_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_threshold_selections
    ADD CONSTRAINT settlement_threshold_selections_pkey PRIMARY KEY (run_id);


--
-- Name: settlement_threshold_selections settlement_threshold_selections_source_sequence_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_threshold_selections
    ADD CONSTRAINT settlement_threshold_selections_source_sequence_key UNIQUE (source_sequence);


--
-- Name: transfer_batch_events transfer_batch_events_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfer_batch_events
    ADD CONSTRAINT transfer_batch_events_pkey PRIMARY KEY (id);


--
-- Name: transfer_batch_execution_claims transfer_batch_execution_claims_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfer_batch_execution_claims
    ADD CONSTRAINT transfer_batch_execution_claims_pkey PRIMARY KEY (transfer_id);


--
-- Name: transfer_batch_executions transfer_batch_executions_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfer_batch_executions
    ADD CONSTRAINT transfer_batch_executions_pkey PRIMARY KEY (execution_no);


--
-- Name: transfer_batch_items transfer_batch_items_batch_id_transfer_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfer_batch_items
    ADD CONSTRAINT transfer_batch_items_batch_id_transfer_id_key UNIQUE (batch_id, transfer_id);


--
-- Name: transfer_batch_items transfer_batch_items_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfer_batch_items
    ADD CONSTRAINT transfer_batch_items_pkey PRIMARY KEY (batch_id, "position");


--
-- Name: transfer_batch_items transfer_batch_items_transfer_id_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfer_batch_items
    ADD CONSTRAINT transfer_batch_items_transfer_id_key UNIQUE (transfer_id);


--
-- Name: transfer_batches transfer_batches_merchant_id_external_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfer_batches
    ADD CONSTRAINT transfer_batches_merchant_id_external_no_key UNIQUE (merchant_id, external_no);


--
-- Name: transfer_batches transfer_batches_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfer_batches
    ADD CONSTRAINT transfer_batches_pkey PRIMARY KEY (id);


--
-- Name: transfer_unsent_cancellations transfer_unsent_cancellations_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfer_unsent_cancellations
    ADD CONSTRAINT transfer_unsent_cancellations_pkey PRIMARY KEY (transfer_id);


--
-- Name: transfers transfers_merchant_id_transfer_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfers
    ADD CONSTRAINT transfers_merchant_id_transfer_no_key UNIQUE (merchant_id, transfer_no);


--
-- Name: transfers transfers_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfers
    ADD CONSTRAINT transfers_pkey PRIMARY KEY (id);


--
-- Name: verified_payment_receipts verified_payment_receipts_channel_id_provider_trade_no_key; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.verified_payment_receipts
    ADD CONSTRAINT verified_payment_receipts_channel_id_provider_trade_no_key UNIQUE (channel_id, provider_trade_no);


--
-- Name: verified_payment_receipts verified_payment_receipts_pkey; Type: CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.verified_payment_receipts
    ADD CONSTRAINT verified_payment_receipts_pkey PRIMARY KEY (order_id);


--
-- Name: admin_funds_audit_actor; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX admin_funds_audit_actor ON member72_1c1acaaf36d7e39a.admin_funds_audit USING btree (username, id DESC);


--
-- Name: admin_funds_challenge_expiry; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX admin_funds_challenge_expiry ON member72_1c1acaaf36d7e39a.admin_funds_challenges USING btree (expires_at);


--
-- Name: admin_funds_grant_expiry; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX admin_funds_grant_expiry ON member72_1c1acaaf36d7e39a.admin_funds_grants USING btree (expires_at);


--
-- Name: alipay_bank_observation_lookup; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX alipay_bank_observation_lookup ON member72_1c1acaaf36d7e39a.alipay_bank_observations USING btree (transfer_id, id);


--
-- Name: application_authorization_session; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX application_authorization_session ON member72_1c1acaaf36d7e39a.application_authorization_requests USING btree (session_hash, expires_at);


--
-- Name: authorization_remaining_audit_order; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX authorization_remaining_audit_order ON member72_1c1acaaf36d7e39a.backoffice_audit USING btree (((changes ->> 'order_id'::text)), resource_id, operation) WHERE (resource = 'authorization-remaining-sources'::text);


--
-- Name: backoffice_audit_lookup; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX backoffice_audit_lookup ON member72_1c1acaaf36d7e39a.backoffice_audit USING btree (resource, resource_id, id DESC);


--
-- Name: backoffice_domain_unique; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE UNIQUE INDEX backoffice_domain_unique ON member72_1c1acaaf36d7e39a.backoffice_records USING btree (owner_id, lower((body ->> 'domain'::text))) WHERE (resource = 'domains'::text);


--
-- Name: backoffice_group_unique; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE UNIQUE INDEX backoffice_group_unique ON member72_1c1acaaf36d7e39a.backoffice_records USING btree (lower((body ->> 'name'::text))) WHERE (resource = 'groups'::text);


--
-- Name: backoffice_invitation_unique; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE UNIQUE INDEX backoffice_invitation_unique ON member72_1c1acaaf36d7e39a.backoffice_records USING btree (((body ->> 'code'::text))) WHERE (resource = 'invitation-codes'::text);


--
-- Name: backoffice_records_list; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX backoffice_records_list ON member72_1c1acaaf36d7e39a.backoffice_records USING btree (resource, owner_id, id DESC);


--
-- Name: backoffice_setting_unique; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE UNIQUE INDEX backoffice_setting_unique ON member72_1c1acaaf36d7e39a.backoffice_records USING btree (((body ->> 'key'::text))) WHERE (resource = 'settings'::text);


--
-- Name: backoffice_style_unique; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE UNIQUE INDEX backoffice_style_unique ON member72_1c1acaaf36d7e39a.backoffice_records USING btree (lower((body ->> 'name'::text))) WHERE (resource = 'collection-styles'::text);


--
-- Name: bank_transfer_observations_lookup; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX bank_transfer_observations_lookup ON member72_1c1acaaf36d7e39a.bank_transfer_observations USING btree (transfer_id, id);


--
-- Name: channel_sharing_finish_merchant_history; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX channel_sharing_finish_merchant_history ON member72_1c1acaaf36d7e39a.channel_sharing_finishes USING btree (merchant_id, id DESC);


--
-- Name: channel_sharing_finish_one_active; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE UNIQUE INDEX channel_sharing_finish_one_active ON member72_1c1acaaf36d7e39a.channel_sharing_finishes USING btree (order_id) WHERE (state <> 'failed'::text);


--
-- Name: channel_sharing_finish_order_history; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX channel_sharing_finish_order_history ON member72_1c1acaaf36d7e39a.channel_sharing_finishes USING btree (order_id, id DESC);


--
-- Name: channel_sharing_receiver_authenticated; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX channel_sharing_receiver_authenticated ON member72_1c1acaaf36d7e39a.channel_sharing_receivers USING btree (relation_auth_hash);


--
-- Name: channel_sharing_receiver_operation_relation; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX channel_sharing_receiver_operation_relation ON member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations USING btree (relation_id, id);


--
-- Name: channel_sharing_receiver_owner; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX channel_sharing_receiver_owner ON member72_1c1acaaf36d7e39a.channel_sharing_receivers USING btree (merchant_id, channel_id, id);


--
-- Name: channel_sharing_receiver_physical; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX channel_sharing_receiver_physical ON member72_1c1acaaf36d7e39a.channel_sharing_receivers USING btree (relation_hash);


--
-- Name: channel_sharing_relation_active_auth; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE UNIQUE INDEX channel_sharing_relation_active_auth ON member72_1c1acaaf36d7e39a.channel_sharing_relations USING btree (relation_auth_hash) WHERE (state <> 'unbound'::text);


--
-- Name: channel_sharing_relation_live_leases; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX channel_sharing_relation_live_leases ON member72_1c1acaaf36d7e39a.channel_sharing_relation_leases USING btree (relation_id) WHERE (released_by_operation_id IS NULL);


--
-- Name: channel_sharing_relation_receiver_lease; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE UNIQUE INDEX channel_sharing_relation_receiver_lease ON member72_1c1acaaf36d7e39a.channel_sharing_relation_leases USING btree (receiver_id) WHERE (released_by_operation_id IS NULL);


--
-- Name: channel_sharing_returns_original; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX channel_sharing_returns_original ON member72_1c1acaaf36d7e39a.channel_sharing_returns USING btree (sharing_id, receiver_id, id);


--
-- Name: channel_stop_audit_channel; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX channel_stop_audit_channel ON member72_1c1acaaf36d7e39a.backoffice_audit USING btree (((changes ->> 'channel_id'::text)), resource_id, operation) WHERE (resource = 'channel-stops'::text);


--
-- Name: channel_stop_original_transfer; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE UNIQUE INDEX channel_stop_original_transfer ON member72_1c1acaaf36d7e39a.channel_stop_events USING btree (transfer_id) WHERE (action = 'pause'::text);


--
-- Name: console_login_audit_created; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX console_login_audit_created ON member72_1c1acaaf36d7e39a.console_login_audit USING btree (created_at DESC, id DESC);


--
-- Name: console_login_throttle_expiry; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX console_login_throttle_expiry ON member72_1c1acaaf36d7e39a.console_login_throttle USING btree (updated_at);


--
-- Name: console_sessions_expiry; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX console_sessions_expiry ON member72_1c1acaaf36d7e39a.console_sessions USING btree (expires_at);


--
-- Name: console_sso_grants_expiry; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX console_sso_grants_expiry ON member72_1c1acaaf36d7e39a.console_sso_grants USING btree (expires_at);


--
-- Name: enrollment_challenge_expiry; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX enrollment_challenge_expiry ON member72_1c1acaaf36d7e39a.enrollment_challenges USING btree (expires_at);


--
-- Name: enrollment_email_recent; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX enrollment_email_recent ON member72_1c1acaaf36d7e39a.enrollment_challenges USING btree (email_hash, created_at DESC);


--
-- Name: identity_lookup_session; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX identity_lookup_session ON member72_1c1acaaf36d7e39a.identity_lookup_requests USING btree (session_hash, expires_at);


--
-- Name: jobs_claim; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX jobs_claim ON member72_1c1acaaf36d7e39a.jobs USING btree (run_at, id) WHERE (state = ANY (ARRAY['pending'::text, 'running'::text]));


--
-- Name: jobs_payment_notify_trade; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX jobs_payment_notify_trade ON member72_1c1acaaf36d7e39a.jobs USING btree (((payload ->> 'trade_no'::text)), created_at DESC, id DESC) WHERE (kind = 'payment.notify'::text);


--
-- Name: ledger_account; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX ledger_account ON member72_1c1acaaf36d7e39a.ledger_entries USING btree (account_id, id);


--
-- Name: ledger_entries_by_journal; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX ledger_entries_by_journal ON member72_1c1acaaf36d7e39a.ledger_entries USING btree (journal_id);


--
-- Name: legacy_refund_history_export; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX legacy_refund_history_export ON member72_1c1acaaf36d7e39a.legacy_refund_history USING btree (export_id, id);


--
-- Name: legacy_refund_history_owner; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX legacy_refund_history_owner ON member72_1c1acaaf36d7e39a.legacy_refund_history USING btree (merchant_id, id);


--
-- Name: mini_oauth_states_order; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX mini_oauth_states_order ON member72_1c1acaaf36d7e39a.mini_oauth_states USING btree (order_id, expires_at);


--
-- Name: oauth_states_order; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX oauth_states_order ON member72_1c1acaaf36d7e39a.oauth_states USING btree (order_id, expires_at);


--
-- Name: operation_audit_lookup; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX operation_audit_lookup ON member72_1c1acaaf36d7e39a.operation_audit USING btree (operation_kind, operation_id, id);


--
-- Name: order_income_one_active; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE UNIQUE INDEX order_income_one_active ON member72_1c1acaaf36d7e39a.order_income_holds USING btree (order_id) WHERE (state = 'held'::text);


--
-- Name: order_income_order_history; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX order_income_order_history ON member72_1c1acaaf36d7e39a.order_income_holds USING btree (order_id, id DESC);


--
-- Name: order_reporting_console_buyer; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX order_reporting_console_buyer ON member72_1c1acaaf36d7e39a.order_reporting USING btree (buyer, order_id) WHERE (buyer <> ''::text);


--
-- Name: order_reporting_console_ip; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX order_reporting_console_ip ON member72_1c1acaaf36d7e39a.order_reporting USING btree (client_ip, order_id) WHERE (client_ip <> ''::text);


--
-- Name: orders_console_created; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX orders_console_created ON member72_1c1acaaf36d7e39a.orders USING btree (created_at DESC, id DESC);


--
-- Name: orders_merchant_created; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX orders_merchant_created ON member72_1c1acaaf36d7e39a.orders USING btree (merchant_id, created_at DESC, id DESC);


--
-- Name: orders_t1_paid; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX orders_t1_paid ON member72_1c1acaaf36d7e39a.orders USING btree (merchant_id, paid_at, id) INCLUDE (amount) WHERE (status = 'paid'::text);


--
-- Name: pay_roll_active_scope; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE UNIQUE INDEX pay_roll_active_scope ON member72_1c1acaaf36d7e39a.backoffice_records USING btree (((body ->> 'merchant_id'::text)), ((body ->> 'type'::text))) WHERE ((resource = 'pay-rolls'::text) AND (body ? 'merchant_id'::text) AND (body ? 'type'::text) AND ((body -> 'enabled'::text) = 'true'::jsonb));


--
-- Name: printing_one_auto; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE UNIQUE INDEX printing_one_auto ON member72_1c1acaaf36d7e39a.printing_intents USING btree (order_id) WHERE (source = 'auto'::text);


--
-- Name: profile_identity_lookup_session; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX profile_identity_lookup_session ON member72_1c1acaaf36d7e39a.profile_identity_lookup_requests USING btree (session_hash, expires_at);


--
-- Name: provider_attempt_channel_time; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX provider_attempt_channel_time ON member72_1c1acaaf36d7e39a.provider_attempts USING btree (channel_id, created_at);


--
-- Name: provider_attempts_console_channel; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX provider_attempts_console_channel ON member72_1c1acaaf36d7e39a.provider_attempts USING btree (channel_id, order_id);


--
-- Name: provider_route_channel_time; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX provider_route_channel_time ON member72_1c1acaaf36d7e39a.provider_route_assignments USING btree (channel_id, created_at);


--
-- Name: provider_route_rule_time; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX provider_route_rule_time ON member72_1c1acaaf36d7e39a.provider_route_assignments USING btree (rule_id, created_at);


--
-- Name: provider_transfer_recipient_lookup; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX provider_transfer_recipient_lookup ON member72_1c1acaaf36d7e39a.provider_transfer_policies USING btree (merchant_id, recipient_hash, transfer_id);


--
-- Name: referral_clawback_one_live_reward; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE UNIQUE INDEX referral_clawback_one_live_reward ON member72_1c1acaaf36d7e39a.referral_refund_clawbacks USING btree (reward_id) WHERE (state <> 'failed'::text);


--
-- Name: referral_clawback_order_history; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX referral_clawback_order_history ON member72_1c1acaaf36d7e39a.referral_refund_clawbacks USING btree (order_id, refund_id);


--
-- Name: referral_daily_due; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX referral_daily_due ON member72_1c1acaaf36d7e39a.referral_daily_liabilities USING btree (eligible_day, order_id);


--
-- Name: referral_daily_one_success_refund; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE UNIQUE INDEX referral_daily_one_success_refund ON member72_1c1acaaf36d7e39a.referral_daily_refund_reservations USING btree (order_id) WHERE (state = 'succeeded'::text);


--
-- Name: referral_daily_one_unresolved_refund; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE UNIQUE INDEX referral_daily_one_unresolved_refund ON member72_1c1acaaf36d7e39a.referral_daily_refund_reservations USING btree (order_id) WHERE (state = ANY (ARRAY['pending'::text, 'unknown'::text]));


--
-- Name: referral_daily_owner; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX referral_daily_owner ON member72_1c1acaaf36d7e39a.referral_daily_terms USING btree (promoter_id, order_id);


--
-- Name: referral_relation_promoter; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX referral_relation_promoter ON member72_1c1acaaf36d7e39a.referral_relations USING btree (promoter_id, invited_id);


--
-- Name: refund_funding_hold_history; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX refund_funding_hold_history ON member72_1c1acaaf36d7e39a.refund_fundings USING btree (hold_id, refund_id);


--
-- Name: refunds_console_merchant_created; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX refunds_console_merchant_created ON member72_1c1acaaf36d7e39a.refunds USING btree (merchant_id, created_at DESC, id DESC);


--
-- Name: refunds_order; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX refunds_order ON member72_1c1acaaf36d7e39a.refunds USING btree (order_id);


--
-- Name: refunds_t1_succeeded; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX refunds_t1_succeeded ON member72_1c1acaaf36d7e39a.refunds USING btree (order_id) INCLUDE (amount) WHERE (status = 'succeeded'::text);


--
-- Name: settlement_auto_claim_budget; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX settlement_auto_claim_budget ON member72_1c1acaaf36d7e39a.settlement_auto_claims USING btree (plan_id, business_date, run_id, claim_seq);


--
-- Name: settlement_plan_original_daily_items; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX settlement_plan_original_daily_items ON member72_1c1acaaf36d7e39a.settlement_plan_items USING btree (merchant_id, run_id, id) WHERE (state = 'created'::text);


--
-- Name: settlement_request_daily; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX settlement_request_daily ON member72_1c1acaaf36d7e39a.ledger_requests USING btree (merchant_id, created_at) WHERE (kind = 'settlements'::text);


--
-- Name: settlement_threshold_day_sequence; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX settlement_threshold_day_sequence ON member72_1c1acaaf36d7e39a.settlement_plan_runs USING btree (plan_id, business_date, threshold_source_sequence DESC) WHERE (threshold_source_version = 1);


--
-- Name: subject_policy_active_scope; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE UNIQUE INDEX subject_policy_active_scope ON member72_1c1acaaf36d7e39a.backoffice_records USING btree (((body ->> 'scope'::text)), ((body ->> 'scope_id'::text))) WHERE ((resource = 'order-subject-policies'::text) AND ((body -> 'enabled'::text) = 'true'::jsonb));


--
-- Name: transfer_biz_no_unique; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE UNIQUE INDEX transfer_biz_no_unique ON member72_1c1acaaf36d7e39a.transfers USING btree (biz_no);


--
-- Name: transfers_console_merchant_id; Type: INDEX; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE INDEX transfers_console_merchant_id ON member72_1c1acaaf36d7e39a.transfers USING btree (merchant_id, id DESC);


--
-- Name: accounts account_balance_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER account_balance_guard AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.accounts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.check_account_balance();


--
-- Name: admin_funds_audit admin_funds_audit_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER admin_funds_audit_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.admin_funds_audit FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: admin_funds_credentials admin_funds_epoch; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER admin_funds_epoch BEFORE UPDATE ON member72_1c1acaaf36d7e39a.admin_funds_credentials FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.bump_admin_funds_epoch();


--
-- Name: alipay_bank_bindings alipay_bank_binding_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER alipay_bank_binding_immutable BEFORE UPDATE ON member72_1c1acaaf36d7e39a.alipay_bank_bindings FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.alipay_bank_binding_guard();


--
-- Name: alipay_bank_bindings alipay_bank_binding_insert; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER alipay_bank_binding_insert BEFORE INSERT ON member72_1c1acaaf36d7e39a.alipay_bank_bindings FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.alipay_bank_binding_insert_guard();


--
-- Name: alipay_bank_bindings alipay_bank_binding_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER alipay_bank_binding_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.alipay_bank_bindings FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: alipay_bank_observations alipay_bank_observation_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER alipay_bank_observation_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.alipay_bank_observations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: application_authorization_code_claims application_authorization_claim_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER application_authorization_claim_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.application_authorization_code_claims FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: application_authorization_events application_authorization_event_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER application_authorization_event_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.application_authorization_events FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: application_authorization_requests application_authorization_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER application_authorization_guard BEFORE UPDATE ON member72_1c1acaaf36d7e39a.application_authorization_requests FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_application_authorization();


--
-- Name: application_authorization_requests application_authorization_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER application_authorization_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.application_authorization_requests FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: oauth_authorization_code_claims authorization_code_claim_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER authorization_code_claim_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.oauth_authorization_code_claims FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: payment_authorization_releases authorization_release_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER authorization_release_guard BEFORE UPDATE ON member72_1c1acaaf36d7e39a.payment_authorization_releases FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_authorization_release();


--
-- Name: payment_authorization_releases authorization_release_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER authorization_release_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.payment_authorization_releases FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: authorization_remaining_claims authorization_remaining_claim_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER authorization_remaining_claim_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.authorization_remaining_claims DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.authorization_remaining_complete();


--
-- Name: authorization_remaining_claims authorization_remaining_claim_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER authorization_remaining_claim_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.authorization_remaining_claims FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: payment_authorization_releases authorization_remaining_parent_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER authorization_remaining_parent_complete AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.payment_authorization_releases DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.authorization_remaining_complete();


--
-- Name: authorization_remaining_sources authorization_remaining_source_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER authorization_remaining_source_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.authorization_remaining_sources DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.authorization_remaining_complete();


--
-- Name: authorization_remaining_sources authorization_remaining_source_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER authorization_remaining_source_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.authorization_remaining_sources FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: backoffice_audit backoffice_audit_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER backoffice_audit_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.backoffice_audit FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: bank_transfer_lifecycle bank_provider_kind_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER bank_provider_kind_immutable BEFORE UPDATE ON member72_1c1acaaf36d7e39a.bank_transfer_lifecycle FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.bank_provider_kind_guard();


--
-- Name: bank_transfer_lifecycle bank_transfer_lifecycle_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER bank_transfer_lifecycle_immutable BEFORE UPDATE ON member72_1c1acaaf36d7e39a.bank_transfer_lifecycle FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.bank_transfer_lifecycle_guard();


--
-- Name: bank_transfer_lifecycle bank_transfer_lifecycle_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER bank_transfer_lifecycle_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.bank_transfer_lifecycle FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: bank_transfer_observations bank_transfer_observations_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER bank_transfer_observations_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.bank_transfer_observations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: bank_transfer_lifecycle bank_unsent_cancel_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER bank_unsent_cancel_guard BEFORE UPDATE ON member72_1c1acaaf36d7e39a.bank_transfer_lifecycle FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.bank_unsent_cancel_guard();


--
-- Name: transfer_batch_executions batch_execution_binding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER batch_execution_binding BEFORE INSERT ON member72_1c1acaaf36d7e39a.transfer_batch_executions FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.batch_execution_binding_guard();


--
-- Name: transfer_batch_execution_claims batch_execution_claim_binding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER batch_execution_claim_binding BEFORE INSERT ON member72_1c1acaaf36d7e39a.transfer_batch_execution_claims FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.batch_execution_claim_guard();


--
-- Name: transfer_batch_execution_claims batch_execution_claim_committed; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER batch_execution_claim_committed AFTER INSERT ON member72_1c1acaaf36d7e39a.transfer_batch_execution_claims DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.batch_execution_claim_committed_guard();


--
-- Name: transfer_batch_execution_claims batch_execution_claim_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER batch_execution_claim_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.transfer_batch_execution_claims FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: transfer_batch_executions batch_execution_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER batch_execution_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.transfer_batch_executions FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: payment_authorizations capture_after_release_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER capture_after_release_guard BEFORE UPDATE ON member72_1c1acaaf36d7e39a.payment_authorizations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_capture_after_release();


--
-- Name: case_comments case_comments_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER case_comments_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.case_comments FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: accounts channel_sharing_account_funding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER channel_sharing_account_funding AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.accounts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN ((new.kind = 'channel_sharing_reserve'::text)) EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_funding_guard();


--
-- Name: accounts channel_sharing_account_identity; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_account_identity BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.accounts FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_account_identity_guard();


--
-- Name: channel_sharing_receivers channel_sharing_active_rule_receiver; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_active_rule_receiver BEFORE UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_receivers FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_active_rule_receiver_guard();


--
-- Name: channel_sharing_completions channel_sharing_completion_finish_exclusion; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_completion_finish_exclusion BEFORE INSERT ON member72_1c1acaaf36d7e39a.channel_sharing_completions FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_completion_finish_exclusion_guard();


--
-- Name: channel_sharing_completions channel_sharing_completion_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_completion_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_completions FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: ledger_entries channel_sharing_entry_funding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER channel_sharing_entry_funding AFTER INSERT ON member72_1c1acaaf36d7e39a.ledger_entries DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_funding_guard();


--
-- Name: channel_sharing_orders channel_sharing_execution_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER channel_sharing_execution_complete AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_orders DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_execution_guard();


--
-- Name: channel_sharing_completions channel_sharing_execution_completion_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER channel_sharing_execution_completion_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.channel_sharing_completions DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_execution_guard();


--
-- Name: channel_sharing_order_items channel_sharing_execution_item_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER channel_sharing_execution_item_complete AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_order_items DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_execution_guard();


--
-- Name: channel_sharing_finishes channel_sharing_finish_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER channel_sharing_finish_complete AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_finishes DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_finish_complete_guard();


--
-- Name: channel_sharing_finishes channel_sharing_finish_identity; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_finish_identity BEFORE INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_finishes FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_finish_identity_guard();


--
-- Name: channel_sharing_finishes channel_sharing_finish_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_finish_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.channel_sharing_finishes FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: channel_sharing_finish_observations channel_sharing_finish_observation_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER channel_sharing_finish_observation_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.channel_sharing_finish_observations DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_finish_complete_guard();


--
-- Name: channel_sharing_finish_observations channel_sharing_finish_observation_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_finish_observation_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_finish_observations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: channel_sharing_fundings channel_sharing_funding_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_funding_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_fundings FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: channel_sharing_fundings channel_sharing_funding_valid; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER channel_sharing_funding_valid AFTER INSERT ON member72_1c1acaaf36d7e39a.channel_sharing_fundings DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_funding_guard();


--
-- Name: order_income_holds channel_sharing_income_hold; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_income_hold BEFORE INSERT ON member72_1c1acaaf36d7e39a.order_income_holds FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_refund_hold_guard();


--
-- Name: order_profit_allocations channel_sharing_internal_allocation_hold; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_internal_allocation_hold BEFORE INSERT ON member72_1c1acaaf36d7e39a.order_profit_allocations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_refund_hold_guard();


--
-- Name: channel_sharing_relation_leases channel_sharing_lease_binding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_lease_binding BEFORE INSERT OR DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_relation_leases FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_lease_guard();


--
-- Name: channel_sharing_observations channel_sharing_observation_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_observation_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_observations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: channel_sharing_receivers channel_sharing_open_payment_receiver; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_open_payment_receiver BEFORE UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_receivers FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_open_payment_receiver_guard();


--
-- Name: channel_sharing_orders channel_sharing_order_binding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_order_binding BEFORE INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_orders FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_order_guard();


--
-- Name: channel_sharing_order_items channel_sharing_order_item_binding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_order_item_binding BEFORE INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_order_items FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_order_item_guard();


--
-- Name: channel_sharing_order_items channel_sharing_order_item_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_order_item_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.channel_sharing_order_items FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: channel_sharing_orders channel_sharing_order_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_order_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.channel_sharing_orders FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: orders channel_sharing_paid_funding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER channel_sharing_paid_funding AFTER UPDATE ON member72_1c1acaaf36d7e39a.orders DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_funding_guard();


--
-- Name: channel_sharing_orders channel_sharing_ps_finish_exclusion; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_ps_finish_exclusion BEFORE INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_orders FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_ps_finish_exclusion_guard();


--
-- Name: channel_sharing_receivers channel_sharing_receiver_binding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_receiver_binding BEFORE INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_receivers FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_receiver_guard();


--
-- Name: channel_sharing_receivers channel_sharing_receiver_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_receiver_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.channel_sharing_receivers FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: channel_sharing_receiver_operations channel_sharing_receiver_operation_binding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_receiver_operation_binding BEFORE INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_receiver_operation_guard();


--
-- Name: channel_sharing_receiver_operations channel_sharing_receiver_operation_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_receiver_operation_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: channel_sharing_receiver_operations channel_sharing_reference_operation_binding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_reference_operation_binding BEFORE INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_reference_operation_guard();


--
-- Name: refunds channel_sharing_refund_hold; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_refund_hold BEFORE INSERT OR UPDATE OF status ON member72_1c1acaaf36d7e39a.refunds FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_refund_hold_guard();


--
-- Name: channel_sharing_relations channel_sharing_relation_binding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_relation_binding BEFORE INSERT OR DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_relations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_relation_guard();


--
-- Name: channel_sharing_relation_leases channel_sharing_relation_complete_leases; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER channel_sharing_relation_complete_leases AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_relation_leases DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_relation_complete();


--
-- Name: channel_sharing_receiver_operations channel_sharing_relation_complete_operations; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER channel_sharing_relation_complete_operations AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_relation_complete();


--
-- Name: channel_sharing_receivers channel_sharing_relation_complete_receivers; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER channel_sharing_relation_complete_receivers AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_receivers DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_relation_complete();


--
-- Name: channel_sharing_relations channel_sharing_relation_complete_registry; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER channel_sharing_relation_complete_registry AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_relations DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_relation_complete();


--
-- Name: channel_sharing_returns channel_sharing_return_binding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_return_binding BEFORE INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_returns FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_return_guard();


--
-- Name: channel_sharing_returns channel_sharing_return_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER channel_sharing_return_complete AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_returns DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_return_complete_guard();


--
-- Name: channel_sharing_return_observations channel_sharing_return_observation_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER channel_sharing_return_observation_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.channel_sharing_return_observations DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_return_complete_guard();


--
-- Name: channel_sharing_return_observations channel_sharing_return_observations_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_return_observations_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_return_observations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: channel_sharing_returns channel_sharing_returns_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_returns_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.channel_sharing_returns FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: channel_sharing_rule_items channel_sharing_rule_complete_items; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER channel_sharing_rule_complete_items AFTER INSERT ON member72_1c1acaaf36d7e39a.channel_sharing_rule_items DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_rule_complete();


--
-- Name: channel_sharing_rules channel_sharing_rule_complete_parent; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER channel_sharing_rule_complete_parent AFTER INSERT ON member72_1c1acaaf36d7e39a.channel_sharing_rules DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_rule_complete();


--
-- Name: channel_sharing_rule_current channel_sharing_rule_current_binding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_rule_current_binding BEFORE INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_rule_current FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_sharing_rule_current_guard();


--
-- Name: channel_sharing_rule_current channel_sharing_rule_current_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_rule_current_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.channel_sharing_rule_current FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: channel_sharing_rules channel_sharing_rule_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_rule_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_rules FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: channel_sharing_rule_items channel_sharing_rule_item_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_sharing_rule_item_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.channel_sharing_rule_items FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: channel_stop_events channel_stop_event_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER channel_stop_event_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.channel_stop_events DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_stop_complete();


--
-- Name: channel_stop_events channel_stop_event_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_stop_event_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.channel_stop_events FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: channel_stop_heads channel_stop_head_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER channel_stop_head_complete AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.channel_stop_heads DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_stop_complete();


--
-- Name: channel_stop_heads channel_stop_head_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_stop_head_guard BEFORE INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.channel_stop_heads FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_stop_head_guard();


--
-- Name: channel_stop_heads channel_stop_head_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_stop_head_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.channel_stop_heads FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: channel_stop_notice_claims channel_stop_notice_claim_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_stop_notice_claim_guard BEFORE INSERT ON member72_1c1acaaf36d7e39a.channel_stop_notice_claims FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_stop_notice_claim_guard();


--
-- Name: channel_stop_notice_claims channel_stop_notice_claim_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_stop_notice_claim_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.channel_stop_notice_claims FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: channel_stop_events channel_stop_source_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER channel_stop_source_guard BEFORE INSERT ON member72_1c1acaaf36d7e39a.channel_stop_events FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.channel_stop_source_guard();


--
-- Name: console_users console_auth_version; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER console_auth_version BEFORE UPDATE ON member72_1c1acaaf36d7e39a.console_users FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.bump_console_auth_version();


--
-- Name: console_login_audit console_login_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER console_login_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.console_login_audit FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: deposit_action_events deposit_events_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER deposit_events_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.deposit_action_events FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: enrollment_emails enrollment_email_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER enrollment_email_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.enrollment_emails FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: enrollment_invitation_uses enrollment_invitation_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER enrollment_invitation_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.enrollment_invitation_uses FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: identity_lookup_events identity_lookup_event_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER identity_lookup_event_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.identity_lookup_events FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: identity_lookup_requests identity_lookup_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER identity_lookup_guard BEFORE UPDATE ON member72_1c1acaaf36d7e39a.identity_lookup_requests FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_identity_lookup();


--
-- Name: identity_lookup_requests identity_lookup_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER identity_lookup_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.identity_lookup_requests FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: identity_lookup_states identity_lookup_state_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER identity_lookup_state_guard BEFORE UPDATE ON member72_1c1acaaf36d7e39a.identity_lookup_states FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_identity_lookup_state();


--
-- Name: identity_lookup_states identity_lookup_state_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER identity_lookup_state_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.identity_lookup_states FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: order_income_hold_fundings income_funding_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER income_funding_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.order_income_hold_fundings DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.income_funding_complete_guard();


--
-- Name: order_income_hold_fundings income_funding_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER income_funding_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.order_income_hold_fundings FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: order_income_holds income_hold_birth_version; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER income_hold_birth_version BEFORE INSERT ON member72_1c1acaaf36d7e39a.order_income_holds FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.income_funding_birth_version_guard();


--
-- Name: order_income_holds income_hold_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER income_hold_complete AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.order_income_holds DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.income_funding_complete_guard();


--
-- Name: order_income_holds income_hold_funding_version; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER income_hold_funding_version BEFORE UPDATE ON member72_1c1acaaf36d7e39a.order_income_holds FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.income_funding_version_guard();


--
-- Name: order_income_hold_releases income_release_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER income_release_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.order_income_hold_releases DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.income_funding_complete_guard();


--
-- Name: order_income_hold_releases income_release_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER income_release_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.order_income_hold_releases FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: accounts income_reserve_identity; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER income_reserve_identity BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.accounts FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.income_funding_account_identity();


--
-- Name: accounts income_scoped_account_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER income_scoped_account_complete AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.accounts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN ((new.kind = ANY (ARRAY['order_income_reserve'::text, 'order_income_refund_reserve'::text]))) EXECUTE FUNCTION member72_1c1acaaf36d7e39a.income_funding_complete_guard();


--
-- Name: ledger_entries income_scoped_entry_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER income_scoped_entry_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.ledger_entries DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.income_funding_complete_guard();


--
-- Name: journals journal_balanced; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER journal_balanced AFTER INSERT ON member72_1c1acaaf36d7e39a.journals DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.check_journal_balance();


--
-- Name: journals journal_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER journal_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.journals FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: console_users last_super_admin; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER last_super_admin BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.console_users FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_last_super_admin();


--
-- Name: ledger_entries ledger_append_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER ledger_append_guard BEFORE INSERT ON member72_1c1acaaf36d7e39a.ledger_entries FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.check_ledger_append();


--
-- Name: ledger_entries ledger_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER ledger_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.ledger_entries FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: ledger_request_events ledger_request_events_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER ledger_request_events_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.ledger_request_events FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: legacy_import_runs legacy_import_history_birth; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER legacy_import_history_birth BEFORE INSERT ON member72_1c1acaaf36d7e39a.legacy_import_runs FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.legacy_import_history_birth();


--
-- Name: legacy_import_runs legacy_import_manifest_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER legacy_import_manifest_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.legacy_import_runs DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.legacy_refund_manifest_complete();


--
-- Name: legacy_import_runs legacy_import_runs_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER legacy_import_runs_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.legacy_import_runs FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: legacy_refund_history legacy_refund_history_birth; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER legacy_refund_history_birth BEFORE INSERT ON member72_1c1acaaf36d7e39a.legacy_refund_history FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.legacy_refund_history_birth();


--
-- Name: legacy_refund_history legacy_refund_history_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER legacy_refund_history_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.legacy_refund_history DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.legacy_refund_history_complete();


--
-- Name: legacy_refund_history legacy_refund_history_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER legacy_refund_history_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.legacy_refund_history FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: legacy_refund_manifests legacy_refund_manifest_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER legacy_refund_manifest_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.legacy_refund_manifests DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.legacy_refund_manifest_complete();


--
-- Name: legacy_refund_manifests legacy_refund_manifest_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER legacy_refund_manifest_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.legacy_refund_manifests FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: membership_baseline_repairs membership_baseline_repairs_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER membership_baseline_repairs_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.membership_baseline_repairs FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_baseline_repair_mutation();


--
-- Name: membership_purchases membership_purchase_version; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER membership_purchase_version BEFORE INSERT ON member72_1c1acaaf36d7e39a.membership_purchases FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_membership_purchase_version();


--
-- Name: membership_purchases membership_purchases_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER membership_purchases_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.membership_purchases FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: membership_referral_events membership_referral_event_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER membership_referral_event_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.membership_referral_events FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: membership_referral_legacy_purchases membership_referral_legacy_closed; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER membership_referral_legacy_closed BEFORE INSERT OR DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.membership_referral_legacy_purchases FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: membership_referral_policy_audits membership_referral_policy_audit_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER membership_referral_policy_audit_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.membership_referral_policy_audits FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: membership_referral_policies membership_referral_policy_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER membership_referral_policy_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.membership_referral_policies FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: membership_referral_rewards membership_referral_reward_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER membership_referral_reward_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.membership_referral_rewards FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: membership_referral_sources membership_referral_source_birth; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER membership_referral_source_birth BEFORE INSERT ON member72_1c1acaaf36d7e39a.membership_referral_sources FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_membership_referral_birth();


--
-- Name: membership_referral_sources membership_referral_source_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER membership_referral_source_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.membership_referral_sources FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: merchants merchant_group_baseline_sync; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER merchant_group_baseline_sync BEFORE INSERT OR UPDATE OF profile ON member72_1c1acaaf36d7e39a.merchants FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.merchant_group_baseline_guard();


--
-- Name: mini_payment_intents mini_intent_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER mini_intent_guard BEFORE UPDATE ON member72_1c1acaaf36d7e39a.mini_payment_intents FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_oauth_binding();


--
-- Name: mini_payment_intents mini_intent_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER mini_intent_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.mini_payment_intents FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: mini_oauth_states mini_state_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER mini_state_guard BEFORE UPDATE ON member72_1c1acaaf36d7e39a.mini_oauth_states FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_mini_oauth_state();


--
-- Name: mini_oauth_states mini_state_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER mini_state_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.mini_oauth_states FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: oauth_code_claims oauth_code_no_update; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER oauth_code_no_update BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.oauth_code_claims FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: oauth_payment_intents oauth_intent_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER oauth_intent_guard BEFORE UPDATE ON member72_1c1acaaf36d7e39a.oauth_payment_intents FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_oauth_binding();


--
-- Name: oauth_payment_intents oauth_intent_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER oauth_intent_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.oauth_payment_intents FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: oauth_states oauth_state_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER oauth_state_guard BEFORE UPDATE ON member72_1c1acaaf36d7e39a.oauth_states FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_oauth_state();


--
-- Name: oauth_states oauth_state_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER oauth_state_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.oauth_states FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: operation_audit operation_audit_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER operation_audit_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.operation_audit FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: order_reporting order_client_ip_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER order_client_ip_immutable BEFORE UPDATE ON member72_1c1acaaf36d7e39a.order_reporting FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_order_client_ip();


--
-- Name: orders order_fee_snapshot_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER order_fee_snapshot_immutable BEFORE INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.orders FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.order_fee_snapshot_guard();


--
-- Name: order_income_hold_events order_income_events_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER order_income_events_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.order_income_hold_events FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: order_income_holds order_income_hold_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER order_income_hold_guard BEFORE UPDATE ON member72_1c1acaaf36d7e39a.order_income_holds FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_order_income_hold();


--
-- Name: order_income_holds order_income_hold_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER order_income_hold_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.order_income_holds FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: accounts order_income_holding_account_funding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER order_income_holding_account_funding AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.accounts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN ((new.kind = 'order_income_hold'::text)) EXECUTE FUNCTION member72_1c1acaaf36d7e39a.order_income_holding_funding_guard();


--
-- Name: accounts order_income_holding_account_identity; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER order_income_holding_account_identity BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.accounts FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.order_income_holding_account_guard();


--
-- Name: order_income_holds order_income_holding_funding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER order_income_holding_funding AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.order_income_holds DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.order_income_holding_funding_guard();


--
-- Name: refunds order_income_refund_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER order_income_refund_guard BEFORE INSERT OR UPDATE OF status ON member72_1c1acaaf36d7e39a.refunds FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.block_refund_while_income_held();


--
-- Name: order_income_holds order_income_source_snapshot; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER order_income_source_snapshot BEFORE INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.order_income_holds FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.order_income_source_snapshot_guard();


--
-- Name: order_print_origins order_print_origin_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER order_print_origin_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.order_print_origins FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: order_profit_allocations order_profit_allocations_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER order_profit_allocations_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.order_profit_allocations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: order_profit_allocations order_profit_request_evidence; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER order_profit_request_evidence AFTER INSERT ON member72_1c1acaaf36d7e39a.order_profit_allocations DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.order_profit_request_evidence_guard();


--
-- Name: ledger_requests order_profit_review_evidence; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER order_profit_review_evidence AFTER UPDATE ON member72_1c1acaaf36d7e39a.ledger_requests DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.order_profit_request_evidence_guard();


--
-- Name: order_profit_allocations order_profit_source; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER order_profit_source BEFORE INSERT ON member72_1c1acaaf36d7e39a.order_profit_allocations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.order_profit_source_guard();


--
-- Name: orders orders_referral_source_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER orders_referral_source_immutable BEFORE UPDATE ON member72_1c1acaaf36d7e39a.orders FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_order_source_guard();


--
-- Name: page_template_assets page_template_assets_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER page_template_assets_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.page_template_assets FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: payment_authorizations payment_authorization_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER payment_authorization_guard BEFORE UPDATE ON member72_1c1acaaf36d7e39a.payment_authorizations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_payment_authorization();


--
-- Name: payment_authorizations payment_authorization_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER payment_authorization_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.payment_authorizations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: payment_print_sources payment_print_source_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER payment_print_source_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.payment_print_sources FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: preauth_observation_events preauth_observation_event_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER preauth_observation_event_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.preauth_observation_events FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: preauth_observations preauth_observation_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER preauth_observation_guard BEFORE INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.preauth_observations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_preauth_observation();


--
-- Name: preauth_observations preauth_observation_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER preauth_observation_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.preauth_observations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: printing_claims printing_claim_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER printing_claim_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.printing_claims FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: printing_intents printing_intent_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER printing_intent_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.printing_intents DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.printing_intent_complete();


--
-- Name: printing_intents printing_intent_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER printing_intent_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.printing_intents FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: printing_merchant_heads printing_merchant_head_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER printing_merchant_head_guard BEFORE INSERT OR DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.printing_merchant_heads FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.printing_head_guard();


--
-- Name: printing_merchant_configs printing_merchant_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER printing_merchant_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.printing_merchant_configs FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: printing_platform_head printing_platform_head_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER printing_platform_head_guard BEFORE INSERT OR DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.printing_platform_head FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.printing_head_guard();


--
-- Name: printing_platform_configs printing_platform_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER printing_platform_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.printing_platform_configs FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: printing_recoveries printing_recovery_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER printing_recovery_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.printing_recoveries FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: printing_results printing_result_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER printing_result_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.printing_results FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: profile_identity_lookup_events profile_identity_event_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER profile_identity_event_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.profile_identity_lookup_events FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: profile_identity_links profile_identity_link_audit_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER profile_identity_link_audit_complete AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.profile_identity_links DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.check_profile_identity_link_audit();


--
-- Name: profile_identity_link_events profile_identity_link_event_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER profile_identity_link_event_guard BEFORE INSERT OR DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.profile_identity_link_events FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_profile_identity_link_event();


--
-- Name: profile_identity_links profile_identity_link_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER profile_identity_link_guard BEFORE INSERT OR DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.profile_identity_links FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_profile_identity_link();


--
-- Name: profile_identity_lookup_requests profile_identity_lookup_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER profile_identity_lookup_guard BEFORE UPDATE ON member72_1c1acaaf36d7e39a.profile_identity_lookup_requests FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_profile_identity_lookup();


--
-- Name: profile_identity_lookup_requests profile_identity_lookup_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER profile_identity_lookup_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.profile_identity_lookup_requests FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: provider_attempt_accounts provider_attempt_account_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_attempt_account_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.provider_attempt_accounts FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: provider_attempt_accounts provider_attempt_account_sharing; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER provider_attempt_account_sharing AFTER INSERT ON member72_1c1acaaf36d7e39a.provider_attempt_accounts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.provider_attempt_sharing_guard();


--
-- Name: provider_attempts provider_attempt_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_attempt_guard BEFORE UPDATE ON member72_1c1acaaf36d7e39a.provider_attempts FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_provider_attempt();


--
-- Name: provider_attempt_identities provider_attempt_identities_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_attempt_identities_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.provider_attempt_identities FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: provider_attempts provider_attempt_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_attempt_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.provider_attempts FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: provider_attempts provider_attempt_original_identity; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_attempt_original_identity BEFORE UPDATE ON member72_1c1acaaf36d7e39a.provider_attempts FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.provider_attempt_original_identity_guard();


--
-- Name: provider_attempts provider_attempt_route; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_attempt_route BEFORE INSERT ON member72_1c1acaaf36d7e39a.provider_attempts FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_provider_route_attempt();


--
-- Name: provider_attempt_sharing provider_attempt_sharing_birth; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_attempt_sharing_birth BEFORE INSERT ON member72_1c1acaaf36d7e39a.provider_attempt_sharing FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.provider_attempt_sharing_birth_guard();


--
-- Name: provider_attempt_sharing provider_attempt_sharing_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER provider_attempt_sharing_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.provider_attempt_sharing DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.provider_attempt_sharing_guard();


--
-- Name: provider_attempt_sharing provider_attempt_sharing_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_attempt_sharing_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.provider_attempt_sharing FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: provider_attempt_sharing_items provider_attempt_sharing_item_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_attempt_sharing_item_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.provider_attempt_sharing_items FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: provider_attempt_sharing_items provider_attempt_sharing_items_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER provider_attempt_sharing_items_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.provider_attempt_sharing_items DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.provider_attempt_sharing_guard();


--
-- Name: provider_attempt_sharing provider_attempt_sharing_purpose; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_attempt_sharing_purpose BEFORE INSERT ON member72_1c1acaaf36d7e39a.provider_attempt_sharing FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.provider_attempt_sharing_purpose_guard();


--
-- Name: provider_attempts provider_attempt_subject; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_attempt_subject BEFORE INSERT ON member72_1c1acaaf36d7e39a.provider_attempts FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_provider_subject_channel();


--
-- Name: provider_operations provider_operation_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_operation_guard BEFORE UPDATE ON member72_1c1acaaf36d7e39a.provider_operations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_provider_operation();


--
-- Name: provider_operations provider_operation_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_operation_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.provider_operations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: provider_reconciliations provider_reconciliation_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_reconciliation_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.provider_reconciliations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: provider_refund_result_evidence provider_refund_result_birth; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_refund_result_birth BEFORE INSERT ON member72_1c1acaaf36d7e39a.provider_refund_result_evidence FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.provider_refund_result_birth_guard();


--
-- Name: provider_refund_result_evidence provider_refund_result_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_refund_result_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.provider_refund_result_evidence FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: provider_refund_result_evidence provider_refund_result_requires_ledger; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER provider_refund_result_requires_ledger AFTER INSERT ON member72_1c1acaaf36d7e39a.provider_refund_result_evidence DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.provider_refund_result_guard();


--
-- Name: provider_route_assignments provider_route_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_route_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.provider_route_assignments FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: provider_subject_snapshots provider_subject_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_subject_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.provider_subject_snapshots FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: provider_transfer_accounts provider_transfer_account_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_transfer_account_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.provider_transfer_accounts FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: provider_transfer_attempts provider_transfer_attempt_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_transfer_attempt_immutable BEFORE UPDATE ON member72_1c1acaaf36d7e39a.provider_transfer_attempts FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.transfer_attempt_guard();


--
-- Name: provider_transfer_attempts provider_transfer_attempt_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_transfer_attempt_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.provider_transfer_attempts FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: provider_transfer_policies provider_transfer_policies_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_transfer_policies_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.provider_transfer_policies FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: provider_transfer_proofs provider_transfer_proof_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_transfer_proof_immutable BEFORE UPDATE ON member72_1c1acaaf36d7e39a.provider_transfer_proofs FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.transfer_proof_guard();


--
-- Name: provider_transfer_proofs provider_transfer_proof_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER provider_transfer_proof_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.provider_transfer_proofs FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: recharge_intents recharge_intent_birth; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER recharge_intent_birth BEFORE INSERT ON member72_1c1acaaf36d7e39a.recharge_intents FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.recharge_intent_birth_guard();


--
-- Name: recharge_intents recharge_intent_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER recharge_intent_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.recharge_intents FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: referral_clawback_audits referral_clawback_audit_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_clawback_audit_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.referral_clawback_audits FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: referral_refund_clawbacks referral_clawback_update; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_clawback_update BEFORE INSERT OR DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.referral_refund_clawbacks FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_clawback_update_guard();


--
-- Name: referral_refund_clawbacks referral_clawback_valid; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER referral_clawback_valid AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.referral_refund_clawbacks DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_clawback_guard();


--
-- Name: referral_daily_liabilities referral_daily_activation_source; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER referral_daily_activation_source AFTER INSERT ON member72_1c1acaaf36d7e39a.referral_daily_liabilities DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_referral_daily_activation_source();


--
-- Name: referral_daily_liabilities referral_daily_activation_tx; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_daily_activation_tx BEFORE INSERT ON member72_1c1acaaf36d7e39a.referral_daily_liabilities FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_referral_daily_activation_tx();


--
-- Name: referral_daily_awards referral_daily_award_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_daily_award_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.referral_daily_awards FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: referral_daily_awards referral_daily_award_source; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER referral_daily_award_source AFTER INSERT ON member72_1c1acaaf36d7e39a.referral_daily_awards DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_referral_daily_award();


--
-- Name: referral_daily_events referral_daily_event_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_daily_event_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.referral_daily_events FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: referral_daily_liabilities referral_daily_liability_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_daily_liability_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.referral_daily_liabilities FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: referral_rewards referral_daily_original_reward; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER referral_daily_original_reward AFTER INSERT ON member72_1c1acaaf36d7e39a.referral_rewards DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_original_daily_reward();


--
-- Name: referral_daily_refund_reservations referral_daily_refund_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_daily_refund_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.referral_daily_refund_reservations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: referral_daily_refund_reservations referral_daily_refund_source; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER referral_daily_refund_source AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.referral_daily_refund_reservations DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_referral_daily_refund_source();


--
-- Name: referral_daily_refund_reservations referral_daily_refund_transition; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_daily_refund_transition BEFORE INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.referral_daily_refund_reservations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_referral_daily_refund_transition();


--
-- Name: referral_daily_terms referral_daily_terms_birth; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_daily_terms_birth BEFORE INSERT ON member72_1c1acaaf36d7e39a.referral_daily_terms FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.guard_referral_daily_terms_birth();


--
-- Name: referral_daily_terms referral_daily_terms_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_daily_terms_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.referral_daily_terms FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: ledger_entries referral_escrow_entry_valid; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER referral_escrow_entry_valid AFTER INSERT ON member72_1c1acaaf36d7e39a.ledger_entries DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_clawback_guard();


--
-- Name: accounts referral_escrow_identity; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_escrow_identity BEFORE UPDATE ON member72_1c1acaaf36d7e39a.accounts FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_escrow_identity_guard();


--
-- Name: accounts referral_escrow_valid; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER referral_escrow_valid AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.accounts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN ((new.kind = 'referral_clawback_reserve'::text)) EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_clawback_guard();


--
-- Name: merchants referral_merchant_birth; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_merchant_birth BEFORE UPDATE OF id, created_at ON member72_1c1acaaf36d7e39a.merchants FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_merchant_birth_guard();


--
-- Name: referral_policy_audits referral_policy_audit_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_policy_audit_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.referral_policy_audits FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: referral_policy_heads referral_policy_head_consistency; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_policy_head_consistency BEFORE INSERT OR DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.referral_policy_heads FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_policy_head_guard();


--
-- Name: referral_policies referral_policy_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_policy_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.referral_policies FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: referral_policies referral_policy_requires_audit; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER referral_policy_requires_audit AFTER INSERT ON member72_1c1acaaf36d7e39a.referral_policies DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_policy_audit_guard();


--
-- Name: referral_profit_costs referral_profit_birth; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_profit_birth BEFORE INSERT ON member72_1c1acaaf36d7e39a.referral_profit_costs FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_profit_birth_guard();


--
-- Name: referral_profit_costs referral_profit_cost_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_profit_cost_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.referral_profit_costs FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: referral_profit_costs referral_profit_cost_requires_terms; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER referral_profit_cost_requires_terms AFTER INSERT ON member72_1c1acaaf36d7e39a.referral_profit_costs DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_profit_terms_guard();


--
-- Name: referral_profit_cost_events referral_profit_event_consistency; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_profit_event_consistency BEFORE INSERT ON member72_1c1acaaf36d7e39a.referral_profit_cost_events FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_profit_event_guard();


--
-- Name: referral_profit_cost_events referral_profit_event_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_profit_event_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.referral_profit_cost_events FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: referral_profit_costs referral_profit_requires_audit; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER referral_profit_requires_audit AFTER INSERT ON member72_1c1acaaf36d7e39a.referral_profit_costs DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_profit_audit_guard();


--
-- Name: referral_order_terms referral_profit_terms_require_cost; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER referral_profit_terms_require_cost AFTER INSERT ON member72_1c1acaaf36d7e39a.referral_order_terms DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_profit_terms_guard();


--
-- Name: recharge_intents referral_recharge_purpose; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_recharge_purpose BEFORE INSERT ON member72_1c1acaaf36d7e39a.recharge_intents FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_recharge_purpose_guard();


--
-- Name: refunds referral_refund_clawback_required; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER referral_refund_clawback_required AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.refunds DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_clawback_guard();


--
-- Name: referral_relations referral_relation_birth; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_relation_birth BEFORE INSERT ON member72_1c1acaaf36d7e39a.referral_relations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_relation_birth_guard();


--
-- Name: referral_relations referral_relation_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER referral_relation_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.referral_relations DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_relation_complete_guard();


--
-- Name: referral_relations referral_relation_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_relation_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.referral_relations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: referral_reward_audits referral_reward_audit_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_reward_audit_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.referral_reward_audits FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: referral_rewards referral_reward_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_reward_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.referral_rewards FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: referral_rewards referral_reward_requires_proof; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER referral_reward_requires_proof AFTER INSERT ON member72_1c1acaaf36d7e39a.referral_rewards DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_reward_guard();


--
-- Name: referral_order_terms referral_terms_birth; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_terms_birth BEFORE INSERT ON member72_1c1acaaf36d7e39a.referral_order_terms FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_terms_birth_guard();


--
-- Name: referral_order_terms referral_terms_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_terms_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.referral_order_terms FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: referral_tokens referral_token_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER referral_token_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.referral_tokens DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_token_complete_guard();


--
-- Name: referral_token_current referral_token_current_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER referral_token_current_complete AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.referral_token_current DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_token_complete_guard();


--
-- Name: referral_token_current referral_token_current_identity; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_token_current_identity BEFORE INSERT OR DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.referral_token_current FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.referral_token_current_guard();


--
-- Name: referral_tokens referral_token_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER referral_token_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.referral_tokens FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: refunds refund_allocation_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER refund_allocation_immutable BEFORE INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.refunds FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.refund_allocation_guard();


--
-- Name: refund_fundings refund_funding_birth; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER refund_funding_birth BEFORE INSERT ON member72_1c1acaaf36d7e39a.refund_fundings FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.refund_funding_birth_guard();


--
-- Name: refunds refund_funding_birth_version; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER refund_funding_birth_version BEFORE INSERT ON member72_1c1acaaf36d7e39a.refunds FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.income_funding_birth_version_guard();


--
-- Name: refund_fundings refund_funding_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER refund_funding_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.refund_fundings DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.income_funding_complete_guard();


--
-- Name: refund_fundings refund_funding_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER refund_funding_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.refund_fundings FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: refund_funding_resolutions refund_funding_result_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER refund_funding_result_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.refund_funding_resolutions DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.income_funding_complete_guard();


--
-- Name: refund_funding_resolutions refund_funding_result_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER refund_funding_result_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.refund_funding_resolutions FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: refunds refund_funding_version; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER refund_funding_version BEFORE UPDATE ON member72_1c1acaaf36d7e39a.refunds FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.income_funding_version_guard();


--
-- Name: refunds refund_requires_terminal_result; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER refund_requires_terminal_result AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.refunds DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.refund_required_result_guard();


--
-- Name: refunds refund_source_required; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER refund_source_required AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.refunds DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.income_funding_complete_guard();


--
-- Name: refunds refunds_audit; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER refunds_audit AFTER INSERT OR UPDATE OF status ON member72_1c1acaaf36d7e39a.refunds FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.audit_operation_transition();


--
-- Name: scan_cancellation_claims scan_cancellation_claim_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER scan_cancellation_claim_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.scan_cancellation_claims FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: scan_cancellation_claims scan_cancellation_claim_source; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER scan_cancellation_claim_source AFTER INSERT ON member72_1c1acaaf36d7e39a.scan_cancellation_claims DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.scan_cancellation_guard();


--
-- Name: scan_cancellation_results scan_cancellation_result_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER scan_cancellation_result_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.scan_cancellation_results FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: scan_cancellation_results scan_cancellation_result_source; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER scan_cancellation_result_source AFTER INSERT ON member72_1c1acaaf36d7e39a.scan_cancellation_results DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.scan_cancellation_guard();


--
-- Name: scan_recovery_eligibility scan_recovery_eligibility_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER scan_recovery_eligibility_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.scan_recovery_eligibility FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: scan_recovery_eligibility scan_recovery_eligibility_source; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER scan_recovery_eligibility_source AFTER INSERT ON member72_1c1acaaf36d7e39a.scan_recovery_eligibility DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.scan_recovery_eligibility_guard();


--
-- Name: scan_recovery_origins scan_recovery_origin_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER scan_recovery_origin_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.scan_recovery_origins FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: scan_recovery_origins scan_recovery_origin_source; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER scan_recovery_origin_source AFTER INSERT ON member72_1c1acaaf36d7e39a.scan_recovery_origins DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.scan_recovery_origin_guard();


--
-- Name: scan_recovery_query_events scan_recovery_query_event_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER scan_recovery_query_event_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.scan_recovery_query_events FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: scan_recovery_query_events scan_recovery_query_event_source; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER scan_recovery_query_event_source AFTER INSERT ON member72_1c1acaaf36d7e39a.scan_recovery_query_events DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.scan_recovery_query_guard();


--
-- Name: scan_recovery_query_heads scan_recovery_query_head_source; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER scan_recovery_query_head_source AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.scan_recovery_query_heads DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.scan_recovery_query_guard();


--
-- Name: accounts settlement_account_funding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_account_funding AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.accounts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW WHEN ((new.kind = 'settlement_reserve'::text)) EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_funding_deferred_guard();


--
-- Name: accounts settlement_account_identity; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_account_identity BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.accounts FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_account_identity_guard();


--
-- Name: provider_transfer_attempts settlement_attempt_funding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_attempt_funding AFTER UPDATE ON member72_1c1acaaf36d7e39a.provider_transfer_attempts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_transfer_funding_guard();


--
-- Name: settlement_auto_authorizations settlement_auto_authority_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_auto_authority_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_auto_authorizations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: settlement_auto_claims settlement_auto_claim_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_auto_claim_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_auto_claims FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: settlement_auto_claims settlement_auto_claim_requires_source; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_auto_claim_requires_source AFTER INSERT ON member72_1c1acaaf36d7e39a.settlement_auto_claims DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_auto_claim_complete();


--
-- Name: settlement_auto_heads settlement_auto_head; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_auto_head BEFORE INSERT OR DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_auto_heads FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_auto_head_guard();


--
-- Name: settlement_payouts settlement_auto_payout_source; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_auto_payout_source BEFORE UPDATE ON member72_1c1acaaf36d7e39a.settlement_payouts FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_auto_payout_source_guard();


--
-- Name: settlement_auto_revocations settlement_auto_revoke_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_auto_revoke_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_auto_revocations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: settlement_bank_payouts settlement_bank_binding_funding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_bank_binding_funding AFTER INSERT ON member72_1c1acaaf36d7e39a.settlement_bank_payouts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_funding_deferred_guard();


--
-- Name: bank_transfer_lifecycle settlement_bank_lifecycle_funding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_bank_lifecycle_funding AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.bank_transfer_lifecycle DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_transfer_funding_guard();


--
-- Name: settlement_bank_payouts settlement_bank_payout_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_bank_payout_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_bank_payouts FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: settlement_recipient_configs settlement_config_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_config_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_recipient_configs FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: ledger_entries settlement_entry_funding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_entry_funding AFTER INSERT ON member72_1c1acaaf36d7e39a.ledger_entries DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_funding_deferred_guard();


--
-- Name: settlement_fundings settlement_funding_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_funding_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_fundings FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: settlement_fundings settlement_funding_valid; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_funding_valid AFTER INSERT ON member72_1c1acaaf36d7e39a.settlement_fundings DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_funding_deferred_guard();


--
-- Name: settlement_payout_cancellations settlement_payout_cancel; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_payout_cancel BEFORE INSERT ON member72_1c1acaaf36d7e39a.settlement_payout_cancellations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_payout_cancel_guard();


--
-- Name: settlement_payout_cancellations settlement_payout_cancellation_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_payout_cancellation_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_payout_cancellations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: settlement_payout_events settlement_payout_event_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_payout_event_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_payout_events FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: settlement_payouts settlement_payout_funding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_payout_funding AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_payouts DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_funding_deferred_guard();


--
-- Name: settlement_payouts settlement_payout_identity; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_payout_identity BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_payouts FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_payout_identity_guard();


--
-- Name: settlement_plan_authorizations settlement_plan_authorization_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_plan_authorization_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.settlement_plan_authorizations DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_plan_config_complete();


--
-- Name: settlement_plan_authorizations settlement_plan_authorization_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_plan_authorization_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_plan_authorizations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: settlement_plan_budget_uses settlement_plan_budget_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_plan_budget_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.settlement_plan_budget_uses DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_plan_item_complete();


--
-- Name: settlement_plan_budget_uses settlement_plan_budget_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_plan_budget_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_plan_budget_uses FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: settlement_plans settlement_plan_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_plan_complete AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_plans DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_plan_config_complete();


--
-- Name: settlement_plans settlement_plan_head; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_plan_head BEFORE INSERT OR DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_plans FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_plan_head_guard();


--
-- Name: settlement_scheduled_intents settlement_plan_intent_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_plan_intent_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.settlement_scheduled_intents DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_plan_item_complete();


--
-- Name: settlement_scheduled_intents settlement_plan_intent_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_plan_intent_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_scheduled_intents FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: settlement_plan_items settlement_plan_item_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_plan_item_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.settlement_plan_items DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_plan_item_complete();


--
-- Name: settlement_plan_items settlement_plan_item_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_plan_item_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_plan_items FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: ledger_requests settlement_plan_request_birth; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_plan_request_birth BEFORE UPDATE OF settlement_plan_item_id ON member72_1c1acaaf36d7e39a.ledger_requests FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_plan_request_birth();


--
-- Name: ledger_requests settlement_plan_request_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_plan_request_complete AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.ledger_requests DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_plan_item_complete();


--
-- Name: ledger_request_events settlement_plan_request_event_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_plan_request_event_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.ledger_request_events DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_plan_item_complete();


--
-- Name: settlement_plan_revocations settlement_plan_revocation_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_plan_revocation_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.settlement_plan_revocations DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_plan_config_complete();


--
-- Name: settlement_plan_revocations settlement_plan_revocation_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_plan_revocation_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_plan_revocations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: settlement_plan_runs settlement_plan_run_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_plan_run_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.settlement_plan_runs DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_plan_run_complete();


--
-- Name: settlement_plan_runs settlement_plan_run_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_plan_run_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_plan_runs FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_threshold_run_source_guard();


--
-- Name: settlement_plan_versions settlement_plan_version_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_plan_version_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.settlement_plan_versions DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_plan_config_complete();


--
-- Name: settlement_plan_versions settlement_plan_version_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_plan_version_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_plan_versions FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: settlement_schedule_preferences settlement_preference_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_preference_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.settlement_schedule_preferences DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_plan_config_complete();


--
-- Name: settlement_schedule_preference_heads settlement_preference_head; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_preference_head BEFORE INSERT OR DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_schedule_preference_heads FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_preference_head_guard();


--
-- Name: settlement_schedule_preferences settlement_preference_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_preference_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_schedule_preferences FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: settlement_recipients settlement_recipient_binding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_recipient_binding BEFORE INSERT ON member72_1c1acaaf36d7e39a.settlement_recipients FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_recipient_binding_guard();


--
-- Name: settlement_recipients settlement_recipient_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_recipient_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_recipients FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: ledger_requests settlement_request_funding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_request_funding AFTER UPDATE ON member72_1c1acaaf36d7e39a.ledger_requests DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_funding_deferred_guard();


--
-- Name: settlement_request_terms settlement_request_terms_binding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_request_terms_binding BEFORE INSERT ON member72_1c1acaaf36d7e39a.settlement_request_terms FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_request_terms_guard();


--
-- Name: settlement_request_terms settlement_request_terms_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_request_terms_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_request_terms FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: settlement_threshold_intents settlement_threshold_intent_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_threshold_intent_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.settlement_threshold_intents DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_plan_item_complete();


--
-- Name: settlement_threshold_intents settlement_threshold_intent_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_threshold_intent_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_threshold_intents FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: settlement_plan_versions settlement_threshold_mode_family; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_threshold_mode_family BEFORE INSERT ON member72_1c1acaaf36d7e39a.settlement_plan_versions FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_threshold_mode_family_guard();


--
-- Name: settlement_plan_items settlement_threshold_selected_items_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_threshold_selected_items_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.settlement_plan_items DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_threshold_selection_complete();


--
-- Name: settlement_threshold_selections settlement_threshold_selection_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_threshold_selection_complete AFTER INSERT ON member72_1c1acaaf36d7e39a.settlement_threshold_selections DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_threshold_selection_complete();


--
-- Name: settlement_threshold_selections settlement_threshold_selection_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER settlement_threshold_selection_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_threshold_selections FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: settlement_plan_runs settlement_threshold_source_complete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_threshold_source_complete AFTER INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.settlement_plan_runs DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_threshold_selection_complete();


--
-- Name: transfers settlement_transfer_funding; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE CONSTRAINT TRIGGER settlement_transfer_funding AFTER UPDATE ON member72_1c1acaaf36d7e39a.transfers DEFERRABLE INITIALLY DEFERRED FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.settlement_transfer_funding_guard();


--
-- Name: transfer_batch_events transfer_batch_events_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER transfer_batch_events_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.transfer_batch_events FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: transfer_batch_items transfer_batch_item_guard; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER transfer_batch_item_guard BEFORE UPDATE ON member72_1c1acaaf36d7e39a.transfer_batch_items FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.transfer_batch_item_guard();


--
-- Name: transfer_batch_items transfer_batch_items_no_delete; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER transfer_batch_items_no_delete BEFORE DELETE ON member72_1c1acaaf36d7e39a.transfer_batch_items FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: transfer_batches transfer_batches_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER transfer_batches_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.transfer_batches FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: transfers transfer_resolution_time_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER transfer_resolution_time_immutable BEFORE INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.transfers FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.transfer_resolution_time_guard();


--
-- Name: transfers transfer_snapshot_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER transfer_snapshot_immutable BEFORE INSERT OR UPDATE ON member72_1c1acaaf36d7e39a.transfers FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.transfer_snapshot_guard();


--
-- Name: transfer_unsent_cancellations transfer_unsent_cancel_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER transfer_unsent_cancel_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.transfer_unsent_cancellations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: transfer_unsent_cancellations transfer_unsent_cancel_proof; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER transfer_unsent_cancel_proof BEFORE INSERT ON member72_1c1acaaf36d7e39a.transfer_unsent_cancellations FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.transfer_unsent_cancel_proof_guard();


--
-- Name: transfers transfers_audit; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER transfers_audit AFTER INSERT OR UPDATE OF status ON member72_1c1acaaf36d7e39a.transfers FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.audit_operation_transition();


--
-- Name: verified_payment_receipts verified_payment_receipts_immutable; Type: TRIGGER; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

CREATE TRIGGER verified_payment_receipts_immutable BEFORE DELETE OR UPDATE ON member72_1c1acaaf36d7e39a.verified_payment_receipts FOR EACH ROW EXECUTE FUNCTION member72_1c1acaaf36d7e39a.reject_ledger_mutation();


--
-- Name: admin_funds_challenges admin_funds_challenges_username_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.admin_funds_challenges
    ADD CONSTRAINT admin_funds_challenges_username_fkey FOREIGN KEY (username) REFERENCES member72_1c1acaaf36d7e39a.admin_funds_credentials(username);


--
-- Name: admin_funds_credentials admin_funds_credentials_username_role_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.admin_funds_credentials
    ADD CONSTRAINT admin_funds_credentials_username_role_fkey FOREIGN KEY (username, role) REFERENCES member72_1c1acaaf36d7e39a.console_users(username, role) ON DELETE CASCADE;


--
-- Name: admin_funds_grants admin_funds_grants_challenge_hash_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.admin_funds_grants
    ADD CONSTRAINT admin_funds_grants_challenge_hash_fkey FOREIGN KEY (challenge_hash) REFERENCES member72_1c1acaaf36d7e39a.admin_funds_challenges(challenge_hash);


--
-- Name: admin_funds_grants admin_funds_grants_username_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.admin_funds_grants
    ADD CONSTRAINT admin_funds_grants_username_fkey FOREIGN KEY (username) REFERENCES member72_1c1acaaf36d7e39a.admin_funds_credentials(username);


--
-- Name: alipay_bank_bindings alipay_bank_bindings_transfer_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.alipay_bank_bindings
    ADD CONSTRAINT alipay_bank_bindings_transfer_id_fkey FOREIGN KEY (transfer_id) REFERENCES member72_1c1acaaf36d7e39a.bank_transfer_lifecycle(transfer_id);


--
-- Name: alipay_bank_observations alipay_bank_observations_transfer_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.alipay_bank_observations
    ADD CONSTRAINT alipay_bank_observations_transfer_id_fkey FOREIGN KEY (transfer_id) REFERENCES member72_1c1acaaf36d7e39a.alipay_bank_bindings(transfer_id);


--
-- Name: application_authorization_code_claims application_authorization_code_claims_request_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.application_authorization_code_claims
    ADD CONSTRAINT application_authorization_code_claims_request_id_fkey FOREIGN KEY (request_id) REFERENCES member72_1c1acaaf36d7e39a.application_authorization_requests(id);


--
-- Name: application_authorization_events application_authorization_events_request_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.application_authorization_events
    ADD CONSTRAINT application_authorization_events_request_id_fkey FOREIGN KEY (request_id) REFERENCES member72_1c1acaaf36d7e39a.application_authorization_requests(id);


--
-- Name: application_authorization_requests application_authorization_requests_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.application_authorization_requests
    ADD CONSTRAINT application_authorization_requests_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: authorization_remaining_claims authorization_remaining_claim_source_id_order_id_source_re_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.authorization_remaining_claims
    ADD CONSTRAINT authorization_remaining_claim_source_id_order_id_source_re_fkey FOREIGN KEY (source_id, order_id, source_revision) REFERENCES member72_1c1acaaf36d7e39a.authorization_remaining_sources(id, order_id, revision);


--
-- Name: authorization_remaining_claims authorization_remaining_claims_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.authorization_remaining_claims
    ADD CONSTRAINT authorization_remaining_claims_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.payment_authorization_releases(order_id);


--
-- Name: payment_authorization_releases authorization_remaining_head_source; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.payment_authorization_releases
    ADD CONSTRAINT authorization_remaining_head_source FOREIGN KEY (remaining_source_id, order_id, remaining_source_revision) REFERENCES member72_1c1acaaf36d7e39a.authorization_remaining_sources(id, order_id, revision) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authorization_remaining_sources authorization_remaining_sources_observation_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.authorization_remaining_sources
    ADD CONSTRAINT authorization_remaining_sources_observation_id_fkey FOREIGN KEY (observation_id) REFERENCES member72_1c1acaaf36d7e39a.preauth_observations(id);


--
-- Name: authorization_remaining_sources authorization_remaining_sources_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.authorization_remaining_sources
    ADD CONSTRAINT authorization_remaining_sources_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.payment_authorization_releases(order_id);


--
-- Name: authorization_remaining_sources authorization_remaining_sources_previous_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.authorization_remaining_sources
    ADD CONSTRAINT authorization_remaining_sources_previous_id_fkey FOREIGN KEY (previous_id) REFERENCES member72_1c1acaaf36d7e39a.authorization_remaining_sources(id);


--
-- Name: backoffice_records backoffice_records_owner_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.backoffice_records
    ADD CONSTRAINT backoffice_records_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: bank_transfer_lifecycle bank_transfer_lifecycle_transfer_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.bank_transfer_lifecycle
    ADD CONSTRAINT bank_transfer_lifecycle_transfer_id_fkey FOREIGN KEY (transfer_id) REFERENCES member72_1c1acaaf36d7e39a.provider_transfer_attempts(transfer_id);


--
-- Name: bank_transfer_observations bank_transfer_observations_transfer_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.bank_transfer_observations
    ADD CONSTRAINT bank_transfer_observations_transfer_id_fkey FOREIGN KEY (transfer_id) REFERENCES member72_1c1acaaf36d7e39a.bank_transfer_lifecycle(transfer_id);


--
-- Name: case_comments case_comments_record_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.case_comments
    ADD CONSTRAINT case_comments_record_id_fkey FOREIGN KEY (record_id) REFERENCES member72_1c1acaaf36d7e39a.backoffice_records(id);


--
-- Name: channel_sharing_completions channel_sharing_completions_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_completions
    ADD CONSTRAINT channel_sharing_completions_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_fundings(order_id);


--
-- Name: channel_sharing_completions channel_sharing_completions_release_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_completions
    ADD CONSTRAINT channel_sharing_completions_release_journal_id_fkey FOREIGN KEY (release_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: channel_sharing_completions channel_sharing_completions_sharing_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_completions
    ADD CONSTRAINT channel_sharing_completions_sharing_id_fkey FOREIGN KEY (sharing_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_orders(id);


--
-- Name: channel_sharing_finishes channel_sharing_finish_observation; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_finishes
    ADD CONSTRAINT channel_sharing_finish_observation FOREIGN KEY (last_observation_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_finish_observations(id);


--
-- Name: channel_sharing_finish_observations channel_sharing_finish_observations_finish_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_finish_observations
    ADD CONSTRAINT channel_sharing_finish_observations_finish_id_fkey FOREIGN KEY (finish_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_finishes(id);


--
-- Name: channel_sharing_finishes channel_sharing_finishes_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_finishes
    ADD CONSTRAINT channel_sharing_finishes_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: channel_sharing_finishes channel_sharing_finishes_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_finishes
    ADD CONSTRAINT channel_sharing_finishes_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_fundings(order_id);


--
-- Name: channel_sharing_finishes channel_sharing_finishes_original_sharing_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_finishes
    ADD CONSTRAINT channel_sharing_finishes_original_sharing_id_fkey FOREIGN KEY (original_sharing_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_orders(id);


--
-- Name: channel_sharing_finishes channel_sharing_finishes_previous_finish_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_finishes
    ADD CONSTRAINT channel_sharing_finishes_previous_finish_id_fkey FOREIGN KEY (previous_finish_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_finishes(id);


--
-- Name: channel_sharing_finishes channel_sharing_finishes_release_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_finishes
    ADD CONSTRAINT channel_sharing_finishes_release_journal_id_fkey FOREIGN KEY (release_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: channel_sharing_fundings channel_sharing_fundings_account_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_fundings
    ADD CONSTRAINT channel_sharing_fundings_account_id_fkey FOREIGN KEY (account_id) REFERENCES member72_1c1acaaf36d7e39a.accounts(id);


--
-- Name: channel_sharing_fundings channel_sharing_fundings_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_fundings
    ADD CONSTRAINT channel_sharing_fundings_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.provider_attempt_sharing(order_id);


--
-- Name: channel_sharing_fundings channel_sharing_fundings_reserve_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_fundings
    ADD CONSTRAINT channel_sharing_fundings_reserve_journal_id_fkey FOREIGN KEY (reserve_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: channel_sharing_orders channel_sharing_last_observation; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_orders
    ADD CONSTRAINT channel_sharing_last_observation FOREIGN KEY (last_observation_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_observations(id);


--
-- Name: channel_sharing_observations channel_sharing_observations_sharing_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_observations
    ADD CONSTRAINT channel_sharing_observations_sharing_id_fkey FOREIGN KEY (sharing_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_orders(id);


--
-- Name: channel_sharing_order_items channel_sharing_order_items_last_observation_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_order_items
    ADD CONSTRAINT channel_sharing_order_items_last_observation_id_fkey FOREIGN KEY (last_observation_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_observations(id);


--
-- Name: channel_sharing_order_items channel_sharing_order_items_paid_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_order_items
    ADD CONSTRAINT channel_sharing_order_items_paid_journal_id_fkey FOREIGN KEY (paid_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: channel_sharing_order_items channel_sharing_order_items_receiver_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_order_items
    ADD CONSTRAINT channel_sharing_order_items_receiver_id_fkey FOREIGN KEY (receiver_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_receivers(id);


--
-- Name: channel_sharing_order_items channel_sharing_order_items_sharing_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_order_items
    ADD CONSTRAINT channel_sharing_order_items_sharing_id_fkey FOREIGN KEY (sharing_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_orders(id);


--
-- Name: channel_sharing_orders channel_sharing_orders_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_orders
    ADD CONSTRAINT channel_sharing_orders_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: channel_sharing_orders channel_sharing_orders_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_orders
    ADD CONSTRAINT channel_sharing_orders_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_fundings(order_id);


--
-- Name: channel_sharing_receivers channel_sharing_receiver_last_operation; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_receivers
    ADD CONSTRAINT channel_sharing_receiver_last_operation FOREIGN KEY (last_operation_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations(id);


--
-- Name: channel_sharing_receiver_operations channel_sharing_receiver_operations_receiver_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations
    ADD CONSTRAINT channel_sharing_receiver_operations_receiver_id_fkey FOREIGN KEY (receiver_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_receivers(id);


--
-- Name: channel_sharing_receiver_operations channel_sharing_receiver_operations_reference_operation_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations
    ADD CONSTRAINT channel_sharing_receiver_operations_reference_operation_id_fkey FOREIGN KEY (reference_operation_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations(id);


--
-- Name: channel_sharing_receiver_operations channel_sharing_receiver_operations_relation_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations
    ADD CONSTRAINT channel_sharing_receiver_operations_relation_id_fkey FOREIGN KEY (relation_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_relations(id);


--
-- Name: channel_sharing_receivers channel_sharing_receivers_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_receivers
    ADD CONSTRAINT channel_sharing_receivers_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: channel_sharing_relation_leases channel_sharing_relation_leases_bind_operation_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_relation_leases
    ADD CONSTRAINT channel_sharing_relation_leases_bind_operation_id_fkey FOREIGN KEY (bind_operation_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations(id);


--
-- Name: channel_sharing_relation_leases channel_sharing_relation_leases_receiver_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_relation_leases
    ADD CONSTRAINT channel_sharing_relation_leases_receiver_id_fkey FOREIGN KEY (receiver_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_receivers(id);


--
-- Name: channel_sharing_relation_leases channel_sharing_relation_leases_relation_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_relation_leases
    ADD CONSTRAINT channel_sharing_relation_leases_relation_id_fkey FOREIGN KEY (relation_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_relations(id);


--
-- Name: channel_sharing_relation_leases channel_sharing_relation_leases_released_by_operation_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_relation_leases
    ADD CONSTRAINT channel_sharing_relation_leases_released_by_operation_id_fkey FOREIGN KEY (released_by_operation_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations(id);


--
-- Name: channel_sharing_relations channel_sharing_relations_bound_operation_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_relations
    ADD CONSTRAINT channel_sharing_relations_bound_operation_id_fkey FOREIGN KEY (bound_operation_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations(id);


--
-- Name: channel_sharing_relations channel_sharing_relations_last_operation_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_relations
    ADD CONSTRAINT channel_sharing_relations_last_operation_id_fkey FOREIGN KEY (last_operation_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_receiver_operations(id);


--
-- Name: channel_sharing_relations channel_sharing_relations_source_receiver_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_relations
    ADD CONSTRAINT channel_sharing_relations_source_receiver_id_fkey FOREIGN KEY (source_receiver_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_receivers(id);


--
-- Name: channel_sharing_returns channel_sharing_return_last_observation; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_returns
    ADD CONSTRAINT channel_sharing_return_last_observation FOREIGN KEY (last_observation_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_return_observations(id);


--
-- Name: channel_sharing_return_observations channel_sharing_return_observations_return_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_return_observations
    ADD CONSTRAINT channel_sharing_return_observations_return_id_fkey FOREIGN KEY (return_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_returns(id);


--
-- Name: channel_sharing_returns channel_sharing_returns_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_returns
    ADD CONSTRAINT channel_sharing_returns_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: channel_sharing_returns channel_sharing_returns_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_returns
    ADD CONSTRAINT channel_sharing_returns_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: channel_sharing_returns channel_sharing_returns_paid_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_returns
    ADD CONSTRAINT channel_sharing_returns_paid_journal_id_fkey FOREIGN KEY (paid_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: channel_sharing_returns channel_sharing_returns_sharing_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_returns
    ADD CONSTRAINT channel_sharing_returns_sharing_id_fkey FOREIGN KEY (sharing_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_orders(id);


--
-- Name: channel_sharing_returns channel_sharing_returns_sharing_id_receiver_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_returns
    ADD CONSTRAINT channel_sharing_returns_sharing_id_receiver_id_fkey FOREIGN KEY (sharing_id, receiver_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_order_items(sharing_id, receiver_id);


--
-- Name: channel_sharing_rule_current channel_sharing_rule_current_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_rule_current
    ADD CONSTRAINT channel_sharing_rule_current_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: channel_sharing_rule_current channel_sharing_rule_current_rule_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_rule_current
    ADD CONSTRAINT channel_sharing_rule_current_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_rules(id);


--
-- Name: channel_sharing_rule_items channel_sharing_rule_items_receiver_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_rule_items
    ADD CONSTRAINT channel_sharing_rule_items_receiver_id_fkey FOREIGN KEY (receiver_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_receivers(id);


--
-- Name: channel_sharing_rule_items channel_sharing_rule_items_rule_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_rule_items
    ADD CONSTRAINT channel_sharing_rule_items_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_rules(id);


--
-- Name: channel_sharing_rules channel_sharing_rules_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_sharing_rules
    ADD CONSTRAINT channel_sharing_rules_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: channel_stop_events channel_stop_events_claim_sequence_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_stop_events
    ADD CONSTRAINT channel_stop_events_claim_sequence_fkey FOREIGN KEY (claim_sequence) REFERENCES member72_1c1acaaf36d7e39a.settlement_auto_claims(claim_seq);


--
-- Name: channel_stop_events channel_stop_events_previous_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_stop_events
    ADD CONSTRAINT channel_stop_events_previous_id_fkey FOREIGN KEY (previous_id) REFERENCES member72_1c1acaaf36d7e39a.channel_stop_events(id);


--
-- Name: channel_stop_events channel_stop_events_request_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_stop_events
    ADD CONSTRAINT channel_stop_events_request_id_fkey FOREIGN KEY (request_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_payouts(request_id);


--
-- Name: channel_stop_events channel_stop_events_transfer_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_stop_events
    ADD CONSTRAINT channel_stop_events_transfer_id_fkey FOREIGN KEY (transfer_id) REFERENCES member72_1c1acaaf36d7e39a.transfers(id);


--
-- Name: channel_stop_heads channel_stop_heads_event_id_channel_id_revision_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_stop_heads
    ADD CONSTRAINT channel_stop_heads_event_id_channel_id_revision_fkey FOREIGN KEY (event_id, channel_id, revision) REFERENCES member72_1c1acaaf36d7e39a.channel_stop_events(id, channel_id, revision) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: channel_stop_notice_claims channel_stop_notice_claims_event_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_stop_notice_claims
    ADD CONSTRAINT channel_stop_notice_claims_event_id_fkey FOREIGN KEY (event_id) REFERENCES member72_1c1acaaf36d7e39a.channel_stop_events(id);


--
-- Name: channel_stop_notice_claims channel_stop_notice_claims_job_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.channel_stop_notice_claims
    ADD CONSTRAINT channel_stop_notice_claims_job_id_fkey FOREIGN KEY (job_id) REFERENCES member72_1c1acaaf36d7e39a.jobs(id);


--
-- Name: console_mfa console_mfa_username_role_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.console_mfa
    ADD CONSTRAINT console_mfa_username_role_fkey FOREIGN KEY (username, role) REFERENCES member72_1c1acaaf36d7e39a.console_users(username, role) ON DELETE CASCADE;


--
-- Name: console_session_issuers console_session_issuers_token_hash_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.console_session_issuers
    ADD CONSTRAINT console_session_issuers_token_hash_fkey FOREIGN KEY (token_hash) REFERENCES member72_1c1acaaf36d7e39a.console_sessions(token_hash) ON DELETE CASCADE;


--
-- Name: console_sessions console_sessions_username_role_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.console_sessions
    ADD CONSTRAINT console_sessions_username_role_fkey FOREIGN KEY (username, role) REFERENCES member72_1c1acaaf36d7e39a.console_users(username, role) ON DELETE CASCADE;


--
-- Name: console_sso_grants console_sso_grants_target_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.console_sso_grants
    ADD CONSTRAINT console_sso_grants_target_id_fkey FOREIGN KEY (target_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: deposit_action_events deposit_action_events_action_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.deposit_action_events
    ADD CONSTRAINT deposit_action_events_action_id_fkey FOREIGN KEY (action_id) REFERENCES member72_1c1acaaf36d7e39a.deposit_actions(id);


--
-- Name: deposit_actions deposit_actions_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.deposit_actions
    ADD CONSTRAINT deposit_actions_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: enrollment_challenges enrollment_challenges_target_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.enrollment_challenges
    ADD CONSTRAINT enrollment_challenges_target_merchant_id_fkey FOREIGN KEY (target_merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: enrollment_emails enrollment_emails_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.enrollment_emails
    ADD CONSTRAINT enrollment_emails_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: enrollment_emails enrollment_emails_username_role_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.enrollment_emails
    ADD CONSTRAINT enrollment_emails_username_role_fkey FOREIGN KEY (username, role) REFERENCES member72_1c1acaaf36d7e39a.console_users(username, role);


--
-- Name: enrollment_invitation_uses enrollment_invitation_uses_invitation_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.enrollment_invitation_uses
    ADD CONSTRAINT enrollment_invitation_uses_invitation_id_fkey FOREIGN KEY (invitation_id) REFERENCES member72_1c1acaaf36d7e39a.backoffice_records(id);


--
-- Name: enrollment_invitation_uses enrollment_invitation_uses_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.enrollment_invitation_uses
    ADD CONSTRAINT enrollment_invitation_uses_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: identity_lookup_events identity_lookup_events_request_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.identity_lookup_events
    ADD CONSTRAINT identity_lookup_events_request_id_fkey FOREIGN KEY (request_id) REFERENCES member72_1c1acaaf36d7e39a.identity_lookup_requests(id);


--
-- Name: identity_lookup_requests identity_lookup_requests_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.identity_lookup_requests
    ADD CONSTRAINT identity_lookup_requests_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: identity_lookup_states identity_lookup_states_request_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.identity_lookup_states
    ADD CONSTRAINT identity_lookup_states_request_id_fkey FOREIGN KEY (request_id) REFERENCES member72_1c1acaaf36d7e39a.identity_lookup_requests(id);


--
-- Name: inbox inbox_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.inbox
    ADD CONSTRAINT inbox_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: ledger_entries ledger_entries_account_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.ledger_entries
    ADD CONSTRAINT ledger_entries_account_id_fkey FOREIGN KEY (account_id) REFERENCES member72_1c1acaaf36d7e39a.accounts(id);


--
-- Name: ledger_entries ledger_entries_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.ledger_entries
    ADD CONSTRAINT ledger_entries_journal_id_fkey FOREIGN KEY (journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: ledger_request_events ledger_request_events_request_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.ledger_request_events
    ADD CONSTRAINT ledger_request_events_request_id_fkey FOREIGN KEY (request_id) REFERENCES member72_1c1acaaf36d7e39a.ledger_requests(id);


--
-- Name: ledger_requests ledger_requests_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.ledger_requests
    ADD CONSTRAINT ledger_requests_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: ledger_requests ledger_requests_recipient_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.ledger_requests
    ADD CONSTRAINT ledger_requests_recipient_id_fkey FOREIGN KEY (recipient_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: ledger_requests ledger_requests_settlement_plan_item_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.ledger_requests
    ADD CONSTRAINT ledger_requests_settlement_plan_item_id_fkey FOREIGN KEY (settlement_plan_item_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plan_items(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: legacy_refund_history legacy_refund_history_export_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.legacy_refund_history
    ADD CONSTRAINT legacy_refund_history_export_id_fkey FOREIGN KEY (export_id) REFERENCES member72_1c1acaaf36d7e39a.legacy_import_runs(export_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: legacy_refund_history legacy_refund_history_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.legacy_refund_history
    ADD CONSTRAINT legacy_refund_history_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: legacy_refund_history legacy_refund_history_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.legacy_refund_history
    ADD CONSTRAINT legacy_refund_history_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: legacy_refund_manifests legacy_refund_manifests_export_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.legacy_refund_manifests
    ADD CONSTRAINT legacy_refund_manifests_export_id_fkey FOREIGN KEY (export_id) REFERENCES member72_1c1acaaf36d7e39a.legacy_import_runs(export_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: membership_baseline_repairs membership_baseline_repairs_audit_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_baseline_repairs
    ADD CONSTRAINT membership_baseline_repairs_audit_id_fkey FOREIGN KEY (audit_id) REFERENCES member72_1c1acaaf36d7e39a.backoffice_audit(id);


--
-- Name: membership_baseline_repairs membership_baseline_repairs_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_baseline_repairs
    ADD CONSTRAINT membership_baseline_repairs_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: membership_purchases membership_purchases_group_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_purchases
    ADD CONSTRAINT membership_purchases_group_id_fkey FOREIGN KEY (group_id) REFERENCES member72_1c1acaaf36d7e39a.backoffice_records(id);


--
-- Name: membership_purchases membership_purchases_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_purchases
    ADD CONSTRAINT membership_purchases_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: membership_referral_events membership_referral_events_purchase_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_events
    ADD CONSTRAINT membership_referral_events_purchase_id_fkey FOREIGN KEY (purchase_id) REFERENCES member72_1c1acaaf36d7e39a.membership_referral_sources(purchase_id);


--
-- Name: membership_referral_legacy_purchases membership_referral_legacy_purchases_purchase_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_legacy_purchases
    ADD CONSTRAINT membership_referral_legacy_purchases_purchase_id_fkey FOREIGN KEY (purchase_id) REFERENCES member72_1c1acaaf36d7e39a.membership_purchases(id);


--
-- Name: membership_referral_policy_audits membership_referral_policy_audits_policy_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_policy_audits
    ADD CONSTRAINT membership_referral_policy_audits_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES member72_1c1acaaf36d7e39a.membership_referral_policies(id);


--
-- Name: membership_referral_policy_heads membership_referral_policy_heads_policy_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_policy_heads
    ADD CONSTRAINT membership_referral_policy_heads_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES member72_1c1acaaf36d7e39a.membership_referral_policies(id);


--
-- Name: membership_referral_rewards membership_referral_rewards_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_rewards
    ADD CONSTRAINT membership_referral_rewards_journal_id_fkey FOREIGN KEY (journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: membership_referral_rewards membership_referral_rewards_promoter_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_rewards
    ADD CONSTRAINT membership_referral_rewards_promoter_id_fkey FOREIGN KEY (promoter_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: membership_referral_rewards membership_referral_rewards_purchase_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_rewards
    ADD CONSTRAINT membership_referral_rewards_purchase_id_fkey FOREIGN KEY (purchase_id) REFERENCES member72_1c1acaaf36d7e39a.membership_referral_sources(purchase_id);


--
-- Name: membership_referral_sources membership_referral_sources_income_account_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_sources
    ADD CONSTRAINT membership_referral_sources_income_account_id_fkey FOREIGN KEY (income_account_id) REFERENCES member72_1c1acaaf36d7e39a.accounts(id);


--
-- Name: membership_referral_sources membership_referral_sources_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_sources
    ADD CONSTRAINT membership_referral_sources_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: membership_referral_sources membership_referral_sources_promoter_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_sources
    ADD CONSTRAINT membership_referral_sources_promoter_id_fkey FOREIGN KEY (promoter_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: membership_referral_sources membership_referral_sources_purchase_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_sources
    ADD CONSTRAINT membership_referral_sources_purchase_id_fkey FOREIGN KEY (purchase_id) REFERENCES member72_1c1acaaf36d7e39a.membership_purchases(id);


--
-- Name: membership_referral_sources membership_referral_sources_purchase_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_sources
    ADD CONSTRAINT membership_referral_sources_purchase_journal_id_fkey FOREIGN KEY (purchase_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: membership_referral_sources membership_referral_sources_relation_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.membership_referral_sources
    ADD CONSTRAINT membership_referral_sources_relation_id_fkey FOREIGN KEY (relation_id) REFERENCES member72_1c1acaaf36d7e39a.referral_relations(id);


--
-- Name: memberships memberships_group_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.memberships
    ADD CONSTRAINT memberships_group_id_fkey FOREIGN KEY (group_id) REFERENCES member72_1c1acaaf36d7e39a.backoffice_records(id);


--
-- Name: memberships memberships_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.memberships
    ADD CONSTRAINT memberships_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: mini_oauth_states mini_oauth_states_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.mini_oauth_states
    ADD CONSTRAINT mini_oauth_states_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: mini_oauth_states mini_oauth_states_order_id_channel_id_provider_app_id_meth_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.mini_oauth_states
    ADD CONSTRAINT mini_oauth_states_order_id_channel_id_provider_app_id_meth_fkey FOREIGN KEY (order_id, channel_id, provider, app_id, method, purpose, path) REFERENCES member72_1c1acaaf36d7e39a.mini_payment_intents(order_id, channel_id, provider, app_id, method, purpose, path);


--
-- Name: mini_oauth_states mini_oauth_states_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.mini_oauth_states
    ADD CONSTRAINT mini_oauth_states_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.mini_payment_intents(order_id);


--
-- Name: mini_payment_intents mini_payment_intents_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.mini_payment_intents
    ADD CONSTRAINT mini_payment_intents_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: notification_resend_requests notification_resend_requests_job_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.notification_resend_requests
    ADD CONSTRAINT notification_resend_requests_job_id_fkey FOREIGN KEY (job_id) REFERENCES member72_1c1acaaf36d7e39a.jobs(id);


--
-- Name: notification_resend_requests notification_resend_requests_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.notification_resend_requests
    ADD CONSTRAINT notification_resend_requests_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: notification_send_controls notification_send_controls_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.notification_send_controls
    ADD CONSTRAINT notification_send_controls_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: oauth_code_claims oauth_code_claims_state_hash_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.oauth_code_claims
    ADD CONSTRAINT oauth_code_claims_state_hash_fkey FOREIGN KEY (state_hash) REFERENCES member72_1c1acaaf36d7e39a.oauth_states(state_hash);


--
-- Name: oauth_code_claims oauth_code_mini_state_binding; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.oauth_code_claims
    ADD CONSTRAINT oauth_code_mini_state_binding FOREIGN KEY (mini_state_hash, provider, app_id) REFERENCES member72_1c1acaaf36d7e39a.mini_oauth_states(state_hash, provider, app_id);


--
-- Name: oauth_payment_intents oauth_payment_intents_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.oauth_payment_intents
    ADD CONSTRAINT oauth_payment_intents_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: oauth_states oauth_states_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.oauth_states
    ADD CONSTRAINT oauth_states_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: oauth_states oauth_states_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.oauth_states
    ADD CONSTRAINT oauth_states_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.oauth_payment_intents(order_id);


--
-- Name: operation_audit operation_audit_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.operation_audit
    ADD CONSTRAINT operation_audit_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: order_income_hold_events order_income_hold_events_hold_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_income_hold_events
    ADD CONSTRAINT order_income_hold_events_hold_id_fkey FOREIGN KEY (hold_id) REFERENCES member72_1c1acaaf36d7e39a.order_income_holds(id);


--
-- Name: order_income_hold_fundings order_income_hold_fundings_account_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_income_hold_fundings
    ADD CONSTRAINT order_income_hold_fundings_account_id_fkey FOREIGN KEY (account_id) REFERENCES member72_1c1acaaf36d7e39a.accounts(id);


--
-- Name: order_income_hold_fundings order_income_hold_fundings_funding_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_income_hold_fundings
    ADD CONSTRAINT order_income_hold_fundings_funding_journal_id_fkey FOREIGN KEY (funding_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: order_income_hold_fundings order_income_hold_fundings_hold_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_income_hold_fundings
    ADD CONSTRAINT order_income_hold_fundings_hold_id_fkey FOREIGN KEY (hold_id) REFERENCES member72_1c1acaaf36d7e39a.order_income_holds(id);


--
-- Name: order_income_hold_fundings order_income_hold_fundings_legacy_pool_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_income_hold_fundings
    ADD CONSTRAINT order_income_hold_fundings_legacy_pool_journal_id_fkey FOREIGN KEY (legacy_pool_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: order_income_hold_fundings order_income_hold_fundings_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_income_hold_fundings
    ADD CONSTRAINT order_income_hold_fundings_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: order_income_hold_fundings order_income_hold_fundings_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_income_hold_fundings
    ADD CONSTRAINT order_income_hold_fundings_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: order_income_hold_releases order_income_hold_releases_hold_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_income_hold_releases
    ADD CONSTRAINT order_income_hold_releases_hold_id_fkey FOREIGN KEY (hold_id) REFERENCES member72_1c1acaaf36d7e39a.order_income_hold_fundings(hold_id);


--
-- Name: order_income_hold_releases order_income_hold_releases_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_income_hold_releases
    ADD CONSTRAINT order_income_hold_releases_journal_id_fkey FOREIGN KEY (journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: order_income_holds order_income_holds_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_income_holds
    ADD CONSTRAINT order_income_holds_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: order_income_holds order_income_holds_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_income_holds
    ADD CONSTRAINT order_income_holds_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: order_print_origins order_print_origins_collection_code_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_print_origins
    ADD CONSTRAINT order_print_origins_collection_code_id_fkey FOREIGN KEY (collection_code_id) REFERENCES member72_1c1acaaf36d7e39a.backoffice_records(id);


--
-- Name: order_print_origins order_print_origins_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_print_origins
    ADD CONSTRAINT order_print_origins_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: order_profit_allocations order_profit_allocations_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_profit_allocations
    ADD CONSTRAINT order_profit_allocations_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: order_profit_allocations order_profit_allocations_request_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_profit_allocations
    ADD CONSTRAINT order_profit_allocations_request_id_fkey FOREIGN KEY (request_id) REFERENCES member72_1c1acaaf36d7e39a.ledger_requests(id);


--
-- Name: order_profit_allocations order_profit_allocations_rule_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_profit_allocations
    ADD CONSTRAINT order_profit_allocations_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES member72_1c1acaaf36d7e39a.backoffice_records(id);


--
-- Name: order_reporting order_reporting_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.order_reporting
    ADD CONSTRAINT order_reporting_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: orders orders_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.orders
    ADD CONSTRAINT orders_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: page_template_configs page_template_configs_kind_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.page_template_configs
    ADD CONSTRAINT page_template_configs_kind_fkey FOREIGN KEY (kind) REFERENCES member72_1c1acaaf36d7e39a.page_template_heads(kind);


--
-- Name: payment_authorization_releases payment_authorization_releases_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.payment_authorization_releases
    ADD CONSTRAINT payment_authorization_releases_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.payment_authorizations(order_id);


--
-- Name: payment_authorizations payment_authorizations_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.payment_authorizations
    ADD CONSTRAINT payment_authorizations_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: payment_print_sources payment_print_sources_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.payment_print_sources
    ADD CONSTRAINT payment_print_sources_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: payment_print_sources payment_print_sources_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.payment_print_sources
    ADD CONSTRAINT payment_print_sources_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: preauth_observation_events preauth_observation_events_observation_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.preauth_observation_events
    ADD CONSTRAINT preauth_observation_events_observation_id_fkey FOREIGN KEY (observation_id) REFERENCES member72_1c1acaaf36d7e39a.preauth_observations(id);


--
-- Name: preauth_observations preauth_observations_attempt_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.preauth_observations
    ADD CONSTRAINT preauth_observations_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES member72_1c1acaaf36d7e39a.provider_attempts(id);


--
-- Name: preauth_observations preauth_observations_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.preauth_observations
    ADD CONSTRAINT preauth_observations_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: preauth_observations preauth_observations_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.preauth_observations
    ADD CONSTRAINT preauth_observations_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: printing_claims printing_claims_intent_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_claims
    ADD CONSTRAINT printing_claims_intent_id_fkey FOREIGN KEY (intent_id) REFERENCES member72_1c1acaaf36d7e39a.printing_intents(id);


--
-- Name: printing_intents printing_intents_merchant_config_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_intents
    ADD CONSTRAINT printing_intents_merchant_config_id_fkey FOREIGN KEY (merchant_config_id) REFERENCES member72_1c1acaaf36d7e39a.printing_merchant_configs(id);


--
-- Name: printing_intents printing_intents_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_intents
    ADD CONSTRAINT printing_intents_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: printing_intents printing_intents_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_intents
    ADD CONSTRAINT printing_intents_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.payment_print_sources(order_id);


--
-- Name: printing_intents printing_intents_platform_config_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_intents
    ADD CONSTRAINT printing_intents_platform_config_id_fkey FOREIGN KEY (platform_config_id) REFERENCES member72_1c1acaaf36d7e39a.printing_platform_configs(id);


--
-- Name: printing_merchant_configs printing_merchant_configs_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_merchant_configs
    ADD CONSTRAINT printing_merchant_configs_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: printing_merchant_heads printing_merchant_heads_config_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_merchant_heads
    ADD CONSTRAINT printing_merchant_heads_config_id_fkey FOREIGN KEY (config_id) REFERENCES member72_1c1acaaf36d7e39a.printing_merchant_configs(id);


--
-- Name: printing_merchant_heads printing_merchant_heads_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_merchant_heads
    ADD CONSTRAINT printing_merchant_heads_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: printing_platform_head printing_platform_head_config_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_platform_head
    ADD CONSTRAINT printing_platform_head_config_id_fkey FOREIGN KEY (config_id) REFERENCES member72_1c1acaaf36d7e39a.printing_platform_configs(id);


--
-- Name: printing_recoveries printing_recoveries_expected_task_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_recoveries
    ADD CONSTRAINT printing_recoveries_expected_task_id_fkey FOREIGN KEY (expected_task_id) REFERENCES member72_1c1acaaf36d7e39a.jobs(id);


--
-- Name: printing_recoveries printing_recoveries_intent_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_recoveries
    ADD CONSTRAINT printing_recoveries_intent_id_fkey FOREIGN KEY (intent_id) REFERENCES member72_1c1acaaf36d7e39a.printing_intents(id);


--
-- Name: printing_recoveries printing_recoveries_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_recoveries
    ADD CONSTRAINT printing_recoveries_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: printing_recoveries printing_recoveries_new_task_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_recoveries
    ADD CONSTRAINT printing_recoveries_new_task_id_fkey FOREIGN KEY (new_task_id) REFERENCES member72_1c1acaaf36d7e39a.jobs(id);


--
-- Name: printing_results printing_results_intent_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.printing_results
    ADD CONSTRAINT printing_results_intent_id_fkey FOREIGN KEY (intent_id) REFERENCES member72_1c1acaaf36d7e39a.printing_claims(intent_id);


--
-- Name: profile_identity_link_events profile_identity_link_events_request_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.profile_identity_link_events
    ADD CONSTRAINT profile_identity_link_events_request_id_fkey FOREIGN KEY (request_id) REFERENCES member72_1c1acaaf36d7e39a.profile_identity_links(request_id);


--
-- Name: profile_identity_links profile_identity_links_request_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.profile_identity_links
    ADD CONSTRAINT profile_identity_links_request_id_fkey FOREIGN KEY (request_id) REFERENCES member72_1c1acaaf36d7e39a.profile_identity_lookup_requests(id);


--
-- Name: profile_identity_lookup_events profile_identity_lookup_events_request_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.profile_identity_lookup_events
    ADD CONSTRAINT profile_identity_lookup_events_request_id_fkey FOREIGN KEY (request_id) REFERENCES member72_1c1acaaf36d7e39a.profile_identity_lookup_requests(id);


--
-- Name: profile_identity_lookup_requests profile_identity_lookup_requests_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.profile_identity_lookup_requests
    ADD CONSTRAINT profile_identity_lookup_requests_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: provider_attempt_accounts provider_attempt_accounts_attempt_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_attempt_accounts
    ADD CONSTRAINT provider_attempt_accounts_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES member72_1c1acaaf36d7e39a.provider_attempts(id);


--
-- Name: provider_attempt_identities provider_attempt_identities_attempt_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_attempt_identities
    ADD CONSTRAINT provider_attempt_identities_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES member72_1c1acaaf36d7e39a.provider_attempts(id);


--
-- Name: provider_attempt_sharing provider_attempt_sharing_attempt_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_attempt_sharing
    ADD CONSTRAINT provider_attempt_sharing_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES member72_1c1acaaf36d7e39a.provider_attempts(id);


--
-- Name: provider_attempt_sharing_items provider_attempt_sharing_items_attempt_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_attempt_sharing_items
    ADD CONSTRAINT provider_attempt_sharing_items_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES member72_1c1acaaf36d7e39a.provider_attempt_sharing(attempt_id);


--
-- Name: provider_attempt_sharing_items provider_attempt_sharing_items_receiver_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_attempt_sharing_items
    ADD CONSTRAINT provider_attempt_sharing_items_receiver_id_fkey FOREIGN KEY (receiver_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_receivers(id);


--
-- Name: provider_attempt_sharing provider_attempt_sharing_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_attempt_sharing
    ADD CONSTRAINT provider_attempt_sharing_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: provider_attempt_sharing provider_attempt_sharing_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_attempt_sharing
    ADD CONSTRAINT provider_attempt_sharing_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: provider_attempt_sharing provider_attempt_sharing_rule_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_attempt_sharing
    ADD CONSTRAINT provider_attempt_sharing_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES member72_1c1acaaf36d7e39a.channel_sharing_rules(id);


--
-- Name: provider_attempts provider_attempts_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_attempts
    ADD CONSTRAINT provider_attempts_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: provider_operations provider_operations_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_operations
    ADD CONSTRAINT provider_operations_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: provider_operations provider_operations_refund_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_operations
    ADD CONSTRAINT provider_operations_refund_id_fkey FOREIGN KEY (refund_id) REFERENCES member72_1c1acaaf36d7e39a.refunds(id);


--
-- Name: provider_reconciliations provider_reconciliations_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_reconciliations
    ADD CONSTRAINT provider_reconciliations_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: provider_refund_result_evidence provider_refund_result_evidence_operation_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_refund_result_evidence
    ADD CONSTRAINT provider_refund_result_evidence_operation_id_fkey FOREIGN KEY (operation_id) REFERENCES member72_1c1acaaf36d7e39a.provider_operations(id);


--
-- Name: provider_refund_result_evidence provider_refund_result_evidence_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_refund_result_evidence
    ADD CONSTRAINT provider_refund_result_evidence_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: provider_refund_result_evidence provider_refund_result_evidence_refund_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_refund_result_evidence
    ADD CONSTRAINT provider_refund_result_evidence_refund_id_fkey FOREIGN KEY (refund_id) REFERENCES member72_1c1acaaf36d7e39a.refunds(id);


--
-- Name: provider_route_assignments provider_route_assignments_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_route_assignments
    ADD CONSTRAINT provider_route_assignments_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: provider_route_assignments provider_route_assignments_rule_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_route_assignments
    ADD CONSTRAINT provider_route_assignments_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES member72_1c1acaaf36d7e39a.backoffice_records(id);


--
-- Name: provider_route_counters provider_route_counters_rule_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_route_counters
    ADD CONSTRAINT provider_route_counters_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES member72_1c1acaaf36d7e39a.backoffice_records(id);


--
-- Name: provider_subject_snapshots provider_subject_snapshots_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_subject_snapshots
    ADD CONSTRAINT provider_subject_snapshots_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: provider_transfer_accounts provider_transfer_accounts_transfer_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_transfer_accounts
    ADD CONSTRAINT provider_transfer_accounts_transfer_id_fkey FOREIGN KEY (transfer_id) REFERENCES member72_1c1acaaf36d7e39a.provider_transfer_attempts(transfer_id);


--
-- Name: provider_transfer_attempts provider_transfer_attempts_transfer_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_transfer_attempts
    ADD CONSTRAINT provider_transfer_attempts_transfer_id_fkey FOREIGN KEY (transfer_id) REFERENCES member72_1c1acaaf36d7e39a.transfers(id);


--
-- Name: provider_transfer_policies provider_transfer_policies_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_transfer_policies
    ADD CONSTRAINT provider_transfer_policies_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: provider_transfer_policies provider_transfer_policies_transfer_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_transfer_policies
    ADD CONSTRAINT provider_transfer_policies_transfer_id_fkey FOREIGN KEY (transfer_id) REFERENCES member72_1c1acaaf36d7e39a.provider_transfer_attempts(transfer_id);


--
-- Name: provider_transfer_proofs provider_transfer_proofs_transfer_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.provider_transfer_proofs
    ADD CONSTRAINT provider_transfer_proofs_transfer_id_fkey FOREIGN KEY (transfer_id) REFERENCES member72_1c1acaaf36d7e39a.provider_transfer_attempts(transfer_id);


--
-- Name: recharge_intents recharge_intents_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.recharge_intents
    ADD CONSTRAINT recharge_intents_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: referral_clawback_audits referral_clawback_audits_refund_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_clawback_audits
    ADD CONSTRAINT referral_clawback_audits_refund_id_fkey FOREIGN KEY (refund_id) REFERENCES member72_1c1acaaf36d7e39a.referral_refund_clawbacks(refund_id);


--
-- Name: referral_daily_awards referral_daily_awards_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_awards
    ADD CONSTRAINT referral_daily_awards_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.referral_daily_liabilities(order_id);


--
-- Name: referral_daily_awards referral_daily_awards_release_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_awards
    ADD CONSTRAINT referral_daily_awards_release_journal_id_fkey FOREIGN KEY (release_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: referral_daily_awards referral_daily_awards_reward_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_awards
    ADD CONSTRAINT referral_daily_awards_reward_id_fkey FOREIGN KEY (reward_id) REFERENCES member72_1c1acaaf36d7e39a.referral_rewards(id);


--
-- Name: referral_daily_events referral_daily_events_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_events
    ADD CONSTRAINT referral_daily_events_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.referral_daily_terms(order_id);


--
-- Name: referral_daily_liabilities referral_daily_liabilities_fees_account_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_liabilities
    ADD CONSTRAINT referral_daily_liabilities_fees_account_id_fkey FOREIGN KEY (fees_account_id) REFERENCES member72_1c1acaaf36d7e39a.accounts(id);


--
-- Name: referral_daily_liabilities referral_daily_liabilities_funding_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_liabilities
    ADD CONSTRAINT referral_daily_liabilities_funding_journal_id_fkey FOREIGN KEY (funding_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: referral_daily_liabilities referral_daily_liabilities_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_liabilities
    ADD CONSTRAINT referral_daily_liabilities_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.referral_daily_terms(order_id);


--
-- Name: referral_daily_liabilities referral_daily_liabilities_pending_account_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_liabilities
    ADD CONSTRAINT referral_daily_liabilities_pending_account_id_fkey FOREIGN KEY (pending_account_id) REFERENCES member72_1c1acaaf36d7e39a.accounts(id);


--
-- Name: referral_daily_refund_reservations referral_daily_refund_reserva_release_remainder_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_refund_reservations
    ADD CONSTRAINT referral_daily_refund_reserva_release_remainder_journal_id_fkey FOREIGN KEY (release_remainder_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: referral_daily_refund_reservations referral_daily_refund_reserva_restore_contribution_journal_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_refund_reservations
    ADD CONSTRAINT referral_daily_refund_reserva_restore_contribution_journal_fkey FOREIGN KEY (restore_contribution_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: referral_daily_refund_reservations referral_daily_refund_reservati_restore_pending_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_refund_reservations
    ADD CONSTRAINT referral_daily_refund_reservati_restore_pending_journal_id_fkey FOREIGN KEY (restore_pending_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: referral_daily_refund_reservations referral_daily_refund_reservations_contribution_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_refund_reservations
    ADD CONSTRAINT referral_daily_refund_reservations_contribution_journal_id_fkey FOREIGN KEY (contribution_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: referral_daily_refund_reservations referral_daily_refund_reservations_escrow_account_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_refund_reservations
    ADD CONSTRAINT referral_daily_refund_reservations_escrow_account_id_fkey FOREIGN KEY (escrow_account_id) REFERENCES member72_1c1acaaf36d7e39a.accounts(id);


--
-- Name: referral_daily_refund_reservations referral_daily_refund_reservations_fee_reserved_account_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_refund_reservations
    ADD CONSTRAINT referral_daily_refund_reservations_fee_reserved_account_id_fkey FOREIGN KEY (fee_reserved_account_id) REFERENCES member72_1c1acaaf36d7e39a.accounts(id);


--
-- Name: referral_daily_refund_reservations referral_daily_refund_reservations_fees_account_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_refund_reservations
    ADD CONSTRAINT referral_daily_refund_reservations_fees_account_id_fkey FOREIGN KEY (fees_account_id) REFERENCES member72_1c1acaaf36d7e39a.accounts(id);


--
-- Name: referral_daily_refund_reservations referral_daily_refund_reservations_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_refund_reservations
    ADD CONSTRAINT referral_daily_refund_reservations_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.referral_daily_liabilities(order_id);


--
-- Name: referral_daily_refund_reservations referral_daily_refund_reservations_pending_account_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_refund_reservations
    ADD CONSTRAINT referral_daily_refund_reservations_pending_account_id_fkey FOREIGN KEY (pending_account_id) REFERENCES member72_1c1acaaf36d7e39a.accounts(id);


--
-- Name: referral_daily_refund_reservations referral_daily_refund_reservations_refund_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_refund_reservations
    ADD CONSTRAINT referral_daily_refund_reservations_refund_id_fkey FOREIGN KEY (refund_id) REFERENCES member72_1c1acaaf36d7e39a.refunds(id);


--
-- Name: referral_daily_refund_reservations referral_daily_refund_reservations_reserve_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_refund_reservations
    ADD CONSTRAINT referral_daily_refund_reservations_reserve_journal_id_fkey FOREIGN KEY (reserve_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: referral_daily_terms referral_daily_terms_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_terms
    ADD CONSTRAINT referral_daily_terms_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: referral_daily_terms referral_daily_terms_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_terms
    ADD CONSTRAINT referral_daily_terms_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.referral_order_terms(order_id);


--
-- Name: referral_daily_terms referral_daily_terms_pending_account_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_terms
    ADD CONSTRAINT referral_daily_terms_pending_account_id_fkey FOREIGN KEY (pending_account_id) REFERENCES member72_1c1acaaf36d7e39a.accounts(id);


--
-- Name: referral_daily_terms referral_daily_terms_promoter_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_daily_terms
    ADD CONSTRAINT referral_daily_terms_promoter_id_fkey FOREIGN KEY (promoter_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: referral_order_terms referral_order_terms_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_order_terms
    ADD CONSTRAINT referral_order_terms_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: referral_order_terms referral_order_terms_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_order_terms
    ADD CONSTRAINT referral_order_terms_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: referral_order_terms referral_order_terms_promoter_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_order_terms
    ADD CONSTRAINT referral_order_terms_promoter_id_fkey FOREIGN KEY (promoter_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: referral_order_terms referral_order_terms_relation_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_order_terms
    ADD CONSTRAINT referral_order_terms_relation_id_fkey FOREIGN KEY (relation_id) REFERENCES member72_1c1acaaf36d7e39a.referral_relations(id);


--
-- Name: referral_policy_audits referral_policy_audits_policy_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_policy_audits
    ADD CONSTRAINT referral_policy_audits_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES member72_1c1acaaf36d7e39a.referral_policies(id);


--
-- Name: referral_policy_heads referral_policy_heads_policy_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_policy_heads
    ADD CONSTRAINT referral_policy_heads_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES member72_1c1acaaf36d7e39a.referral_policies(id);


--
-- Name: referral_profit_cost_events referral_profit_cost_events_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_profit_cost_events
    ADD CONSTRAINT referral_profit_cost_events_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.referral_profit_costs(order_id);


--
-- Name: referral_profit_costs referral_profit_costs_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_profit_costs
    ADD CONSTRAINT referral_profit_costs_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: referral_profit_costs referral_profit_costs_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_profit_costs
    ADD CONSTRAINT referral_profit_costs_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.referral_order_terms(order_id);


--
-- Name: referral_refund_clawbacks referral_refund_clawbacks_contribution_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_refund_clawbacks
    ADD CONSTRAINT referral_refund_clawbacks_contribution_journal_id_fkey FOREIGN KEY (contribution_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: referral_refund_clawbacks referral_refund_clawbacks_escrow_account_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_refund_clawbacks
    ADD CONSTRAINT referral_refund_clawbacks_escrow_account_id_fkey FOREIGN KEY (escrow_account_id) REFERENCES member72_1c1acaaf36d7e39a.accounts(id);


--
-- Name: referral_refund_clawbacks referral_refund_clawbacks_fee_reserved_account_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_refund_clawbacks
    ADD CONSTRAINT referral_refund_clawbacks_fee_reserved_account_id_fkey FOREIGN KEY (fee_reserved_account_id) REFERENCES member72_1c1acaaf36d7e39a.accounts(id);


--
-- Name: referral_refund_clawbacks referral_refund_clawbacks_fees_account_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_refund_clawbacks
    ADD CONSTRAINT referral_refund_clawbacks_fees_account_id_fkey FOREIGN KEY (fees_account_id) REFERENCES member72_1c1acaaf36d7e39a.accounts(id);


--
-- Name: referral_refund_clawbacks referral_refund_clawbacks_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_refund_clawbacks
    ADD CONSTRAINT referral_refund_clawbacks_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: referral_refund_clawbacks referral_refund_clawbacks_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_refund_clawbacks
    ADD CONSTRAINT referral_refund_clawbacks_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: referral_refund_clawbacks referral_refund_clawbacks_promoter_account_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_refund_clawbacks
    ADD CONSTRAINT referral_refund_clawbacks_promoter_account_id_fkey FOREIGN KEY (promoter_account_id) REFERENCES member72_1c1acaaf36d7e39a.accounts(id);


--
-- Name: referral_refund_clawbacks referral_refund_clawbacks_promoter_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_refund_clawbacks
    ADD CONSTRAINT referral_refund_clawbacks_promoter_id_fkey FOREIGN KEY (promoter_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: referral_refund_clawbacks referral_refund_clawbacks_refund_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_refund_clawbacks
    ADD CONSTRAINT referral_refund_clawbacks_refund_id_fkey FOREIGN KEY (refund_id) REFERENCES member72_1c1acaaf36d7e39a.refunds(id);


--
-- Name: referral_refund_clawbacks referral_refund_clawbacks_release_remainder_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_refund_clawbacks
    ADD CONSTRAINT referral_refund_clawbacks_release_remainder_journal_id_fkey FOREIGN KEY (release_remainder_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: referral_refund_clawbacks referral_refund_clawbacks_reserve_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_refund_clawbacks
    ADD CONSTRAINT referral_refund_clawbacks_reserve_journal_id_fkey FOREIGN KEY (reserve_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: referral_refund_clawbacks referral_refund_clawbacks_restore_contribution_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_refund_clawbacks
    ADD CONSTRAINT referral_refund_clawbacks_restore_contribution_journal_id_fkey FOREIGN KEY (restore_contribution_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: referral_refund_clawbacks referral_refund_clawbacks_restore_reward_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_refund_clawbacks
    ADD CONSTRAINT referral_refund_clawbacks_restore_reward_journal_id_fkey FOREIGN KEY (restore_reward_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: referral_refund_clawbacks referral_refund_clawbacks_reward_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_refund_clawbacks
    ADD CONSTRAINT referral_refund_clawbacks_reward_id_fkey FOREIGN KEY (reward_id) REFERENCES member72_1c1acaaf36d7e39a.referral_rewards(id);


--
-- Name: referral_relations referral_relations_challenge_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_relations
    ADD CONSTRAINT referral_relations_challenge_id_fkey FOREIGN KEY (challenge_id) REFERENCES member72_1c1acaaf36d7e39a.enrollment_challenges(id);


--
-- Name: referral_relations referral_relations_invited_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_relations
    ADD CONSTRAINT referral_relations_invited_id_fkey FOREIGN KEY (invited_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: referral_relations referral_relations_promoter_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_relations
    ADD CONSTRAINT referral_relations_promoter_id_fkey FOREIGN KEY (promoter_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: referral_relations referral_relations_token_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_relations
    ADD CONSTRAINT referral_relations_token_id_fkey FOREIGN KEY (token_id) REFERENCES member72_1c1acaaf36d7e39a.referral_tokens(id);


--
-- Name: referral_reward_audits referral_reward_audits_reward_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_reward_audits
    ADD CONSTRAINT referral_reward_audits_reward_id_fkey FOREIGN KEY (reward_id) REFERENCES member72_1c1acaaf36d7e39a.referral_rewards(id);


--
-- Name: referral_rewards referral_rewards_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_rewards
    ADD CONSTRAINT referral_rewards_journal_id_fkey FOREIGN KEY (journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: referral_rewards referral_rewards_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_rewards
    ADD CONSTRAINT referral_rewards_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: referral_rewards referral_rewards_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_rewards
    ADD CONSTRAINT referral_rewards_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.referral_order_terms(order_id);


--
-- Name: referral_rewards referral_rewards_promoter_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_rewards
    ADD CONSTRAINT referral_rewards_promoter_id_fkey FOREIGN KEY (promoter_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: referral_token_current referral_token_current_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_token_current
    ADD CONSTRAINT referral_token_current_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: referral_token_current referral_token_current_token_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_token_current
    ADD CONSTRAINT referral_token_current_token_id_fkey FOREIGN KEY (token_id) REFERENCES member72_1c1acaaf36d7e39a.referral_tokens(id);


--
-- Name: referral_tokens referral_tokens_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.referral_tokens
    ADD CONSTRAINT referral_tokens_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: refund_funding_resolutions refund_funding_resolutions_available_return_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.refund_funding_resolutions
    ADD CONSTRAINT refund_funding_resolutions_available_return_journal_id_fkey FOREIGN KEY (available_return_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: refund_funding_resolutions refund_funding_resolutions_consume_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.refund_funding_resolutions
    ADD CONSTRAINT refund_funding_resolutions_consume_journal_id_fkey FOREIGN KEY (consume_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: refund_funding_resolutions refund_funding_resolutions_held_return_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.refund_funding_resolutions
    ADD CONSTRAINT refund_funding_resolutions_held_return_journal_id_fkey FOREIGN KEY (held_return_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: refund_funding_resolutions refund_funding_resolutions_refund_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.refund_funding_resolutions
    ADD CONSTRAINT refund_funding_resolutions_refund_id_fkey FOREIGN KEY (refund_id) REFERENCES member72_1c1acaaf36d7e39a.refund_fundings(refund_id);


--
-- Name: refund_fundings refund_fundings_available_reserve_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.refund_fundings
    ADD CONSTRAINT refund_fundings_available_reserve_journal_id_fkey FOREIGN KEY (available_reserve_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: refund_fundings refund_fundings_hold_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.refund_fundings
    ADD CONSTRAINT refund_fundings_hold_id_fkey FOREIGN KEY (hold_id) REFERENCES member72_1c1acaaf36d7e39a.order_income_hold_fundings(hold_id);


--
-- Name: refund_fundings refund_fundings_hold_reserve_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.refund_fundings
    ADD CONSTRAINT refund_fundings_hold_reserve_journal_id_fkey FOREIGN KEY (hold_reserve_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: refund_fundings refund_fundings_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.refund_fundings
    ADD CONSTRAINT refund_fundings_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: refund_fundings refund_fundings_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.refund_fundings
    ADD CONSTRAINT refund_fundings_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: refund_fundings refund_fundings_refund_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.refund_fundings
    ADD CONSTRAINT refund_fundings_refund_id_fkey FOREIGN KEY (refund_id) REFERENCES member72_1c1acaaf36d7e39a.refunds(id);


--
-- Name: refund_fundings refund_fundings_reserve_account_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.refund_fundings
    ADD CONSTRAINT refund_fundings_reserve_account_id_fkey FOREIGN KEY (reserve_account_id) REFERENCES member72_1c1acaaf36d7e39a.accounts(id);


--
-- Name: refunds refunds_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.refunds
    ADD CONSTRAINT refunds_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: refunds refunds_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.refunds
    ADD CONSTRAINT refunds_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: scan_cancellation_claims scan_cancellation_claims_attempt_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.scan_cancellation_claims
    ADD CONSTRAINT scan_cancellation_claims_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES member72_1c1acaaf36d7e39a.scan_recovery_origins(attempt_id);


--
-- Name: scan_cancellation_claims scan_cancellation_claims_job_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.scan_cancellation_claims
    ADD CONSTRAINT scan_cancellation_claims_job_id_fkey FOREIGN KEY (job_id) REFERENCES member72_1c1acaaf36d7e39a.jobs(id);


--
-- Name: scan_cancellation_results scan_cancellation_results_attempt_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.scan_cancellation_results
    ADD CONSTRAINT scan_cancellation_results_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES member72_1c1acaaf36d7e39a.scan_cancellation_claims(attempt_id);


--
-- Name: scan_recovery_eligibility scan_recovery_eligibility_attempt_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.scan_recovery_eligibility
    ADD CONSTRAINT scan_recovery_eligibility_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES member72_1c1acaaf36d7e39a.scan_recovery_origins(attempt_id);


--
-- Name: scan_recovery_origins scan_recovery_origins_attempt_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.scan_recovery_origins
    ADD CONSTRAINT scan_recovery_origins_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES member72_1c1acaaf36d7e39a.provider_attempts(id);


--
-- Name: scan_recovery_origins scan_recovery_origins_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.scan_recovery_origins
    ADD CONSTRAINT scan_recovery_origins_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: scan_recovery_origins scan_recovery_origins_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.scan_recovery_origins
    ADD CONSTRAINT scan_recovery_origins_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- Name: scan_recovery_query_events scan_recovery_query_events_attempt_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.scan_recovery_query_events
    ADD CONSTRAINT scan_recovery_query_events_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES member72_1c1acaaf36d7e39a.scan_recovery_eligibility(attempt_id);


--
-- Name: scan_recovery_query_events scan_recovery_query_events_job_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.scan_recovery_query_events
    ADD CONSTRAINT scan_recovery_query_events_job_id_fkey FOREIGN KEY (job_id) REFERENCES member72_1c1acaaf36d7e39a.jobs(id);


--
-- Name: scan_recovery_query_events scan_recovery_query_events_query_claim_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.scan_recovery_query_events
    ADD CONSTRAINT scan_recovery_query_events_query_claim_id_fkey FOREIGN KEY (query_claim_id) REFERENCES member72_1c1acaaf36d7e39a.scan_recovery_query_events(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: scan_recovery_query_heads scan_recovery_query_heads_attempt_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.scan_recovery_query_heads
    ADD CONSTRAINT scan_recovery_query_heads_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES member72_1c1acaaf36d7e39a.scan_recovery_eligibility(attempt_id);


--
-- Name: scan_recovery_query_heads scan_recovery_query_heads_event_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.scan_recovery_query_heads
    ADD CONSTRAINT scan_recovery_query_heads_event_id_fkey FOREIGN KEY (event_id) REFERENCES member72_1c1acaaf36d7e39a.scan_recovery_query_events(id);


--
-- Name: settlement_auto_authorizations settlement_auto_authorizations_expected_authorization_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_authorizations
    ADD CONSTRAINT settlement_auto_authorizations_expected_authorization_id_fkey FOREIGN KEY (expected_authorization_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_auto_authorizations(id);


--
-- Name: settlement_auto_authorizations settlement_auto_authorizations_generation_authorization_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_authorizations
    ADD CONSTRAINT settlement_auto_authorizations_generation_authorization_id_fkey FOREIGN KEY (generation_authorization_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plan_authorizations(id);


--
-- Name: settlement_auto_authorizations settlement_auto_authorizations_plan_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_authorizations
    ADD CONSTRAINT settlement_auto_authorizations_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plans(id);


--
-- Name: settlement_auto_authorizations settlement_auto_authorizations_plan_id_plan_revision_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_authorizations
    ADD CONSTRAINT settlement_auto_authorizations_plan_id_plan_revision_fkey FOREIGN KEY (plan_id, plan_revision) REFERENCES member72_1c1acaaf36d7e39a.settlement_plan_versions(plan_id, revision);


--
-- Name: settlement_auto_claims settlement_auto_claims_authorization_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_claims
    ADD CONSTRAINT settlement_auto_claims_authorization_id_fkey FOREIGN KEY (authorization_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_auto_authorizations(id);


--
-- Name: settlement_auto_claims settlement_auto_claims_item_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_claims
    ADD CONSTRAINT settlement_auto_claims_item_id_fkey FOREIGN KEY (item_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plan_items(id);


--
-- Name: settlement_auto_claims settlement_auto_claims_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_claims
    ADD CONSTRAINT settlement_auto_claims_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: settlement_auto_claims settlement_auto_claims_plan_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_claims
    ADD CONSTRAINT settlement_auto_claims_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plans(id);


--
-- Name: settlement_auto_claims settlement_auto_claims_request_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_claims
    ADD CONSTRAINT settlement_auto_claims_request_id_fkey FOREIGN KEY (request_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_payouts(request_id);


--
-- Name: settlement_auto_claims settlement_auto_claims_run_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_claims
    ADD CONSTRAINT settlement_auto_claims_run_id_fkey FOREIGN KEY (run_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plan_runs(id);


--
-- Name: settlement_auto_claims settlement_auto_claims_transfer_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_claims
    ADD CONSTRAINT settlement_auto_claims_transfer_id_fkey FOREIGN KEY (transfer_id) REFERENCES member72_1c1acaaf36d7e39a.transfers(id);


--
-- Name: settlement_auto_heads settlement_auto_heads_authorization_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_heads
    ADD CONSTRAINT settlement_auto_heads_authorization_id_fkey FOREIGN KEY (authorization_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_auto_authorizations(id);


--
-- Name: settlement_auto_heads settlement_auto_heads_plan_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_heads
    ADD CONSTRAINT settlement_auto_heads_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plans(id);


--
-- Name: settlement_auto_revocations settlement_auto_revocations_authorization_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_auto_revocations
    ADD CONSTRAINT settlement_auto_revocations_authorization_id_fkey FOREIGN KEY (authorization_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_auto_authorizations(id);


--
-- Name: settlement_bank_payouts settlement_bank_payouts_request_id_transfer_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_bank_payouts
    ADD CONSTRAINT settlement_bank_payouts_request_id_transfer_id_fkey FOREIGN KEY (request_id, transfer_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_payouts(request_id, transfer_id);


--
-- Name: settlement_bank_payouts settlement_bank_payouts_transfer_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_bank_payouts
    ADD CONSTRAINT settlement_bank_payouts_transfer_id_fkey FOREIGN KEY (transfer_id) REFERENCES member72_1c1acaaf36d7e39a.bank_transfer_lifecycle(transfer_id);


--
-- Name: settlement_fundings settlement_fundings_account_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_fundings
    ADD CONSTRAINT settlement_fundings_account_id_fkey FOREIGN KEY (account_id) REFERENCES member72_1c1acaaf36d7e39a.accounts(id);


--
-- Name: settlement_fundings settlement_fundings_request_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_fundings
    ADD CONSTRAINT settlement_fundings_request_id_fkey FOREIGN KEY (request_id) REFERENCES member72_1c1acaaf36d7e39a.ledger_requests(id);


--
-- Name: settlement_fundings settlement_fundings_reserve_journal_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_fundings
    ADD CONSTRAINT settlement_fundings_reserve_journal_id_fkey FOREIGN KEY (reserve_journal_id) REFERENCES member72_1c1acaaf36d7e39a.journals(id);


--
-- Name: settlement_payout_cancellations settlement_payout_cancellations_request_id_transfer_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_payout_cancellations
    ADD CONSTRAINT settlement_payout_cancellations_request_id_transfer_id_fkey FOREIGN KEY (request_id, transfer_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_payouts(request_id, transfer_id);


--
-- Name: settlement_payout_events settlement_payout_events_request_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_payout_events
    ADD CONSTRAINT settlement_payout_events_request_id_fkey FOREIGN KEY (request_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_payouts(request_id);


--
-- Name: settlement_payouts settlement_payouts_auto_authorization_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_payouts
    ADD CONSTRAINT settlement_payouts_auto_authorization_id_fkey FOREIGN KEY (auto_authorization_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_auto_authorizations(id);


--
-- Name: settlement_payouts settlement_payouts_request_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_payouts
    ADD CONSTRAINT settlement_payouts_request_id_fkey FOREIGN KEY (request_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_recipients(request_id);


--
-- Name: settlement_payouts settlement_payouts_transfer_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_payouts
    ADD CONSTRAINT settlement_payouts_transfer_id_fkey FOREIGN KEY (transfer_id) REFERENCES member72_1c1acaaf36d7e39a.provider_transfer_attempts(transfer_id);


--
-- Name: settlement_plan_authorizations settlement_plan_authorizations_expected_authorization_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_authorizations
    ADD CONSTRAINT settlement_plan_authorizations_expected_authorization_id_fkey FOREIGN KEY (expected_authorization_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plan_authorizations(id);


--
-- Name: settlement_plan_authorizations settlement_plan_authorizations_plan_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_authorizations
    ADD CONSTRAINT settlement_plan_authorizations_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plans(id);


--
-- Name: settlement_plan_authorizations settlement_plan_authorizations_plan_id_plan_revision_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_authorizations
    ADD CONSTRAINT settlement_plan_authorizations_plan_id_plan_revision_fkey FOREIGN KEY (plan_id, plan_revision) REFERENCES member72_1c1acaaf36d7e39a.settlement_plan_versions(plan_id, revision);


--
-- Name: settlement_plan_budget_uses settlement_plan_budget_uses_authorization_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_budget_uses
    ADD CONSTRAINT settlement_plan_budget_uses_authorization_id_fkey FOREIGN KEY (authorization_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plan_authorizations(id);


--
-- Name: settlement_plan_budget_uses settlement_plan_budget_uses_item_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_budget_uses
    ADD CONSTRAINT settlement_plan_budget_uses_item_id_fkey FOREIGN KEY (item_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plan_items(id);


--
-- Name: settlement_plan_budget_uses settlement_plan_budget_uses_plan_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_budget_uses
    ADD CONSTRAINT settlement_plan_budget_uses_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plans(id);


--
-- Name: settlement_plan_items settlement_plan_items_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_items
    ADD CONSTRAINT settlement_plan_items_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: settlement_plan_items settlement_plan_items_recipient_config_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_items
    ADD CONSTRAINT settlement_plan_items_recipient_config_id_fkey FOREIGN KEY (recipient_config_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_recipient_configs(id);


--
-- Name: settlement_plan_items settlement_plan_items_request_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_items
    ADD CONSTRAINT settlement_plan_items_request_id_fkey FOREIGN KEY (request_id) REFERENCES member72_1c1acaaf36d7e39a.ledger_requests(id);


--
-- Name: settlement_plan_items settlement_plan_items_run_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_items
    ADD CONSTRAINT settlement_plan_items_run_id_fkey FOREIGN KEY (run_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plan_runs(id);


--
-- Name: settlement_plan_revocations settlement_plan_revocations_authorization_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_revocations
    ADD CONSTRAINT settlement_plan_revocations_authorization_id_fkey FOREIGN KEY (authorization_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plan_authorizations(id);


--
-- Name: settlement_plan_revocations settlement_plan_revocations_plan_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_revocations
    ADD CONSTRAINT settlement_plan_revocations_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plans(id);


--
-- Name: settlement_plan_runs settlement_plan_runs_authorization_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_runs
    ADD CONSTRAINT settlement_plan_runs_authorization_id_fkey FOREIGN KEY (authorization_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plan_authorizations(id);


--
-- Name: settlement_plan_runs settlement_plan_runs_plan_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_runs
    ADD CONSTRAINT settlement_plan_runs_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plans(id);


--
-- Name: settlement_plan_runs settlement_plan_runs_plan_id_plan_revision_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_runs
    ADD CONSTRAINT settlement_plan_runs_plan_id_plan_revision_fkey FOREIGN KEY (plan_id, plan_revision) REFERENCES member72_1c1acaaf36d7e39a.settlement_plan_versions(plan_id, revision);


--
-- Name: settlement_plan_versions settlement_plan_versions_plan_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plan_versions
    ADD CONSTRAINT settlement_plan_versions_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plans(id);


--
-- Name: settlement_plans settlement_plans_last_authorization_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_plans
    ADD CONSTRAINT settlement_plans_last_authorization_id_fkey FOREIGN KEY (last_authorization_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plan_authorizations(id);


--
-- Name: settlement_recipient_configs settlement_recipient_configs_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_recipient_configs
    ADD CONSTRAINT settlement_recipient_configs_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: settlement_recipient_current settlement_recipient_current_merchant_id_config_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_recipient_current
    ADD CONSTRAINT settlement_recipient_current_merchant_id_config_id_fkey FOREIGN KEY (merchant_id, config_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_recipient_configs(merchant_id, id);


--
-- Name: settlement_recipient_current settlement_recipient_current_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_recipient_current
    ADD CONSTRAINT settlement_recipient_current_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: settlement_recipients settlement_recipients_config_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_recipients
    ADD CONSTRAINT settlement_recipients_config_id_fkey FOREIGN KEY (config_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_recipient_configs(id);


--
-- Name: settlement_recipients settlement_recipients_request_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_recipients
    ADD CONSTRAINT settlement_recipients_request_id_fkey FOREIGN KEY (request_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_fundings(request_id);


--
-- Name: settlement_request_terms settlement_request_terms_request_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_request_terms
    ADD CONSTRAINT settlement_request_terms_request_id_fkey FOREIGN KEY (request_id) REFERENCES member72_1c1acaaf36d7e39a.ledger_requests(id);


--
-- Name: settlement_schedule_preference_heads settlement_schedule_preference_heads_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_schedule_preference_heads
    ADD CONSTRAINT settlement_schedule_preference_heads_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: settlement_schedule_preference_heads settlement_schedule_preference_heads_preference_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_schedule_preference_heads
    ADD CONSTRAINT settlement_schedule_preference_heads_preference_id_fkey FOREIGN KEY (preference_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_schedule_preferences(id);


--
-- Name: settlement_schedule_preferences settlement_schedule_preferences_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_schedule_preferences
    ADD CONSTRAINT settlement_schedule_preferences_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: settlement_schedule_preferences settlement_schedule_preferences_recipient_config_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_schedule_preferences
    ADD CONSTRAINT settlement_schedule_preferences_recipient_config_id_fkey FOREIGN KEY (recipient_config_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_recipient_configs(id);


--
-- Name: settlement_scheduled_intents settlement_scheduled_intents_item_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_scheduled_intents
    ADD CONSTRAINT settlement_scheduled_intents_item_id_fkey FOREIGN KEY (item_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plan_items(id);


--
-- Name: settlement_scheduled_intents settlement_scheduled_intents_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_scheduled_intents
    ADD CONSTRAINT settlement_scheduled_intents_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: settlement_scheduled_intents settlement_scheduled_intents_request_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_scheduled_intents
    ADD CONSTRAINT settlement_scheduled_intents_request_id_fkey FOREIGN KEY (request_id) REFERENCES member72_1c1acaaf36d7e39a.ledger_requests(id);


--
-- Name: settlement_threshold_intents settlement_threshold_intents_item_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_threshold_intents
    ADD CONSTRAINT settlement_threshold_intents_item_id_fkey FOREIGN KEY (item_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plan_items(id);


--
-- Name: settlement_threshold_intents settlement_threshold_intents_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_threshold_intents
    ADD CONSTRAINT settlement_threshold_intents_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: settlement_threshold_intents settlement_threshold_intents_request_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_threshold_intents
    ADD CONSTRAINT settlement_threshold_intents_request_id_fkey FOREIGN KEY (request_id) REFERENCES member72_1c1acaaf36d7e39a.ledger_requests(id);


--
-- Name: settlement_threshold_intents settlement_threshold_intents_run_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_threshold_intents
    ADD CONSTRAINT settlement_threshold_intents_run_id_fkey FOREIGN KEY (run_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plan_runs(id);


--
-- Name: settlement_threshold_selections settlement_threshold_selections_run_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.settlement_threshold_selections
    ADD CONSTRAINT settlement_threshold_selections_run_id_fkey FOREIGN KEY (run_id) REFERENCES member72_1c1acaaf36d7e39a.settlement_plan_runs(id);


--
-- Name: transfer_batch_events transfer_batch_events_batch_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfer_batch_events
    ADD CONSTRAINT transfer_batch_events_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES member72_1c1acaaf36d7e39a.transfer_batches(id);


--
-- Name: transfer_batch_events transfer_batch_events_batch_id_transfer_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfer_batch_events
    ADD CONSTRAINT transfer_batch_events_batch_id_transfer_id_fkey FOREIGN KEY (batch_id, transfer_id) REFERENCES member72_1c1acaaf36d7e39a.transfer_batch_items(batch_id, transfer_id);


--
-- Name: transfer_batch_events transfer_batch_events_transfer_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfer_batch_events
    ADD CONSTRAINT transfer_batch_events_transfer_id_fkey FOREIGN KEY (transfer_id) REFERENCES member72_1c1acaaf36d7e39a.transfer_batch_items(transfer_id);


--
-- Name: transfer_batch_execution_claims transfer_batch_execution_claims_execution_no_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfer_batch_execution_claims
    ADD CONSTRAINT transfer_batch_execution_claims_execution_no_fkey FOREIGN KEY (execution_no) REFERENCES member72_1c1acaaf36d7e39a.transfer_batch_executions(execution_no);


--
-- Name: transfer_batch_execution_claims transfer_batch_execution_claims_transfer_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfer_batch_execution_claims
    ADD CONSTRAINT transfer_batch_execution_claims_transfer_id_fkey FOREIGN KEY (transfer_id) REFERENCES member72_1c1acaaf36d7e39a.transfer_batch_items(transfer_id);


--
-- Name: transfer_batch_executions transfer_batch_executions_batch_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfer_batch_executions
    ADD CONSTRAINT transfer_batch_executions_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES member72_1c1acaaf36d7e39a.transfer_batches(id);


--
-- Name: transfer_batch_executions transfer_batch_executions_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfer_batch_executions
    ADD CONSTRAINT transfer_batch_executions_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: transfer_batch_items transfer_batch_items_batch_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfer_batch_items
    ADD CONSTRAINT transfer_batch_items_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES member72_1c1acaaf36d7e39a.transfer_batches(id);


--
-- Name: transfer_batch_items transfer_batch_items_transfer_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfer_batch_items
    ADD CONSTRAINT transfer_batch_items_transfer_id_fkey FOREIGN KEY (transfer_id) REFERENCES member72_1c1acaaf36d7e39a.provider_transfer_attempts(transfer_id);


--
-- Name: transfer_batches transfer_batches_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfer_batches
    ADD CONSTRAINT transfer_batches_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: transfer_unsent_cancellations transfer_unsent_cancellations_transfer_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfer_unsent_cancellations
    ADD CONSTRAINT transfer_unsent_cancellations_transfer_id_fkey FOREIGN KEY (transfer_id) REFERENCES member72_1c1acaaf36d7e39a.transfer_batch_items(transfer_id);


--
-- Name: transfers transfers_merchant_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.transfers
    ADD CONSTRAINT transfers_merchant_id_fkey FOREIGN KEY (merchant_id) REFERENCES member72_1c1acaaf36d7e39a.merchants(id);


--
-- Name: verified_payment_receipts verified_payment_receipts_order_id_fkey; Type: FK CONSTRAINT; Schema: member72_1c1acaaf36d7e39a; Owner: -
--

ALTER TABLE ONLY member72_1c1acaaf36d7e39a.verified_payment_receipts
    ADD CONSTRAINT verified_payment_receipts_order_id_fkey FOREIGN KEY (order_id) REFERENCES member72_1c1acaaf36d7e39a.orders(id);


--
-- PostgreSQL database dump complete
--

\unrestrict shSK4XrrvRXGSjF4a1VPno5Cui4VjXOEI5sKTHccS4By3eQFLf8TnBghQ92BvGG

