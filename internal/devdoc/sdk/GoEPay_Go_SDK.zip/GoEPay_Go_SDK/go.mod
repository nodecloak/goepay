module example.com/goepay-sdk

go 1.22
